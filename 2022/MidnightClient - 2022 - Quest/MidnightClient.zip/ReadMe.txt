//If You Claim You Cracked This Do The Following And Kill Yourself.
//Updates Will Be Once A Week Or When I Can.
//I'm Trying My Best So Please Dont Beg.

Midnight Devs
_Sever/Exploit
RABBIX
sachiel.J 

Helpers
Ikari No Kami
PC Prinipal
Umbra - Fade Away
Cyril XD
