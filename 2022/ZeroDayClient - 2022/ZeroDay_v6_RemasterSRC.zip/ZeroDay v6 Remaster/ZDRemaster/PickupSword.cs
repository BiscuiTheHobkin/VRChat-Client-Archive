﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;
using ZDBase;

// Token: 0x02000010 RID: 16
internal class PickupSword
{
	// Token: 0x06000039 RID: 57 RVA: 0x00004478 File Offset: 0x00002678
	public static IEnumerator runaftergrav(object rigbod)
	{
		for (;;)
		{
			try
			{
				((Rigidbody)rigbod).AddForce(new Vector3(0f, 0.14f, 0f), 1);
			}
			catch
			{
				Logs.LogError("THE GAME IS RASIST!", true);
			}
			yield return null;
		}
		yield break;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00004487 File Offset: 0x00002687
	public static IEnumerator SwastikaMaker()
	{
		for (;;)
		{
			yield return new WaitForSeconds(0.0001f);
			PickupSword.sovastica();
		}
		yield break;
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00004490 File Offset: 0x00002690
	public static void sovastica()
	{
		Vector3 vector = PickupSword.vec3poz;
		VRC_Pickup[] array = PickupSword.array1;
		try
		{
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = Networking.GetOwner(array[i].gameObject) != Networking.LocalPlayer;
				if (flag)
				{
					Networking.SetOwner(Networking.LocalPlayer, array[i].gameObject);
				}
			}
			array[0].transform.position = new Vector3(vector.x, vector.y, vector.z);
			array[1].transform.position = new Vector3(vector.x, vector.y + 0.5f, vector.z);
			array[2].transform.position = new Vector3(vector.x, vector.y + 1f, vector.z);
			array[3].transform.position = new Vector3(vector.x, vector.y + 1.5f, vector.z);
			array[4].transform.position = new Vector3(vector.x, vector.y + 2f, vector.z);
			array[17].transform.position = new Vector3(vector.x, vector.y + 0.5f, vector.z);
			array[18].transform.position = new Vector3(vector.x, vector.y + 1f, vector.z);
			array[19].transform.position = new Vector3(vector.x, vector.y + 1.5f, vector.z);
			array[20].transform.position = new Vector3(vector.x, vector.y, vector.z);
			array[21].transform.position = new Vector3(vector.x, vector.y + 2.5f, vector.z);
			array[22].transform.position = new Vector3(vector.x, vector.y + 3f, vector.z);
			array[5].transform.position = new Vector3(vector.x + 0.5f, vector.y + 1.5f, vector.z);
			array[6].transform.position = new Vector3(vector.x + 1f, vector.y + 1.5f, vector.z);
			array[7].transform.position = new Vector3(vector.x - 0.5f, vector.y + 1.5f, vector.z);
			array[8].transform.position = new Vector3(vector.x - 1f, vector.y + 1.5f, vector.z);
			array[27].transform.position = new Vector3(vector.x + 1.5f, vector.y + 1.5f, vector.z);
			array[28].transform.position = new Vector3(vector.x - 1.5f, vector.y + 1.5f, vector.z);
			array[9].transform.position = new Vector3(vector.x + 1.5f, vector.y + 1.7f, vector.z);
			array[10].transform.position = new Vector3(vector.x + 1.5f, vector.y + 1.9f, vector.z);
			array[23].transform.position = new Vector3(vector.x + 1.5f, vector.y + 2.1f, vector.z);
			array[11].transform.position = new Vector3(vector.x - 1.5f, vector.y + 1.3f, vector.z);
			array[12].transform.position = new Vector3(vector.x - 1.5f, vector.y + 1.1f, vector.z);
			array[24].transform.position = new Vector3(vector.x - 1.5f, vector.y + 1.3f, vector.z);
			array[13].transform.position = new Vector3(vector.x - 0.2f, vector.y + 3f, vector.z);
			array[14].transform.position = new Vector3(vector.x - 0.4f, vector.y + 3f, vector.z);
			array[25].transform.position = new Vector3(vector.x - 0.6f, vector.y + 3f, vector.z);
			array[15].transform.position = new Vector3(vector.x + 0.2f, vector.y, vector.z);
			array[16].transform.position = new Vector3(vector.x + 0.4f, vector.y, vector.z);
			array[26].transform.position = new Vector3(vector.x + 0.6f, vector.y, vector.z);
		}
		catch
		{
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x00004A58 File Offset: 0x00002C58
	public static void CalcItems()
	{
		PickupSword.pickupsBeforeFilter = Resources.FindObjectsOfTypeAll<VRC_Pickup>();
		PickupSword.pickups = new List<Transform>();
		VRC_Pickup[] array = PickupSword.pickupsBeforeFilter;
		foreach (VRC_Pickup vrc_Pickup in array)
		{
			PickupSword.pickups.Add(vrc_Pickup.transform);
			Logs.LogSuccess("Added [" + vrc_Pickup.name + "]", false);
		}
		PickupSword.spread = PickupSword.spreadCheck / (float)PickupSword.pickups.Count;
	}

	// Token: 0x04000019 RID: 25
	private static VRC_Pickup[] pickupsBeforeFilter = null;

	// Token: 0x0400001A RID: 26
	public static List<Transform> pickups = new List<Transform>();

	// Token: 0x0400001B RID: 27
	public static bool shouldRun = false;

	// Token: 0x0400001C RID: 28
	public static float spreadCheck = 3f;

	// Token: 0x0400001D RID: 29
	public static float spread = 0f;

	// Token: 0x0400001E RID: 30
	private static Quaternion defaultStateRotation = new Quaternion(0f, 0f, 0f, 0f);

	// Token: 0x0400001F RID: 31
	public static Transform rightHandBone = null;

	// Token: 0x04000020 RID: 32
	public static List<GameObject> gameobjectsForKen = new List<GameObject>();

	// Token: 0x04000021 RID: 33
	public static List<bool> boolsForKen = new List<bool>();

	// Token: 0x04000022 RID: 34
	public static bool KnifeSword;

	// Token: 0x04000023 RID: 35
	public static bool Calc;

	// Token: 0x04000024 RID: 36
	public static Vector3 vec3poz;

	// Token: 0x04000025 RID: 37
	public static VRC_Pickup[] array1;

	// Token: 0x04000026 RID: 38
	public static Transform placement;

	// Token: 0x04000027 RID: 39
	public static List<VRC_Pickup> AllPickups = new List<VRC_Pickup>();

	// Token: 0x04000028 RID: 40
	public static List<VRCPickup> AllUdonPickups = new List<VRCPickup>();

	// Token: 0x04000029 RID: 41
	public static List<VRC_Trigger> AllTriggers = new List<VRC_Trigger>();

	// Token: 0x0400002A RID: 42
	public static List<VRC_ObjectSync> AllSyncPickups = new List<VRC_ObjectSync>();
}
