﻿using System;
using UnityEngine;
using VRC.SDKBase;
using ZDBase.Modules;

// Token: 0x02000013 RID: 19
internal class QMFreeze
{
	// Token: 0x06000046 RID: 70 RVA: 0x00004F50 File Offset: 0x00003150
	public static void Apply()
	{
		bool frozen = QMFreeze.Frozen;
		if (frozen)
		{
			QMFreeze.Unfreeze();
		}
	}

	// Token: 0x06000047 RID: 71 RVA: 0x00004F70 File Offset: 0x00003170
	public static void OnUI()
	{
		EnableDisableListener enableDisableListener = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Worlds/Background").AddComponent<EnableDisableListener>();
		enableDisableListener.OnEnabled += delegate()
		{
			QMFreeze.Freeze();
		};
		enableDisableListener.OnDisabled += delegate()
		{
			QMFreeze.Unfreeze();
		};
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00004FDC File Offset: 0x000031DC
	public static void Freeze()
	{
		QMFreeze._originalGravity = Physics.gravity;
		QMFreeze._originalVelocity = Networking.LocalPlayer.GetVelocity();
		bool flag = !(QMFreeze._originalVelocity == Vector3.zero);
		if (flag)
		{
			Physics.gravity = Vector3.zero;
			Networking.LocalPlayer.SetVelocity(Vector3.zero);
			QMFreeze.Frozen = true;
		}
	}

	// Token: 0x06000049 RID: 73 RVA: 0x0000503C File Offset: 0x0000323C
	public static void Unfreeze()
	{
		bool frozen = QMFreeze.Frozen;
		if (frozen)
		{
			Physics.gravity = QMFreeze._originalGravity;
			QMFreeze.Frozen = false;
		}
	}

	// Token: 0x04000030 RID: 48
	public static bool Frozen;

	// Token: 0x04000031 RID: 49
	private static Vector3 _originalGravity;

	// Token: 0x04000032 RID: 50
	private static Vector3 _originalVelocity;
}
