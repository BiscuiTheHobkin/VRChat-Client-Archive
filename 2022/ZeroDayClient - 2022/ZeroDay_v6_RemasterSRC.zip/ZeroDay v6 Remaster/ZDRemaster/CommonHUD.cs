﻿using System;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using ZDBase.Utils.Wrappers;

// Token: 0x02000015 RID: 21
public static class CommonHUD
{
	// Token: 0x0600005A RID: 90 RVA: 0x00005618 File Offset: 0x00003818
	public static Color LerpFramerateColor(this PlayerNet net)
	{
		bool flag = net.GetFramerate() == -1f;
		Color result;
		if (flag)
		{
			result = Color.grey;
		}
		else
		{
			result = Color.Lerp(Color.red, Color.green, net.GetFramerate() / 100f);
		}
		return result;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00005660 File Offset: 0x00003860
	public static float GetFramerate(this PlayerNet net)
	{
		byte field_Private_Byte_ = net.field_Private_Byte_0;
		bool flag = (float)net.field_Private_Byte_0 == 0f;
		float result;
		if (flag)
		{
			result = -1f;
		}
		else
		{
			result = Mathf.Floor(1000f / (float)net.field_Private_Byte_0);
		}
		return result;
	}

	// Token: 0x0600005C RID: 92 RVA: 0x000056A8 File Offset: 0x000038A8
	public static string RenderPlayerList()
	{
		string text = "";
		bool flag = RoomManager.field_Internal_Static_ApiWorld_0 != null;
		if (flag)
		{
			int num = 0;
			bool flag2 = PlayerManager.field_Private_Static_PlayerManager_0 != null && PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0 != null;
			if (flag2)
			{
				try
				{
					List<Player>.Enumerator enumerator = PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0.GetEnumerator();
					while (enumerator.MoveNext())
					{
						Player current = enumerator.current;
						bool flag3 = current != null && current.field_Private_VRCPlayerApi_0 != null && num != 22;
						if (flag3)
						{
							text = string.Concat(new string[]
							{
								text,
								current.field_Private_VRCPlayerApi_0.isMaster ? "[MASTER] " : "     ",
								"<color=#",
								ColorConversion.ColorToHex(VRCPlayer.Method_Public_Static_Color_APIUser_0(current.field_Private_APIUser_0), false),
								">",
								current.field_Private_APIUser_0.DisplayName(),
								"</color> - ",
								current._vrcplayer.Method_Public_get_Int16_0().ToString(),
								" ms - <color=",
								ColorConversion.ColorToHex(current.Method_Internal_get_PlayerNet_0().LerpFramerateColor(), true),
								">",
								(current.Method_Internal_get_PlayerNet_0().GetFramerate() != -1f) ? (current.Method_Internal_get_PlayerNet_0().GetFramerate().ToString() ?? "") : "N/A",
								"</color> fps\n"
							});
							num++;
						}
					}
					return text;
				}
				catch (Exception)
				{
					new Exception();
					return text;
				}
			}
		}
		return text;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00005878 File Offset: 0x00003A78
	public static string RenderWorldInfo()
	{
		string str = "";
		bool flag = RoomManager.field_Internal_Static_ApiWorld_0 != null && VRCPlayer.field_Internal_Static_VRCPlayer_0 != null;
		if (flag)
		{
			str = str + "<b><color=red>X: " + (Mathf.Floor(VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<Player>().transform.position.x * 10f) / 10f).ToString() + "</color></b>  ";
			str = str + "<b><color=lime>Y: " + (Mathf.Floor(VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<Player>().transform.position.y * 10f) / 10f).ToString() + "</color></b>  ";
			str = str + "<b><color=cyan>Z: " + (Mathf.Floor(VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<Player>().transform.position.z * 10f) / 10f).ToString() + "</color></b>  ";
		}
		return str + "\n\n";
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00005994 File Offset: 0x00003B94
	public static GameObject[] InitializeHUD(Transform parent)
	{
		GameObject gameObject = new GameObject("Background");
		gameObject.AddComponent<CanvasRenderer>();
		gameObject.AddComponent<RawImage>();
		gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(256f, 768f);
		gameObject.GetComponent<RectTransform>().position = new Vector2((float)(130 - Screen.width / 2), (float)(Screen.height / 6 - 64));
		gameObject.transform.SetParent(parent, false);
		gameObject.GetComponent<Image>().sprite = null;
		GameObject gameObject2 = new GameObject("Text");
		gameObject2.AddComponent<CanvasRenderer>();
		gameObject2.transform.SetParent(gameObject.transform, false);
		Text text = gameObject2.AddComponent<Text>();
		text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
		text.fontSize = 15;
		text.text = "            emmVRClient  fps: 90";
		gameObject2.GetComponent<RectTransform>().sizeDelta = new Vector2(250f, 768f);
		return new GameObject[]
		{
			gameObject,
			gameObject2
		};
	}
}
