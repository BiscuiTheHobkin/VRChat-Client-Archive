﻿using System;
using System.Reflection;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnityEngine;

// Token: 0x0200000E RID: 14
internal static class Offsets
{
	// Token: 0x06000030 RID: 48 RVA: 0x00004090 File Offset: 0x00002290
	public static IntPtr GetICall(string name)
	{
		return IL2CPP.il2cpp_resolve_icall(name);
	}

	// Token: 0x06000031 RID: 49 RVA: 0x000040A8 File Offset: 0x000022A8
	public static uint GetFieldOffset<T>(string fieldName)
	{
		IntPtr nativeClassPtr = Il2CppClassPointerStore<T>.NativeClassPtr;
		bool flag = nativeClassPtr == IntPtr.Zero;
		uint result;
		if (flag)
		{
			result = 0U;
		}
		else
		{
			IntPtr intPtr = IL2CPP.il2cpp_class_get_field_from_name(nativeClassPtr, fieldName);
			bool flag2 = intPtr == IntPtr.Zero;
			if (flag2)
			{
				FieldInfo field = typeof(T).GetField("NativeFieldInfoPtr_" + fieldName, BindingFlags.Static | BindingFlags.NonPublic);
				bool flag3 = field == null;
				if (flag3)
				{
					return 0U;
				}
				intPtr = (IntPtr)field.GetValue(null);
				bool flag4 = intPtr == IntPtr.Zero;
				if (flag4)
				{
					return 0U;
				}
			}
			result = IL2CPP.il2cpp_field_get_offset(intPtr);
		}
		return result;
	}

	// Token: 0x06000032 RID: 50 RVA: 0x0000414C File Offset: 0x0000234C
	private static IntPtr GetProcAddressSafe(IntPtr module, string name)
	{
		bool flag = module == IntPtr.Zero;
		IntPtr result;
		if (flag)
		{
			result = IntPtr.Zero;
		}
		else
		{
			result = SolverApi.GetProcAddress(module, name);
		}
		return result;
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00004180 File Offset: 0x00002380
	public static void SetOffsets()
	{
		IntPtr module = SolverApi.LoadLibraryA("GameAssembly.dll");
		Offsets.ICallOffsets callOffsets = new Offsets.ICallOffsets
		{
			get_transform_component = Offsets.GetICall("UnityEngine.Component::get_transform"),
			get_transform_ltw_matrix = Offsets.GetICall("UnityEngine.Transform::get_localToWorldMatrix_Injected"),
			get_component_enabled = Offsets.GetICall("UnityEngine.Behaviour::get_enabled"),
			get_transform_child_count = Offsets.GetICall("UnityEngine.Transform::get_childCount"),
			set_transform_position_and_rotation = Offsets.GetICall("UnityEngine.Transform::SetPositionAndRotation_Injected"),
			gchandle_create = Offsets.GetProcAddressSafe(module, "il2cpp_gchandle_new"),
			gchandle_drop = Offsets.GetProcAddressSafe(module, "il2cpp_gchandle_free"),
			transform_get_local_rotation = Offsets.GetICall("UnityEngine.Transform::get_localRotation_Injected")
		};
		Offsets.ObjectOffsets objectOffsets = new Offsets.ObjectOffsets
		{
			cached_ptr = Offsets.GetFieldOffset<Object>("m_CachedPtr")
		};
		Offsets.ColliderComponentOffsets colliderComponentOffsets = new Offsets.ColliderComponentOffsets
		{
			collider_radius = Offsets.GetFieldOffset<DynamicBoneCollider>("m_Radius"),
			collider_center = Offsets.GetFieldOffset<DynamicBoneCollider>("m_Center"),
			collider_bound = Offsets.GetFieldOffset<DynamicBoneCollider>("m_Bound"),
			collider_direction = Offsets.GetFieldOffset<DynamicBoneCollider>("m_Direction"),
			collider_height = Offsets.GetFieldOffset<DynamicBoneCollider>("m_Height")
		};
		Offsets.ListClassOffsets listClassOffsets = new Offsets.ListClassOffsets
		{
			size = Offsets.GetFieldOffset<List<Object>>("_size"),
			store = Offsets.GetFieldOffset<List<Object>>("_items"),
			array_store = (uint)(IntPtr.Size * 4)
		};
		Offsets.BoneComponentOffsets boneComponentOffsets = new Offsets.BoneComponentOffsets
		{
			collider_list = Offsets.GetFieldOffset<DynamicBone>("m_Colliders"),
			particle_list = Offsets.GetFieldOffset<DynamicBone>("field_Private_List_1_ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique_0"),
			force = Offsets.GetFieldOffset<DynamicBone>("m_Force"),
			gravity = Offsets.GetFieldOffset<DynamicBone>("m_Gravity"),
			local_gravity = Offsets.GetFieldOffset<DynamicBone>("field_Private_Vector3_0"),
			freeze_axis = Offsets.GetFieldOffset<DynamicBone>("m_FreezeAxis"),
			update_rate = Offsets.GetFieldOffset<DynamicBone>("m_UpdateRate"),
			root = Offsets.GetFieldOffset<DynamicBone>("m_Root")
		};
		Offsets.ParticleClassOffsets particleClassOffsets = new Offsets.ParticleClassOffsets
		{
			transform = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Transform_0"),
			parent_index = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Int32_0"),
			damping = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Single_0"),
			elasticity = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Single_1"),
			stiffness = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Single_2"),
			inert = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Single_3"),
			radius = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Single_4"),
			end_offset = Offsets.GetFieldOffset<DynamicBone.ObjectNPrivateTrInSiVeSiQuVeSiVeSiUnique>("field_Public_Vector3_2")
		};
		SolverApi.SetPointersAndOffsets(ref callOffsets, ref colliderComponentOffsets, ref boneComponentOffsets, ref particleClassOffsets, ref listClassOffsets, ref objectOffsets);
	}

	// Token: 0x020000AC RID: 172
	internal struct ICallOffsets
	{
		// Token: 0x04000324 RID: 804
		public IntPtr get_transform_component;

		// Token: 0x04000325 RID: 805
		public IntPtr get_transform_ltw_matrix;

		// Token: 0x04000326 RID: 806
		public IntPtr get_component_enabled;

		// Token: 0x04000327 RID: 807
		public IntPtr set_transform_position_and_rotation;

		// Token: 0x04000328 RID: 808
		public IntPtr get_transform_child_count;

		// Token: 0x04000329 RID: 809
		public IntPtr gchandle_create;

		// Token: 0x0400032A RID: 810
		public IntPtr gchandle_drop;

		// Token: 0x0400032B RID: 811
		public IntPtr transform_get_local_rotation;
	}

	// Token: 0x020000AD RID: 173
	internal struct ObjectOffsets
	{
		// Token: 0x0400032C RID: 812
		public uint cached_ptr;
	}

	// Token: 0x020000AE RID: 174
	internal struct ColliderComponentOffsets
	{
		// Token: 0x0400032D RID: 813
		public uint collider_radius;

		// Token: 0x0400032E RID: 814
		public uint collider_height;

		// Token: 0x0400032F RID: 815
		public uint collider_center;

		// Token: 0x04000330 RID: 816
		public uint collider_bound;

		// Token: 0x04000331 RID: 817
		public uint collider_direction;
	}

	// Token: 0x020000AF RID: 175
	internal struct ListClassOffsets
	{
		// Token: 0x04000332 RID: 818
		public uint size;

		// Token: 0x04000333 RID: 819
		public uint store;

		// Token: 0x04000334 RID: 820
		public uint array_store;
	}

	// Token: 0x020000B0 RID: 176
	internal struct BoneComponentOffsets
	{
		// Token: 0x04000335 RID: 821
		public uint particle_list;

		// Token: 0x04000336 RID: 822
		public uint collider_list;

		// Token: 0x04000337 RID: 823
		public uint gravity;

		// Token: 0x04000338 RID: 824
		public uint force;

		// Token: 0x04000339 RID: 825
		public uint local_gravity;

		// Token: 0x0400033A RID: 826
		public uint freeze_axis;

		// Token: 0x0400033B RID: 827
		public uint update_rate;

		// Token: 0x0400033C RID: 828
		public uint root;
	}

	// Token: 0x020000B1 RID: 177
	internal struct ParticleClassOffsets
	{
		// Token: 0x0400033D RID: 829
		public uint transform;

		// Token: 0x0400033E RID: 830
		public uint parent_index;

		// Token: 0x0400033F RID: 831
		public uint damping;

		// Token: 0x04000340 RID: 832
		public uint elasticity;

		// Token: 0x04000341 RID: 833
		public uint stiffness;

		// Token: 0x04000342 RID: 834
		public uint inert;

		// Token: 0x04000343 RID: 835
		public uint radius;

		// Token: 0x04000344 RID: 836
		public uint end_offset;
	}
}
