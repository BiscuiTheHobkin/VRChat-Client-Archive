﻿using System;
using System.Collections;
using MelonLoader;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

// Token: 0x02000022 RID: 34
internal class WireframeComponent
{
	// Token: 0x060000C4 RID: 196 RVA: 0x00007D9C File Offset: 0x00005F9C
	public void OnUiManagerInitEarly()
	{
		this._wireframeIgnoreZ = true;
		this._wireframeIncludePlayers = true;
		this._wireframeIncludeSelf = true;
		this.WireframeRange = float.MaxValue;
		this._wireframeCamera = this.CreateCamera();
		bool flag = !(this._wireframeCamera == null);
		if (flag)
		{
			this._wireframeCamera.enabled = this._wireframeEnabled;
			this._wireframeCamera.gameObject.AddComponent<WireframeEnabler>();
			this._wireframeCamera.cullingMask = 0;
			bool wireframeIncludePlayers = this._wireframeIncludePlayers;
			if (wireframeIncludePlayers)
			{
				this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Player");
			}
			else
			{
				this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
			}
			bool wireframeIncludeSelf = this._wireframeIncludeSelf;
			if (wireframeIncludeSelf)
			{
				this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("PlayerLocal");
			}
			else
			{
				this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
			}
			bool wireframeIncludeDefault = this._wireframeIncludeDefault;
			if (wireframeIncludeDefault)
			{
				this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Default");
			}
			else
			{
				this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
			}
			bool wireframeIncludePickups = this._wireframeIncludePickups;
			if (wireframeIncludePickups)
			{
				this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Pickup");
			}
			else
			{
				this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
			}
			this._wireframeCamera.clearFlags = (this._wireframeIgnoreZ ? 3 : 4);
			this._wireframeCamera.farClipPlane = this.WireframeRange;
		}
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00007FA0 File Offset: 0x000061A0
	private void ToggleIncludePickups(bool b)
	{
		this._wireframeIncludePickups = b;
		bool wireframeIncludePickups = this._wireframeIncludePickups;
		if (wireframeIncludePickups)
		{
			this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Pickup");
			bool flag = this._wireframeHideOriginalObjects && this._wireframeEnabled;
			if (flag)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
			}
		}
		else
		{
			this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
			bool wireframeHideOriginalObjects = this._wireframeHideOriginalObjects;
			if (wireframeHideOriginalObjects)
			{
				this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Pickup");
			}
		}
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00008074 File Offset: 0x00006274
	private void ToggleIncludeDefault(bool b)
	{
		this._wireframeIncludeDefault = b;
		bool wireframeIncludeDefault = this._wireframeIncludeDefault;
		if (wireframeIncludeDefault)
		{
			this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Default");
			bool flag = this._wireframeHideOriginalObjects && this._wireframeEnabled;
			if (flag)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
			}
		}
		else
		{
			this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
			bool wireframeHideOriginalObjects = this._wireframeHideOriginalObjects;
			if (wireframeHideOriginalObjects)
			{
				this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Default");
			}
		}
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00008148 File Offset: 0x00006348
	private void ToggleIncludeSelf(bool b)
	{
		this._wireframeIncludeSelf = b;
		bool wireframeIncludeSelf = this._wireframeIncludeSelf;
		if (wireframeIncludeSelf)
		{
			this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("PlayerLocal");
			bool flag = this._wireframeHideOriginalObjects && this._wireframeEnabled;
			if (flag)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
			}
		}
		else
		{
			this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
			bool wireframeHideOriginalObjects = this._wireframeHideOriginalObjects;
			if (wireframeHideOriginalObjects)
			{
				this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("PlayerLocal");
			}
		}
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x0000821C File Offset: 0x0000641C
	private void ToggleIncludePlayers(bool b)
	{
		this._wireframeIncludePlayers = b;
		bool wireframeIncludePlayers = this._wireframeIncludePlayers;
		if (wireframeIncludePlayers)
		{
			this._wireframeCamera.cullingMask |= 1 << LayerMask.NameToLayer("Player");
			bool flag = this._wireframeHideOriginalObjects && this._wireframeEnabled;
			if (flag)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
			}
		}
		else
		{
			this._wireframeCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
			bool wireframeHideOriginalObjects = this._wireframeHideOriginalObjects;
			if (wireframeHideOriginalObjects)
			{
				this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Player");
			}
		}
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x000082F0 File Offset: 0x000064F0
	private void ToggleHideOriginalObject(bool b)
	{
		this._wireframeHideOriginalObjects = b;
		bool flag = !this._wireframeHideOriginalObjects;
		if (flag)
		{
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Player");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("PlayerLocal");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Default");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Pickup");
		}
		else
		{
			bool wireframeEnabled = this._wireframeEnabled;
			if (wireframeEnabled)
			{
				bool wireframeIncludePlayers = this._wireframeIncludePlayers;
				if (wireframeIncludePlayers)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
				}
				bool wireframeIncludeSelf = this._wireframeIncludeSelf;
				if (wireframeIncludeSelf)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
				}
				bool wireframeIncludeDefault = this._wireframeIncludeDefault;
				if (wireframeIncludeDefault)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
				}
				bool wireframeIncludePickups = this._wireframeIncludePickups;
				if (wireframeIncludePickups)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
				}
			}
		}
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00008474 File Offset: 0x00006674
	public void ToggleWireframe(bool enabled)
	{
		this._wireframeEnabled = enabled;
		this._wireframeCamera.enabled = this._wireframeEnabled;
		bool flag = !this._wireframeEnabled;
		if (flag)
		{
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Player");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("PlayerLocal");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Default");
			this._originalCamera.cullingMask |= 1 << LayerMask.NameToLayer("Pickup");
		}
		else
		{
			bool wireframeHideOriginalObjects = this._wireframeHideOriginalObjects;
			if (wireframeHideOriginalObjects)
			{
				bool wireframeIncludePlayers = this._wireframeIncludePlayers;
				if (wireframeIncludePlayers)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
				}
				bool wireframeIncludeSelf = this._wireframeIncludeSelf;
				if (wireframeIncludeSelf)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
				}
				bool wireframeIncludeDefault = this._wireframeIncludeDefault;
				if (wireframeIncludeDefault)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
				}
				bool wireframeIncludePickups = this._wireframeIncludePickups;
				if (wireframeIncludePickups)
				{
					this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
				}
			}
		}
	}

	// Token: 0x060000CB RID: 203 RVA: 0x0000860C File Offset: 0x0000680C
	public void OnSceneWasLoaded(int buildIndex, string sceneName)
	{
		bool flag = !(this._wireframeCamera == null) && buildIndex > 1;
		if (flag)
		{
			MelonCoroutines.Start(this.FixCameraDelayed());
		}
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00008641 File Offset: 0x00006841
	private IEnumerator FixCameraDelayed()
	{
		yield return new WaitForSecondsRealtime(5f);
		this._wireframeCamera.clearFlags = (this._wireframeIgnoreZ ? 3 : 4);
		this._wireframeCamera.farClipPlane = this.WireframeRange;
		Object.DestroyImmediate(this._wireframeCamera.GetComponent<PostProcessLayer>());
		bool flag = this._wireframeEnabled && this._wireframeHideOriginalObjects;
		if (flag)
		{
			bool wireframeIncludePlayers = this._wireframeIncludePlayers;
			if (wireframeIncludePlayers)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Player"));
			}
			bool wireframeIncludeSelf = this._wireframeIncludeSelf;
			if (wireframeIncludeSelf)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("PlayerLocal"));
			}
			bool wireframeIncludeDefault = this._wireframeIncludeDefault;
			if (wireframeIncludeDefault)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Default"));
			}
			bool wireframeIncludePickups = this._wireframeIncludePickups;
			if (wireframeIncludePickups)
			{
				this._originalCamera.cullingMask &= ~(1 << LayerMask.NameToLayer("Pickup"));
			}
		}
		yield break;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00008650 File Offset: 0x00006850
	private Camera CreateCamera()
	{
		VRCVrCamera field_Private_Static_VRCVrCamera_ = VRCVrCamera.field_Private_Static_VRCVrCamera_0;
		bool flag = !field_Private_Static_VRCVrCamera_;
		Camera result;
		if (flag)
		{
			result = null;
		}
		else
		{
			this._originalCamera = field_Private_Static_VRCVrCamera_.field_Public_Camera_0;
			bool flag2 = this._originalCamera == null;
			if (flag2)
			{
				result = null;
			}
			else
			{
				Camera camera = new GameObject("WireframeCamera")
				{
					transform = 
					{
						localScale = this._originalCamera.transform.localScale,
						parent = this._originalCamera.transform.parent,
						localRotation = Quaternion.identity,
						localPosition = Vector3.zero
					}
				}.AddComponent<Camera>();
				camera.fieldOfView = this._originalCamera.fieldOfView;
				camera.nearClipPlane /= 4f;
				camera.cameraType = this._originalCamera.cameraType;
				result = camera;
			}
		}
		return result;
	}

	// Token: 0x04000088 RID: 136
	public static WireframeComponent instance = new WireframeComponent();

	// Token: 0x04000089 RID: 137
	private Camera _wireframeCamera;

	// Token: 0x0400008A RID: 138
	private Camera _originalCamera;

	// Token: 0x0400008B RID: 139
	private bool _wireframeEnabled;

	// Token: 0x0400008C RID: 140
	private bool _wireframeIgnoreZ;

	// Token: 0x0400008D RID: 141
	private bool _wireframeIncludePlayers;

	// Token: 0x0400008E RID: 142
	private bool _wireframeIncludeSelf;

	// Token: 0x0400008F RID: 143
	private bool _wireframeIncludeDefault;

	// Token: 0x04000090 RID: 144
	private bool _wireframeIncludePickups;

	// Token: 0x04000091 RID: 145
	private bool _wireframeHideOriginalObjects;

	// Token: 0x04000092 RID: 146
	private float WireframeRange;
}
