﻿using System;
using System.Reflection;
using UnhollowerRuntimeLib.XrefScans;

// Token: 0x02000024 RID: 36
public static class NoBitches
{
	// Token: 0x060000D3 RID: 211 RVA: 0x00008780 File Offset: 0x00006980
	internal static bool XRefScanForMethod(this MethodBase methodBase, string methodName = null, string reflectedType = null)
	{
		bool flag = false;
		foreach (XrefInstance xrefInstance in XrefScanner.XrefScan(methodBase))
		{
			bool flag2 = xrefInstance.Type != 1;
			if (!flag2)
			{
				MethodBase methodBase2 = xrefInstance.TryResolve();
				bool flag3 = !(methodBase2 == null);
				if (flag3)
				{
					bool flag4 = !string.IsNullOrEmpty(methodName);
					if (flag4)
					{
						flag = (!string.IsNullOrEmpty(methodBase2.Name) && methodBase2.Name.IndexOf(methodName, StringComparison.OrdinalIgnoreCase) >= 0);
					}
					bool flag5 = !string.IsNullOrEmpty(reflectedType);
					if (flag5)
					{
						Type reflectedType2 = methodBase2.ReflectedType;
						flag = (!string.IsNullOrEmpty((reflectedType2 != null) ? reflectedType2.Name : null) && methodBase2.ReflectedType.Name.IndexOf(reflectedType, StringComparison.OrdinalIgnoreCase) >= 0);
					}
					bool flag6 = flag;
					if (flag6)
					{
						return true;
					}
				}
			}
		}
		return false;
	}
}
