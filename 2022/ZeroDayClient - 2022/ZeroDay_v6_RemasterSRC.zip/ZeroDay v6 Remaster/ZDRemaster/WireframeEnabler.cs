﻿using System;
using UnityEngine;

// Token: 0x02000023 RID: 35
public class WireframeEnabler : MonoBehaviour
{
	// Token: 0x060000D0 RID: 208 RVA: 0x00008760 File Offset: 0x00006960
	public WireframeEnabler(IntPtr obj) : base(obj)
	{
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x0000876B File Offset: 0x0000696B
	public void OnPreRender()
	{
		GL.wireframe = true;
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x00008775 File Offset: 0x00006975
	public void OnPostRender()
	{
		GL.wireframe = false;
	}
}
