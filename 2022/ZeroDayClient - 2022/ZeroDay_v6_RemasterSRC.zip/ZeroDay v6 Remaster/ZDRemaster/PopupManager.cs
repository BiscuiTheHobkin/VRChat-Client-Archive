﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000029 RID: 41
public static class PopupManager
{
	// Token: 0x17000020 RID: 32
	// (get) Token: 0x060000FF RID: 255 RVA: 0x00009754 File Offset: 0x00007954
	internal static PopupManager.ShowUiInputPopupAction ShowUiInputPopup
	{
		get
		{
			bool flag = PopupManager.ourShowUiInputPopupAction != null;
			PopupManager.ShowUiInputPopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowUiInputPopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 12)
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/InputPopup");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowUiInputPopupAction = (PopupManager.ShowUiInputPopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowUiInputPopupAction), VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0(), method);
				result = PopupManager.ourShowUiInputPopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000100 RID: 256 RVA: 0x000097D8 File Offset: 0x000079D8
	internal static PopupManager.ShowAlertPopupAction ShowAlertPopup
	{
		get
		{
			bool flag = PopupManager.ourShowAlertPopupAction != null;
			PopupManager.ShowAlertPopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowAlertPopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 3)
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/AlertPopup");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowAlertPopupAction = (PopupManager.ShowAlertPopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowAlertPopupAction), VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0(), method);
				result = PopupManager.ourShowAlertPopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000101 RID: 257 RVA: 0x0000985C File Offset: 0x00007A5C
	internal static PopupManager.ShowStandart1PopupAction ShowStandartV1Popup
	{
		get
		{
			bool flag = PopupManager.ourShowStandartV1PopupAction != null;
			PopupManager.ShowStandart1PopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowStandartV1PopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 3 && !it.Name.Contains("PDM"))
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/StandardPopup");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowStandartV1PopupAction = (PopupManager.ShowStandart1PopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowStandart1PopupAction), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = PopupManager.ourShowStandartV1PopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000102 RID: 258 RVA: 0x000098E0 File Offset: 0x00007AE0
	internal static PopupManager.ShowStandart2PopupAction ShowStandart2Popup
	{
		get
		{
			bool flag = PopupManager.ourShowStandart2PopupAction != null;
			PopupManager.ShowStandart2PopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowStandart2PopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 5 && !it.Name.Contains("PDM"))
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/StandardPopup");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowStandart2PopupAction = (PopupManager.ShowStandart2PopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowStandart2PopupAction), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = PopupManager.ourShowStandart2PopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000103 RID: 259 RVA: 0x00009964 File Offset: 0x00007B64
	internal static PopupManager.ShowStandart3PopupAction ShowStandart3Popup
	{
		get
		{
			bool flag = PopupManager.ourShowStandart3PopupAction != null;
			PopupManager.ShowStandart3PopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowStandart3PopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 7 && !it.Name.Contains("PDM"))
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/StandardPopup");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowStandart3PopupAction = (PopupManager.ShowStandart3PopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowStandart3PopupAction), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = PopupManager.ourShowStandart3PopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000104 RID: 260 RVA: 0x000099E8 File Offset: 0x00007BE8
	internal static PopupManager.ShowStandartV21PopupAction ShowStandartV21Popup
	{
		get
		{
			bool flag = PopupManager.ourShowStandartV21PopupAction != null;
			PopupManager.ShowStandartV21PopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowStandartV21PopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 5 && !it.Name.Contains("PDM"))
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/StandardPopupV2");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowStandartV21PopupAction = (PopupManager.ShowStandartV21PopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowStandartV21PopupAction), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = PopupManager.ourShowStandartV21PopupAction;
			}
			return result;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000105 RID: 261 RVA: 0x00009A6C File Offset: 0x00007C6C
	internal static PopupManager.ShowStandartV22PopupAction ShowStandartV22Popup
	{
		get
		{
			bool flag = PopupManager.ourShowStandartV22PopupAction != null;
			PopupManager.ShowStandartV22PopupAction result;
			if (flag)
			{
				result = PopupManager.ourShowStandartV22PopupAction;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo it)
				{
					bool result2;
					if (it.GetParameters().Length == 7 && !it.Name.Contains("PDM"))
					{
						result2 = XrefScanner.XrefScan(it).Any(delegate(XrefInstance jt)
						{
							bool result3;
							if (jt.Type == null)
							{
								Object @object = jt.ReadAsObject();
								result3 = (((@object != null) ? @object.ToString() : null) == "UserInterface/MenuContent/Popups/StandardPopupV2");
							}
							else
							{
								result3 = false;
							}
							return result3;
						});
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				PopupManager.ourShowStandartV22PopupAction = (PopupManager.ShowStandartV22PopupAction)Delegate.CreateDelegate(typeof(PopupManager.ShowStandartV22PopupAction), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = PopupManager.ourShowStandartV22PopupAction;
			}
			return result;
		}
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00009AED File Offset: 0x00007CED
	public static void Alert(this VRCUiPopupManager instance, string title, string Content, string buttonname, Action onSucces, Action<VRCUiPopup> onPopupShown = null)
	{
		PopupManager.ShowStandart2Popup("ZeroDay", Content, buttonname, onSucces, onPopupShown);
	}

	// Token: 0x06000107 RID: 263 RVA: 0x00009B10 File Offset: 0x00007D10
	public static void Alert(this VRCUiPopupManager instance, string title, string Content, string buttonname, Action action, string button2, Action action2, Action<VRCUiPopup> onPopupShown = null)
	{
		PopupManager.ShowStandart3Popup("ZeroDay", Content, buttonname, action, button2, action2, onPopupShown);
	}

	// Token: 0x06000108 RID: 264 RVA: 0x00009B3C File Offset: 0x00007D3C
	public static void AlertV2(this VRCUiPopupManager instance, string title, string Content, string buttonname, Action onSucces, Action<VRCUiPopup> onPopupShown = null)
	{
		PopupManager.ShowStandartV21Popup("ZeroDay", Content, buttonname, onSucces, onPopupShown);
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00009B5F File Offset: 0x00007D5F
	public static void AlertV2(this VRCUiPopupManager instance, string title, string Content, string buttonname, Action action, string button2, Action action2, Action<VRCUiPopup> onPopupShown = null)
	{
		PopupManager.ShowStandartV22Popup("ZeroDay", Content, buttonname, action, button2, action, onPopupShown);
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00009B8B File Offset: 0x00007D8B
	public static void HideCurrentPopUp(this VRCUiPopupManager instance)
	{
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
	}

	// Token: 0x0600010B RID: 267 RVA: 0x00009B9E File Offset: 0x00007D9E
	public static void ClearHudMessages(this VRCUiManager instance)
	{
		instance.field_Private_List_1_String_0.Clear();
		instance.field_Public_Text_0.text = "";
		PopupManager.HudMessage1.text = "";
		PopupManager.MessagesList.Clear();
	}

	// Token: 0x0600010C RID: 268 RVA: 0x00009BDC File Offset: 0x00007DDC
	internal static void InputPopUp(this VRCUiPopupManager instance, string title, string okButtonName, Action<string> onSuccess, Action Button2, string def = null)
	{
		PopupManager.ShowUiInputPopup("ZeroDay", "", 0, false, okButtonName, delegate(string g, List<KeyCode> l, Text t)
		{
			bool flag = string.Empty == g;
			if (flag)
			{
				g = def;
			}
			onSuccess(g);
		}, Button2, def ?? "", true, null, false, 0);
	}

	// Token: 0x0600010D RID: 269 RVA: 0x00009C44 File Offset: 0x00007E44
	internal static void NumericInputPopup(this VRCUiPopupManager instance, string title, string okButtonName, Action<string> onSuccess, string def = null)
	{
		PopupManager.ShowUiInputPopup("ZeroDay", "", 0, true, okButtonName, delegate(string g, List<KeyCode> l, Text t)
		{
			bool flag = string.Empty == g;
			if (flag)
			{
				g = def;
			}
			onSuccess(g);
		}, delegate()
		{
			instance.HideCurrentPopUp();
			PopupManager.IsTyping = false;
		}, def ?? "", true, null, false, 0);
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00009CBB File Offset: 0x00007EBB
	public static void ShowAlert(this VRCUiPopupManager instance, string title, string content, float timeout = 10f)
	{
		PopupManager.ShowAlertPopup("ZeroDay", content, timeout);
	}

	// Token: 0x0600010F RID: 271 RVA: 0x00009CD0 File Offset: 0x00007ED0
	public static Image CreateImage(string name, float offset)
	{
		GameObject gameObject = GameObject.Find("UserInterface/UnscaledUI/HudContent/Hud");
		Transform transform = gameObject.transform.Find("NotificationDotParent");
		GameObject gameObject2 = Object.Instantiate<GameObject>(gameObject.transform.Find("NotificationDotParent/NotificationDot").gameObject, transform, false).Cast<GameObject>();
		gameObject2.name = "NotifyDot-" + name;
		gameObject2.SetActive(true);
		gameObject2.transform.localPosition += Vector3.right * offset;
		Image component = gameObject2.GetComponent<Image>();
		component.enabled = false;
		return component;
	}

	// Token: 0x06000110 RID: 272 RVA: 0x00009D70 File Offset: 0x00007F70
	public static Text CreateTextNear(Image image, float offset, TextAnchor alignment)
	{
		GameObject gameObject = new GameObject(image.gameObject.name + "-text");
		gameObject.AddComponent<Text>();
		gameObject.transform.SetParent(image.transform, false);
		gameObject.transform.localScale = Vector3.one;
		gameObject.transform.localPosition = Vector3.up * offset + Vector3.right * 300f;
		Text component = gameObject.GetComponent<Text>();
		component.color = Color.white;
		component.fontStyle = 1;
		component.horizontalOverflow = 1;
		component.verticalOverflow = 1;
		component.alignment = alignment;
		component.fontSize = 30;
		component.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
		component.supportRichText = true;
		gameObject.SetActive(true);
		return component;
	}

	// Token: 0x06000111 RID: 273 RVA: 0x00009E51 File Offset: 0x00008051
	public static IEnumerator ShowMessage(Text text, List<string> MessagesList, string message)
	{
		bool flag = MessagesList.Count < 250;
		if (flag)
		{
			MessagesList.Add(message);
			text.text = string.Join("\n", MessagesList);
			yield return new WaitForSeconds(4f);
			MessagesList.Remove(message);
			text.text = string.Join("\n", MessagesList);
		}
		yield break;
	}

	// Token: 0x040000A1 RID: 161
	public static bool IsTyping = false;

	// Token: 0x040000A2 RID: 162
	public static List<string> MessagesList = new List<string>();

	// Token: 0x040000A3 RID: 163
	private static PopupManager.ShowUiInputPopupAction ourShowUiInputPopupAction;

	// Token: 0x040000A4 RID: 164
	private static PopupManager.ShowAlertPopupAction ourShowAlertPopupAction;

	// Token: 0x040000A5 RID: 165
	private static PopupManager.ShowStandart1PopupAction ourShowStandartV1PopupAction;

	// Token: 0x040000A6 RID: 166
	private static PopupManager.ShowStandart2PopupAction ourShowStandart2PopupAction;

	// Token: 0x040000A7 RID: 167
	private static PopupManager.ShowStandart3PopupAction ourShowStandart3PopupAction;

	// Token: 0x040000A8 RID: 168
	private static PopupManager.ShowStandartV21PopupAction ourShowStandartV21PopupAction;

	// Token: 0x040000A9 RID: 169
	private static PopupManager.ShowStandartV22PopupAction ourShowStandartV22PopupAction;

	// Token: 0x040000AA RID: 170
	public static Text HudMessage1;

	// Token: 0x020000D2 RID: 210
	// (Invoke) Token: 0x06000539 RID: 1337
	internal delegate void ShowUiInputPopupAction(string title, string initialText, InputField.InputType inputType, bool isNumeric, string confirmButtonText, Action<string, List<KeyCode>, Text> onComplete, Action onCancel, string placeholderText = "Enter text...", bool closeAfterInput = true, Action<VRCUiPopup> onPopupShown = null, bool startOnLeft = false, int characterLimit = 0);

	// Token: 0x020000D3 RID: 211
	// (Invoke) Token: 0x0600053D RID: 1341
	internal delegate void ShowAlertPopupAction(string title, string content, float timeout);

	// Token: 0x020000D4 RID: 212
	// (Invoke) Token: 0x06000541 RID: 1345
	internal delegate void ShowStandart1PopupAction(string title, string body, Action<VRCUiPopup> onPopupShown = null);

	// Token: 0x020000D5 RID: 213
	// (Invoke) Token: 0x06000545 RID: 1349
	public delegate void ShowStandart2PopupAction(string title, string body, string middleButtonText, Action middleButtonAction, Action<VRCUiPopup> onPopupShown = null);

	// Token: 0x020000D6 RID: 214
	// (Invoke) Token: 0x06000549 RID: 1353
	internal delegate void ShowStandart3PopupAction(string title, string body, string leftButtonText, Action leftButtonAction, string rightButtonText, Action rightButtonAction, Action<VRCUiPopup> onPopupShown = null);

	// Token: 0x020000D7 RID: 215
	// (Invoke) Token: 0x0600054D RID: 1357
	internal delegate void ShowStandartV21PopupAction(string title, string body, string middleButtonText, Action middleButtonAction, Action<VRCUiPopup> onPopupShown = null);

	// Token: 0x020000D8 RID: 216
	// (Invoke) Token: 0x06000551 RID: 1361
	internal delegate void ShowStandartV22PopupAction(string title, string body, string leftButtonText, Action leftButtonAction, string rightButtonText, Action rightButtonAction, Action<VRCUiPopup> onPopupShown = null);
}
