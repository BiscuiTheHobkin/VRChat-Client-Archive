﻿using System;
using UnityEngine;
using VRC;
using VRC.Core;
using ZDBase.Utils;
using ZDBase.Utils.Wrappers;

namespace ZDBase.Components
{
	// Token: 0x02000041 RID: 65
	public class BoneEsp : MonoBehaviour
	{
		// Token: 0x06000199 RID: 409 RVA: 0x0000BF78 File Offset: 0x0000A178
		public void OnGUI()
		{
			bool flag = this._tex == null;
			if (flag)
			{
				this._tex = new Texture2D(1, 1);
			}
			Camera main = Camera.main;
			foreach (Player player in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
			{
				player.GetApiAvatar();
				APIUser apiuser = player.GetAPIUser();
				bool flag2 = apiuser != null && !(apiuser.id == APIUser.CurrentUser.id) && BoneEsp.BonesEnabled;
				if (flag2)
				{
					GUI.skin.label.alignment = 4;
					bool flag3 = false;
					VRCPlayer vrcplayer = player._vrcplayer;
					bool flag4 = vrcplayer == null;
					Animator animator;
					if (flag4)
					{
						animator = null;
					}
					else
					{
						VRCAvatarManager vrcavatarManager = vrcplayer.Method_Public_get_VRCAvatarManager_0();
						bool flag5 = vrcavatarManager == null;
						if (flag5)
						{
							animator = null;
						}
						else
						{
							GameObject gameObject = vrcavatarManager.gameObject;
							animator = ((gameObject != null) ? gameObject.GetComponent<Animator>() : null);
						}
					}
					Animator animator2 = animator;
					bool flag6 = animator2 != null;
					if (flag6)
					{
						for (int i = 0; i < 56; i++)
						{
							HumanBodyBones humanBodyBones = i;
							Transform boneTransform = animator2.GetBoneTransform(humanBodyBones);
							bool flag7 = !(boneTransform == null);
							if (flag7)
							{
								Vector3 position = boneTransform.position;
								bool flag8 = Vector3.Dot(main.transform.forward, position - main.transform.position) > 0f;
								if (flag8)
								{
									Vector3 vector = main.WorldToScreenPoint(position);
									Graphics.DrawTexture(new Rect(vector.x, (float)Screen.height - vector.y, 2f, 2f), this._tex);
									bool flag9 = BoneEsp.NamesEnabled && humanBodyBones == 10;
									if (flag9)
									{
										position.y += 0.25f;
										vector = main.WorldToScreenPoint(position);
										GUI.Label(new Rect(vector.x - 50f, (float)Screen.height - vector.y - 50f, 100f, 100f), apiuser.displayName, GUI.skin.label);
										flag3 = true;
									}
								}
							}
						}
					}
					bool flag10 = BoneEsp.NamesEnabled && !flag3;
					if (flag10)
					{
						Vector3 position2 = player._vrcplayer.transform.position;
						bool flag11 = Vector3.Dot(main.transform.forward, position2 - main.transform.position) > 0f;
						if (flag11)
						{
							Vector3 vector2 = main.WorldToScreenPoint(position2);
							GUI.Label(new Rect(vector2.x - 50f, (float)Screen.height - vector2.y - 50f, 100f, 100f), apiuser.displayName, GUI.skin.label);
						}
					}
				}
			}
		}

		// Token: 0x0400014E RID: 334
		private Texture2D _tex;

		// Token: 0x0400014F RID: 335
		public static bool BonesEnabled = true;

		// Token: 0x04000150 RID: 336
		public static bool NamesEnabled = false;
	}
}
