﻿using System;
using VRC.Core;

namespace ZDBase
{
	// Token: 0x02000031 RID: 49
	public class AvatarObject
	{
		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600013F RID: 319 RVA: 0x0000AFAC File Offset: 0x000091AC
		// (set) Token: 0x06000140 RID: 320 RVA: 0x0000AFB4 File Offset: 0x000091B4
		public string name { get; set; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000141 RID: 321 RVA: 0x0000AFBD File Offset: 0x000091BD
		// (set) Token: 0x06000142 RID: 322 RVA: 0x0000AFC5 File Offset: 0x000091C5
		public string id { get; set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000143 RID: 323 RVA: 0x0000AFCE File Offset: 0x000091CE
		// (set) Token: 0x06000144 RID: 324 RVA: 0x0000AFD6 File Offset: 0x000091D6
		public string authorId { get; set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000145 RID: 325 RVA: 0x0000AFDF File Offset: 0x000091DF
		// (set) Token: 0x06000146 RID: 326 RVA: 0x0000AFE7 File Offset: 0x000091E7
		public string authorName { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000147 RID: 327 RVA: 0x0000AFF0 File Offset: 0x000091F0
		// (set) Token: 0x06000148 RID: 328 RVA: 0x0000AFF8 File Offset: 0x000091F8
		public string assetUrl { get; set; }

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000149 RID: 329 RVA: 0x0000B001 File Offset: 0x00009201
		// (set) Token: 0x0600014A RID: 330 RVA: 0x0000B009 File Offset: 0x00009209
		public string thumbnailImageUrl { get; set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x0600014B RID: 331 RVA: 0x0000B012 File Offset: 0x00009212
		// (set) Token: 0x0600014C RID: 332 RVA: 0x0000B01A File Offset: 0x0000921A
		public string supportedPlatforms { get; set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x0600014D RID: 333 RVA: 0x0000B023 File Offset: 0x00009223
		// (set) Token: 0x0600014E RID: 334 RVA: 0x0000B02B File Offset: 0x0000922B
		public string releaseStatus { get; set; }

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x0600014F RID: 335 RVA: 0x0000B034 File Offset: 0x00009234
		// (set) Token: 0x06000150 RID: 336 RVA: 0x0000B03C File Offset: 0x0000923C
		public string description { get; set; }

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000151 RID: 337 RVA: 0x0000B045 File Offset: 0x00009245
		// (set) Token: 0x06000152 RID: 338 RVA: 0x0000B04D File Offset: 0x0000924D
		public int version { get; set; }

		// Token: 0x06000153 RID: 339 RVA: 0x0000B058 File Offset: 0x00009258
		public ApiAvatar ToApiAvatar()
		{
			return new ApiAvatar
			{
				name = this.name,
				id = this.id,
				authorId = this.authorId,
				authorName = this.authorName,
				assetUrl = this.assetUrl,
				thumbnailImageUrl = this.thumbnailImageUrl,
				supportedPlatforms = ((this.supportedPlatforms == "All ") ? 3 : 1),
				description = this.description,
				releaseStatus = this.releaseStatus,
				version = this.version
			};
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0000B104 File Offset: 0x00009304
		public static ApiAvatar ApiAvatar(AvatarObject avatar)
		{
			return new ApiAvatar
			{
				name = avatar.name,
				id = avatar.id,
				authorId = avatar.authorId,
				authorName = avatar.authorName,
				assetUrl = avatar.assetUrl,
				thumbnailImageUrl = avatar.thumbnailImageUrl,
				supportedPlatforms = ((avatar.supportedPlatforms == "All") ? 3 : 1),
				description = avatar.description,
				releaseStatus = avatar.releaseStatus,
				version = avatar.version
			};
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0000B1B0 File Offset: 0x000093B0
		public AvatarObject(ApiAvatar avtr)
		{
			this.name = avtr.name;
			this.id = avtr.id;
			this.authorId = avtr.authorId;
			this.authorName = avtr.authorName;
			this.assetUrl = avtr.assetUrl;
			this.thumbnailImageUrl = avtr.thumbnailImageUrl;
			this.supportedPlatforms = avtr.supportedPlatforms.ToString();
			this.description = avtr.description;
			this.releaseStatus = avtr.releaseStatus;
			this.version = avtr.version;
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0000B255 File Offset: 0x00009455
		public AvatarObject()
		{
		}
	}
}
