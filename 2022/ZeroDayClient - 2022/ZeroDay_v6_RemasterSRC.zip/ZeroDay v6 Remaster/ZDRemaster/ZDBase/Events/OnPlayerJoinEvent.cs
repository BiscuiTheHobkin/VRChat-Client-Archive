﻿using System;
using VRC;

namespace ZDBase.Events
{
	// Token: 0x02000036 RID: 54
	public interface OnPlayerJoinEvent
	{
		// Token: 0x06000160 RID: 352
		void OnPlayerJoin(Player player);
	}
}
