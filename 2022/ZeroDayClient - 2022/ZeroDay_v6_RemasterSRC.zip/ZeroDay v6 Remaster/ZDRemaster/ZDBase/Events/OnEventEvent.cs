﻿using System;
using ExitGames.Client.Photon;

namespace ZDBase.Events
{
	// Token: 0x02000035 RID: 53
	public interface OnEventEvent
	{
		// Token: 0x0600015F RID: 351
		bool OnEvent(EventData eventData);
	}
}
