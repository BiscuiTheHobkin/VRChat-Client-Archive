﻿using System;
using VRC;
using VRC.SDKBase;

namespace ZDBase.Events
{
	// Token: 0x02000038 RID: 56
	public interface OnRPCEvent
	{
		// Token: 0x06000162 RID: 354
		bool OnRPC(Player sender, VRC_EventHandler.VrcEvent vrcEvent, VRC_EventHandler.VrcBroadcastType vrcBroadcastType, int instagatorId, float fastforward);
	}
}
