﻿using System;

namespace ZDBase.Events
{
	// Token: 0x02000039 RID: 57
	public interface OnSceneLoadedEvent
	{
		// Token: 0x06000163 RID: 355
		void OnSceneWasLoadedEvent(int buildIndex, string sceneName);
	}
}
