﻿using System;
using VRC;

namespace ZDBase.Events
{
	// Token: 0x02000037 RID: 55
	public interface OnPlayerLeaveEvent
	{
		// Token: 0x06000161 RID: 353
		void PlayerLeave(Player player);
	}
}
