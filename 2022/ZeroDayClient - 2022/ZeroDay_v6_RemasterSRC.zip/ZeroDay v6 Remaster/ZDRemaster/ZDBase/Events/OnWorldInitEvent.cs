﻿using System;

namespace ZDBase.Events
{
	// Token: 0x0200003D RID: 61
	public interface OnWorldInitEvent
	{
		// Token: 0x06000167 RID: 359
		void OnWorldInit();
	}
}
