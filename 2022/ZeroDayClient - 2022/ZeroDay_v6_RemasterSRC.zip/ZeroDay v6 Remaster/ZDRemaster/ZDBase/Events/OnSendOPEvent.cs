﻿using System;
using Il2CppSystem;
using Photon.Realtime;

namespace ZDBase.Events
{
	// Token: 0x0200003A RID: 58
	public interface OnSendOPEvent
	{
		// Token: 0x06000164 RID: 356
		bool OnSendOP(byte opCode, ref Object parameters, ref RaiseEventOptions raiseEventOptions);
	}
}
