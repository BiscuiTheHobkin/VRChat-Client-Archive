﻿using System;
using VRC;

namespace ZDBase.Events
{
	// Token: 0x0200003B RID: 59
	public interface OnUdonEvent
	{
		// Token: 0x06000165 RID: 357
		bool OnUdon(string __0, Player __1);
	}
}
