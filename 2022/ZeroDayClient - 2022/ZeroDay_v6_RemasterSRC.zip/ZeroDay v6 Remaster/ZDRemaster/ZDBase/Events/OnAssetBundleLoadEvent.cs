﻿using System;
using UnityEngine;
using ZDBase.Utils;

namespace ZDBase.Events
{
	// Token: 0x02000034 RID: 52
	public abstract class OnAssetBundleLoadEvent
	{
		// Token: 0x0600015D RID: 349 RVA: 0x0000B360 File Offset: 0x00009560
		public static bool OnAvatarAssetBundleLoad(GameObject avatar, string avatarID)
		{
			SkinnedMeshRenderer[] array = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true);
			MeshFilter[] array2 = avatar.GetComponentsInChildren<MeshFilter>(true);
			foreach (SkinnedMeshRenderer skinnedMeshRenderer in array)
			{
				bool flag = false;
				bool flag2 = !skinnedMeshRenderer.sharedMesh.isReadable;
				if (flag2)
				{
					Object.DestroyImmediate(skinnedMeshRenderer, true);
					Logs.Log("[AnitCrash] deleted unreadable Mesh", false);
				}
				else
				{
					for (int j = 0; j < Patches.blacklistMesh.Length; j++)
					{
						bool flag3 = skinnedMeshRenderer.name.ToLower().Contains(Patches.blacklistMesh[j]);
						if (flag3)
						{
							Logs.Log("[AnitCrash] deleted blackListed Mesh " + skinnedMeshRenderer.name, true);
							Object.DestroyImmediate(skinnedMeshRenderer, true);
							flag = true;
							break;
						}
					}
					bool flag4 = flag;
					if (!flag4)
					{
						int num = 0;
						for (int k = 0; k < skinnedMeshRenderer.sharedMesh.subMeshCount; k++)
						{
							num += skinnedMeshRenderer.sharedMesh.GetTriangles(k).Length / 3;
							bool flag5 = num >= Patches.maxPoly;
							if (flag5)
							{
								Object.DestroyImmediate(skinnedMeshRenderer, true);
								Logs.Log("[AnitCrash] deleted Mesh with too many polys", true);
								flag = true;
								break;
							}
						}
						bool flag6 = flag;
						if (!flag6)
						{
							Material[] array3 = skinnedMeshRenderer.materials;
							bool flag7 = array3.Length >= Patches.maxMatirial;
							if (flag7)
							{
								Object.DestroyImmediate(skinnedMeshRenderer, true);
								Logs.Log("[AnitCrash] deleted Mesh with " + array3.Length.ToString() + " materials", true);
							}
							else
							{
								for (int l = 0; l < array3.Length; l++)
								{
									Shader shader = array3[l].shader;
									Logs.Log("[AnitCrash] replaced Shader " + shader.name, true);
									shader = Patches.defaultShader;
								}
							}
						}
					}
				}
			}
			foreach (MeshFilter meshFilter in array2)
			{
				bool flag8 = !meshFilter.sharedMesh.isReadable;
				if (flag8)
				{
					Object.DestroyImmediate(meshFilter, true);
					Logs.Log("[AnitCrash] deleted unreadable Mesh", true);
				}
				else
				{
					bool flag9 = false;
					for (int n = 0; n < Patches.blacklistMesh.Length; n++)
					{
						bool flag10 = meshFilter.name.ToLower().Contains(Patches.blacklistMesh[n]);
						if (flag10)
						{
							Logs.Log("[AnitCrash] deleted blackListed Mesh " + meshFilter.name, true);
							Object.DestroyImmediate(meshFilter, true);
							flag9 = true;
							break;
						}
					}
					bool flag11 = flag9;
					if (!flag11)
					{
						int num2 = 0;
						for (int num3 = 0; num3 < meshFilter.sharedMesh.subMeshCount; num3++)
						{
							num2 += meshFilter.sharedMesh.GetTriangles(num3).Length / 3;
							bool flag12 = num2 >= Patches.maxPoly;
							if (flag12)
							{
								Object.DestroyImmediate(meshFilter, true);
								Logs.Log("[AnitCrash] deleted Mesh with too many polys", true);
								flag9 = true;
								break;
							}
						}
						bool flag13 = flag9;
						if (!flag13)
						{
							MeshRenderer component = meshFilter.gameObject.GetComponent<MeshRenderer>();
							Material[] array4 = component.materials;
							bool flag14 = array4.Length >= Patches.maxMatirial;
							if (flag14)
							{
								Object.DestroyImmediate(meshFilter, true);
								Logs.Log("[AnitCrash] deleted Mesh with " + array4.Length.ToString() + " materials", true);
							}
							else
							{
								for (int num4 = 0; num4 < array4.Length; num4++)
								{
									Shader shader2 = array4[num4].shader;
									Logs.Log("[AnitCrash] replaced Shader " + shader2.name, true);
									shader2 = Patches.defaultShader;
								}
							}
						}
					}
				}
			}
			AudioSource[] array5 = avatar.GetComponentsInChildren<AudioSource>();
			bool flag15 = array5.Length >= Patches.maxAudio;
			if (flag15)
			{
				for (int num5 = 0; num5 < Patches.maxAudio; num5++)
				{
					Object.DestroyImmediate(array5[num5].gameObject, true);
				}
				Logs.Log("[AnitCrash] deleted " + Patches.maxAudio.ToString() + " AudioSources", true);
			}
			Light[] array6 = avatar.GetComponentsInChildren<Light>();
			bool flag16 = array6.Length >= Patches.maxLight;
			if (flag16)
			{
				for (int num6 = 0; num6 < Patches.maxLight; num6++)
				{
					Object.DestroyImmediate(array6[num6].gameObject, true);
				}
				Logs.Log("[AnitCrash] deleted " + Patches.maxLight.ToString() + " Lights", true);
			}
			Cloth[] array7 = avatar.GetComponentsInChildren<Cloth>();
			bool flag17 = array7.Length >= Patches.maxCloth;
			if (flag17)
			{
				for (int num7 = 0; num7 < Patches.maxCloth; num7++)
				{
					Object.DestroyImmediate(array7[num7].gameObject, true);
				}
				Logs.Log("[AnitCrash] deleted " + Patches.maxCloth.ToString() + " Cloth", true);
			}
			Collider[] array8 = avatar.GetComponentsInChildren<Collider>();
			bool flag18 = array8.Length >= Patches.maxColliders;
			if (flag18)
			{
				for (int num8 = 0; num8 < Patches.maxColliders; num8++)
				{
					Object.DestroyImmediate(array8[num8].gameObject, true);
				}
				Logs.Log("[AnitCrash] deleted " + Patches.maxColliders.ToString() + " Colliders", true);
			}
			DynamicBoneCollider[] array9 = avatar.GetComponentsInChildren<DynamicBoneCollider>();
			bool flag19 = array9.Length >= Patches.maxDynamicBonesCollider;
			if (flag19)
			{
				for (int num9 = 0; num9 < Patches.maxDynamicBonesCollider; num9++)
				{
					Object.DestroyImmediate(array9[num9].gameObject, true);
				}
				Logs.Log("[AnitCrash] deleted " + Patches.maxDynamicBonesCollider.ToString() + " DynamicBoneColliders", true);
			}
			return true;
		}
	}
}
