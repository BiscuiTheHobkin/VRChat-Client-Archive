﻿using System;

namespace ZDBase.Events
{
	// Token: 0x0200003C RID: 60
	public interface OnUpdateEvent
	{
		// Token: 0x06000166 RID: 358
		void OnUpdateEvent();
	}
}
