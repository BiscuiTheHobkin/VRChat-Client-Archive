﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ZDBase.Modules
{
	// Token: 0x02000042 RID: 66
	[NullableContext(2)]
	[Nullable(0)]
	internal class EnableDisableListener : MonoBehaviour
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x0600019C RID: 412 RVA: 0x0000C298 File Offset: 0x0000A498
		// (remove) Token: 0x0600019D RID: 413 RVA: 0x0000C2D0 File Offset: 0x0000A4D0
		[method: HideFromIl2Cpp]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action OnEnabled;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600019E RID: 414 RVA: 0x0000C308 File Offset: 0x0000A508
		// (remove) Token: 0x0600019F RID: 415 RVA: 0x0000C340 File Offset: 0x0000A540
		[method: HideFromIl2Cpp]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action OnDisabled;

		// Token: 0x060001A0 RID: 416 RVA: 0x0000C375 File Offset: 0x0000A575
		public EnableDisableListener(IntPtr obj0) : base(obj0)
		{
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x0000C380 File Offset: 0x0000A580
		private void OnEnable()
		{
			Action onEnabled = this.OnEnabled;
			if (onEnabled != null)
			{
				onEnabled();
			}
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x0000C395 File Offset: 0x0000A595
		private void OnDisable()
		{
			Action onDisabled = this.OnDisabled;
			if (onDisabled != null)
			{
				onDisabled();
			}
		}
	}
}
