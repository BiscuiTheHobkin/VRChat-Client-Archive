﻿using System;
using System.Collections;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.SDKBase;
using VRC.Udon;
using VRC.UI.Elements.Menus;
using ZeroDayRemastered.Modules;

namespace ZDBase.Modules.JarGames
{
	// Token: 0x02000047 RID: 71
	public class Murder
	{
		// Token: 0x060001AB RID: 427 RVA: 0x0000C74C File Offset: 0x0000A94C
		public static void bringRevolver()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Revolver";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001AC RID: 428 RVA: 0x0000C810 File Offset: 0x0000AA10
		public static void bringKnife()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Knife (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001AD RID: 429 RVA: 0x0000C8D4 File Offset: 0x0000AAD4
		public static void bringLuger()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Luger (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0000C998 File Offset: 0x0000AB98
		public static void bringFrag()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Frag (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001AF RID: 431 RVA: 0x0000CA5C File Offset: 0x0000AC5C
		public static void bringShotgun()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Shotgun (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x0000CB20 File Offset: 0x0000AD20
		public static void BringSmoke()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Smoke (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x0000CBE4 File Offset: 0x0000ADE4
		public static void BringTrap()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Bear Trap (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x0000CCA8 File Offset: 0x0000AEA8
		public static void StartFFA()
		{
			List<GameObject> list = new List<GameObject>();
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (0)").gameObject);
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (1)").gameObject);
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (2)").gameObject);
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (3)").gameObject);
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (4)").gameObject);
			list.Add(GameObject.Find("Game Logic").transform.Find("Weapons/Knife (5)").gameObject);
			GameObject gameObject = new GameObject();
			gameObject.transform.position = new Vector3(0.455f, 0.504f, 115f);
			MelonCoroutines.Start(Exploits.smethod_4());
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000CDCC File Offset: 0x0000AFCC
		public static void LightsON()
		{
			UdonBehaviour component = GameObject.Find("Game Logic/Switch Boxes/Switchbox (0)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component.gameObject, "SwitchUp", null, false);
			UdonBehaviour component2 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (1)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component2.gameObject, "SwitchUp", null, false);
			UdonBehaviour component3 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (2)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component3.gameObject, "SwitchUp", null, false);
			UdonBehaviour component4 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (3)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component4.gameObject, "SwitchUp", null, false);
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000CE68 File Offset: 0x0000B068
		public static void LightsOFF()
		{
			UdonBehaviour component = GameObject.Find("Game Logic/Switch Boxes/Switchbox (0)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component.gameObject, "SwitchDown", null, false);
			UdonBehaviour component2 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (1)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component2.gameObject, "SwitchDown", null, false);
			UdonBehaviour component3 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (2)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component3.gameObject, "SwitchDown", null, false);
			UdonBehaviour component4 = GameObject.Find("Game Logic/Switch Boxes/Switchbox (3)").GetComponent<UdonBehaviour>();
			Exploits.SendUdonRPC(component4.gameObject, "SwitchDown", null, false);
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0000CF04 File Offset: 0x0000B104
		public static void BlindAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerBlinded");
				}
			}
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000CF78 File Offset: 0x0000B178
		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncStartGame");
				}
			}
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000CFEC File Offset: 0x0000B1EC
		public static void KillAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
				}
			}
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000D060 File Offset: 0x0000B260
		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
				}
			}
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x0000D0D4 File Offset: 0x0000B2D4
		public static void MurderWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
				}
			}
		}

		// Token: 0x060001BA RID: 442 RVA: 0x0000D148 File Offset: 0x0000B348
		public static void ByStandWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
				}
			}
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000D1BC File Offset: 0x0000B3BC
		public static void LockDoors()
		{
			List<Transform> list = new List<Transform>
			{
				GameObject.Find("Door").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (3)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (4)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (5)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (6)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (7)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (15)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (16)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (8)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (13)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (17)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (18)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (19)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (20)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (21)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (22)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (23)").transform.Find("Door Anim/Hinge/Interact lock"),
				GameObject.Find("Door (14)").transform.Find("Door Anim/Hinge/Interact lock")
			};
			foreach (Transform transform in list)
			{
				transform.GetComponent<UdonBehaviour>().Interact();
			}
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000D45C File Offset: 0x0000B65C
		public static void OpenDoors()
		{
			List<Transform> list = new List<Transform>
			{
				GameObject.Find("Door").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (3)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (4)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (5)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (6)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (7)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (15)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (16)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (8)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (13)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (17)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (18)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (19)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (20)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (21)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (22)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (23)").transform.Find("Door Anim/Hinge/Interact open"),
				GameObject.Find("Door (14)").transform.Find("Door Anim/Hinge/Interact open")
			};
			foreach (Transform transform in list)
			{
				transform.GetComponent<UdonBehaviour>().Interact();
			}
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000D6FC File Offset: 0x0000B8FC
		public static void CloseDoors()
		{
			List<Transform> list = new List<Transform>
			{
				GameObject.Find("Door").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (3)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (4)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (5)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (6)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (7)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (15)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (16)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (8)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (13)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (17)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (18)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (19)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (20)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (21)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (22)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (23)").transform.Find("Door Anim/Hinge/Interact close"),
				GameObject.Find("Door (14)").transform.Find("Door Anim/Hinge/Interact close")
			};
			foreach (Transform transform in list)
			{
				transform.GetComponent<UdonBehaviour>().Interact();
			}
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000D99C File Offset: 0x0000BB9C
		public static void UnlockDoors()
		{
			List<Transform> list = new List<Transform>
			{
				GameObject.Find("Door").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (3)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (4)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (5)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (6)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (7)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (15)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (16)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (8)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (13)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (17)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (18)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (19)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (20)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (21)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (22)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (23)").transform.Find("Door Anim/Hinge/Interact shove"),
				GameObject.Find("Door (14)").transform.Find("Door Anim/Hinge/Interact shove")
			};
			foreach (Transform transform in list)
			{
				transform.GetComponent<UdonBehaviour>().Interact();
				transform.GetComponent<UdonBehaviour>().Interact();
				transform.GetComponent<UdonBehaviour>().Interact();
				transform.GetComponent<UdonBehaviour>().Interact();
			}
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000DC60 File Offset: 0x0000BE60
		public static void SelfBystander()
		{
			VRCPlayer component = VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<VRCPlayer>();
			string value = component._player.ToString();
			for (int i = 0; i < 24; i++)
			{
				string text = "Player Node (" + i.ToString() + ")";
				string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
				if (flag)
				{
					MelonLogger.Msg(text);
					UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
					component2.SendCustomNetworkEvent(0, "SyncAssignB");
				}
			}
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000DD14 File Offset: 0x0000BF14
		public static void SeldMurderer()
		{
			VRCPlayer component = VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<VRCPlayer>();
			string value = component._player.ToString();
			for (int i = 0; i < 24; i++)
			{
				string text = "Player Node (" + i.ToString() + ")";
				string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
				if (flag)
				{
					MelonLogger.Msg(text);
					UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
					component2.SendCustomNetworkEvent(0, "SyncAssignM");
				}
			}
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000DDC6 File Offset: 0x0000BFC6
		public static IEnumerator Flashes()
		{
			GameObject camera = GameObject.Find("FlashCamera");
			UdonBehaviour cameraUdon = camera.GetComponent<UdonBehaviour>();
			for (;;)
			{
				bool flashAnnoy = Murder.FlashAnnoy;
				if (flashAnnoy)
				{
					Player player9 = null;
					int num17;
					for (int num15 = 0; num15 < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; num15 = num17 + 1)
					{
						bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[num15].Method_Internal_get_APIUser_0().id.Equals(GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
						if (flag)
						{
							player9 = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[num15];
						}
						num17 = num15;
					}
					string displayName = player9.Method_Internal_get_APIUser_0().displayName;
					for (int num16 = 0; num16 < 24; num16 = num17 + 1)
					{
						string text = "Player Node (" + num16.ToString() + ")";
						string name = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + num16.ToString() + ")/Player Name Text";
						bool flag2 = GameObject.Find(name).GetComponent<Text>().text.Equals(displayName);
						if (flag2)
						{
							Logs.LogSuccess(text, true);
							UdonBehaviour component = GameObject.Find(text).GetComponent<UdonBehaviour>();
							cameraUdon.SendCustomNetworkEvent(0, "SyncPhoto");
							component.SendCustomNetworkEvent(0, "SyncFlashbang");
							component = null;
						}
						text = null;
						name = null;
						num17 = num16;
					}
					player9 = null;
					displayName = null;
				}
				yield return new WaitForSeconds(0.2f);
			}
			yield break;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000DDD0 File Offset: 0x0000BFD0
		public static void KnifeShield()
		{
			List<GameObject> list = new List<GameObject>
			{
				GameObject.Find("Game Logic").transform.Find("Polaroids Unlock Camera/FlashCamera").gameObject
			};
			GameObject gameObject = new GameObject();
			gameObject.transform.position = Exploits.istargeted.field_Private_VRCPlayerApi_0.GetBonePosition(9) + new Vector3(0f, 0.35f, 0f);
			gameObject.transform.Rotate(new Vector3(0f, 360f * Time.time, 0f));
			foreach (GameObject gameObject2 in list)
			{
				Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0(), gameObject2.gameObject);
				gameObject2.transform.position = gameObject.transform.position + gameObject.transform.forward;
				gameObject2.transform.LookAt(Exploits.istargeted.field_Private_VRCPlayerApi_0.GetBonePosition(8));
				gameObject.transform.Rotate(new Vector3(0f, (float)(360 / list.Count), 0f));
			}
			Object.Destroy(gameObject);
			gameObject = null;
		}

		// Token: 0x0400015D RID: 349
		public static bool FlashAnnoy;
	}
}
