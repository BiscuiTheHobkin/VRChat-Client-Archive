﻿using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using VRC.Udon;
using ZeroDayRemastered.Modules;

namespace ZDBase.Modules.JarGames
{
	// Token: 0x02000048 RID: 72
	public class AmongUs
	{
		// Token: 0x060001C4 RID: 452 RVA: 0x0000DF48 File Offset: 0x0000C148
		public static void Sussy()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
				}
			}
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x0000E098 File Offset: 0x0000C298
		public static void CloseDoors()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				}
			}
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x0000E194 File Offset: 0x0000C394
		public static IEnumerable<WaitForSeconds> CloseDoors1(bool state)
		{
			foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = item.name.Contains("Game Logic");
				if (flag)
				{
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				}
				item = null;
			}
			IEnumerator<GameObject> enumerator = null;
			yield return new WaitForSeconds(5f);
			yield break;
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0000E1A4 File Offset: 0x0000C3A4
		public static void Lights()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
				}
			}
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0000E218 File Offset: 0x0000C418
		public static void Comms()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
				}
			}
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000E28C File Offset: 0x0000C48C
		public static void Reactor()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
				}
			}
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000E300 File Offset: 0x0000C500
		public static void Oxygen()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
				}
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000E374 File Offset: 0x0000C574
		public static void RepairAl()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairLights");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairReactor");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygenA");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygenB");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygen");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairComms");
				}
			}
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000E448 File Offset: 0x0000C648
		public static void BecomeCrew()
		{
			VRCPlayer component = VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<VRCPlayer>();
			string value = component._player.ToString();
			for (int i = 0; i < 24; i++)
			{
				string text = "Player Node (" + i.ToString() + ")";
				string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
				if (flag)
				{
					MelonLogger.Msg(text);
					UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
					component2.SendCustomNetworkEvent(0, "SyncAssignB");
				}
			}
		}

		// Token: 0x060001CD RID: 461 RVA: 0x0000E4FC File Offset: 0x0000C6FC
		public static void VoteOutAll()
		{
			GameObject gameObject = GameObject.Find("Player Nodes");
			foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
			{
				bool flag = transform.name != gameObject.name;
				if (flag)
				{
					Exploits.SendUdonRPC(transform.gameObject, "SyncVotedOut", null, false);
				}
			}
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000E57C File Offset: 0x0000C77C
		public static void BecomeImposter()
		{
			VRCPlayer component = VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<VRCPlayer>();
			string value = component._player.ToString();
			for (int i = 0; i < 24; i++)
			{
				string text = "Player Node (" + i.ToString() + ")";
				string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
				if (flag)
				{
					MelonLogger.Msg(text);
					UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
					component2.SendCustomNetworkEvent(0, "SyncAssignM");
				}
			}
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000E62E File Offset: 0x0000C82E
		public static IEnumerable<WaitForSeconds> VoteAll(bool state)
		{
			foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = item.name.Contains("Game Logic");
				if (flag)
				{
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVotedOut");
				}
				item = null;
			}
			IEnumerator<GameObject> enumerator = null;
			yield return new WaitForSeconds(1f);
			yield break;
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000E640 File Offset: 0x0000C840
		public static void Taskcomplet()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerCompletedTask");
				}
			}
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000E6B4 File Offset: 0x0000C8B4
		public static void SkipVote()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_SkipVoting");
				}
			}
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000E728 File Offset: 0x0000C928
		public static void Em()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "StartMeeting");
				}
			}
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000E79C File Offset: 0x0000C99C
		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_Start");
				}
			}
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000E810 File Offset: 0x0000CA10
		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
				}
			}
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000E884 File Offset: 0x0000CA84
		public static void InpostWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
				}
			}
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000E8F8 File Offset: 0x0000CAF8
		public static void CrewWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
				}
			}
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000E96C File Offset: 0x0000CB6C
		public static void KillAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
				}
			}
		}
	}
}
