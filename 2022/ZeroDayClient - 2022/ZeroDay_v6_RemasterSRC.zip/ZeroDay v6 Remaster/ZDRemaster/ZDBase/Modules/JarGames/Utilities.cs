﻿using System;

namespace ZDBase.Modules.JarGames
{
	// Token: 0x02000049 RID: 73
	public class Utilities
	{
	}
}
