﻿using System;
using MelonLoader;
using UnityEngine;
using VRC.SDKBase;
using ZeroDayRemastered.Modules;

namespace ZDBase.Modules
{
	// Token: 0x02000044 RID: 68
	internal class sitonpickups : MonoBehaviour
	{
		// Token: 0x060001A5 RID: 421 RVA: 0x0000C418 File Offset: 0x0000A618
		public sitonpickups(IntPtr ptr)
		{
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x0000C424 File Offset: 0x0000A624
		private void OnCollisionEnter(Collision col)
		{
			bool flag = col.gameObject.GetComponent<VRC_Pickup>();
			if (flag)
			{
				sitonpickups.collisionobj = col;
				MelonCoroutines.Start(Nazis.sitonobj(sitonpickups.collisionobj));
			}
		}

		// Token: 0x04000157 RID: 343
		public static bool sitonobj;

		// Token: 0x04000158 RID: 344
		public static bool waitforcooldown2;

		// Token: 0x04000159 RID: 345
		public static Collision collisionobj;
	}
}
