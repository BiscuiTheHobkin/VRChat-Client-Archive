﻿using System;
using System.Collections;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;
using VRC;
using VRC.Core;
using ZDBase.Utils;

namespace ZDBase.Modules.AvatarHider
{
	// Token: 0x0200004A RID: 74
	internal class AviDistanceHide
	{
		// Token: 0x060001DA RID: 474 RVA: 0x0000E9F4 File Offset: 0x0000CBF4
		public static VRCPlayer GetLocalVRCPlayer()
		{
			return VRCPlayer.field_Internal_Static_VRCPlayer_0;
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000EA0C File Offset: 0x0000CC0C
		public static GameObject GetAvatarObject(Player p)
		{
			return p.Method_Internal_get_VRCPlayer_1().Method_Public_get_VRCAvatarManager_0().Method_Public_get_GameObject_0();
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000EA30 File Offset: 0x0000CC30
		public static bool IsMe(Player p)
		{
			return p.name == AviDistanceHide.GetLocalVRCPlayer().name;
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000EA58 File Offset: 0x0000CC58
		public static bool IsFriendsWith(string id)
		{
			return APIUser.CurrentUser.friendIDs.Contains(id);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000EA7A File Offset: 0x0000CC7A
		public static IEnumerator AvatarScanner()
		{
			for (;;)
			{
				yield return new WaitForSeconds(1f);
				bool flag = MainConfigSettings.Instance.M_hidavaatrs && AviDistanceHide.GetLocalVRCPlayer() != null;
				if (flag)
				{
					foreach (Player player in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
					{
						bool flag2 = player != null && player != VRCPlayer.field_Internal_Static_VRCPlayer_0._player;
						if (flag2)
						{
							GameObject avatarObject = AviDistanceHide.GetAvatarObject(player);
							float num = Vector3.Distance(AviDistanceHide.GetLocalVRCPlayer().transform.position, avatarObject.transform.position);
							bool active = avatarObject.active;
							bool flag3 = num > MainConfigSettings.Instance.m_Distance && active && MainConfigSettings.Instance.M_hidavaatrs;
							if (flag3)
							{
								avatarObject.SetActive(false);
							}
							else
							{
								bool flag4 = num <= MainConfigSettings.Instance.m_Distance && !active && MainConfigSettings.Instance.M_hidavaatrs;
								if (flag4)
								{
									avatarObject.SetActive(true);
								}
								else
								{
									bool flag5 = !MainConfigSettings.Instance.M_hidavaatrs && !active;
									if (flag5)
									{
										avatarObject.SetActive(true);
									}
								}
							}
							avatarObject = null;
						}
						player = null;
					}
					List<Player>.Enumerator enumerator = null;
				}
			}
			yield break;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000EA84 File Offset: 0x0000CC84
		public static void UnHideAvatars()
		{
			try
			{
				foreach (Player player in PlayerManager.Method_Public_Static_ArrayOf_Player_0())
				{
					bool flag = !(player == null) && !AviDistanceHide.IsMe(player);
					if (flag)
					{
						GameObject avatarObject = AviDistanceHide.GetAvatarObject(player);
						bool flag2 = !(avatarObject == null) && !avatarObject.active;
						if (flag2)
						{
							avatarObject.SetActive(true);
						}
					}
				}
			}
			catch (Exception arg)
			{
				MelonLogger.Log(string.Format("Failed to unhide avatar: {0}", arg));
			}
		}
	}
}
