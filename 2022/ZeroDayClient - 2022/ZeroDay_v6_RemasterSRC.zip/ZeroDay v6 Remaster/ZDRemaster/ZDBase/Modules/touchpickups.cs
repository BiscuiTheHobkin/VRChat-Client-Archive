﻿using System;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;
using VRC.SDKBase;

namespace ZDBase.Modules
{
	// Token: 0x02000043 RID: 67
	internal class touchpickups : MonoBehaviour
	{
		// Token: 0x060001A3 RID: 419 RVA: 0x0000C3AA File Offset: 0x0000A5AA
		public touchpickups(IntPtr id) : base(id)
		{
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0000C3B8 File Offset: 0x0000A5B8
		private void OnCollisionEnter(Collision col)
		{
			try
			{
				bool flag = col.gameObject.GetComponent<VRC_Pickup>();
				if (flag)
				{
					MelonCoroutines.Start(PickupSword.runaftergrav(col.gameObject.GetComponent<Rigidbody>()));
				}
			}
			catch
			{
				Logs.LogError("Failed", true);
			}
		}

		// Token: 0x04000153 RID: 339
		public static bool waitforcooldown;

		// Token: 0x04000154 RID: 340
		public static bool touchpickupstog;

		// Token: 0x04000155 RID: 341
		internal static touchpickups oAyLi2r8qXyMPd6SVqw;

		// Token: 0x04000156 RID: 342
		public static List<string> blist;
	}
}
