﻿using System;

namespace ZDBase.Modules.Events
{
	// Token: 0x02000046 RID: 70
	internal interface OnUIEvent
	{
		// Token: 0x060001AA RID: 426
		void UI();
	}
}
