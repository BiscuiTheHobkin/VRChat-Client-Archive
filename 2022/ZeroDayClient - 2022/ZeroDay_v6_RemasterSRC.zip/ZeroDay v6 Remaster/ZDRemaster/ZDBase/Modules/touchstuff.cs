﻿using System;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Udon;
using ZDBase.Utils;

namespace ZDBase.Modules
{
	// Token: 0x02000045 RID: 69
	internal class touchstuff : MonoBehaviour
	{
		// Token: 0x060001A7 RID: 423 RVA: 0x0000C45E File Offset: 0x0000A65E
		public touchstuff(IntPtr id) : base(id)
		{
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000C46C File Offset: 0x0000A66C
		private void OnCollisionEnter(Collision collision)
		{
			bool flag = collision.gameObject.name.Contains("VRCPlayer[Remote]");
			if (flag)
			{
				try
				{
					Utilities.StaffNotify(collision.gameObject.GetComponent<Player>().Method_Public_get_VRCPlayerApi_0().displayName + " - " + touchstuff.actionforontap);
					Logs.LogSuccess(collision.gameObject.GetComponent<Player>().Method_Public_get_VRCPlayerApi_0().displayName + " - " + touchstuff.actionforontap, false);
					VRCPlayer component = collision.gameObject.GetComponent<VRCPlayer>();
					string value = component._player.ToString();
					for (int i = 0; i < 29; i++)
					{
						string text = "Player Node (" + i.ToString() + ")";
						string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
						bool flag2 = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
						if (flag2)
						{
							UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
							bool flag3 = RoomManager.field_Internal_Static_ApiWorld_0.id == "wrld_dd036610-a246-4f52-bf01-9d7cea3405d7";
							if (flag3)
							{
								component2.SendCustomNetworkEvent(0, "Btn_Kill");
							}
							component2.SendCustomNetworkEvent(0, "SyncKill");
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0000C5DC File Offset: 0x0000A7DC
		private void OnTriggerEnter(Collider col)
		{
			bool flag = col.gameObject.name.Contains("VRCPlayer[Remote]");
			if (flag)
			{
				try
				{
					Utilities.StaffNotify(col.gameObject.GetComponent<Player>().Method_Public_get_VRCPlayerApi_0().displayName + " - " + touchstuff.actionforontap);
					Logs.LogSuccess(col.gameObject.GetComponent<Player>().Method_Public_get_VRCPlayerApi_0().displayName + " - " + touchstuff.actionforontap, false);
					VRCPlayer component = col.gameObject.GetComponent<VRCPlayer>();
					string value = component._player.ToString();
					for (int i = 0; i < 29; i++)
					{
						string text = "Player Node (" + i.ToString() + ")";
						string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
						bool flag2 = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
						if (flag2)
						{
							UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
							bool flag3 = RoomManager.field_Internal_Static_ApiWorld_0.id == "wrld_dd036610-a246-4f52-bf01-9d7cea3405d7";
							if (flag3)
							{
								component2.SendCustomNetworkEvent(0, "Btn_Kill");
							}
							component2.SendCustomNetworkEvent(0, "SyncKill");
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0400015A RID: 346
		public static bool cooldown;

		// Token: 0x0400015B RID: 347
		public static string actionforontap;

		// Token: 0x0400015C RID: 348
		internal static touchstuff wkjRdurQus78AaxVrx9;
	}
}
