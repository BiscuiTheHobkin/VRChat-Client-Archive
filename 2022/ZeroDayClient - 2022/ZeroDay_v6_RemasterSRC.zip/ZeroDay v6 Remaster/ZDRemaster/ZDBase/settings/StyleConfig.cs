﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace ZDBase.settings
{
	// Token: 0x02000040 RID: 64
	public class StyleConfig
	{
		// Token: 0x06000196 RID: 406 RVA: 0x0000BD7C File Offset: 0x00009F7C
		public static void savestyleconfig(string path)
		{
			styledata styledata = new styledata
			{
				redb = StyleConfig.redb,
				greenb = new float?(StyleConfig.greenb),
				blueb = new float?(StyleConfig.blueb),
				Transpb = new float?(StyleConfig.Transpb),
				HRed = new float?(StyleConfig.HRed),
				HGreen = new float?(StyleConfig.HGreen),
				HBlue = new float?(StyleConfig.HBlue),
				HTransp = new float?(StyleConfig.Transpb),
				TRed = new float?(StyleConfig.TRed),
				TGreen = new float?(StyleConfig.TGreen),
				TBlue = new float?(StyleConfig.TBlue),
				TTransp = new float?(StyleConfig.TTransp)
			};
			File.WriteAllText(path, JsonConvert.SerializeObject(styledata) ?? "");
		}

		// Token: 0x06000197 RID: 407 RVA: 0x0000BE70 File Offset: 0x0000A070
		public static void applyconfig(string path, styledata sta)
		{
			StyleConfig.redb = new float?(sta.redb.Value);
			StyleConfig.greenb = sta.greenb.Value;
			StyleConfig.blueb = sta.blueb.Value;
			StyleConfig.Transpb = sta.Transpb.Value;
			StyleConfig.HRed = sta.HRed.Value;
			StyleConfig.HGreen = sta.HGreen.Value;
			StyleConfig.HBlue = sta.HBlue.Value;
			StyleConfig.HTransp = sta.Transpb.Value;
			StyleConfig.TRed = sta.TRed.Value;
			StyleConfig.TGreen = sta.TGreen.Value;
			StyleConfig.TBlue = sta.TBlue.Value;
			StyleConfig.TTransp = sta.TTransp.Value;
			StyleConfig.savestyleconfig(path);
		}

		// Token: 0x04000133 RID: 307
		public static string Chatmsg;

		// Token: 0x04000134 RID: 308
		public static string JoyStick;

		// Token: 0x04000135 RID: 309
		public static string BiguiImg;

		// Token: 0x04000136 RID: 310
		public static string qmimg;

		// Token: 0x04000137 RID: 311
		public static string debuggerimg;

		// Token: 0x04000138 RID: 312
		public static string Playerlistimg;

		// Token: 0x04000139 RID: 313
		public static float? redb;

		// Token: 0x0400013A RID: 314
		public static float blueb;

		// Token: 0x0400013B RID: 315
		public static float greenb;

		// Token: 0x0400013C RID: 316
		public static float Transpb;

		// Token: 0x0400013D RID: 317
		public static float HRed;

		// Token: 0x0400013E RID: 318
		public static float HGreen;

		// Token: 0x0400013F RID: 319
		public static float HBlue;

		// Token: 0x04000140 RID: 320
		public static float HTransp;

		// Token: 0x04000141 RID: 321
		public static float TRed;

		// Token: 0x04000142 RID: 322
		public static float TGreen;

		// Token: 0x04000143 RID: 323
		public static float TBlue;

		// Token: 0x04000144 RID: 324
		public static float TTransp;

		// Token: 0x04000145 RID: 325
		public static bool backgoundbuttons;

		// Token: 0x04000146 RID: 326
		public static float Playerlisttransparancy;

		// Token: 0x04000147 RID: 327
		public static float debuggertrasnparancy;

		// Token: 0x04000148 RID: 328
		public static float qmtransparancy;

		// Token: 0x04000149 RID: 329
		public static float Biguitransparancy;

		// Token: 0x0400014A RID: 330
		public static float PlayerlistDim;

		// Token: 0x0400014B RID: 331
		public static float DebuggerDim;

		// Token: 0x0400014C RID: 332
		public static float QmDim;

		// Token: 0x0400014D RID: 333
		public static float BigmenuDim;
	}
}
