﻿using System;

namespace ZDBase.settings
{
	// Token: 0x0200003F RID: 63
	[Serializable]
	public class styledata
	{
		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600016B RID: 363 RVA: 0x0000BC0C File Offset: 0x00009E0C
		// (set) Token: 0x0600016C RID: 364 RVA: 0x0000BC14 File Offset: 0x00009E14
		public float? redb { get; set; }

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600016D RID: 365 RVA: 0x0000BC1D File Offset: 0x00009E1D
		// (set) Token: 0x0600016E RID: 366 RVA: 0x0000BC25 File Offset: 0x00009E25
		public float? blueb { get; set; }

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600016F RID: 367 RVA: 0x0000BC2E File Offset: 0x00009E2E
		// (set) Token: 0x06000170 RID: 368 RVA: 0x0000BC36 File Offset: 0x00009E36
		public float? greenb { get; set; }

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000171 RID: 369 RVA: 0x0000BC3F File Offset: 0x00009E3F
		// (set) Token: 0x06000172 RID: 370 RVA: 0x0000BC47 File Offset: 0x00009E47
		public float? Transpb { get; set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000173 RID: 371 RVA: 0x0000BC50 File Offset: 0x00009E50
		// (set) Token: 0x06000174 RID: 372 RVA: 0x0000BC58 File Offset: 0x00009E58
		public float? HRed { get; set; }

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000175 RID: 373 RVA: 0x0000BC61 File Offset: 0x00009E61
		// (set) Token: 0x06000176 RID: 374 RVA: 0x0000BC69 File Offset: 0x00009E69
		public float? HGreen { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000177 RID: 375 RVA: 0x0000BC72 File Offset: 0x00009E72
		// (set) Token: 0x06000178 RID: 376 RVA: 0x0000BC7A File Offset: 0x00009E7A
		public float? HBlue { get; set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000179 RID: 377 RVA: 0x0000BC83 File Offset: 0x00009E83
		// (set) Token: 0x0600017A RID: 378 RVA: 0x0000BC8B File Offset: 0x00009E8B
		public float? HTransp { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x0600017B RID: 379 RVA: 0x0000BC94 File Offset: 0x00009E94
		// (set) Token: 0x0600017C RID: 380 RVA: 0x0000BC9C File Offset: 0x00009E9C
		public float? TRed { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600017D RID: 381 RVA: 0x0000BCA5 File Offset: 0x00009EA5
		// (set) Token: 0x0600017E RID: 382 RVA: 0x0000BCAD File Offset: 0x00009EAD
		public float? TGreen { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x0600017F RID: 383 RVA: 0x0000BCB6 File Offset: 0x00009EB6
		// (set) Token: 0x06000180 RID: 384 RVA: 0x0000BCBE File Offset: 0x00009EBE
		public float? TBlue { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000181 RID: 385 RVA: 0x0000BCC7 File Offset: 0x00009EC7
		// (set) Token: 0x06000182 RID: 386 RVA: 0x0000BCCF File Offset: 0x00009ECF
		public float? TTransp { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000183 RID: 387 RVA: 0x0000BCD8 File Offset: 0x00009ED8
		// (set) Token: 0x06000184 RID: 388 RVA: 0x0000BCE0 File Offset: 0x00009EE0
		public bool? backgoundbuttons { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000185 RID: 389 RVA: 0x0000BCE9 File Offset: 0x00009EE9
		// (set) Token: 0x06000186 RID: 390 RVA: 0x0000BCF1 File Offset: 0x00009EF1
		public float? Playerlisttransparancy { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000187 RID: 391 RVA: 0x0000BCFA File Offset: 0x00009EFA
		// (set) Token: 0x06000188 RID: 392 RVA: 0x0000BD02 File Offset: 0x00009F02
		public float? debuggertrasnparancy { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000189 RID: 393 RVA: 0x0000BD0B File Offset: 0x00009F0B
		// (set) Token: 0x0600018A RID: 394 RVA: 0x0000BD13 File Offset: 0x00009F13
		public float? qmtransparancy { get; set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600018B RID: 395 RVA: 0x0000BD1C File Offset: 0x00009F1C
		// (set) Token: 0x0600018C RID: 396 RVA: 0x0000BD24 File Offset: 0x00009F24
		public float? Biguitransparancy { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x0600018D RID: 397 RVA: 0x0000BD2D File Offset: 0x00009F2D
		// (set) Token: 0x0600018E RID: 398 RVA: 0x0000BD35 File Offset: 0x00009F35
		public float? PlayerlistDim { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x0600018F RID: 399 RVA: 0x0000BD3E File Offset: 0x00009F3E
		// (set) Token: 0x06000190 RID: 400 RVA: 0x0000BD46 File Offset: 0x00009F46
		public float? DebuggerDim { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000191 RID: 401 RVA: 0x0000BD4F File Offset: 0x00009F4F
		// (set) Token: 0x06000192 RID: 402 RVA: 0x0000BD57 File Offset: 0x00009F57
		public float? QmDim { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000193 RID: 403 RVA: 0x0000BD60 File Offset: 0x00009F60
		// (set) Token: 0x06000194 RID: 404 RVA: 0x0000BD68 File Offset: 0x00009F68
		public float? BigmenuDim { get; set; }
	}
}
