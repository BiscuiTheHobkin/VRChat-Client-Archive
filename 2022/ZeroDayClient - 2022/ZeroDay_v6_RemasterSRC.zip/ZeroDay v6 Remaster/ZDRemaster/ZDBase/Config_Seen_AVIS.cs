﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ZDBase
{
	// Token: 0x02000033 RID: 51
	internal class Config_Seen_AVIS
	{
		// Token: 0x0600015A RID: 346 RVA: 0x0000B2E0 File Offset: 0x000094E0
		internal void SaveConfig()
		{
			string contents = JsonConvert.SerializeObject(this, 1);
			File.WriteAllText("ZDRemastered\\Config2.json", contents);
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000B304 File Offset: 0x00009504
		internal static Config_Seen_AVIS Load()
		{
			bool flag = !File.Exists("ZDRemastered\\Config2.json");
			Config_Seen_AVIS result;
			if (flag)
			{
				result = new Config_Seen_AVIS();
			}
			else
			{
				Config_Seen_AVIS.Instance = JsonConvert.DeserializeObject<Config_Seen_AVIS>(File.ReadAllText("ZDRemastered\\Config2.json"));
				result = Config_Seen_AVIS.Instance;
			}
			return result;
		}

		// Token: 0x0400011A RID: 282
		public List<AvatarObject> SEEN_AVIS = new List<AvatarObject>();

		// Token: 0x0400011B RID: 283
		public static Config_Seen_AVIS Instance;
	}
}
