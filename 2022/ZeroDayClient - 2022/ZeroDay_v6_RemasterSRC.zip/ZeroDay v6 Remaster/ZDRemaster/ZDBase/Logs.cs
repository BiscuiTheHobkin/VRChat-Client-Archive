﻿using System;
using MelonLoader;
using ZeroDayRemastered.Modules.MenuClass;

namespace ZDBase
{
	// Token: 0x0200002F RID: 47
	internal static class Logs
	{
		// Token: 0x06000136 RID: 310 RVA: 0x0000AC78 File Offset: 0x00008E78
		internal static void WriteToConsole(ConsoleColor Azura, string value1, string TextColor, ConsoleColor color, string Text)
		{
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write("[");
			Console.ForegroundColor = ConsoleColor.DarkMagenta;
			Console.Write(DateTime.Now.ToString("hh:mm:ss.ms"));
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write("] [");
			Console.ForegroundColor = Azura;
			Console.Write(value1);
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write("] [");
			Console.ForegroundColor = color;
			Console.Write(TextColor);
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write("]: ");
			Console.WriteLine(Text);
			Console.ResetColor();
		}

		// Token: 0x06000137 RID: 311 RVA: 0x0000AD1C File Offset: 0x00008F1C
		internal static void Log(string text, bool ToDebugger)
		{
			if (ToDebugger)
			{
				MainMenu.LogAPIDEBUGGER(text);
			}
			Logs.WriteToConsole(ConsoleColor.DarkMagenta, "ZeroDay", "APi", ConsoleColor.Magenta, text);
		}

		// Token: 0x06000138 RID: 312 RVA: 0x0000AD4C File Offset: 0x00008F4C
		internal static void LogError(string text, bool ToDebugger)
		{
			if (ToDebugger)
			{
				MainMenu.LogAPIDEBUGGER(text);
			}
			Logs.WriteToConsole(ConsoleColor.DarkMagenta, "ZeroDay", "ERROR", ConsoleColor.DarkRed, text);
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0000AD7C File Offset: 0x00008F7C
		internal static void LogSuccess(string text, bool ToDebugger)
		{
			if (ToDebugger)
			{
				MainMenu.LogAPIDEBUGGER(text);
			}
			Logs.WriteToConsole(ConsoleColor.DarkMagenta, "ZeroDay", "SUCCESS", ConsoleColor.Green, text);
		}

		// Token: 0x0600013A RID: 314 RVA: 0x0000ADAC File Offset: 0x00008FAC
		internal static void LogWarn(string text, bool ToDebugger)
		{
			if (ToDebugger)
			{
				MainMenu.LogAPIDEBUGGER(text);
			}
			Logs.WriteToConsole(ConsoleColor.DarkMagenta, "ZeroDay", "WARN", ConsoleColor.Yellow, text);
		}

		// Token: 0x040000B1 RID: 177
		private static MelonLogger.Instance instance = new MelonLogger.Instance("ZeroDay Remastered", ConsoleColor.DarkMagenta);
	}
}
