﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace ZDBase
{
	// Token: 0x02000030 RID: 48
	public class MainConfigSettings
	{
		// Token: 0x0600013C RID: 316 RVA: 0x0000ADF0 File Offset: 0x00008FF0
		internal void SaveConfig()
		{
			string contents = JsonConvert.SerializeObject(this, 1);
			File.WriteAllText("ZDRemastered\\Config.json", contents);
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000AE14 File Offset: 0x00009014
		internal static MainConfigSettings Load()
		{
			bool flag = !File.Exists("ZDRemastered\\Config.json");
			MainConfigSettings result;
			if (flag)
			{
				result = new MainConfigSettings();
			}
			else
			{
				MainConfigSettings.Instance = JsonConvert.DeserializeObject<MainConfigSettings>(File.ReadAllText("ZDRemastered\\Config.json"));
				result = MainConfigSettings.Instance;
			}
			return result;
		}

		// Token: 0x040000B2 RID: 178
		public string[] meshList = new string[]
		{
			"125k",
			"medusa",
			"inside",
			"outside",
			"mill",
			"Sphere_250k_poly"
		};

		// Token: 0x040000B3 RID: 179
		public string[] anticrashwhitelist = new string[0];

		// Token: 0x040000B4 RID: 180
		public int maxAudio;

		// Token: 0x040000B5 RID: 181
		public int maxLight;

		// Token: 0x040000B6 RID: 182
		public int maxDynamicBonesCollider;

		// Token: 0x040000B7 RID: 183
		public int maxMatirial;

		// Token: 0x040000B8 RID: 184
		public int maxCloth;

		// Token: 0x040000B9 RID: 185
		public int maxColliders;

		// Token: 0x040000BA RID: 186
		public int maxPoly;

		// Token: 0x040000BB RID: 187
		public int maxParticles;

		// Token: 0x040000BC RID: 188
		public float FPSSpoofValue;

		// Token: 0x040000BD RID: 189
		public int PINGSpoofValue;

		// Token: 0x040000BE RID: 190
		public bool ItemEsp;

		// Token: 0x040000BF RID: 191
		public bool BetterHighlights = false;

		// Token: 0x040000C0 RID: 192
		public bool BigPPEnergy = true;

		// Token: 0x040000C1 RID: 193
		public bool PlayerESP;

		// Token: 0x040000C2 RID: 194
		public bool NoBlindKillScreen;

		// Token: 0x040000C3 RID: 195
		public bool joinleavelogger;

		// Token: 0x040000C4 RID: 196
		public bool UdonLogger;

		// Token: 0x040000C5 RID: 197
		public bool blockphoton;

		// Token: 0x040000C6 RID: 198
		public bool InfiniteJump;

		// Token: 0x040000C7 RID: 199
		public bool PickupsESP;

		// Token: 0x040000C8 RID: 200
		public bool Event8blockNonfriends = false;

		// Token: 0x040000C9 RID: 201
		public bool Event8blockfriend = false;

		// Token: 0x040000CA RID: 202
		public bool Event9blockNonfriends = false;

		// Token: 0x040000CB RID: 203
		public bool Event9blockfriend = false;

		// Token: 0x040000CC RID: 204
		public bool Event6blockNonfriends = false;

		// Token: 0x040000CD RID: 205
		public bool Event6blockfriend = false;

		// Token: 0x040000CE RID: 206
		public bool Event4blockNonfriends = false;

		// Token: 0x040000CF RID: 207
		public bool Event4blockfriend = false;

		// Token: 0x040000D0 RID: 208
		public bool Event33blockNonfriends = false;

		// Token: 0x040000D1 RID: 209
		public bool Event33blockfriend = false;

		// Token: 0x040000D2 RID: 210
		public bool Event210blockNonfriends = false;

		// Token: 0x040000D3 RID: 211
		public bool Event210blockfriend = false;

		// Token: 0x040000D4 RID: 212
		public bool Event209blockNonfriends = false;

		// Token: 0x040000D5 RID: 213
		public bool Event209blockfriend = false;

		// Token: 0x040000D6 RID: 214
		public bool EventBlock;

		// Token: 0x040000D7 RID: 215
		public bool EventLog;

		// Token: 0x040000D8 RID: 216
		public bool ModerationLogs;

		// Token: 0x040000D9 RID: 217
		public bool SpotfyLogs;

		// Token: 0x040000DA RID: 218
		public bool GHOSTGODMODE;

		// Token: 0x040000DB RID: 219
		public bool murderGodMode;

		// Token: 0x040000DC RID: 220
		public bool CalibrationSaverEnabled;

		// Token: 0x040000DD RID: 221
		public bool Rock_jump;

		// Token: 0x040000DE RID: 222
		public bool TouchGB;

		// Token: 0x040000DF RID: 223
		public bool HeadBones;

		// Token: 0x040000E0 RID: 224
		public bool ChestBones;

		// Token: 0x040000E1 RID: 225
		public bool HipBones;

		// Token: 0x040000E2 RID: 226
		public bool HandColliders;

		// Token: 0x040000E3 RID: 227
		public bool FeetColliders;

		// Token: 0x040000E4 RID: 228
		public bool HideDiscordName;

		// Token: 0x040000E5 RID: 229
		public bool HideDiscordWorld;

		// Token: 0x040000E6 RID: 230
		public bool HudLog;

		// Token: 0x040000E7 RID: 231
		public float Frames;

		// Token: 0x040000E8 RID: 232
		public int Ping;

		// Token: 0x040000E9 RID: 233
		public bool FramesSpoofer;

		// Token: 0x040000EA RID: 234
		public bool PingSpoof;

		// Token: 0x040000EB RID: 235
		public bool QSpoof;

		// Token: 0x040000EC RID: 236
		public bool nostats;

		// Token: 0x040000ED RID: 237
		public bool M_hidavaatrs;

		// Token: 0x040000EE RID: 238
		public bool RGBFriends;

		// Token: 0x040000EF RID: 239
		public bool OptimizeGameLoad;

		// Token: 0x040000F0 RID: 240
		public float m_Distance;

		// Token: 0x040000F1 RID: 241
		public float FlightSpeed;

		// Token: 0x040000F2 RID: 242
		public bool CleanAvatars;

		// Token: 0x040000F3 RID: 243
		public bool NotifSounds;

		// Token: 0x040000F4 RID: 244
		public bool LogMedia;

		// Token: 0x040000F5 RID: 245
		public bool toggleconsole;

		// Token: 0x040000F6 RID: 246
		public bool toggleplayerlist;

		// Token: 0x040000F7 RID: 247
		public float TRed = 1f;

		// Token: 0x040000F8 RID: 248
		public float TGreen = 0f;

		// Token: 0x040000F9 RID: 249
		public float TBlue = 0f;

		// Token: 0x040000FA RID: 250
		public float TTransp = 1f;

		// Token: 0x040000FB RID: 251
		public float HRed = 1f;

		// Token: 0x040000FC RID: 252
		public float HGreen = 0f;

		// Token: 0x040000FD RID: 253
		public float HBlue = 0f;

		// Token: 0x040000FE RID: 254
		public float HTransp = 1f;

		// Token: 0x040000FF RID: 255
		public float redb = 1f;

		// Token: 0x04000100 RID: 256
		public float greenb = 0f;

		// Token: 0x04000101 RID: 257
		public float blueb = 0f;

		// Token: 0x04000102 RID: 258
		public float Transpb = 1f;

		// Token: 0x04000103 RID: 259
		public static MainConfigSettings Instance;

		// Token: 0x04000104 RID: 260
		public static bool flight;

		// Token: 0x04000105 RID: 261
		public static bool CSGO;

		// Token: 0x04000106 RID: 262
		public static bool Thirdperson;

		// Token: 0x04000107 RID: 263
		public static bool Rotator;

		// Token: 0x04000108 RID: 264
		public static bool InvisibleJoin;

		// Token: 0x04000109 RID: 265
		public static bool DeathHands;

		// Token: 0x0400010A RID: 266
		public static bool AntiUdon;

		// Token: 0x0400010B RID: 267
		public static bool PickupsOrbit;

		// Token: 0x0400010C RID: 268
		public static bool m_HideAvatars;

		// Token: 0x0400010D RID: 269
		public static float DistanceHide;
	}
}
