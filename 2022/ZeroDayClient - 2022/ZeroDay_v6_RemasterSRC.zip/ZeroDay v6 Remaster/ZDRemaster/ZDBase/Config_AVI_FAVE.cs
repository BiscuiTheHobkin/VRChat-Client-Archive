﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ZDBase
{
	// Token: 0x02000032 RID: 50
	public class Config_AVI_FAVE
	{
		// Token: 0x06000157 RID: 343 RVA: 0x0000B260 File Offset: 0x00009460
		internal void SaveConfig()
		{
			string contents = JsonConvert.SerializeObject(this, 0);
			File.WriteAllText("ZDRemastered\\Config1.json", contents);
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000B284 File Offset: 0x00009484
		internal static Config_AVI_FAVE Load()
		{
			bool flag = !File.Exists("ZDRemastered\\Config1.json");
			Config_AVI_FAVE result;
			if (flag)
			{
				result = new Config_AVI_FAVE();
			}
			else
			{
				Config_AVI_FAVE.Instance = JsonConvert.DeserializeObject<Config_AVI_FAVE>(File.ReadAllText("ZDRemastered\\Config1.json"));
				result = Config_AVI_FAVE.Instance;
			}
			return result;
		}

		// Token: 0x04000118 RID: 280
		public List<AvatarObject> Avis = new List<AvatarObject>();

		// Token: 0x04000119 RID: 281
		public static Config_AVI_FAVE Instance;
	}
}
