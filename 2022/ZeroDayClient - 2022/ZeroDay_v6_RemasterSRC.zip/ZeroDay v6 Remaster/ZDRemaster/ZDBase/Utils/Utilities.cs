﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using MelonLoader;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC;
using ZDBase.Utils.Wrappers;

namespace ZDBase.Utils
{
	// Token: 0x0200004E RID: 78
	internal static class Utilities
	{
		// Token: 0x06000206 RID: 518 RVA: 0x00010C44 File Offset: 0x0000EE44
		internal static void NoHitbox(bool state)
		{
			bool flag = !(VRCPlayer.field_Internal_Static_VRCPlayer_0 != null);
			if (flag)
			{
				bool flag2 = Utilities.head == null;
				if (flag2)
				{
					Utilities.head = VRCVrCamera.field_Private_Static_VRCVrCamera_0.transform.parent;
				}
				bool flag3 = Utilities.animController == null;
				if (flag3)
				{
					Utilities.animController = VRCPlayer.field_Internal_Static_VRCPlayer_0.GetComponentInChildren<VRC_AnimationController>();
				}
				bool flag4 = Utilities.ikController == null;
				if (flag4)
				{
					Utilities.ikController = VRCPlayer.field_Internal_Static_VRCPlayer_0.GetComponentInChildren<VRCVrIkController>();
				}
				VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += new Vector3(0f, (float)(state ? -4 : 4), 0f);
				Utilities.animController.field_Private_Boolean_0 = !state;
				Utilities.ikController.field_Private_Boolean_0 = true;
				if (state)
				{
					Utilities.head.localPosition += new Vector3(0f, 4f / Utilities.head.parent.transform.localScale.y, 0f);
				}
				else
				{
					Utilities.head.localPosition = Vector3.zero;
				}
			}
		}

		// Token: 0x06000207 RID: 519 RVA: 0x00010D80 File Offset: 0x0000EF80
		internal static bool ClientDetect(this Player player)
		{
			bool flag = player.GetFrames() <= 90f && player.GetFrames() >= 1f && player.GetPing() <= 665;
			return !flag || player.GetPing() < 0;
		}

		// Token: 0x06000208 RID: 520 RVA: 0x00010DD4 File Offset: 0x0000EFD4
		internal static Color GetRainbow()
		{
			return new Color((float)Math.Sin((double)(1f * Time.time)) * 0.5f + 0.5f, (float)Math.Sin((double)(1f * Time.time) + 2.0933333333333333) * 0.5f + 0.5f, (float)Math.Sin((double)(1f * Time.time) + 4.1866666666666665) * 0.5f + 0.5f);
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00010E5C File Offset: 0x0000F05C
		internal static Image Notify(string Text)
		{
			Utilities.<>c__DisplayClass7_0 CS$<>8__locals1 = new Utilities.<>c__DisplayClass7_0();
			CS$<>8__locals1.Text = Text;
			GameObject gameObject = GameObject.Find("UserInterface/UnscaledUI/HudContent/Hud");
			Transform transform = gameObject.transform.Find("NotificationDotParent");
			CS$<>8__locals1.indicator = Object.Instantiate<GameObject>(gameObject.transform.Find("NotificationDotParent/NotificationDot").gameObject, transform, false).Cast<GameObject>();
			CS$<>8__locals1.indicator.name = "AzureX Notification";
			CS$<>8__locals1.indicator.SetActive(true);
			CS$<>8__locals1.indicator.transform.localPosition = new Vector3(-770f, 150f, 0f);
			CS$<>8__locals1.image = CS$<>8__locals1.indicator.GetComponent<Image>();
			CS$<>8__locals1.image.color = Color.white;
			CS$<>8__locals1.image.sprite = null;
			MelonCoroutines.Start(CS$<>8__locals1.<Notify>g__GetNotificationsSprite|1());
			return CS$<>8__locals1.image;
		}

		// Token: 0x0600020A RID: 522
		[DllImport("user32.dll")]
		internal static extern bool SetWindowText(IntPtr hwnd, string lpString);

		// Token: 0x0600020B RID: 523 RVA: 0x00010F42 File Offset: 0x0000F142
		internal static IEnumerator animation()
		{
			string nct12 = "Z";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E ";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D A";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D A Y";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D A Y V";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D A Y V 4";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			nct12 = "Z E R O D A Y V 4 X_X";
			Utilities.SetWindowText(Utilities.window, nct12);
			yield return new WaitForSeconds(1f);
			while (nct12.Length != 0)
			{
				nct12 = nct12.Remove(nct12.Length - 1);
				Utilities.SetWindowText(Utilities.window, nct12);
				yield return new WaitForSeconds(0.5f);
			}
			MelonCoroutines.Start(Utilities.animation());
			yield break;
		}

		// Token: 0x0600020C RID: 524 RVA: 0x00010F4C File Offset: 0x0000F14C
		internal static void reset(GameObject gameobject)
		{
			gameobject.transform.localPosition = new Vector3(0f, 0f, 0f);
			gameobject.transform.localRotation = new Quaternion(0f, 0f, 0f, 0f);
			gameobject.transform.localScale = new Vector3(1f, 1f, 1f);
		}

		// Token: 0x0600020D RID: 525 RVA: 0x00010FBF File Offset: 0x0000F1BF
		internal static IEnumerator loadbundle()
		{
			WebClient wc = new WebClient();
			byte[] bytes = wc.DownloadData("http://nocturnal-client.xyz/cl/Download/Assets/join");
			AssetBundle myLoadedAssetBundle = AssetBundle.LoadFromMemory(bytes);
			bool flag = !(myLoadedAssetBundle == null);
			if (flag)
			{
				GameObject toinst = myLoadedAssetBundle.LoadAsset<GameObject>("JoinNot");
				myLoadedAssetBundle.Unload(false);
				GameObject instanciate = Object.Instantiate<GameObject>(toinst, GameObject.Find("/UserInterface").transform.Find("UnscaledUI/HudContent").transform);
				instanciate.name = "Join Logger";
				Object.Destroy(instanciate.GetComponent<Canvas>());
				Object.Destroy(instanciate.GetComponent<CanvasScaler>());
				Object.Destroy(instanciate.GetComponent<GraphicRaycaster>());
				Utilities.reset(instanciate);
				instanciate.transform.localScale = new Vector3(1.3f, 1.3f, 1.3f);
				Utilities.uia = instanciate.transform.Find("JoinElement").gameObject;
				instanciate.transform.Find("JoinElement/Image").gameObject.transform.localPosition = new Vector3(0f, -330f, 0f);
				byte[] bytess = wc.DownloadData("http://nocturnal-client.xyz/cl/Download/Assets/join2");
				AssetBundle myLoadedAssetBundle2 = AssetBundle.LoadFromMemory(bytess);
				bool flag2 = !(myLoadedAssetBundle2 == null);
				if (flag2)
				{
					GameObject toinsts = myLoadedAssetBundle2.LoadAsset<GameObject>("JoinNot2");
					myLoadedAssetBundle2.Unload(false);
					GameObject instanciates = Object.Instantiate<GameObject>(toinsts, GameObject.Find("/UserInterface").transform.Find("UnscaledUI/HudContent").transform);
					instanciates.name = "Leave Logger";
					Object.Destroy(instanciates.GetComponent<Canvas>());
					Object.Destroy(instanciates.GetComponent<CanvasScaler>());
					Object.Destroy(instanciates.GetComponent<GraphicRaycaster>());
					Utilities.reset(instanciates);
					instanciates.transform.localScale = new Vector3(1.3f, 1.3f, 1.3f);
					Utilities.uia1 = instanciates.transform.Find("JoinElement").gameObject;
					instanciates.transform.Find("JoinElement/Image").gameObject.transform.localPosition = new Vector3(0f, -330f, 0f);
					yield return null;
					toinsts = null;
					instanciates = null;
				}
				toinst = null;
				instanciate = null;
				bytess = null;
				myLoadedAssetBundle2 = null;
			}
			yield break;
		}

		// Token: 0x0600020E RID: 526 RVA: 0x00010FC7 File Offset: 0x0000F1C7
		internal static IEnumerator loadparticles()
		{
			WebClient wc = new WebClient();
			byte[] bytesa = wc.DownloadData("http://nocturnal-client.xyz/cl/Download/Assets/loadingscreen");
			AssetBundle myLoadedAssetBundle = AssetBundle.LoadFromMemory(bytesa);
			bool flag = myLoadedAssetBundle == null;
			if (flag)
			{
				Logs.LogError("Failed to load AssetBundle!", false);
				yield break;
			}
			GameObject partsystem = myLoadedAssetBundle.LoadAsset<GameObject>("ParticleLoader");
			GameObject gmj = Object.Instantiate<GameObject>(partsystem, GameObject.Find("/UserInterface").transform.Find("MenuContent/Popups/LoadingPopup").transform);
			gmj.transform.localPosition = new Vector3(0f, 0f, 8000f);
			gmj.transform.Find("finished").gameObject.transform.localPosition = new Vector3(0f, 0f, 10000f);
			gmj.transform.Find("finished/Other").gameObject.transform.localPosition = new Vector3(0f, 0f, 3000f);
			gmj.transform.Find("middle").gameObject.transform.localPosition = new Vector3(-50f, 0f, 10000f);
			gmj.transform.Find("cirlce mid").gameObject.transform.localPosition = new Vector3(-673.8608f, 0f, 4000f);
			gmj.transform.Find("spawn").gameObject.transform.localPosition = new Vector3(800f, 0f, -8500f);
			foreach (ParticleSystem gmjs in gmj.GetComponentsInChildren<ParticleSystem>(true))
			{
				gmjs.startColor = new Color(1f, 0f, 1f);
				gmjs.trails.colorOverTrail = new Color(0.5f, 0f, 1f);
				gmjs = null;
			}
			IEnumerator<ParticleSystem> enumerator = null;
			GameObject.Find("/UserInterface").transform.Find("MenuContent/Popups/LoadingPopup/3DElements").gameObject.SetActive(false);
			while (GameObject.Find("/UserInterface").transform.Find("DesktopUImanager") == null)
			{
				yield return null;
			}
			GameObject toload = myLoadedAssetBundle.LoadAsset<GameObject>("Holder");
			myLoadedAssetBundle.Unload(false);
			GameObject gmjsa = Object.Instantiate<GameObject>(toload, GameObject.Find("/UserInterface").transform.Find("DesktopUImanager").transform);
			gmjsa.transform.localPosition = new Vector3(0f, 360.621f, 700f);
			gmjsa.transform.localRotation = new Quaternion(0f, 0f, 0f, 0f);
			gmjsa.transform.localScale = new Vector3(1f, 1f, 1f);
			Transform p = gmjsa.transform.Find("Particle System").transform;
			p.localScale = new Vector3(0.08f, 0.08f, 0.08f);
			p.localPosition = new Vector3(0f, 64.16f, 7.2f);
			Transform p2 = gmjsa.transform.Find("Particle System (1)").transform;
			p2.localScale = new Vector3(0.06f, 0.06f, 0.06f);
			p2.localPosition = new Vector3(-30.78f, -321.5403f, 8.54f);
			yield return null;
			yield break;
		}

		// Token: 0x0600020F RID: 527 RVA: 0x00010FCF File Offset: 0x0000F1CF
		internal static IEnumerator StartModeration(float Vol)
		{
			UnityWebRequest www = UnityWebRequest.Get("//music.wixstatic.com/preview/bcf284_b2094441ec604384a5002159e8eb73ea-128.mp3");
			yield return www.SendWebRequest();
			bool flag = www.isNetworkError || www.isHttpError;
			if (flag)
			{
				MelonLogger.LogError(www.error);
			}
			else
			{
				AudioClip t = WebRequestWWW.InternalCreateAudioClipUsingDH(www.downloadHandler, www.url, false, false, 0);
				GameObject AudioObject = new GameObject();
				AudioObject.transform.parent = GameObject.Find("/UserInterface").transform;
				AudioObject.transform.position = ((Component)VRCPlayer.field_Internal_Static_VRCPlayer_0).transform.position;
				AudioObject.AddComponent<AudioSource>();
				AudioObject.GetComponent<AudioSource>().clip = t;
				AudioObject.GetComponent<AudioSource>().volume = Vol;
				AudioObject.GetComponent<AudioSource>().Play();
				yield return new WaitForSeconds(2f);
				Object.Destroy(AudioObject);
				t = null;
				AudioObject = null;
			}
			yield break;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00010FE0 File Offset: 0x0000F1E0
		internal static void StaffNotify(string text)
		{
			Utilities.uia.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = text;
			Utilities.uia.SetActive(false);
			Utilities.uia.SetActive(true);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00011030 File Offset: 0x0000F230
		internal static Image StaffNotify1(string Text)
		{
			Utilities.<>c__DisplayClass18_0 CS$<>8__locals1 = new Utilities.<>c__DisplayClass18_0();
			CS$<>8__locals1.Text = Text;
			GameObject gameObject = GameObject.Find("UserInterface/UnscaledUI/HudContent/Hud");
			Transform transform = gameObject.transform.Find("NotificationDotParent");
			CS$<>8__locals1.indicator = Object.Instantiate<GameObject>(gameObject.transform.Find("NotificationDotParent/NotificationDot").gameObject, transform, false).Cast<GameObject>();
			CS$<>8__locals1.indicator.name = "AzureX Notification";
			CS$<>8__locals1.indicator.SetActive(true);
			CS$<>8__locals1.indicator.transform.localPosition = new Vector3(-770f, 150f, 0f);
			CS$<>8__locals1.image = CS$<>8__locals1.indicator.GetComponent<Image>();
			CS$<>8__locals1.image.color = Color.white;
			CS$<>8__locals1.image.sprite = null;
			MelonCoroutines.Start(CS$<>8__locals1.<StaffNotify1>g__GetNotificationsSprite|1());
			return CS$<>8__locals1.image;
		}

		// Token: 0x06000212 RID: 530 RVA: 0x00011118 File Offset: 0x0000F318
		internal static void StartProcess(string Path, string Commands)
		{
			using (Process process = new Process())
			{
				process.StartInfo.FileName = Path;
				process.StartInfo.Arguments = Commands;
				process.StartInfo.UseShellExecute = true;
				process.Start();
			}
		}

		// Token: 0x06000213 RID: 531 RVA: 0x0001117C File Offset: 0x0000F37C
		[CompilerGenerated]
		internal static IEnumerator <Notify>g__Animation|7_0(GameObject Object)
		{
			int num;
			for (int I2 = 0; I2 < 20; I2 = num + 1)
			{
				yield return new WaitForSeconds(0.03f);
				Object.transform.localPosition += new Vector3(30f, 0f, 0f);
				num = I2;
			}
			yield return new WaitForSeconds(4f);
			for (int I3 = 0; I3 < 20; I3 = num + 1)
			{
				yield return new WaitForSeconds(0.03f);
				Object.transform.localPosition -= new Vector3(50f, 0f, 0f);
				num = I3;
			}
			Object.Destroy(Object);
			Utilities.IsRunning = false;
			yield break;
		}

		// Token: 0x06000214 RID: 532 RVA: 0x0001119C File Offset: 0x0000F39C
		[CompilerGenerated]
		internal static IEnumerator <StaffNotify1>g__Animation|18_0(GameObject Object)
		{
			int num;
			for (int I2 = 0; I2 < 20; I2 = num + 1)
			{
				yield return new WaitForSeconds(0.03f);
				Object.transform.localPosition += new Vector3(30f, 0f, 0f);
				num = I2;
			}
			yield return new WaitForSeconds(4f);
			for (int I3 = 0; I3 < 20; I3 = num + 1)
			{
				yield return new WaitForSeconds(0.03f);
				Object.transform.localPosition -= new Vector3(50f, 0f, 0f);
				num = I3;
			}
			Object.Destroy(Object);
			Utilities.IsRunning = false;
			yield break;
		}

		// Token: 0x0400017F RID: 383
		private static Transform head;

		// Token: 0x04000180 RID: 384
		private static VRC_AnimationController animController;

		// Token: 0x04000181 RID: 385
		private static VRCVrIkController ikController;

		// Token: 0x04000182 RID: 386
		internal static bool IsRunning;

		// Token: 0x04000183 RID: 387
		internal static GameObject uia;

		// Token: 0x04000184 RID: 388
		internal static IntPtr window;

		// Token: 0x04000185 RID: 389
		internal static GameObject uia1;
	}
}
