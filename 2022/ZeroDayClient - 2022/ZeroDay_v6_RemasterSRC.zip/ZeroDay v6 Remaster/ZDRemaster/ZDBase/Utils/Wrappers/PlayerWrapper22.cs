﻿using System;
using System.Collections.Generic;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.DataModel;
using VRC.UI;
using VRC.UI.Elements.Menus;

namespace ZDBase.Utils.Wrappers
{
	// Token: 0x02000050 RID: 80
	internal static class PlayerWrapper22
	{
		// Token: 0x06000243 RID: 579 RVA: 0x000119A0 File Offset: 0x0000FBA0
		private static VRCPlayer Local_Player()
		{
			return VRCPlayer.field_Internal_Static_VRCPlayer_0;
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000244 RID: 580 RVA: 0x000119B8 File Offset: 0x0000FBB8
		public static string GetUserID
		{
			get
			{
				return PlayerWrapper22.LocalVRCPlayer.Method_Public_get_VRCPlayerApi_0().playerId.ToString();
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000245 RID: 581 RVA: 0x000119E4 File Offset: 0x0000FBE4
		public static VRCPlayer LocalVRCPlayer
		{
			get
			{
				return VRCPlayer.field_Internal_Static_VRCPlayer_0;
			}
		}

		// Token: 0x06000246 RID: 582 RVA: 0x000119FC File Offset: 0x0000FBFC
		public static float GetFrames(this Player player)
		{
			bool flag = player.Method_Internal_get_PlayerNet_0().Method_Public_get_Byte_0() == 0;
			float result;
			if (flag)
			{
				result = 0f;
			}
			else
			{
				result = (float)((int)(1000f / (float)player.Method_Internal_get_PlayerNet_0().Method_Public_get_Byte_0()));
			}
			return result;
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00011A40 File Offset: 0x0000FC40
		public static string GetPlatform(this Player player)
		{
			bool isOnMobile = player.Method_Internal_get_APIUser_0().IsOnMobile;
			bool flag = isOnMobile;
			string result;
			if (flag)
			{
				result = "Q";
			}
			else
			{
				bool flag2 = player.Method_Public_get_VRCPlayerApi_0().IsUserInVR();
				bool flag3 = flag2;
				if (flag3)
				{
					result = "<color=#CE00D5>VR</color>";
				}
				else
				{
					result = "<color=grey>PC</color>";
				}
			}
			return result;
		}

		// Token: 0x06000248 RID: 584 RVA: 0x00011A98 File Offset: 0x0000FC98
		public static short GetPing(this Player player)
		{
			return player._playerNet.field_Private_Int16_0;
		}

		// Token: 0x06000249 RID: 585 RVA: 0x00011AB8 File Offset: 0x0000FCB8
		public static bool IsBot(this Player player)
		{
			return (player.GetPing() <= 0 && player.GetFrames() <= 0f) || player.GetFrames() <= -1f || player.transform.position == Vector3.zero;
		}

		// Token: 0x0600024A RID: 586 RVA: 0x00011B08 File Offset: 0x0000FD08
		public static bool ZeroPingFPS(this Player player)
		{
			return player.GetPing() <= 0 && player.GetFrames() <= 0f && player.GetFrames() <= -1f;
		}

		// Token: 0x0600024B RID: 587 RVA: 0x00011B44 File Offset: 0x0000FD44
		public static bool VectorZero(this Player player)
		{
			return (player.GetPing() <= 0 && player.GetFrames() <= 0f) || player.transform.position == Vector3.zero;
		}

		// Token: 0x0600024C RID: 588 RVA: 0x00011B84 File Offset: 0x0000FD84
		public static IUser GetSelectedUser(this SelectedUserMenuQM selectMenu)
		{
			return selectMenu.field_Private_IUser_0;
		}

		// Token: 0x0600024D RID: 589 RVA: 0x00011B9C File Offset: 0x0000FD9C
		public static Color GetTrustColor(this Player player)
		{
			return VRCPlayer.Method_Public_Static_Color_APIUser_0(player.Method_Internal_get_APIUser_0());
		}

		// Token: 0x0600024E RID: 590 RVA: 0x00011BBC File Offset: 0x0000FDBC
		public static void ClearAssets()
		{
			AssetBundleDownloadManager.field_Private_Static_AssetBundleDownloadManager_0.field_Private_Cache_0.ClearCache();
			AssetBundleDownloadManager.field_Private_Static_AssetBundleDownloadManager_0.field_Private_Queue_1_AssetBundleDownload_0.Clear();
			AssetBundleDownloadManager.field_Private_Static_AssetBundleDownloadManager_0.field_Private_Queue_1_AssetBundleDownload_1.Clear();
		}

		// Token: 0x0600024F RID: 591 RVA: 0x00011C00 File Offset: 0x0000FE00
		public static int CrashDetected(this Player player)
		{
			byte field_Private_Byte_ = player._playerNet.field_Private_Byte_0;
			byte field_Private_Byte_2 = player._playerNet.field_Private_Byte_1;
			bool flag = field_Private_Byte_ == player._playerNet.field_Private_Byte_0 && field_Private_Byte_2 == player._playerNet.field_Private_Byte_1;
			bool flag2 = flag;
			if (flag2)
			{
				PlayerWrapper22.noUpdateCount++;
			}
			else
			{
				PlayerWrapper22.noUpdateCount = 0;
			}
			return PlayerWrapper22.noUpdateCount;
		}

		// Token: 0x06000250 RID: 592 RVA: 0x00011C70 File Offset: 0x0000FE70
		public static string GetFramesColord(this Player player)
		{
			float frames = player.GetFrames();
			bool flag = frames > 80f;
			bool flag2 = flag;
			string result;
			if (flag2)
			{
				result = "<color=green>" + frames.ToString() + "</color>";
			}
			else
			{
				bool flag3 = frames > 30f;
				bool flag4 = flag3;
				if (flag4)
				{
					result = "<color=yellow>" + frames.ToString() + "</color>";
				}
				else
				{
					result = "<color=red>" + frames.ToString() + "</color>";
				}
			}
			return result;
		}

		// Token: 0x06000251 RID: 593 RVA: 0x00011D00 File Offset: 0x0000FF00
		public static string GetPingColord(this Player player)
		{
			short ping = player.GetPing();
			bool flag = ping > 150;
			bool flag2 = flag;
			string result;
			if (flag2)
			{
				result = "<color=red>" + ping.ToString() + "</color>";
			}
			else
			{
				bool flag3 = ping > 75;
				bool flag4 = flag3;
				if (flag4)
				{
					result = "<color=yellow>" + ping.ToString() + "</color>";
				}
				else
				{
					result = "<color=green>" + ping.ToString() + "</color>";
				}
			}
			return result;
		}

		// Token: 0x06000252 RID: 594 RVA: 0x00011D8A File Offset: 0x0000FF8A
		public static void SetHide(this VRCPlayer Instance, bool State)
		{
			Instance._player.SetHide(State);
		}

		// Token: 0x06000253 RID: 595 RVA: 0x00011D9A File Offset: 0x0000FF9A
		public static void SetHide(this Player Instance, bool State)
		{
			Instance.transform.Find("ForwardDirection").gameObject.active = !State;
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00011DBC File Offset: 0x0000FFBC
		public static void ChangeAvatar(string AvatarID)
		{
			PageAvatar component = GameObject.Find("Screens").transform.Find("Avatar").GetComponent<PageAvatar>();
			component.field_Public_SimpleAvatarPedestal_0.field_Internal_ApiAvatar_0 = new ApiAvatar
			{
				id = AvatarID
			};
			component.ChangeToSelectedAvatar();
		}

		// Token: 0x04000186 RID: 390
		private static GameObject avatarPreviewBase;

		// Token: 0x04000187 RID: 391
		private static int noUpdateCount = 0;

		// Token: 0x04000188 RID: 392
		public static string backupID = "";

		// Token: 0x04000189 RID: 393
		public static Dictionary<int, Player> PlayersActorID = new Dictionary<int, Player>();
	}
}
