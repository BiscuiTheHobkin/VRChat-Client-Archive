﻿using System;
using System.Collections.Generic;
using VRC;
using VRC.Core;
using VRC.SDKBase;

namespace ZDBase.Utils.Wrappers
{
	// Token: 0x02000051 RID: 81
	internal static class WorldWrapper
	{
		// Token: 0x06000256 RID: 598 RVA: 0x00011E28 File Offset: 0x00010028
		internal static ApiWorld CurrentWorld()
		{
			return RoomManager.field_Internal_Static_ApiWorld_0;
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00011E40 File Offset: 0x00010040
		internal static ApiWorldInstance CurrentInstance()
		{
			return RoomManager.field_Internal_Static_ApiWorldInstance_0;
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00011E58 File Offset: 0x00010058
		internal static IEnumerable<Player> GetPlayers()
		{
			return PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0.ToArray();
		}

		// Token: 0x06000259 RID: 601 RVA: 0x00011E7C File Offset: 0x0001007C
		internal static bool IsInRoom()
		{
			return RoomManager.field_Internal_Static_ApiWorld_0 != null && RoomManager.field_Internal_Static_ApiWorldInstance_0 != null;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x00011EA0 File Offset: 0x000100A0
		internal static int GetPlayerCount()
		{
			return PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0.Count;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00011EC4 File Offset: 0x000100C4
		internal static string GetJoinID()
		{
			return WorldWrapper.CurrentInstance().id;
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00011EE0 File Offset: 0x000100E0
		internal static void JoinWorld(string worldID)
		{
			Networking.GoToRoom(worldID);
		}
	}
}
