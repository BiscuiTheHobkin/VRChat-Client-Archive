﻿using System;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;

namespace ZDBase.Utils.Wrappers
{
	// Token: 0x0200004F RID: 79
	internal static class PlayerExtensions
	{
		// Token: 0x06000215 RID: 533 RVA: 0x000111BC File Offset: 0x0000F3BC
		public static APIUser GetAPIUser(this Player Instance)
		{
			return Instance.Method_Internal_get_APIUser_0();
		}

		// Token: 0x06000216 RID: 534 RVA: 0x000111D4 File Offset: 0x0000F3D4
		public static APIUser GetAPIUser(this VRCPlayer Instance)
		{
			return Instance._player.Method_Internal_get_APIUser_0();
		}

		// Token: 0x06000217 RID: 535 RVA: 0x000111F4 File Offset: 0x0000F3F4
		public static APIUser GetAPIUser(this PlayerNet Instance)
		{
			return Instance._vrcPlayer._player.Method_Internal_get_APIUser_0();
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00011218 File Offset: 0x0000F418
		public static Player GetPlayer(this VRCPlayer Instance)
		{
			return Instance._player;
		}

		// Token: 0x06000219 RID: 537 RVA: 0x00011230 File Offset: 0x0000F430
		public static Player GetPlayer(this PlayerNet Instance)
		{
			return Instance.Method_Public_get_Player_0();
		}

		// Token: 0x0600021A RID: 538 RVA: 0x00011248 File Offset: 0x0000F448
		public static VRCPlayer GetVRCPlayer(this Player Instance)
		{
			return Instance._vrcplayer;
		}

		// Token: 0x0600021B RID: 539 RVA: 0x00011260 File Offset: 0x0000F460
		public static VRCPlayer GetVRCPlayer(this PlayerNet Instance)
		{
			return Instance._vrcPlayer;
		}

		// Token: 0x0600021C RID: 540 RVA: 0x00011278 File Offset: 0x0000F478
		public static VRCPlayerApi GetVRCPlayerApi(this Player Instance)
		{
			return Instance.Method_Public_get_VRCPlayerApi_0();
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00011290 File Offset: 0x0000F490
		public static VRCPlayerApi GetVRCPlayerApi(this VRCPlayer Instance)
		{
			return Instance.Method_Public_get_VRCPlayerApi_0();
		}

		// Token: 0x0600021E RID: 542 RVA: 0x000112A8 File Offset: 0x0000F4A8
		public static VRCPlayerApi GetVRCPlayerApi(this PlayerNet Instance)
		{
			return Instance.GetVRCPlayer().GetVRCPlayerApi();
		}

		// Token: 0x0600021F RID: 543 RVA: 0x000112C8 File Offset: 0x0000F4C8
		public static string UserID(this Player Instance)
		{
			return Instance.GetAPIUser().id;
		}

		// Token: 0x06000220 RID: 544 RVA: 0x000112E8 File Offset: 0x0000F4E8
		public static string UserID(this VRCPlayer Instance)
		{
			return Instance.GetAPIUser().id;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00011308 File Offset: 0x0000F508
		public static string UserID(this PlayerNet Instance)
		{
			return Instance.GetAPIUser().id;
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00011328 File Offset: 0x0000F528
		public static string UserID(this APIUser Instance)
		{
			return Instance.id;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x00011340 File Offset: 0x0000F540
		public static string DisplayName(this Player Instance)
		{
			return Instance.GetAPIUser().displayName;
		}

		// Token: 0x06000224 RID: 548 RVA: 0x00011360 File Offset: 0x0000F560
		public static string DisplayName(this VRCPlayer Instance)
		{
			return Instance.GetAPIUser().displayName;
		}

		// Token: 0x06000225 RID: 549 RVA: 0x00011380 File Offset: 0x0000F580
		public static string DisplayName(this PlayerNet Instance)
		{
			return Instance.GetAPIUser().displayName;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x000113A0 File Offset: 0x0000F5A0
		public static string DisplayName(this APIUser Instance)
		{
			return Instance.displayName;
		}

		// Token: 0x06000227 RID: 551 RVA: 0x000113B8 File Offset: 0x0000F5B8
		public static bool GetIsMaster(this Player Instance)
		{
			return Instance.GetVRCPlayerApi().isMaster;
		}

		// Token: 0x06000228 RID: 552 RVA: 0x000113D8 File Offset: 0x0000F5D8
		public static bool GetIsMaster(this VRCPlayer Instance)
		{
			return Instance.GetVRCPlayerApi().isMaster;
		}

		// Token: 0x06000229 RID: 553 RVA: 0x000113F8 File Offset: 0x0000F5F8
		public static bool GetIsMaster(this PlayerNet Instance)
		{
			return Instance.GetVRCPlayerApi().isMaster;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00011418 File Offset: 0x0000F618
		public static bool GetIsInVR(this Player Instance)
		{
			return Instance.GetVRCPlayerApi().IsUserInVR();
		}

		// Token: 0x0600022B RID: 555 RVA: 0x00011438 File Offset: 0x0000F638
		public static bool GetIsInVR(this VRCPlayer Instance)
		{
			return Instance.GetVRCPlayerApi().IsUserInVR();
		}

		// Token: 0x0600022C RID: 556 RVA: 0x00011458 File Offset: 0x0000F658
		public static bool GetIsInVR(this PlayerNet Instance)
		{
			return Instance.GetVRCPlayerApi().IsUserInVR();
		}

		// Token: 0x0600022D RID: 557 RVA: 0x00011478 File Offset: 0x0000F678
		public static short GetPing(this VRCPlayer Instance)
		{
			return Instance.Method_Public_get_PlayerNet_0().field_Private_Int16_0;
		}

		// Token: 0x0600022E RID: 558 RVA: 0x00011498 File Offset: 0x0000F698
		public static bool IsEvolved(this VRCPlayer Instance)
		{
			return true;
		}

		// Token: 0x0600022F RID: 559 RVA: 0x000114AB File Offset: 0x0000F6AB
		public static void SetBotTarget(this VRCPlayer Instance)
		{
		}

		// Token: 0x06000230 RID: 560 RVA: 0x000114B0 File Offset: 0x0000F6B0
		public static int GetFrames(this VRCPlayer Instance)
		{
			bool flag = Instance.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0() == 0;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				result = (int)(1000f / (float)Instance.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0());
			}
			return result;
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000114EC File Offset: 0x0000F6EC
		public static string GetPingColored(this VRCPlayer Instance)
		{
			bool flag = Instance.GetPing() <= 75;
			string arg;
			if (flag)
			{
				arg = "<color=#59D365>";
			}
			else
			{
				bool flag2 = Instance.GetPing() >= 75 && Instance.GetPing() <= 150;
				if (flag2)
				{
					arg = "<color=#FF7000>";
				}
				else
				{
					arg = "<color=red>";
				}
			}
			return string.Format("{0}{1}</color>", arg, Instance.GetPing());
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00011564 File Offset: 0x0000F764
		public static string GetFramesColored(this VRCPlayer Instance)
		{
			bool flag = Instance.GetFrames() >= 80;
			string arg;
			if (flag)
			{
				arg = "<color=#59D365>";
			}
			else
			{
				bool flag2 = Instance.GetFrames() <= 80 && Instance.GetFrames() >= 30;
				if (flag2)
				{
					arg = "<color=#FF7000>";
				}
				else
				{
					arg = "<color=red>";
				}
			}
			return string.Format("{0}{1}</color>", arg, Instance.GetFrames());
		}

		// Token: 0x06000233 RID: 563 RVA: 0x000115D7 File Offset: 0x0000F7D7
		public static void ReloadAvatar(this VRCPlayer Instance)
		{
			VRCPlayer.Method_Public_Static_Void_APIUser_0(Instance.GetAPIUser());
		}

		// Token: 0x06000234 RID: 564 RVA: 0x000115E6 File Offset: 0x0000F7E6
		public static void ReloadAvatar(this Player Instance)
		{
			Instance.GetVRCPlayer().ReloadAvatar();
		}

		// Token: 0x06000235 RID: 565 RVA: 0x000115F8 File Offset: 0x0000F7F8
		public static string GetRank(this APIUser Instance)
		{
			bool flag = Instance.hasModerationPowers || Instance.tags.Contains("admin_moderator");
			string result;
			if (flag)
			{
				result = "Moderator";
			}
			else
			{
				bool flag2 = Instance.hasSuperPowers || Instance.tags.Contains("admin_");
				if (flag2)
				{
					result = "Admin";
				}
				else
				{
					bool flag3 = Instance.hasVIPAccess || (Instance.tags.Contains("system_legend") && Instance.tags.Contains("system_trust_legend") && Instance.tags.Contains("system_trust_trusted"));
					if (flag3)
					{
						result = "Legend";
					}
					else
					{
						bool flag4 = Instance.hasLegendTrustLevel || (Instance.tags.Contains("system_trust_legend") && Instance.tags.Contains("system_trust_trusted"));
						if (flag4)
						{
							result = "Veteran";
						}
						else
						{
							bool hasVeteranTrustLevel = Instance.hasVeteranTrustLevel;
							if (hasVeteranTrustLevel)
							{
								result = "Trusted";
							}
							else
							{
								bool hasTrustedTrustLevel = Instance.hasTrustedTrustLevel;
								if (hasTrustedTrustLevel)
								{
									result = "Known";
								}
								else
								{
									bool hasKnownTrustLevel = Instance.hasKnownTrustLevel;
									if (hasKnownTrustLevel)
									{
										result = "User";
									}
									else
									{
										bool flag5 = Instance.hasBasicTrustLevel || Instance.isNewUser;
										if (flag5)
										{
											result = "New User";
										}
										else
										{
											bool hasNegativeTrustLevel = Instance.hasNegativeTrustLevel;
											if (hasNegativeTrustLevel)
											{
												result = "NegativeTrust";
											}
											else
											{
												bool hasVeryNegativeTrustLevel = Instance.hasVeryNegativeTrustLevel;
												if (hasVeryNegativeTrustLevel)
												{
													result = "VeryNegativeTrust";
												}
												else
												{
													result = "Visitor";
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00011798 File Offset: 0x0000F998
		public static bool GetIsFriend(this APIUser Instance)
		{
			return Instance.isFriend || APIUser.IsFriendsWith(Instance.id);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x000117C0 File Offset: 0x0000F9C0
		public static bool GetIsDANGER(this VRCPlayer Instance)
		{
			return Instance.GetVRCPlayerApi().isModerator || Instance.GetAPIUser().hasModerationPowers || Instance.GetAPIUser().hasSuperPowers || Instance.GetAPIUser().hasSuperPowers;
		}

		// Token: 0x06000238 RID: 568 RVA: 0x00011808 File Offset: 0x0000FA08
		public static bool GetIsBot(this VRCPlayer Instance)
		{
			return Instance.transform.position.x == 0f && Instance.UserID() != APIUser.CurrentUser.id;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0001184C File Offset: 0x0000FA4C
		public static bool GetIsQuest(this VRCPlayer Instance)
		{
			return Instance._player.Method_Internal_get_APIUser_0().IsOnMobile;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00011870 File Offset: 0x0000FA70
		public static ApiAvatar GetApiAvatar(this Player Instance)
		{
			return Instance.Method_Public_get_ApiAvatar_0();
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00011888 File Offset: 0x0000FA88
		public static ApiAvatar GetApiAvatar(this VRCPlayer Instance)
		{
			return Instance.Method_Public_get_ApiAvatar_1();
		}

		// Token: 0x0600023C RID: 572 RVA: 0x000118A0 File Offset: 0x0000FAA0
		public static GameObject GetAvatar(this Player Instance)
		{
			return Instance.GetVRCPlayer().GetAvatarManager().GetAvatar();
		}

		// Token: 0x0600023D RID: 573 RVA: 0x000118C4 File Offset: 0x0000FAC4
		public static VRCAvatarManager GetAvatarManager(this VRCPlayer Instance)
		{
			return Instance.Method_Public_get_VRCAvatarManager_0();
		}

		// Token: 0x0600023E RID: 574 RVA: 0x000118DC File Offset: 0x0000FADC
		public static GameObject GetAvatar(this VRCPlayer Instance)
		{
			return Instance.GetAvatarManager().GetAvatar();
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000118FC File Offset: 0x0000FAFC
		public static GameObject GetAvatar(this VRCAvatarManager Instance)
		{
			bool flag = Instance.Method_Public_get_GameObject_0() != null;
			GameObject result;
			if (flag)
			{
				result = Instance.Method_Public_get_GameObject_0();
			}
			else
			{
				bool flag2 = Instance.field_Public_GameObject_1 != null;
				if (flag2)
				{
					result = Instance.field_Public_GameObject_1;
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06000240 RID: 576 RVA: 0x00011944 File Offset: 0x0000FB44
		public static APIUser SelectedAPIUser(this QuickMenu instance)
		{
			return instance.field_Private_APIUser_0;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x0001195C File Offset: 0x0000FB5C
		public static VRCPlayer SelectedVRCPlayer(this QuickMenu instance)
		{
			return instance.field_Private_Player_0.Method_Internal_get_VRCPlayer_1();
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0001197C File Offset: 0x0000FB7C
		public static Player SelectedPlayer(this QuickMenu instance, VRCPlayer currentUser)
		{
			return instance.field_Private_Player_0.Method_Internal_get_VRCPlayer_1().GetPlayer();
		}
	}
}
