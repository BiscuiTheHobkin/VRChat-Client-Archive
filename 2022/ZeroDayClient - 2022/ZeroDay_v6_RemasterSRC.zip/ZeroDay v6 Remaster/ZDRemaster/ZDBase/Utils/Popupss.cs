﻿using System;

namespace ZDBase.Utils
{
	// Token: 0x0200004D RID: 77
	public class Popupss
	{
	}
}
