﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Cache;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;
using ZDBase.settings;

namespace ZDBase.Utils
{
	// Token: 0x0200004B RID: 75
	internal static class ModFiles
	{
		// Token: 0x060001E1 RID: 481 RVA: 0x0000EB4C File Offset: 0x0000CD4C
		public static string[] Array(WebResponse res)
		{
			return ModFiles.Convert(res).Split(Environment.NewLine.ToCharArray());
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x0000EB74 File Offset: 0x0000CD74
		public static string Convert(WebResponse res)
		{
			string result = "";
			using (Stream responseStream = res.GetResponseStream())
			{
				using (StreamReader streamReader = new StreamReader(responseStream))
				{
					result = streamReader.ReadToEnd();
				}
			}
			res.Dispose();
			return result;
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000EBE4 File Offset: 0x0000CDE4
		public static string[] GetStatus()
		{
			WebRequest webRequest = WebRequest.Create("https://raw.githubusercontent.com/AzureEngine/AzureEngineTerminal/main/killswitch.txt");
			string[] source = ModFiles.Array(webRequest.GetResponse());
			HttpRequestCachePolicy httpRequestCachePolicy = (HttpRequestCachePolicy)(webRequest.CachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore));
			ServicePointManager.ServerCertificateValidationCallback = ((object s, X509Certificate c, X509Chain cc, SslPolicyErrors ssl) => true);
			return (from x in source
			where !string.IsNullOrEmpty(x)
			select x).ToArray<string>();
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x0000EC74 File Offset: 0x0000CE74
		internal static void Initialize()
		{
			int num = 0;
			CalibrationSavingComponent.PatchSteamTracking();
			bool flag = !Directory.Exists(ModFiles.ModFolder);
			if (flag)
			{
				Directory.CreateDirectory(ModFiles.ModFolder);
				num++;
			}
			bool flag2 = !Directory.Exists(ModFiles.MiscFolder);
			if (flag2)
			{
				Directory.CreateDirectory(ModFiles.MiscFolder);
				num++;
			}
			bool flag3 = num != 0;
			if (flag3)
			{
				Logs.LogSuccess(string.Format("Created {0} Folders!", num), false);
			}
			bool flag4 = !File.Exists(ModFiles.MiscFolder + "\\StyleConfig.json");
			if (flag4)
			{
				Logs.LogError("Couldn't find style config, making new one.", false);
				StyleConfig.savestyleconfig(ModFiles.MiscFolder + "\\StyleConfig.json");
			}
			MainConfigSettings.Instance = MainConfigSettings.Load();
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0000ED3C File Offset: 0x0000CF3C
		// Note: this type is marked as 'beforefieldinit'.
		static ModFiles()
		{
			DirectoryInfo parent = Directory.GetParent(Application.dataPath);
			ModFiles.ModFolder = ((parent != null) ? parent.ToString() : null) + "\\ZDRemastered";
			DirectoryInfo parent2 = Directory.GetParent(Application.dataPath);
			ModFiles.MLModsFolder = ((parent2 != null) ? parent2.ToString() : null) + "\\Mods";
			DirectoryInfo parent3 = Directory.GetParent(Application.dataPath);
			ModFiles.MLPluginsFolder = ((parent3 != null) ? parent3.ToString() : null) + "\\Plugins";
			ModFiles.VRChatFolder = Directory.GetParent(Application.dataPath).FullName;
			ModFiles.MiscFolder = ModFiles.ModFolder + "\\Misc";
		}

		// Token: 0x0400015E RID: 350
		internal static string ModFolder;

		// Token: 0x0400015F RID: 351
		internal static string MLModsFolder;

		// Token: 0x04000160 RID: 352
		internal static string MLPluginsFolder;

		// Token: 0x04000161 RID: 353
		internal static string VRChatFolder;

		// Token: 0x04000162 RID: 354
		internal static string MiscFolder;
	}
}
