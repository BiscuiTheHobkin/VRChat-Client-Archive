﻿using System;
using System.Collections;
using UnityEngine;
using VRC.Core;

namespace ZDBase.Discord
{
	// Token: 0x0200003E RID: 62
	internal static class DiscordManager
	{
		// Token: 0x06000168 RID: 360 RVA: 0x0000B988 File Offset: 0x00009B88
		public static IEnumerator gif()
		{
			for (;;)
			{
				DiscordManager.presence.largeImageKey = "1";
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
				yield return new WaitForSeconds(1f);
				DiscordManager.presence.largeImageKey = "2";
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
				yield return new WaitForSeconds(1f);
				DiscordManager.presence.largeImageKey = "3";
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
				yield return new WaitForSeconds(1f);
				DiscordManager.presence.largeImageKey = "4";
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
				yield return new WaitForSeconds(1f);
			}
			yield break;
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000B990 File Offset: 0x00009B90
		public static void Init()
		{
			DiscordManager.eventHandlers = default(DiscordRpc.EventHandlers);
			DiscordManager.eventHandlers.errorCallback = delegate(int code, string message)
			{
			};
			DiscordManager.presence.state = "No Bitches?";
			DiscordManager.presence.details = "User Loading";
			DiscordManager.presence.largeImageKey = "azureengine_full";
			DiscordManager.presence.largeImageText = "Pasted Client V4";
			DiscordManager.presence.smallImageKey = "azureengine_full";
			DiscordManager.presence.smallImageText = "discord.gg/vrkittens";
			DiscordManager.presence.partySize = 0;
			DiscordManager.presence.partyMax = 0;
			DiscordManager.presence.startTimestamp = (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
			DiscordManager.presence.partyId = "";
			try
			{
				DiscordRpc.Initialize("948518402807435274", ref DiscordManager.eventHandlers, true, "");
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
			}
			catch
			{
			}
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000BAB8 File Offset: 0x00009CB8
		public static void Update()
		{
			try
			{
				DiscordManager.eventHandlers = default(DiscordRpc.EventHandlers);
				DiscordManager.eventHandlers.errorCallback = delegate(int code, string message)
				{
				};
				DiscordManager.presence.state = "World: [" + RoomManager.field_Internal_Static_ApiWorldInstance_0.name + "]";
				DiscordManager.presence.details = "Logged In As [" + APIUser.CurrentUser.displayName + "]";
				DiscordManager.presence.largeImageKey = "azureengine_full";
				DiscordManager.presence.largeImageText = "Edward Was Here Lmfao";
				DiscordManager.presence.smallImageKey = "azzzz";
				DiscordManager.presence.smallImageText = "Pasted Client Lol";
				DiscordManager.presence.partySize = 0;
				DiscordManager.presence.partyMax = 0;
				DiscordManager.presence.startTimestamp = (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
				DiscordManager.presence.partyId = "";
				DiscordRpc.UpdatePresence(ref DiscordManager.presence);
			}
			catch
			{
				Logs.LogError("Failed To Update Presence, Sorry kid.", false);
			}
		}

		// Token: 0x0400011C RID: 284
		public static DiscordRpc.RichPresence presence;

		// Token: 0x0400011D RID: 285
		public static DiscordRpc.EventHandlers eventHandlers;
	}
}
