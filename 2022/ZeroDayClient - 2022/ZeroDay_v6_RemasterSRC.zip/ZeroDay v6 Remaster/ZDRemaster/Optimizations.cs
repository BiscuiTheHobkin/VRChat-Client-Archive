﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x0200000F RID: 15
internal class Optimizations
{
	// Token: 0x06000034 RID: 52
	[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
	internal static extern bool SetProcessWorkingSetSize32Bit(IntPtr pProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize);

	// Token: 0x06000035 RID: 53
	[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
	internal static extern bool SetProcessWorkingSetSize64Bit(IntPtr pProcess, long dwMinimumWorkingSetSize, long dwMaximumWorkingSetSize);

	// Token: 0x06000036 RID: 54 RVA: 0x00004428 File Offset: 0x00002628
	public static void RamClear()
	{
		GC.Collect();
		GC.WaitForPendingFinalizers();
		bool flag = Environment.OSVersion.Platform == PlatformID.Win32NT;
		if (flag)
		{
			Optimizations.SetProcessWorkingSetSize32Bit(Process.GetCurrentProcess().Handle, -1, -1);
		}
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00004467 File Offset: 0x00002667
	public static IEnumerator Loop()
	{
		for (;;)
		{
			yield return new WaitForSeconds(5f);
			Optimizations.RamClear();
		}
		yield break;
	}
}
