﻿using System;
using System.Runtime.InteropServices;
using MelonLoader;

// Token: 0x0200001F RID: 31
internal static class SolverApi
{
	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000091 RID: 145 RVA: 0x000075B8 File Offset: 0x000057B8
	// (set) Token: 0x06000092 RID: 146 RVA: 0x000075BF File Offset: 0x000057BF
	internal static SolverApi.VoidDelegate FlushColliderCache { get; private set; }

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000093 RID: 147 RVA: 0x000075C7 File Offset: 0x000057C7
	// (set) Token: 0x06000094 RID: 148 RVA: 0x000075CE File Offset: 0x000057CE
	internal static SolverApi.VoidDelegate JoinMultithreadedJobs { get; private set; }

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x06000095 RID: 149 RVA: 0x000075D6 File Offset: 0x000057D6
	// (set) Token: 0x06000096 RID: 150 RVA: 0x000075DD File Offset: 0x000057DD
	internal static SolverApi.SetPointersAndOffsetsDelegate SetPointersAndOffsets { get; private set; }

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000097 RID: 151 RVA: 0x000075E5 File Offset: 0x000057E5
	// (set) Token: 0x06000098 RID: 152 RVA: 0x000075EC File Offset: 0x000057EC
	internal static SolverApi.SetThreadNumberDelegate SetNumThreads { get; private set; }

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x06000099 RID: 153 RVA: 0x000075F4 File Offset: 0x000057F4
	// (set) Token: 0x0600009A RID: 154 RVA: 0x000075FB File Offset: 0x000057FB
	internal static SolverApi.ComponentDelegate DynamicBoneOnEnablePatch { get; private set; }

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600009B RID: 155 RVA: 0x00007603 File Offset: 0x00005803
	// (set) Token: 0x0600009C RID: 156 RVA: 0x0000760A File Offset: 0x0000580A
	internal static SolverApi.ComponentDelegate DynamicBoneOnDisablePatch { get; private set; }

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x0600009D RID: 157 RVA: 0x00007612 File Offset: 0x00005812
	// (set) Token: 0x0600009E RID: 158 RVA: 0x00007619 File Offset: 0x00005819
	internal static SolverApi.ComponentDelegate DynamicBoneStartPatch { get; private set; }

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x0600009F RID: 159 RVA: 0x00007621 File Offset: 0x00005821
	// (set) Token: 0x060000A0 RID: 160 RVA: 0x00007628 File Offset: 0x00005828
	internal static SolverApi.ComponentDelegate DynamicBoneOnDestroyPatch { get; private set; }

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x060000A1 RID: 161 RVA: 0x00007630 File Offset: 0x00005830
	// (set) Token: 0x060000A2 RID: 162 RVA: 0x00007637 File Offset: 0x00005837
	internal static SolverApi.ComponentDelegate ResetParticlePositions { get; private set; }

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060000A3 RID: 163 RVA: 0x0000763F File Offset: 0x0000583F
	// (set) Token: 0x060000A4 RID: 164 RVA: 0x00007646 File Offset: 0x00005846
	public static SolverApi.RegisterColliderForCollisionFeedbackDelegate RegisterColliderForCollisionFeedback { get; private set; }

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060000A5 RID: 165 RVA: 0x0000764E File Offset: 0x0000584E
	// (set) Token: 0x060000A6 RID: 166 RVA: 0x00007655 File Offset: 0x00005855
	public static SolverApi.UnregisterColliderForCollisionFeedbackDelegate UnregisterColliderForCollisionFeedback { get; private set; }

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000765D File Offset: 0x0000585D
	// (set) Token: 0x060000A8 RID: 168 RVA: 0x00007664 File Offset: 0x00005864
	public static SolverApi.VoidDelegate ClearCollisionFeedbackColliders { get; private set; }

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x060000A9 RID: 169 RVA: 0x0000766C File Offset: 0x0000586C
	// (set) Token: 0x060000AA RID: 170 RVA: 0x00007673 File Offset: 0x00005873
	public static SolverApi.GetAndClearCollidingGroupsMaskDelegate GetAndClearCollidingGroupsMask { get; private set; }

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x060000AB RID: 171 RVA: 0x0000767B File Offset: 0x0000587B
	// (set) Token: 0x060000AC RID: 172 RVA: 0x00007682 File Offset: 0x00005882
	public static SolverApi.BoneConsumingDelegate SetCurrentlySimulatingBone { get; private set; }

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x060000AD RID: 173 RVA: 0x0000768A File Offset: 0x0000588A
	// (set) Token: 0x060000AE RID: 174 RVA: 0x00007691 File Offset: 0x00005891
	public static SolverApi.BoneConsumingDelegate SetOriginalBoneUpdateDelegate { get; private set; }

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x060000AF RID: 175 RVA: 0x00007699 File Offset: 0x00005899
	// (set) Token: 0x060000B0 RID: 176 RVA: 0x000076A0 File Offset: 0x000058A0
	public static SolverApi.BoneConsumingDelegate ExcludeBoneFromCollisionFeedback { get; private set; }

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x060000B1 RID: 177 RVA: 0x000076A8 File Offset: 0x000058A8
	// (set) Token: 0x060000B2 RID: 178 RVA: 0x000076AF File Offset: 0x000058AF
	public static SolverApi.BoneConsumingDelegate UnExcludeBoneFromCollisionFeedback { get; private set; }

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x060000B3 RID: 179 RVA: 0x000076B7 File Offset: 0x000058B7
	// (set) Token: 0x060000B4 RID: 180 RVA: 0x000076BE File Offset: 0x000058BE
	public static SolverApi.VoidDelegate ClearExcludedBonesFromCollisionFeedback { get; private set; }

	// Token: 0x060000B5 RID: 181 RVA: 0x000076C8 File Offset: 0x000058C8
	internal static bool Initialize(string dllName)
	{
		IntPtr intPtr = SolverApi.LoadLibraryA(dllName);
		bool flag = intPtr == IntPtr.Zero;
		bool result;
		if (flag)
		{
			MelonLogger.Error("Native library load failed, mod won't work");
			result = false;
		}
		else
		{
			SolverApi.SetPointersAndOffsets = SolverApi.GetPointer<SolverApi.SetPointersAndOffsetsDelegate>(intPtr, "SetPointersAndOffsets");
			SolverApi.FlushColliderCache = SolverApi.GetPointer<SolverApi.VoidDelegate>(intPtr, "FlushColliderCache");
			SolverApi.JoinMultithreadedJobs = SolverApi.GetPointer<SolverApi.VoidDelegate>(intPtr, "JoinMultithreadedJobs");
			SolverApi.SetNumThreads = SolverApi.GetPointer<SolverApi.SetThreadNumberDelegate>(intPtr, "SetNumThreads");
			SolverApi.DynamicBoneOnDestroyPatch = SolverApi.GetPointer<SolverApi.ComponentDelegate>(intPtr, "DynamicBoneOnDestroyPatch");
			SolverApi.DynamicBoneOnEnablePatch = SolverApi.GetPointer<SolverApi.ComponentDelegate>(intPtr, "DynamicBoneOnEnablePatch");
			SolverApi.DynamicBoneOnDisablePatch = SolverApi.GetPointer<SolverApi.ComponentDelegate>(intPtr, "DynamicBoneOnDisablePatch");
			SolverApi.DynamicBoneStartPatch = SolverApi.GetPointer<SolverApi.ComponentDelegate>(intPtr, "DynamicBoneStartPatch");
			SolverApi.ResetParticlePositions = SolverApi.GetPointer<SolverApi.ComponentDelegate>(intPtr, "ResetParticlePositions");
			SolverApi.RegisterColliderForCollisionFeedback = SolverApi.GetPointer<SolverApi.RegisterColliderForCollisionFeedbackDelegate>(intPtr, "RegisterColliderForCollisionFeedback");
			SolverApi.UnregisterColliderForCollisionFeedback = SolverApi.GetPointer<SolverApi.UnregisterColliderForCollisionFeedbackDelegate>(intPtr, "UnregisterColliderForCollisionFeedback");
			SolverApi.ClearCollisionFeedbackColliders = SolverApi.GetPointer<SolverApi.VoidDelegate>(intPtr, "ClearCollisionFeedbackColliders");
			SolverApi.GetAndClearCollidingGroupsMask = SolverApi.GetPointer<SolverApi.GetAndClearCollidingGroupsMaskDelegate>(intPtr, "GetAndClearCollidingGroupsMask");
			SolverApi.ExcludeBoneFromCollisionFeedback = SolverApi.GetPointer<SolverApi.BoneConsumingDelegate>(intPtr, "ExcludeBoneFromCollisionFeedback");
			SolverApi.UnExcludeBoneFromCollisionFeedback = SolverApi.GetPointer<SolverApi.BoneConsumingDelegate>(intPtr, "UnExcludeBoneFromCollisionFeedback");
			SolverApi.SetCurrentlySimulatingBone = SolverApi.GetPointer<SolverApi.BoneConsumingDelegate>(intPtr, "SetCurrentlySimulatingBone");
			SolverApi.SetOriginalBoneUpdateDelegate = SolverApi.GetPointer<SolverApi.BoneConsumingDelegate>(intPtr, "SetOriginalBoneUpdateDelegate");
			SolverApi.ClearExcludedBonesFromCollisionFeedback = SolverApi.GetPointer<SolverApi.VoidDelegate>(intPtr, "ClearExcludedBonesFromCollisionFeedback");
			SolverApi.LibDynBoneCollideEntryPoint = SolverApi.GetProcAddress(intPtr, "ColliderCollidePatch");
			SolverApi.LibDynBoneUpdateSingleThreaded = SolverApi.GetProcAddress(intPtr, "DynamicBoneUpdateSingleThreadPatch");
			SolverApi.LibDynBoneUpdateMultiThreaded = SolverApi.GetProcAddress(intPtr, "DynamicBoneUpdateMultiThreadPatch");
			SolverApi.DynamicBoneUpdateNotifyPatch = SolverApi.GetProcAddress(intPtr, "DynamicBoneUpdateNotifyPatch");
			Offsets.SetOffsets();
			result = true;
		}
		return result;
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x0000787C File Offset: 0x00005A7C
	private static T GetPointer<T>(IntPtr lib, string name) where T : MulticastDelegate
	{
		T delegateForFunctionPointer = Marshal.GetDelegateForFunctionPointer<T>(SolverApi.GetProcAddress(lib, name));
		bool flag = delegateForFunctionPointer == null;
		if (flag)
		{
			MelonLogger.Error("Delegate for " + name + " not found! Bug?");
		}
		return delegateForFunctionPointer;
	}

	// Token: 0x060000B7 RID: 183
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

	// Token: 0x060000B8 RID: 184
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	internal static extern IntPtr LoadLibraryA(string libName);

	// Token: 0x04000069 RID: 105
	internal static IntPtr LibDynBoneCollideEntryPoint;

	// Token: 0x0400006A RID: 106
	internal static IntPtr LibDynBoneUpdateSingleThreaded;

	// Token: 0x0400006B RID: 107
	internal static IntPtr LibDynBoneUpdateMultiThreaded;

	// Token: 0x0400006C RID: 108
	internal static IntPtr DynamicBoneUpdateNotifyPatch;

	// Token: 0x020000C4 RID: 196
	// (Invoke) Token: 0x060004F9 RID: 1273
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void SetPointersAndOffsetsDelegate(ref Offsets.ICallOffsets icalls, ref Offsets.ColliderComponentOffsets component_offsets, ref Offsets.BoneComponentOffsets bone_offsets, ref Offsets.ParticleClassOffsets particle_offsets, ref Offsets.ListClassOffsets list_offsets, ref Offsets.ObjectOffsets object_offsets);

	// Token: 0x020000C5 RID: 197
	// (Invoke) Token: 0x060004FD RID: 1277
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void VoidDelegate();

	// Token: 0x020000C6 RID: 198
	// (Invoke) Token: 0x06000501 RID: 1281
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void SetThreadNumberDelegate(int threadNumber);

	// Token: 0x020000C7 RID: 199
	// (Invoke) Token: 0x06000505 RID: 1285
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void ComponentDelegate(IntPtr boneComponent);

	// Token: 0x020000C8 RID: 200
	// (Invoke) Token: 0x06000509 RID: 1289
	public delegate void RegisterColliderForCollisionFeedbackDelegate(IntPtr colliderPtr, byte group);

	// Token: 0x020000C9 RID: 201
	// (Invoke) Token: 0x0600050D RID: 1293
	public delegate void UnregisterColliderForCollisionFeedbackDelegate(IntPtr colliderPtr);

	// Token: 0x020000CA RID: 202
	// (Invoke) Token: 0x06000511 RID: 1297
	public delegate ulong GetAndClearCollidingGroupsMaskDelegate();

	// Token: 0x020000CB RID: 203
	// (Invoke) Token: 0x06000515 RID: 1301
	public delegate void BoneConsumingDelegate(IntPtr bonePtr);
}
