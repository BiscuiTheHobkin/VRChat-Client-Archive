﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

// Token: 0x02000009 RID: 9
public class DynamicContractResolver : DefaultContractResolver
{
	// Token: 0x06000017 RID: 23 RVA: 0x0000263C File Offset: 0x0000083C
	public DynamicContractResolver(List<string> propertyNamesToExclude)
	{
		this._propertyNamesToExclude = propertyNamesToExclude;
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002650 File Offset: 0x00000850
	protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
	{
		return (from p in base.CreateProperties(type, memberSerialization)
		where !this._propertyNamesToExclude.Contains(p.PropertyName)
		select p).ToList<JsonProperty>();
	}

	// Token: 0x04000005 RID: 5
	private readonly List<string> _propertyNamesToExclude;
}
