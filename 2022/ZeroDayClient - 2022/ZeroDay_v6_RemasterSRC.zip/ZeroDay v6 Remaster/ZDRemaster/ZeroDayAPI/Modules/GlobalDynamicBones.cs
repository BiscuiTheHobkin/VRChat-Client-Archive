﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using ZDBase;

namespace ZeroDayAPI.Modules
{
	// Token: 0x0200002E RID: 46
	internal class GlobalDynamicBones
	{
		// Token: 0x06000133 RID: 307 RVA: 0x0000A708 File Offset: 0x00008908
		public static void ProcessDynamicBones(VRCAvatarManager avatarManager, GameObject AvatarObject = null)
		{
			try
			{
				VRCPlayer field_Private_VRCPlayer_ = avatarManager.field_Private_VRCPlayer_0;
				bool flag = !GlobalDynamicBones.Users.Contains(field_Private_VRCPlayer_._player.field_Private_APIUser_0.id);
				if (flag)
				{
					GlobalDynamicBones.Users.Add(field_Private_VRCPlayer_._player.field_Private_APIUser_0.id);
				}
				bool flag2 = avatarManager != null;
				GameObject gameObject;
				if (flag2)
				{
					gameObject = avatarManager.Method_Public_get_GameObject_0();
				}
				else
				{
					gameObject = AvatarObject;
				}
				bool flag3 = GlobalDynamicBones.Users.Contains(field_Private_VRCPlayer_.Method_Public_get_Player_0().Method_Internal_get_APIUser_0().id) && gameObject != null;
				if (flag3)
				{
					bool headBones = MainConfigSettings.Instance.HeadBones;
					if (headBones)
					{
						foreach (DynamicBone item in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(10).GetComponentsInChildren<DynamicBone>())
						{
							GlobalDynamicBones.currentWorldDynamicBones.Add(item);
						}
					}
					bool chestBones = MainConfigSettings.Instance.ChestBones;
					if (chestBones)
					{
						foreach (DynamicBone item2 in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(8).GetComponentsInChildren<DynamicBone>())
						{
							GlobalDynamicBones.currentWorldDynamicBones.Add(item2);
						}
					}
					bool hipBones = MainConfigSettings.Instance.HipBones;
					if (hipBones)
					{
						foreach (DynamicBone item3 in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(0).GetComponentsInChildren<DynamicBone>())
						{
							GlobalDynamicBones.currentWorldDynamicBones.Add(item3);
						}
					}
					bool handColliders = MainConfigSettings.Instance.HandColliders;
					if (handColliders)
					{
						foreach (DynamicBoneCollider dynamicBoneCollider in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(17).GetComponentsInChildren<DynamicBoneCollider>())
						{
							bool flag4 = dynamicBoneCollider.m_Bound != 1;
							if (flag4)
							{
								GlobalDynamicBones.currentWorldDynamicBoneColliders.Add(dynamicBoneCollider);
							}
						}
						foreach (DynamicBoneCollider dynamicBoneCollider2 in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(18).GetComponentsInChildren<DynamicBoneCollider>())
						{
							bool flag5 = dynamicBoneCollider2.m_Bound != 1;
							if (flag5)
							{
								GlobalDynamicBones.currentWorldDynamicBoneColliders.Add(dynamicBoneCollider2);
							}
						}
					}
					bool feetColliders = MainConfigSettings.Instance.FeetColliders;
					if (feetColliders)
					{
						foreach (DynamicBoneCollider dynamicBoneCollider3 in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(5).GetComponentsInChildren<DynamicBoneCollider>())
						{
							bool flag6 = dynamicBoneCollider3.m_Bound != 1;
							if (flag6)
							{
								GlobalDynamicBones.currentWorldDynamicBoneColliders.Add(dynamicBoneCollider3);
							}
						}
						foreach (DynamicBoneCollider dynamicBoneCollider4 in gameObject.GetComponentInChildren<Animator>().GetBoneTransform(6).GetComponentsInChildren<DynamicBoneCollider>())
						{
							bool flag7 = dynamicBoneCollider4.m_Bound != 1;
							if (flag7)
							{
								GlobalDynamicBones.currentWorldDynamicBoneColliders.Add(dynamicBoneCollider4);
							}
						}
					}
					foreach (DynamicBone dynamicBone in GlobalDynamicBones.currentWorldDynamicBones.ToList<DynamicBone>())
					{
						bool flag8 = dynamicBone == null;
						if (flag8)
						{
							GlobalDynamicBones.currentWorldDynamicBones.Remove(dynamicBone);
						}
						else
						{
							foreach (DynamicBoneCollider dynamicBoneCollider5 in GlobalDynamicBones.currentWorldDynamicBoneColliders.ToList<DynamicBoneCollider>())
							{
								bool flag9 = dynamicBoneCollider5 == null;
								if (flag9)
								{
									GlobalDynamicBones.currentWorldDynamicBoneColliders.Remove(dynamicBoneCollider5);
								}
								else
								{
									bool flag10 = dynamicBone.m_Colliders.IndexOf(dynamicBoneCollider5) == -1;
									if (flag10)
									{
										dynamicBone.m_Colliders.Add(dynamicBoneCollider5);
									}
								}
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040000AE RID: 174
		public static List<string> Users = new List<string>();

		// Token: 0x040000AF RID: 175
		public static List<DynamicBone> currentWorldDynamicBones = new List<DynamicBone>();

		// Token: 0x040000B0 RID: 176
		public static List<DynamicBoneCollider> currentWorldDynamicBoneColliders = new List<DynamicBoneCollider>();
	}
}
