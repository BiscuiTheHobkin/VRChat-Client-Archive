﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200000D RID: 13
internal static class ColorChanger
{
	// Token: 0x0600002E RID: 46 RVA: 0x00002BF8 File Offset: 0x00000DF8
	public static GameObject menuContent(this VRCUiManager mngr)
	{
		return mngr.field_Public_GameObject_0;
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00002C10 File Offset: 0x00000E10
	public static void ApplyIfApplicable()
	{
		Color red = Color.red;
		Color color;
		color..ctor(red.r, red.g, red.b, 0.7f);
		new Color(red.r / 0.75f, red.g / 0.75f, red.b / 0.75f);
		Color color2;
		color2..ctor(red.r / 0.75f, red.g / 0.75f, red.b / 0.75f, 0.9f);
		Color color3;
		color3..ctor(red.r / 2.5f, red.g / 2.5f, red.b / 2.5f);
		Color color4;
		color4..ctor(red.r / 2.5f, red.g / 2.5f, red.b / 2.5f, 0.9f);
		bool flag = ColorChanger.normalColorImage == null || ColorChanger.normalColorImage.Count == 0;
		if (flag)
		{
			ColorChanger.normalColorImage = new List<Image>();
			GameObject gameObject = QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0().gameObject;
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/Settings_Safety/_Description_SafetyLevel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Custom/ON").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_None/ON").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Normal/ON").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Maxiumum/ON").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/InputKeypadPopup/Rectangle/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/InputKeypadPopup/InputField").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/StandardPopupV2/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/StandardPopup/InnerDashRing").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/StandardPopup/RingGlow").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/UpdateStatusPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/InputPopup/InputField").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/UpdateStatusPopup/Popup/InputFieldStatus").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/AdvancedSettingsPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/AddToPlaylistPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/BookmarkFriendPopup/Popup/Panel (2)").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/EditPlaylistPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/PerformanceSettingsPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/AlertPopup/Lighter").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/RoomInstancePopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/ReportWorldPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/ReportUserPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/AddToAvatarFavoritesPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/SearchOptionsPopup/Popup/Panel (1)").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/SendInvitePopup/SendInviteMenu/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/RequestInvitePopup/RequestInviteMenu/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/ControllerBindingsPopup/Popup/Panel").GetComponent<Image>());
			ColorChanger.normalColorImage.Add(gameObject.transform.Find("Screens/UserInfo/User Panel/Panel (1)").GetComponent<Image>());
			foreach (Transform transform in from x in gameObject.GetComponentsInChildren<Transform>(true)
			where x.name.Contains("Panel_Header")
			select x)
			{
				foreach (Image item in transform.GetComponentsInChildren<Image>())
				{
					ColorChanger.normalColorImage.Add(item);
				}
			}
			foreach (Transform transform2 in from x in gameObject.GetComponentsInChildren<Transform>(true)
			where x.name.Contains("Handle")
			select x)
			{
				foreach (Image item2 in transform2.GetComponentsInChildren<Image>())
				{
					ColorChanger.normalColorImage.Add(item2);
				}
			}
			try
			{
				ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop").GetComponent<Image>());
				ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Left").GetComponent<Image>());
				ColorChanger.normalColorImage.Add(gameObject.transform.Find("Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Right").GetComponent<Image>());
			}
			catch (Exception)
			{
				new Exception();
			}
		}
		bool flag2 = ColorChanger.dimmerColorImage == null || ColorChanger.dimmerColorImage.Count == 0;
		if (flag2)
		{
			ColorChanger.dimmerColorImage = new List<Image>();
			GameObject gameObject2 = GameObject.Find("UserInterface/MenuContent/Screens");
			ColorChanger.dimmerColorImage.Add(gameObject2.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Custom/ON/TopPanel_SafetyLevel").GetComponent<Image>());
			ColorChanger.dimmerColorImage.Add(gameObject2.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_None/ON/TopPanel_SafetyLevel").GetComponent<Image>());
			ColorChanger.dimmerColorImage.Add(gameObject2.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Normal/ON/TopPanel_SafetyLevel").GetComponent<Image>());
			ColorChanger.dimmerColorImage.Add(gameObject2.transform.Find("Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Maxiumum/ON/TopPanel_SafetyLevel").GetComponent<Image>());
			foreach (Transform transform3 in from x in gameObject2.GetComponentsInChildren<Transform>(true)
			where x.name.Contains("Fill")
			select x)
			{
				foreach (Image item3 in transform3.GetComponentsInChildren<Image>())
				{
					ColorChanger.dimmerColorImage.Add(item3);
				}
			}
		}
		bool flag3 = ColorChanger.darkerColorImage == null || ColorChanger.darkerColorImage.Count == 0;
		if (flag3)
		{
			ColorChanger.darkerColorImage = new List<Image>();
			GameObject gameObject3 = GameObject.Find("UserInterface/MenuContent/Screens");
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/InputKeypadPopup/Rectangle").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/StandardPopupV2/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/StandardPopup/Rectangle").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/StandardPopup/MidRing").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/UpdateStatusPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/AdvancedSettingsPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/AddToPlaylistPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/BookmarkFriendPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/EditPlaylistPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/PerformanceSettingsPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/RoomInstancePopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/RoomInstancePopup/Popup/BorderImage (1)").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/ReportWorldPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/ReportUserPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/AddToAvatarFavoritesPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/SearchOptionsPopup/Popup/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/SendInvitePopup/SendInviteMenu/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/RequestInvitePopup/RequestInviteMenu/BorderImage").GetComponent<Image>());
			ColorChanger.darkerColorImage.Add(gameObject3.transform.Find("Popups/ControllerBindingsPopup/Popup/BorderImage").GetComponent<Image>());
			foreach (Transform transform4 in from x in gameObject3.GetComponentsInChildren<Transform>(true)
			where x.name.Contains("Background")
			select x)
			{
				foreach (Image item4 in transform4.GetComponentsInChildren<Image>())
				{
					ColorChanger.darkerColorImage.Add(item4);
				}
			}
		}
		bool flag4 = ColorChanger.normalColorText == null || ColorChanger.normalColorText.Count == 0;
		if (flag4)
		{
			ColorChanger.normalColorText = new List<Text>();
			GameObject gameObject4 = GameObject.Find("UserInterface/MenuContent/Screens");
			foreach (Text item5 in gameObject4.transform.Find("Popups/InputPopup/Keyboard/Keys").GetComponentsInChildren<Text>(true))
			{
				ColorChanger.normalColorText.Add(item5);
			}
			foreach (Text item6 in gameObject4.transform.Find("Popups/InputKeypadPopup/Keyboard/Keys").GetComponentsInChildren<Text>(true))
			{
				ColorChanger.normalColorText.Add(item6);
			}
		}
		foreach (Image image in ColorChanger.normalColorImage)
		{
			image.color = color;
		}
		foreach (Image image2 in ColorChanger.dimmerColorImage)
		{
			image2.color = color2;
		}
		foreach (Image image3 in ColorChanger.darkerColorImage)
		{
			image3.color = color4;
		}
		foreach (Text text in ColorChanger.normalColorText)
		{
			text.color = red;
		}
		ColorBlock colorBlock = default(ColorBlock);
		colorBlock.colorMultiplier = 1f;
		colorBlock.disabledColor = Color.grey;
		colorBlock.highlightedColor = red * 1.5f;
		colorBlock.normalColor = red / 1.5f;
		colorBlock.pressedColor = Color.grey * 1.5f;
		colorBlock.fadeDuration = 0.1f;
		ColorBlock colors = colorBlock;
		red.a = 0.9f;
		bool flag5 = Resources.FindObjectsOfTypeAll<HighlightsFXStandalone>().Count != 0;
		if (flag5)
		{
			Resources.FindObjectsOfTypeAll<HighlightsFXStandalone>().FirstOrDefault<HighlightsFXStandalone>().highlightColor = red;
		}
		GameObject gameObject5 = QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0().gameObject;
		try
		{
			colorBlock = default(ColorBlock);
			colorBlock.colorMultiplier = 1f;
			colorBlock.disabledColor = Color.grey;
			colorBlock.highlightedColor = color3;
			colorBlock.normalColor = red;
			colorBlock.pressedColor = Color.gray;
			colorBlock.fadeDuration = 0.1f;
			ColorBlock colors2 = colorBlock;
			gameObject5.GetComponentsInChildren<Transform>(true).FirstOrDefault((Transform x) => x.name == "Row:4 Column:0").GetComponent<Button>().colors = colors;
			red.a = 0.5f;
			color3.a = 1f;
			colors2.normalColor = color3;
			foreach (Slider slider in gameObject5.GetComponentsInChildren<Slider>(true))
			{
				slider.colors = colors2;
			}
			color3.a = 0.5f;
			colors2.normalColor = red;
			foreach (Button button in gameObject5.GetComponentsInChildren<Button>(true))
			{
				bool flag6 = button.gameObject.name != "SubscribeToAddPhotosButton";
				if (flag6)
				{
					button.colors = colors;
				}
			}
			gameObject5 = GameObject.Find("QuickMenu");
			foreach (UiToggleButton uiToggleButton in gameObject5.GetComponentsInChildren<UiToggleButton>(true))
			{
				foreach (Image image4 in uiToggleButton.GetComponentsInChildren<Image>(true))
				{
					image4.color = red;
				}
			}
			foreach (Slider slider2 in gameObject5.GetComponentsInChildren<Slider>(true))
			{
				slider2.colors = colors2;
				foreach (Image image5 in slider2.GetComponentsInChildren<Image>(true))
				{
					image5.color = red;
				}
			}
			foreach (Toggle toggle in gameObject5.GetComponentsInChildren<Toggle>(true))
			{
				toggle.colors = colors2;
				foreach (Image image6 in toggle.GetComponentsInChildren<Image>(true))
				{
					image6.color = red;
				}
			}
			foreach (Image image7 in GameObject.Find("UserInterface/QuickMenu/QuickModeMenus/QuickModeNotificationsMenu/ScrollRect").GetComponentsInChildren<Image>(true))
			{
				bool flag7 = image7.transform.name == "Background";
				if (flag7)
				{
					image7.color = red;
				}
			}
			foreach (MonoBehaviourPublicObCoGaCoObCoObCoUnique monoBehaviourPublicObCoGaCoObCoObCoUnique in GameObject.Find("UserInterface/QuickMenu/QuickModeTabs").GetComponentsInChildren<MonoBehaviourPublicObCoGaCoObCoObCoUnique>())
			{
				Color color5;
				color5..ctor(red.r / 2.25f, red.g / 2.25f, red.b / 2.25f);
				monoBehaviourPublicObCoGaCoObCoObCoUnique.field_Public_Color32_0 = color5;
			}
		}
		catch (Exception)
		{
			new Exception();
		}
		foreach (Text text2 in QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0().transform.Find("QuickMenu_NewElements/_CONTEXT").GetComponentsInChildren<Text>(true))
		{
			bool flag8 = text2.transform.name == "Text" && text2.transform.parent.name != "AvatarImage";
			if (flag8)
			{
				text2.color = new Color(red.r * 1.25f, red.g * 1.25f, red.b * 1.25f);
			}
		}
	}

	// Token: 0x04000012 RID: 18
	private static List<Image> normalColorImage;

	// Token: 0x04000013 RID: 19
	private static List<Image> dimmerColorImage;

	// Token: 0x04000014 RID: 20
	private static List<Image> darkerColorImage;

	// Token: 0x04000015 RID: 21
	private static List<Text> normalColorText;

	// Token: 0x04000016 RID: 22
	private static bool setupSkybox;

	// Token: 0x04000017 RID: 23
	private static GameObject loadingBackground;

	// Token: 0x04000018 RID: 24
	private static GameObject initialLoadingBackground;
}
