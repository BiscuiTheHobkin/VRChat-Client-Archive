﻿using System;
using UnityEngine;

// Token: 0x0200000B RID: 11
internal interface IControlScheme
{
	// Token: 0x06000026 RID: 38
	bool HandleInput(Transform playerTransform, Transform cameraTransform);
}
