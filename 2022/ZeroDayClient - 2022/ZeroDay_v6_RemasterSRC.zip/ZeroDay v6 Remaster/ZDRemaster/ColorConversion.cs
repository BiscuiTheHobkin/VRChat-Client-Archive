﻿using System;
using System.Globalization;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class ColorConversion
{
	// Token: 0x0600000B RID: 11 RVA: 0x000024D0 File Offset: 0x000006D0
	public static Color HexToColor(string hexColor)
	{
		bool flag = hexColor.IndexOf('#') != -1;
		if (flag)
		{
			hexColor = hexColor.Replace("#", "");
		}
		float num = (float)int.Parse(hexColor.Substring(0, 2), NumberStyles.AllowHexSpecifier) / 255f;
		float num2 = (float)int.Parse(hexColor.Substring(2, 2), NumberStyles.AllowHexSpecifier) / 255f;
		float num3 = (float)int.Parse(hexColor.Substring(4, 2), NumberStyles.AllowHexSpecifier) / 255f;
		return new Color(num, num2, num3);
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002568 File Offset: 0x00000768
	public static string ColorToHex(Color baseColor, bool hash = false)
	{
		int num = Convert.ToInt32(baseColor.r * 255f);
		int num2 = Convert.ToInt32(baseColor.g * 255f);
		string str = Convert.ToInt32(baseColor.b * 255f).ToString("X2");
		string text = num.ToString("X2") + num2.ToString("X2") + str;
		if (hash)
		{
			text = "#" + text;
		}
		return text;
	}
}
