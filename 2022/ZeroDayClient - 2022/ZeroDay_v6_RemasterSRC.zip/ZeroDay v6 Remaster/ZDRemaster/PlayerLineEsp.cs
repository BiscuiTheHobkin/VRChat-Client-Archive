﻿using System;
using System.Collections;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;
using VRC;
using VRC.Core;
using ZDBase;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered.Modules.MenuClass;

// Token: 0x0200000C RID: 12
internal class PlayerLineEsp
{
	// Token: 0x06000027 RID: 39 RVA: 0x00002AC1 File Offset: 0x00000CC1
	internal static void Enable()
	{
		MelonCoroutines.Start(PlayerLineEsp.LineESP());
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00002ACF File Offset: 0x00000CCF
	internal static void Disable()
	{
		PlayerLineEsp.ForceDisableLine();
		PlayerLineEsp.Clear();
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002AE0 File Offset: 0x00000CE0
	internal static void Clear()
	{
		List<Player>.Enumerator enumerator = PlayerLineEsp.VRC_PlayerList.GetEnumerator();
		while (enumerator.MoveNext())
		{
			Player current = enumerator.current;
			try
			{
				current.Method_Internal_get_VRCPlayer_0().Method_Public_get_VRCAvatarManager_0().GetComponent<LineRenderer>().enabled = false;
			}
			catch
			{
			}
		}
		List<GameObject>.Enumerator enumerator2 = PlayerLineEsp.Texts.GetEnumerator();
		while (enumerator2.MoveNext())
		{
			GameObject current2 = enumerator2.current;
			try
			{
				Object.Destroy(current2);
			}
			catch
			{
			}
		}
		PlayerLineEsp.Texts.Clear();
		PlayerLineEsp.VRC_PlayerList.Clear();
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002B94 File Offset: 0x00000D94
	internal static void ForceDisableLine()
	{
		try
		{
			PlayerLineEsp.Clear();
		}
		catch
		{
		}
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002BC4 File Offset: 0x00000DC4
	internal static IEnumerator LineESP()
	{
		while (MainConfigSettings.CSGO)
		{
			PlayerLineEsp.Clear();
			PlayerLineEsp.AllPlayer = PlayerManager.Method_Public_Static_get_PlayerManager_0().field_Private_List_1_Player_0;
			List<Player>.Enumerator enumerator = PlayerLineEsp.AllPlayer.GetEnumerator();
			for (;;)
			{
				bool flag = enumerator.MoveNext();
				if (!flag)
				{
					break;
				}
				Player current = enumerator.current;
				try
				{
					PlayerLineEsp.line1 = current.Method_Internal_get_VRCPlayer_0().Method_Public_get_VRCAvatarManager_0().gameObject.GetOrAddComponent2<LineRenderer>();
					PlayerLineEsp.line1.enabled = true;
					PlayerLineEsp.line1.startWidth = 0.001f;
					PlayerLineEsp.line1.alignment = 0;
					PlayerLineEsp.line1.material = new Material(Shader.Find("GUI/Text Shader"));
					PlayerLineEsp.line1.material.color = current.GetTrustColor();
					bool flag2 = current.Method_Internal_get_APIUser_0().id != APIUser.CurrentUser.id;
					if (flag2)
					{
						PlayerLineEsp.VRC_PlayerList.Add(current);
					}
				}
				catch
				{
				}
				try
				{
					bool flag3 = current.Method_Internal_get_APIUser_0().id != APIUser.CurrentUser.id;
					if (flag3)
					{
						GameObject gameObject = new GameObject();
						gameObject.transform.SetParent(current.transform);
						gameObject.name = "LookAtText";
						gameObject.GetOrAddComponent2<MeshRenderer>().enabled = true;
						TextMesh orAddComponent = gameObject.GetOrAddComponent2<TextMesh>();
						orAddComponent.fontSize = 10;
						orAddComponent.text = current.Method_Public_get_VRCPlayerApi_0().displayName;
						orAddComponent.color = current.GetTrustColor();
						orAddComponent.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
						gameObject.transform.localPosition = new Vector3(0f, 1f, 0f);
						gameObject.transform.localScale = new Vector3(0.03f, 0.03f, 0.03f);
						PlayerLineEsp.Texts.Add(gameObject);
						gameObject = null;
						orAddComponent = null;
					}
				}
				catch (Exception ex)
				{
				}
			}
			for (;;)
			{
				try
				{
					bool flag4 = PlayerLineEsp.AllPlayer.ToArray().Length != PlayerLineEsp._u;
					if (flag4)
					{
						PlayerLineEsp._u = PlayerLineEsp.AllPlayer.ToArray().Length;
						break;
					}
					enumerator = PlayerLineEsp.VRC_PlayerList.GetEnumerator();
					while (enumerator.MoveNext())
					{
						Player current2 = enumerator.current;
						try
						{
							current2.Method_Internal_get_VRCPlayer_0().Method_Public_get_VRCAvatarManager_0().gameObject.GetComponent<LineRenderer>().SetPosition(0, current2.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(0).position);
							current2.Method_Internal_get_VRCPlayer_0().Method_Public_get_VRCAvatarManager_0().gameObject.GetComponent<LineRenderer>().SetPosition(1, Camera.current.transform.position + Camera.current.transform.forward * 0.3f);
						}
						catch
						{
						}
						current2 = null;
					}
					List<GameObject>.Enumerator enumerator2 = PlayerLineEsp.Texts.GetEnumerator();
					while (enumerator2.MoveNext())
					{
						GameObject current3 = enumerator2.current;
						try
						{
							current3.GetComponent<TextMesh>().fontSize = Convert.ToInt32(Math.Round((double)(10f * Vector3.Distance(current3.transform.position, Camera.current.transform.position)), 0));
							current3.transform.LookAt(Camera.main.transform);
							current3.transform.Rotate(0f, 180f, 0f);
						}
						catch
						{
						}
						current3 = null;
					}
				}
				catch (Exception ex)
				{
					PlayerLineEsp.ForceDisableLine();
				}
				yield return new WaitForSeconds(0.01f);
			}
			enumerator = null;
		}
		PlayerLineEsp.ForceDisableLine();
		yield break;
	}

	// Token: 0x0400000D RID: 13
	private static LineRenderer line1;

	// Token: 0x0400000E RID: 14
	internal static int _u;

	// Token: 0x0400000F RID: 15
	private static List<GameObject> Texts = new List<GameObject>();

	// Token: 0x04000010 RID: 16
	private static List<Player> VRC_PlayerList = new List<Player>();

	// Token: 0x04000011 RID: 17
	public static List<Player> AllPlayer = new List<Player>();
}
