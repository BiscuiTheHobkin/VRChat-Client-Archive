﻿using System;
using UnityEngine;
using VRC;
using ZDBase.Utils.Wrappers;

// Token: 0x02000028 RID: 40
internal static class Playerlist
{
	// Token: 0x060000E5 RID: 229 RVA: 0x00008B84 File Offset: 0x00006D84
	internal static string PlayerName(Player Instance)
	{
		return "[<color=#F0F0F0>" + Instance.field_Private_VRCPlayerApi_0.displayName + "</color>] ";
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x00008BB0 File Offset: 0x00006DB0
	public static PlayerNet GetPlayerNet(this Player Instance)
	{
		return (Instance == null) ? null : Instance.Method_Internal_get_PlayerNet_0();
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00008BD4 File Offset: 0x00006DD4
	public static string GetIsCrashed(this Player Instance)
	{
		bool flag = Playerlist.frames == Instance._playerNet.field_Private_Byte_0 && Playerlist.ping == Instance._playerNet.Method_Public_get_Byte_0();
		bool flag2 = flag;
		if (flag2)
		{
			Playerlist.noUpdateCount++;
		}
		else
		{
			Playerlist.noUpdateCount = 0;
		}
		Playerlist.frames = Instance._playerNet.Method_Public_get_Byte_0();
		Playerlist.ping = Instance._playerNet.field_Private_Byte_1;
		string result = "[<color=green>Stable</color>]";
		bool flag3 = Playerlist.noUpdateCount > 35;
		bool flag4 = flag3;
		if (flag4)
		{
			result = "[<color=yellow>Lagging</color>]";
		}
		bool flag5 = Playerlist.noUpdateCount > 375;
		bool flag6 = flag5;
		if (flag6)
		{
			result = "[<color=red>Crashed</color>]";
		}
		return result;
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00008C8C File Offset: 0x00006E8C
	internal static string PlayerisFristring(Player Instance)
	{
		bool isFriend = Instance.field_Private_APIUser_0.GetIsFriend();
		string result;
		if (isFriend)
		{
			result = "[<color=#ffdd00>F</color>]";
		}
		else
		{
			result = "";
		}
		return result;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x00008CBC File Offset: 0x00006EBC
	internal static string PlayerPING(Player Instance)
	{
		return "[ <color=#9400D3>P : " + Instance.GetPlayerNet().field_Private_Int16_0.ToString() + "</color> ]";
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00008CF0 File Offset: 0x00006EF0
	internal static string PlayerFPS(Player Instance)
	{
		return "[ <color=#55ff00>FPS : " + ((Instance.GetPlayerNet().Method_Public_get_Byte_0() != 0) ? ((int)(1000f / (float)Instance.GetPlayerNet().Method_Public_get_Byte_0())) : 0).ToString() + "</color>]";
	}

	// Token: 0x060000EB RID: 235 RVA: 0x00008D3C File Offset: 0x00006F3C
	internal static string Playerisvr(Player Instance)
	{
		bool flag = Instance.GetVRCPlayerApi().IsUserInVR();
		string result;
		if (flag)
		{
			result = "[<color=#9400D3>VR</color>]";
		}
		else
		{
			result = "[<color=#696969>PC</color>]";
		}
		return result;
	}

	// Token: 0x060000EC RID: 236 RVA: 0x00008D6C File Offset: 0x00006F6C
	internal static string Playerisquet(Player Instance)
	{
		bool isOnMobile = Instance.Method_Internal_get_APIUser_0().IsOnMobile;
		string result;
		if (isOnMobile)
		{
			result = "[<color=#42f20c>Q</color>]";
		}
		else
		{
			result = "";
		}
		return result;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x00008D9C File Offset: 0x00006F9C
	internal static string Playerismaster(Player Instance)
	{
		bool isMaster = Instance.GetVRCPlayerApi().isMaster;
		string result;
		if (isMaster)
		{
			result = "[<color=#00ffd5>M</color>]";
		}
		else
		{
			result = "";
		}
		return result;
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00008DCC File Offset: 0x00006FCC
	internal static string TrustRank(Player Instance)
	{
		bool flag = Instance.Method_Internal_get_APIUser_0().hasModerationPowers || Instance.Method_Internal_get_APIUser_0().tags.Contains("admin_moderator");
		string result;
		if (flag)
		{
			result = "[<color=#ff0000>Moderation User</color>]";
		}
		else
		{
			bool flag2 = Instance.Method_Internal_get_APIUser_0().hasSuperPowers || Instance.Method_Internal_get_APIUser_0().tags.Contains("admin_");
			if (flag2)
			{
				result = "[<color=#ff0000>Admin User</color>]";
			}
			else
			{
				bool flag3 = Instance.Method_Internal_get_APIUser_0().tags.Contains("system_legend") && Instance.Method_Internal_get_APIUser_0().tags.Contains("system_trust_legend") && Instance.Method_Internal_get_APIUser_0().tags.Contains("system_trust_trusted");
				if (flag3)
				{
					result = "[<color=#8c00ff>Legend</color>]";
				}
				else
				{
					bool flag4 = Instance.Method_Internal_get_APIUser_0().hasLegendTrustLevel || (Instance.Method_Internal_get_APIUser_0().tags.Contains("system_trust_legend") && Instance.Method_Internal_get_APIUser_0().tags.Contains("system_trust_trusted"));
					if (flag4)
					{
						result = "[<color=#8c00ff>Veteran</color>]";
					}
					else
					{
						bool hasVeteranTrustLevel = Instance.Method_Internal_get_APIUser_0().hasVeteranTrustLevel;
						if (hasVeteranTrustLevel)
						{
							result = "[<color=#8c00ff>Trusted</color>]";
						}
						else
						{
							bool hasTrustedTrustLevel = Instance.Method_Internal_get_APIUser_0().hasTrustedTrustLevel;
							if (hasTrustedTrustLevel)
							{
								result = "[<color=#ff9100>Known</color>]";
							}
							else
							{
								bool hasKnownTrustLevel = Instance.Method_Internal_get_APIUser_0().hasKnownTrustLevel;
								if (hasKnownTrustLevel)
								{
									result = "[<color=#11ff00>User</color>]";
								}
								else
								{
									bool flag5 = Instance.Method_Internal_get_APIUser_0().hasBasicTrustLevel || Instance.Method_Internal_get_APIUser_0().isNewUser;
									if (flag5)
									{
										result = "[<color=#0095ff>New User</color>]";
									}
									else
									{
										bool hasNegativeTrustLevel = Instance.Method_Internal_get_APIUser_0().hasNegativeTrustLevel;
										if (hasNegativeTrustLevel)
										{
											result = "[<color=#8c8c8c>Nuisance</color>]";
										}
										else
										{
											bool hasVeryNegativeTrustLevel = Instance.Method_Internal_get_APIUser_0().hasVeryNegativeTrustLevel;
											if (hasVeryNegativeTrustLevel)
											{
												result = "[<color=#8c8c8c>Nuisance++</color>]";
											}
											else
											{
												result = "[<color=#8c8c8c>Visitor</color>]";
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return result;
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00008FA8 File Offset: 0x000071A8
	internal static string PlayerAviname(Player Instance)
	{
		return "<color=#008cff>[Avi name : " + Instance.Method_Public_get_ApiAvatar_0().name + "]</color>";
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00008FD4 File Offset: 0x000071D4
	internal static string PlayerAviID(Player Instance)
	{
		return "<color=#ff0040>[Avi id : " + Instance.Method_Public_get_ApiAvatar_0().id + "]</color>";
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00009000 File Offset: 0x00007200
	internal static string PlayerAviAuth(Player Instance)
	{
		return "<color=#f457ff>[Avi author name : " + Instance.Method_Public_get_ApiAvatar_0().authorName + "]</color>";
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x0000902C File Offset: 0x0000722C
	internal static string PlayerAvipuborpri(Player Instance)
	{
		return "<color=#57fff7>[Avi Release Status : " + Instance.Method_Public_get_ApiAvatar_0().releaseStatus + "]</color>";
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00009058 File Offset: 0x00007258
	internal static string PlayerAviPatform(Player Instance)
	{
		return string.Format("<color=#ff8052>[Avi Supported Platforms : {0}]</color>", Instance.Method_Public_get_ApiAvatar_0().supportedPlatforms);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00009084 File Offset: 0x00007284
	internal static string PlayerAviWhen(Player Instance)
	{
		return "<color=#f9ff4f>[Avi Release Date : " + Instance.Method_Public_get_ApiAvatar_0().updated_at.ToString() + "]</color>";
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x000090B8 File Offset: 0x000072B8
	internal static void Nameplate_TExt_QUEST(Player Instance)
	{
		bool isOnMobile = Instance.Method_Internal_get_APIUser_0().IsOnMobile;
		if (isOnMobile)
		{
			Playerlist.Nameplate_color_Quest(Instance);
		}
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x000090E0 File Offset: 0x000072E0
	internal static void Nameplate_color_dev(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(2f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(2f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(2f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(2f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(2f, 0f, 0f, 0.5f);
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x000091DC File Offset: 0x000073DC
	internal static void Nameplate_color_Vis(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(0f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(0f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(0f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(0f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(0f, 0f, 0f, 0.5f);
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x000092D8 File Offset: 0x000074D8
	internal static void Nameplate_color_New(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(0f, 0f, 2.7f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(0f, 0f, 2.7f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(0f, 0f, 2.7f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(0f, 0f, 2.7f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(0f, 0f, 2.7f, 0.5f);
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x000093D4 File Offset: 0x000075D4
	internal static void Nameplate_color_User(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(0.2f, 1f, 0.2f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(0.2f, 1f, 0.2f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(0.2f, 1f, 0.2f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(0.2f, 1f, 0.2f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(0.2f, 1f, 0.2f, 0.5f);
	}

	// Token: 0x060000FA RID: 250 RVA: 0x000094D0 File Offset: 0x000076D0
	internal static void Nameplate_color_Known(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(1.6f, 0.5f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(1.6f, 0.5f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(1.6f, 0.5f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(1.6f, 0f, 0f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(1.6f, 0f, 0f, 0.5f);
	}

	// Token: 0x060000FB RID: 251 RVA: 0x000095CC File Offset: 0x000077CC
	internal static void Nameplate_color_trused(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_1.color = new Color(0.9f, 0f, 1f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_2.color = new Color(0.9f, 0f, 1f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_3.color = new Color(0.9f, 0f, 1f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_5.color = new Color(0.9f, 0f, 1f, 0.5f);
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_Graphic_7.color = new Color(0.9f, 0f, 1f, 0.5f);
	}

	// Token: 0x060000FC RID: 252 RVA: 0x000096C5 File Offset: 0x000078C5
	internal static void Nameplate_color_WorldMaster(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_TextMeshProUGUI_0.color = new Color(0f, 1.5f, 1.8f);
	}

	// Token: 0x060000FD RID: 253 RVA: 0x000096F2 File Offset: 0x000078F2
	internal static void Nameplate_color_ADMIN(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_TextMeshProUGUI_0.color = new Color(2f, 0f, 0f);
	}

	// Token: 0x060000FE RID: 254 RVA: 0x0000971F File Offset: 0x0000791F
	internal static void Nameplate_color_Quest(Player Instance)
	{
		Instance.Method_Internal_get_VRCPlayer_0().field_Public_PlayerNameplate_0.field_Public_TextMeshProUGUI_1.color = new Color(0.2f, 1f, 0.2f, 0.5f);
	}

	// Token: 0x0400009E RID: 158
	private static int noUpdateCount;

	// Token: 0x0400009F RID: 159
	private static byte ping;

	// Token: 0x040000A0 RID: 160
	private static byte frames;
}
