﻿using System;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000017 RID: 23
internal class MenuButton
{
	// Token: 0x06000063 RID: 99 RVA: 0x00005E48 File Offset: 0x00004048
	public MenuButton(MenuButton.MenuType type, MenuButton.MenuButtonType buttontype, string text, float x_pos, float y_pos, Action listener)
	{
		try
		{
			switch (buttontype)
			{
			case MenuButton.MenuButtonType.PlaylistButton:
			{
				GameObject playlistsButton = MenuContent.Screens_1.UserInfo_2.Buttons_3.RightSideButtons_4.RightUpperButtonColumn_5.PlaylistsButton;
				this.Button = Object.Instantiate<GameObject>(playlistsButton, playlistsButton.transform);
				break;
			}
			case MenuButton.MenuButtonType.AvatarFavButton:
			{
				GameObject favorite_Button = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button, favorite_Button.transform.parent);
				break;
			}
			case MenuButton.MenuButtonType.HeaderButton:
			{
				GameObject worldsPageTab = MenuButton.WorldsPageTab;
				this.Button = Object.Instantiate<GameObject>(worldsPageTab, worldsPageTab.transform.parent);
				break;
			}
			default:
			{
				GameObject favorite_Button2 = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button2, favorite_Button2.transform.parent);
				break;
			}
			}
		}
		catch (Exception)
		{
			throw;
		}
		try
		{
			switch (type)
			{
			case MenuButton.MenuType.UserInfo:
				this.Button.transform.SetParent(MenuContent.Screens_1.UserInfo.transform);
				break;
			case MenuButton.MenuType.AvatarMenu:
				this.Button.transform.SetParent(MenuContent.Screens_1.Avatar.transform);
				break;
			case MenuButton.MenuType.SettingsMenu:
				this.Button.transform.SetParent(MenuContent.Screens_1.Settings.transform);
				break;
			case MenuButton.MenuType.SocialMenu:
				this.Button.transform.SetParent(MenuContent.Screens_1.Social.transform);
				break;
			case MenuButton.MenuType.WorldMenu:
				this.Button.transform.SetParent(MenuContent.Screens_1.Worlds.transform);
				break;
			case MenuButton.MenuType.WorldInfo:
				break;
			default:
				this.Button.transform.SetParent(MenuContent.Screens_1.UserInfo.transform);
				break;
			}
		}
		catch (Exception)
		{
			throw;
		}
		foreach (Text text2 in this.Button.GetComponentsInChildren<Text>(true))
		{
			text2.text = "";
		}
		foreach (Image image in this.Button.GetComponentsInChildren<Image>(true))
		{
			bool flag = image.name.ToLower().Contains("icon");
			if (flag)
			{
				Object.Destroy(image);
			}
		}
		this.Button.GetComponentInChildren<Text>().text = text;
		this.Button.name = text;
		this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
		this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
		this.Button.GetComponentInChildren<Button>().m_Interactable = true;
		this.Button.GetComponent<RectTransform>().anchoredPosition = new Vector2(x_pos, y_pos);
		this.Button.name = string.Format("MenuButton_{0}_{1}_{2}", text, x_pos, y_pos);
		this.Button.SetActive(true);
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00006170 File Offset: 0x00004370
	public MenuButton(MenuButton.MenuType type, MenuButton.MenuButtonType buttontype, string text, float x_pos, float y_pos, Action listener, float xSize, float ySize)
	{
		try
		{
			switch (buttontype)
			{
			case MenuButton.MenuButtonType.PlaylistButton:
			{
				GameObject playlistsButton = MenuContent.Screens_1.UserInfo_2.Buttons_3.RightSideButtons_4.RightUpperButtonColumn_5.PlaylistsButton;
				this.Button = Object.Instantiate<GameObject>(playlistsButton, playlistsButton.transform);
				break;
			}
			case MenuButton.MenuButtonType.AvatarFavButton:
			{
				GameObject favorite_Button = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button, favorite_Button.transform.parent);
				break;
			}
			case MenuButton.MenuButtonType.HeaderButton:
			{
				GameObject worldsPageTab = MenuButton.WorldsPageTab;
				this.Button = Object.Instantiate<GameObject>(worldsPageTab, worldsPageTab.transform.parent);
				break;
			}
			default:
			{
				GameObject favorite_Button2 = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button2, favorite_Button2.transform.parent);
				break;
			}
			}
		}
		catch (Exception)
		{
			throw;
		}
		try
		{
			switch (type)
			{
			case MenuButton.MenuType.UserInfo:
				this.Button.transform.SetParent(MenuButton.UserInfoPage.transform);
				break;
			case MenuButton.MenuType.AvatarMenu:
				this.Button.transform.SetParent(MenuButton.AvatarPage.transform);
				break;
			case MenuButton.MenuType.SettingsMenu:
				this.Button.transform.SetParent(MenuButton.SettingsPage.transform);
				break;
			case MenuButton.MenuType.SocialMenu:
				this.Button.transform.SetParent(MenuButton.SocialPage.transform);
				break;
			case MenuButton.MenuType.WorldMenu:
				this.Button.transform.SetParent(MenuButton.WorldsPage.transform);
				break;
			default:
				this.Button.transform.SetParent(MenuButton.UserInfoPage.transform);
				break;
			}
		}
		catch (Exception)
		{
			throw;
		}
		foreach (Text text2 in this.Button.GetComponentsInChildren<Text>(true))
		{
			text2.text = "";
		}
		foreach (Image image in this.Button.GetComponentsInChildren<Image>(true))
		{
			bool flag = image.name.ToLower().Contains("icon");
			if (flag)
			{
				Object.Destroy(image);
			}
		}
		this.Button.GetComponentInChildren<Text>().text = text;
		this.Button.name = text;
		this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
		this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
		this.Button.GetComponentInChildren<Button>().m_Interactable = true;
		this.Button.GetComponent<RectTransform>().anchoredPosition = new Vector2(x_pos, y_pos);
		this.Button.GetComponent<RectTransform>().sizeDelta += new Vector2(xSize, ySize);
		this.Button.name = string.Format("MenuButton_{0}_{1}_{2}", text, x_pos, y_pos);
		this.Button.SetActive(true);
	}

	// Token: 0x06000065 RID: 101 RVA: 0x000064B8 File Offset: 0x000046B8
	public MenuButton(Transform Parent, MenuButton.MenuButtonType buttontype, string text, float x_pos, float y_pos, Action listener, float xSize, float ySize)
	{
		try
		{
			switch (buttontype)
			{
			case MenuButton.MenuButtonType.PlaylistButton:
			{
				GameObject playlistsButton = MenuContent.Screens_1.UserInfo_2.Buttons_3.RightSideButtons_4.RightUpperButtonColumn_5.PlaylistsButton;
				this.Button = Object.Instantiate<GameObject>(playlistsButton, playlistsButton.transform);
				break;
			}
			case MenuButton.MenuButtonType.AvatarFavButton:
			{
				GameObject favorite_Button = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button, favorite_Button.transform.parent);
				break;
			}
			case MenuButton.MenuButtonType.HeaderButton:
			{
				GameObject worldsPageTab = MenuButton.WorldsPageTab;
				this.Button = Object.Instantiate<GameObject>(worldsPageTab, worldsPageTab.transform.parent);
				break;
			}
			default:
			{
				GameObject favorite_Button2 = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button2, favorite_Button2.transform.parent);
				break;
			}
			}
			this.Button.transform.SetParent(Parent);
			foreach (Text text2 in this.Button.GetComponentsInChildren<Text>(true))
			{
				text2.text = "";
			}
			foreach (Image image in this.Button.GetComponentsInChildren<Image>(true))
			{
				bool flag = image.name.ToLower().Contains("icon");
				if (flag)
				{
					Object.Destroy(image);
				}
			}
			this.Button.GetComponentInChildren<Text>().text = text;
			this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
			this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
			this.Button.GetComponentInChildren<Button>().m_Interactable = true;
			this.Button.GetComponent<RectTransform>().anchoredPosition = new Vector2(x_pos, y_pos);
			Il2CppReferenceArray<Component> componentsInChildren = this.Button.GetComponentsInChildren(Il2CppType.Of<Image>());
			this.Button.GetComponent<RectTransform>().sizeDelta += new Vector2(xSize, ySize);
			this.Button.name = text;
		}
		catch (Exception)
		{
			throw;
		}
		this.Button.SetActive(true);
	}

	// Token: 0x06000066 RID: 102 RVA: 0x00006738 File Offset: 0x00004938
	public MenuButton(Transform Parent, GameObject Tmeplate, string text, float x_pos, float y_pos, Action listener, float xSize, float ySize)
	{
		try
		{
			this.Button = Object.Instantiate<GameObject>(Tmeplate, Tmeplate.transform.parent);
			this.Button.transform.SetParent(Parent);
			foreach (Text text2 in this.Button.GetComponentsInChildren<Text>(true))
			{
				text2.text = "";
			}
			foreach (Image image in this.Button.GetComponentsInChildren<Image>(true))
			{
				bool flag = image.name.ToLower().Contains("icon");
				if (flag)
				{
					Object.Destroy(image);
				}
			}
			this.Button.GetComponentInChildren<Text>().text = text;
			this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
			this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
			this.Button.GetComponentInChildren<Button>().m_Interactable = true;
			this.Button.GetComponent<RectTransform>().anchoredPosition = new Vector2(x_pos, y_pos);
			Il2CppReferenceArray<Component> componentsInChildren = this.Button.GetComponentsInChildren(Il2CppType.Of<Image>());
			this.Button.GetComponent<RectTransform>().sizeDelta += new Vector2(xSize, ySize);
			this.Button.name = text;
		}
		catch (Exception)
		{
			throw;
		}
		this.Button.SetActive(true);
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00006924 File Offset: 0x00004B24
	public MenuButton(Transform Parent, MenuButton.MenuButtonType buttontype, string text, float x_pos, float y_pos, Action listener)
	{
		try
		{
			switch (buttontype)
			{
			case MenuButton.MenuButtonType.PlaylistButton:
			{
				GameObject playlistsButton = MenuContent.Screens_1.UserInfo_2.Buttons_3.RightSideButtons_4.RightUpperButtonColumn_5.PlaylistsButton;
				this.Button = Object.Instantiate<GameObject>(playlistsButton, playlistsButton.transform);
				break;
			}
			case MenuButton.MenuButtonType.AvatarFavButton:
			{
				GameObject favorite_Button = MenuContent.Screens_1.Avatar_2.Favorite_Button;
				this.Button = Object.Instantiate<GameObject>(favorite_Button, favorite_Button.transform.parent);
				break;
			}
			case MenuButton.MenuButtonType.HeaderButton:
			{
				GameObject worldsPageTab = MenuButton.WorldsPageTab;
				this.Button = Object.Instantiate<GameObject>(worldsPageTab, worldsPageTab.transform.parent);
				break;
			}
			default:
				throw new ArgumentOutOfRangeException("buttontype", buttontype, null);
			}
			this.Button.transform.SetParent(Parent);
			this.Button.name = text;
			foreach (Text text2 in this.Button.GetComponentsInChildren<Text>(true))
			{
				text2.text = "";
			}
			foreach (Image image in this.Button.GetComponentsInChildren<Image>(true))
			{
				bool flag = image.name.ToLower().Contains("icon");
				if (flag)
				{
					Object.Destroy(image);
				}
			}
			this.Button.GetComponentInChildren<Text>().text = text;
			this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
			this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
			this.Button.GetComponentInChildren<Button>().m_Interactable = true;
			this.Button.GetComponent<RectTransform>().anchoredPosition = new Vector2(x_pos, y_pos);
			this.Button.name = string.Format("MenuButton_{0}_{1}_{2}", text, x_pos, y_pos);
		}
		catch (Exception)
		{
			throw;
		}
		this.Button.SetActive(true);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00006B7C File Offset: 0x00004D7C
	public void SetPos(float x, float y)
	{
		this.Button.GetComponent<RectTransform>().anchoredPosition += new Vector2(x, y);
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00006BA2 File Offset: 0x00004DA2
	public void SetSize(float x, float y)
	{
		this.Button.GetComponent<RectTransform>().sizeDelta += new Vector2(x, y);
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00006BC8 File Offset: 0x00004DC8
	public void SetText(string Text)
	{
		this.Button.GetComponentInChildren<Text>().text = Text;
	}

	// Token: 0x0600006B RID: 107 RVA: 0x00006BDD File Offset: 0x00004DDD
	public void SetAction(Action listener)
	{
		this.Button.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
		this.Button.GetComponentInChildren<Button>().onClick.AddListener(listener);
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00006C12 File Offset: 0x00004E12
	public void Delete()
	{
		Object.Destroy(this.Button);
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00006C21 File Offset: 0x00004E21
	public void SetActive(bool value)
	{
		this.Button.SetActive(value);
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00006C31 File Offset: 0x00004E31
	public void SetBackgroundColor(Color color)
	{
		this.Button.GetComponentInChildren<Image>().color = color;
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00006C46 File Offset: 0x00004E46
	public void SetTextColor(Color color)
	{
		this.Button.GetComponentInChildren<Text>().color = color;
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00006C5B File Offset: 0x00004E5B
	public void SetInteractable(bool result)
	{
		this.Button.GetComponentInChildren<Button>().interactable = result;
	}

	// Token: 0x04000050 RID: 80
	internal static GameObject WorldsPageTab = GameObject.Find("/UserInterface/MenuContent/Screens/Worlds");

	// Token: 0x04000051 RID: 81
	internal static GameObject UserInfoPage = GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo");

	// Token: 0x04000052 RID: 82
	internal static GameObject AvatarPage = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar");

	// Token: 0x04000053 RID: 83
	internal static GameObject SettingsPage = GameObject.Find("/UserInterface/MenuContent/Screens/Settings");

	// Token: 0x04000054 RID: 84
	internal static GameObject SocialPage = GameObject.Find("/UserInterface/MenuContent/Screens/Social");

	// Token: 0x04000055 RID: 85
	internal static GameObject WorldsPage = GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo");

	// Token: 0x04000056 RID: 86
	public GameObject Button;

	// Token: 0x020000BE RID: 190
	public enum MenuType
	{
		// Token: 0x04000367 RID: 871
		UserInfo,
		// Token: 0x04000368 RID: 872
		AvatarMenu,
		// Token: 0x04000369 RID: 873
		SettingsMenu,
		// Token: 0x0400036A RID: 874
		SocialMenu,
		// Token: 0x0400036B RID: 875
		WorldMenu,
		// Token: 0x0400036C RID: 876
		WorldInfo
	}

	// Token: 0x020000BF RID: 191
	internal enum MenuButtonType
	{
		// Token: 0x0400036E RID: 878
		PlaylistButton,
		// Token: 0x0400036F RID: 879
		AvatarFavButton,
		// Token: 0x04000370 RID: 880
		HeaderButton
	}
}
