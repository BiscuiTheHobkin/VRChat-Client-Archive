﻿using System;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using VRC.Core;

// Token: 0x0200001A RID: 26
public static class rendererlmao
{
	// Token: 0x0600007D RID: 125 RVA: 0x00006E24 File Offset: 0x00005024
	public static void StartRenderElementsCoroutine(this UiVRCList instance, List<ApiAvatar> avatarList, int offset = 0, bool endOfPickers = true, VRCUiContentButton contentHeaderElement = null)
	{
		bool flag = !instance.gameObject.activeInHierarchy || !instance.isActiveAndEnabled || instance.isOffScreen || !instance.enabled;
		bool flag2 = !flag;
		if (flag2)
		{
			bool flag3 = instance.scrollRect != null;
			bool flag4 = flag3;
			if (flag4)
			{
				instance.scrollRect.normalizedPosition = new Vector2(0f, 0f);
			}
			instance.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(avatarList, offset, endOfPickers, contentHeaderElement);
		}
	}
}
