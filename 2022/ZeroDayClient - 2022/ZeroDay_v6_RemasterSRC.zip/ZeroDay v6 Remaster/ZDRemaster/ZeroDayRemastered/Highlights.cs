﻿using System;
using System.Collections;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;
using ZDBase;

namespace ZeroDayRemastered
{
	// Token: 0x02000054 RID: 84
	public static class Highlights
	{
		// Token: 0x06000274 RID: 628 RVA: 0x0001305F File Offset: 0x0001125F
		public static IEnumerator itemsespref()
		{
			for (;;)
			{
				int num;
				for (int i = 0; i < PickupSword.array1.Length; i = num + 1)
				{
					try
					{
						bool flag = PickupSword.array1[i].gameObject && !(HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null);
						if (flag)
						{
							bool flag2 = !(PickupSword.array1[i].GetComponent<MeshRenderer>() != null);
							if (flag2)
							{
								bool flag3 = !PickupSword.array1[i].GetComponent<MonoBehaviourPublicObReGaMaCaTeMaUnique>() && !PickupSword.array1[i].GetComponent<SphereCollider>();
								if (flag3)
								{
									MeshRenderer render2 = PickupSword.array1[i].GetComponentInChildren<MeshRenderer>();
									HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(render2, MainConfigSettings.Instance.ItemEsp);
									render2 = null;
								}
							}
							else
							{
								MeshRenderer render3 = PickupSword.array1[i].GetComponent<MeshRenderer>();
								HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(render3, MainConfigSettings.Instance.ItemEsp);
								render3 = null;
							}
						}
					}
					catch
					{
					}
					yield return null;
					num = i;
				}
				bool flag4 = !MainConfigSettings.Instance.ItemEsp;
				if (flag4)
				{
					break;
				}
				yield return new WaitForSeconds(0.8f);
			}
			yield break;
		}

		// Token: 0x06000275 RID: 629 RVA: 0x00013068 File Offset: 0x00011268
		public static void PlayerMeshEsp(Player Target, bool State)
		{
			try
			{
				foreach (Renderer renderer in Target._vrcplayer.field_Internal_GameObject_0.GetComponentsInChildren<Renderer>())
				{
					Highlights.GetHighlightsFX(Target.Method_Internal_get_APIUser_0()).Method_Public_Void_Renderer_Boolean_0(renderer, State);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000276 RID: 630 RVA: 0x000130E8 File Offset: 0x000112E8
		public static void PlayerMeshEsp1(Player Target, bool State)
		{
			try
			{
				foreach (SkinnedMeshRenderer skinnedMeshRenderer in Target.gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
				{
					bool flag = Target.Method_Internal_get_APIUser_0() == APIUser.CurrentUser;
					if (!flag)
					{
						Highlights.GetHighlightsFX(Target.Method_Internal_get_APIUser_0()).Method_Public_Void_Renderer_Boolean_0(skinnedMeshRenderer, State);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00013178 File Offset: 0x00011378
		public static IEnumerator togglepickupsesp()
		{
			for (;;)
			{
				bool pickupsESP = MainConfigSettings.Instance.PickupsESP;
				if (pickupsESP)
				{
					Highlights.PickupsEsp(true);
				}
				else
				{
					Highlights.PickupsEsp(false);
				}
				yield return new WaitForSeconds(1f);
			}
			yield break;
		}

		// Token: 0x06000278 RID: 632 RVA: 0x00013180 File Offset: 0x00011380
		internal static void PickupsEsp(bool state)
		{
			Il2CppArrayBase<VRCPickup> il2CppArrayBase = Resources.FindObjectsOfTypeAll<VRCPickup>();
			foreach (VRCPickup vrcpickup in il2CppArrayBase)
			{
				bool flag = !(vrcpickup == null) && !(vrcpickup.gameObject == null) && vrcpickup.gameObject.active && vrcpickup.enabled && vrcpickup.pickupable;
				if (flag)
				{
					HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Virtual_Boolean_0();
					HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().field_Protected_Material_0.SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
					HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(vrcpickup.GetComponent<MeshRenderer>(), state);
				}
			}
		}

		// Token: 0x06000279 RID: 633 RVA: 0x00013254 File Offset: 0x00011454
		internal static IEnumerator amungusESP1(bool state)
		{
			for (;;)
			{
				MeshRenderer body = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer body2 = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body3 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body4 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body5 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body6 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body7 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body8 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body9 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body10 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body11 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body12 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body13 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body14 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body15 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body16 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body17 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body18 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body19 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body20 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer body21 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().field_Protected_Material_0.SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body2.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body3.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body4.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body5.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body6.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body7.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body8.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body9.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body10.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body11.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body12.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body13.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body14.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body15.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body16.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body17.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body18.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body19.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body20.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(body21.GetComponent<MeshRenderer>(), state);
				yield return new WaitForSeconds(0.1f);
				body = null;
				body2 = null;
				body3 = null;
				body4 = null;
				body5 = null;
				body6 = null;
				body7 = null;
				body8 = null;
				body9 = null;
				body10 = null;
				body11 = null;
				body12 = null;
				body13 = null;
				body14 = null;
				body15 = null;
				body16 = null;
				body17 = null;
				body18 = null;
				body19 = null;
				body20 = null;
				body21 = null;
			}
			yield break;
		}

		// Token: 0x0600027A RID: 634 RVA: 0x00013263 File Offset: 0x00011463
		internal static IEnumerator HenryESP(bool state)
		{
			for (;;)
			{
				SkinnedMeshRenderer snake = GameObject.Find("Game Logic/Snakes/Snake/Geo/Snake Stuff/Snake Geo/snake/snake").GetComponent<SkinnedMeshRenderer>();
				MeshRenderer knife = GameObject.Find("Game Logic/Weapons/Knife (0)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer knife2 = GameObject.Find("Game Logic/Weapons/Knife (1)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer knife3 = GameObject.Find("Game Logic/Weapons/Knife (2)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer knife4 = GameObject.Find("Game Logic/Weapons/Knife (3)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer knife5 = GameObject.Find("Game Logic/Weapons/Knife (4)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer knife6 = GameObject.Find("Game Logic/Weapons/Knife (5)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer revolver = GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer trap = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer trap2 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer trap3 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer trap4 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				MeshRenderer trap5 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				GameObject trap6 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (0)");
				MeshRenderer trap7 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer trap8 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer trap9 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer Luger = GameObject.Find("Game Logic/Weapons/Unlockables/Luger (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer Shotgun = GameObject.Find("Game Logic/Weapons/Unlockables/Shotgun (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer Frag = GameObject.Find("Game Logic/Weapons/Unlockables/Frag (0)/Intact/frag geo").GetComponent<MeshRenderer>();
				MeshRenderer Smoke = GameObject.Find("Game Logic/Weapons/Unlockables/Smoke (0)/Intact/smoke geo").GetComponent<MeshRenderer>();
				MeshRenderer snake2 = GameObject.Find("Game Logic/Snakes/SnakeDispenser/snake crate geo").GetComponent<MeshRenderer>();
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().field_Protected_Material_0.SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(snake.GetComponent<SkinnedMeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife2.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife3.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife4.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife5.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(knife6.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(revolver.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap2.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap3.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap4.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap5.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap6.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap7.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap8.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(trap9.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(Luger.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(Shotgun.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(Frag.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(Smoke.GetComponent<MeshRenderer>(), state);
				HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(snake2.GetComponent<MeshRenderer>(), state);
				yield return new WaitForSeconds(0.1f);
				snake = null;
				knife = null;
				knife2 = null;
				knife3 = null;
				knife4 = null;
				knife5 = null;
				knife6 = null;
				revolver = null;
				trap = null;
				trap2 = null;
				trap3 = null;
				trap4 = null;
				trap5 = null;
				trap6 = null;
				trap7 = null;
				trap8 = null;
				trap9 = null;
				Luger = null;
				Shotgun = null;
				Frag = null;
				Smoke = null;
				snake2 = null;
			}
			yield break;
		}

		// Token: 0x0600027B RID: 635 RVA: 0x00013274 File Offset: 0x00011474
		public static void HighlightPlayer(Player player, bool highlighted)
		{
			Transform transform = player.transform.Find("SelectRegion");
			bool flag = !(transform == null);
			if (flag)
			{
				Highlights.GetHighlightsFX(player.field_Private_APIUser_0).Method_Public_Void_Renderer_Boolean_0(transform.GetComponent<Renderer>(), highlighted);
			}
		}

		// Token: 0x0600027C RID: 636 RVA: 0x000132BC File Offset: 0x000114BC
		public static Player[] GetPlayers(this PlayerManager playerManager)
		{
			return playerManager.Method_Public_get_ArrayOf_Player_0();
		}

		// Token: 0x0600027D RID: 637 RVA: 0x000132DC File Offset: 0x000114DC
		public static void ToggleESP(bool enabled)
		{
			try
			{
				PlayerManager field_Private_Static_PlayerManager_ = PlayerManager.field_Private_Static_PlayerManager_0;
				bool flag = !(field_Private_Static_PlayerManager_ == null);
				if (flag)
				{
					Player[] players = field_Private_Static_PlayerManager_.GetPlayers();
					foreach (Player player in players)
					{
						Highlights.HighlightPlayer(player, enabled);
					}
				}
			}
			catch (Exception ex)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
		}

		// Token: 0x0600027E RID: 638 RVA: 0x00013354 File Offset: 0x00011554
		private static HighlightsFXStandalone GetHighlightsFX(APIUser apiUser)
		{
			HighlightsFXStandalone result;
			try
			{
				bool flag = APIUser.IsFriendsWith(apiUser.id);
				if (flag)
				{
					result = Highlights._friendsHighlights;
				}
				else
				{
					result = Highlights._othersHighlights;
				}
			}
			catch (Exception ex)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
			return result;
		}

		// Token: 0x0600027F RID: 639 RVA: 0x000133A4 File Offset: 0x000115A4
		internal static IEnumerator GhostV1ESP(bool state)
		{
			for (;;)
			{
				GameObject file = GameObject.Find("NameClueSystem/NameClues/CluePickup/Folder_file");
				GameObject file2 = GameObject.Find("NameClueSystem/NameClues/CluePickup (1)/Folder_file");
				GameObject file3 = GameObject.Find("NameClueSystem/NameClues/CluePickup (2)/Folder_file");
				GameObject file4 = GameObject.Find("NameClueSystem/NameClues/CluePickup (3)/Folder_file");
				GameObject file5 = GameObject.Find("NameClueSystem/NameClues/CluePickup (4)/Folder_file");
				GameObject file6 = GameObject.Find("NameClueSystem/NameClues/CluePickup (5)/Folder_file");
				GameObject file7 = GameObject.Find("NameClueSystem/NameClues/CluePickup (6)/Folder_file");
				GameObject file8 = GameObject.Find("NameClueSystem/NameClues/CluePickup (7)/Folder_file");
				GameObject file9 = GameObject.Find("NameClueSystem/NameClues/CluePickup (8)/Folder_file");
				GameObject file10 = GameObject.Find("PoliceStation/Props/NameClueSystem/NameClues/CluePickup (9)/Folder_file");
				GameObject key = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key/KeyModel/prf_v_key_02/sm_key_01");
				GameObject key2 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (1)/KeyModel/prf_v_key_02/sm_key_01");
				Highlights.keys.Method_Public_Void_Renderer_Boolean_0(key.GetComponent<MeshRenderer>(), state);
				Highlights.keys.Method_Public_Void_Renderer_Boolean_0(key2.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file2.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file3.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file4.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file5.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file6.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file7.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file8.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file9.GetComponent<MeshRenderer>(), state);
				Highlights.folders.Method_Public_Void_Renderer_Boolean_0(file10.GetComponent<MeshRenderer>(), state);
				yield return new WaitForSeconds(1f);
				file = null;
				file2 = null;
				file3 = null;
				file4 = null;
				file5 = null;
				file6 = null;
				file7 = null;
				file8 = null;
				file9 = null;
				file10 = null;
				key = null;
				key2 = null;
			}
			yield break;
		}

		// Token: 0x040001A2 RID: 418
		public static List<VRC_Pickup> AllPickups = new List<VRC_Pickup>();

		// Token: 0x040001A3 RID: 419
		public static List<VRCPickup> AllUdonPickups = new List<VRCPickup>();

		// Token: 0x040001A4 RID: 420
		public static List<VRC_Trigger> AllTriggers = new List<VRC_Trigger>();

		// Token: 0x040001A5 RID: 421
		public static List<VRC_ObjectSync> AllSyncPickups = new List<VRC_ObjectSync>();

		// Token: 0x040001A6 RID: 422
		public static bool Esptest2 = false;

		// Token: 0x040001A7 RID: 423
		public static bool outlineesp = false;

		// Token: 0x040001A8 RID: 424
		public static HighlightsFXStandalone _friendsHighlights;

		// Token: 0x040001A9 RID: 425
		public static HighlightsFXStandalone _othersHighlights;

		// Token: 0x040001AA RID: 426
		public static HighlightsFXStandalone pickuphighlight;

		// Token: 0x040001AB RID: 427
		public static List<Renderer> TriggersRenderers = new List<Renderer>();

		// Token: 0x040001AC RID: 428
		public static List<Renderer> PickupsRenderers = new List<Renderer>();

		// Token: 0x040001AD RID: 429
		public static HighlightsFXStandalone keys;

		// Token: 0x040001AE RID: 430
		public static HighlightsFXStandalone folders;
	}
}
