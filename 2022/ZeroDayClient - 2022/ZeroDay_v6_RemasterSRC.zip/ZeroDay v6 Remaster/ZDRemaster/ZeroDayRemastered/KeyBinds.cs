﻿using System;
using System.Collections;
using MelonLoader;
using UnityEngine;
using VRC.SDKBase;
using ZDBase;
using ZDBase.Modules;
using ZDBase.Utils;
using ZeroDayRemastered.Modules;

namespace ZeroDayRemastered
{
	// Token: 0x02000055 RID: 85
	public class KeyBinds
	{
		// Token: 0x06000281 RID: 641 RVA: 0x00013409 File Offset: 0x00011609
		public static IEnumerator Fly()
		{
			for (;;)
			{
				KeyBinds.CameraTransform = Camera.main.transform;
				bool keyDown = Input.GetKeyDown(304);
				if (keyDown)
				{
					Movement.FlySpeed *= 2f;
				}
				bool keyUp = Input.GetKeyUp(304);
				if (keyUp)
				{
					Movement.FlySpeed /= 2f;
				}
				bool key = Input.GetKey(101);
				if (key)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.up * Movement.FlySpeed * Time.deltaTime;
				}
				bool key2 = Input.GetKey(113);
				if (key2)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position -= KeyBinds.CameraTransform.up * Movement.FlySpeed * Time.deltaTime;
				}
				bool key3 = Input.GetKey(119);
				if (key3)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.forward * Movement.FlySpeed * Time.deltaTime;
				}
				bool key4 = Input.GetKey(97);
				if (key4)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position -= KeyBinds.CameraTransform.right * Movement.FlySpeed * Time.deltaTime;
				}
				bool key5 = Input.GetKey(100);
				if (key5)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.right * Movement.FlySpeed * Time.deltaTime;
				}
				bool key6 = Input.GetKey(115);
				if (key6)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position -= KeyBinds.CameraTransform.forward * Movement.FlySpeed * Time.deltaTime;
				}
				bool flag = Networking.LocalPlayer.IsUserInVR();
				if (flag)
				{
					bool flag2 = Math.Abs(Input.GetAxis("Vertical")) != 0f;
					if (flag2)
					{
						VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.forward * Movement.FlySpeed * Time.deltaTime * Input.GetAxis("Vertical");
					}
					bool flag3 = Math.Abs(Input.GetAxis("Horizontal")) != 0f;
					if (flag3)
					{
						VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.right * Movement.FlySpeed * Time.deltaTime * Input.GetAxis("Horizontal");
					}
					bool flag4 = Input.GetAxis("Oculus_CrossPlatform_SecondaryThumbstickVertical") < 0f;
					if (flag4)
					{
						VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.up * Movement.FlySpeed * Time.deltaTime * Input.GetAxisRaw("Oculus_CrossPlatform_SecondaryThumbstickVertical");
					}
					bool flag5 = Input.GetAxis("Oculus_CrossPlatform_SecondaryThumbstickVertical") > 0f;
					if (flag5)
					{
						VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position += KeyBinds.CameraTransform.up * Movement.FlySpeed * Time.deltaTime * Input.GetAxisRaw("Oculus_CrossPlatform_SecondaryThumbstickVertical");
					}
				}
				Networking.LocalPlayer.SetVelocity(Vector3.zero);
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00013414 File Offset: 0x00011614
		public static void Initialize()
		{
			bool flag = Input.GetKey(306) && Input.GetKeyDown(102);
			if (flag)
			{
				bool flag2 = !MainConfigSettings.flight;
				if (flag2)
				{
					MainConfigSettings.flight = true;
					KeyBinds.flycor = MelonCoroutines.Start(KeyBinds.Fly());
					VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = false;
				}
				else
				{
					MainConfigSettings.flight = false;
					MelonCoroutines.Stop(KeyBinds.flycor);
					VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = true;
				}
			}
			else
			{
				bool flag3 = Input.GetKey(306) && Input.GetKeyDown(100);
				if (flag3)
				{
					bool flag4 = !MainConfigSettings.DeathHands;
					if (flag4)
					{
						try
						{
							MainConfigSettings.DeathHands = true;
							Utilities.StaffNotify("Activated Hands Of Death");
							touchstuff.actionforontap = "SyncKill";
							GameObject gameObject = GameObject.CreatePrimitive(3);
							gameObject.name = "AzureEngineLmfao";
							gameObject.transform.localScale = new Vector3(0.06f, 0.06f, 0.06f);
							gameObject.transform.parent = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject.transform;
							gameObject.transform.localPosition = new Vector3(0f, 0.005f, 0f);
							gameObject.AddComponent<touchstuff>();
							gameObject.GetComponent<MeshRenderer>().material.color = Color.red;
							gameObject.AddComponent<Rigidbody>().isKinematic = true;
							gameObject.layer = 2;
						}
						catch
						{
						}
					}
					else
					{
						try
						{
							MainConfigSettings.DeathHands = false;
							touchstuff.actionforontap = "SyncKill";
							GameObject gameObject2 = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject;
							Object.Destroy(gameObject2.transform.Find("AzureEngineLmfao").gameObject);
						}
						catch
						{
						}
					}
				}
				else
				{
					bool flag5 = Input.GetKey(306) && Input.GetKeyDown(116);
					if (flag5)
					{
						bool flag6 = !ThirdPerson.IsFirst;
						if (flag6)
						{
							ThirdPerson.First();
						}
						else
						{
							bool flag7 = ThirdPerson.IsFirst && !ThirdPerson.IsSecond;
							if (flag7)
							{
								ThirdPerson.Second();
							}
							else
							{
								bool isSecond = ThirdPerson.IsSecond;
								if (isSecond)
								{
									ThirdPerson.Third();
								}
							}
						}
					}
				}
			}
			bool enabled = ThirdPerson.Enabled;
			if (enabled)
			{
				float axis = Input.GetAxis("Mouse ScrollWheel");
				bool key = Input.GetKey(273);
				if (key)
				{
					ThirdPerson.CameraObject1.transform.position += ThirdPerson.CameraObject1.transform.up * 0.008f;
					ThirdPerson.CameraObject2.transform.position += ThirdPerson.CameraObject2.transform.up * 0.008f;
				}
				else
				{
					bool key2 = Input.GetKey(274);
					if (key2)
					{
						ThirdPerson.CameraObject1.transform.position -= ThirdPerson.CameraObject1.transform.up * 0.008f;
						ThirdPerson.CameraObject2.transform.position -= ThirdPerson.CameraObject2.transform.up * 0.008f;
					}
					else
					{
						bool key3 = Input.GetKey(276);
						if (key3)
						{
							ThirdPerson.CameraObject1.transform.position -= ThirdPerson.CameraObject1.transform.right * 0.008f;
							ThirdPerson.CameraObject2.transform.position += ThirdPerson.CameraObject2.transform.right * 0.008f;
						}
						else
						{
							bool key4 = Input.GetKey(275);
							if (key4)
							{
								ThirdPerson.CameraObject1.transform.position += ThirdPerson.CameraObject1.transform.right * 0.008f;
								ThirdPerson.CameraObject2.transform.position -= ThirdPerson.CameraObject2.transform.right * 0.008f;
							}
						}
					}
				}
				bool flag8 = axis > 0f;
				if (flag8)
				{
					ThirdPerson.CameraObject1.transform.position += ThirdPerson.CameraObject1.transform.forward * 0.08f;
					ThirdPerson.CameraObject2.transform.position += ThirdPerson.CameraObject2.transform.forward * 0.08f;
				}
				else
				{
					bool flag9 = axis < 0f;
					if (flag9)
					{
						ThirdPerson.CameraObject1.transform.position -= ThirdPerson.CameraObject1.transform.forward * 0.08f;
						ThirdPerson.CameraObject2.transform.position -= ThirdPerson.CameraObject2.transform.forward * 0.08f;
					}
				}
			}
			else
			{
				bool flag10 = Input.GetKey(306) && Input.GetKeyDown(103);
				if (flag10)
				{
					bool flag11 = !MainConfigSettings.Rotator;
					if (flag11)
					{
						RotationSystem.Toggle();
						MainConfigSettings.Rotator = true;
					}
					else
					{
						RotationSystem.Toggle();
						MainConfigSettings.Rotator = false;
					}
				}
			}
		}

		// Token: 0x040001AF RID: 431
		private static Transform CameraTransform;

		// Token: 0x040001B0 RID: 432
		public static object flycor;

		// Token: 0x040001B1 RID: 433
		private static bool keyFlag;
	}
}
