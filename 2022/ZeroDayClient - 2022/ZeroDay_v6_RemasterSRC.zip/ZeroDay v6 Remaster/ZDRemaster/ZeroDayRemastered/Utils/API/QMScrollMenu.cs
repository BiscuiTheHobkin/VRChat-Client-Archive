﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Utils.API
{
	// Token: 0x02000082 RID: 130
	public class QMScrollMenu
	{
		// Token: 0x0600039D RID: 925 RVA: 0x0001F09C File Offset: 0x0001D29C
		public QMScrollMenu(QMNestedButton basemenu)
		{
			this.BaseMenu = basemenu;
			this.IndexButton = new QMSingleButton(this.BaseMenu, 4f, 1.65f, "Page:\n" + (this.currentMenuIndex + 1).ToString() + " of " + (this.Index + 1).ToString(), delegate()
			{
			}, "", false, null, null, null, false);
			this.IndexButton.GetGameObject().GetComponent<Button>().enabled = false;
			this.BackButton = new QMSingleButton(this.BaseMenu, 4f, 0.75f, "Back", delegate()
			{
				this.ShowMenu(this.currentMenuIndex - 1);
			}, "Go Back", false, null, null, null, false);
			this.NextButton = new QMSingleButton(this.BaseMenu, 4f, 2.55f, "Next", delegate()
			{
				this.ShowMenu(this.currentMenuIndex + 1);
			}, "Go Next", false, null, null, null, false);
		}

		// Token: 0x0600039E RID: 926 RVA: 0x0001F21C File Offset: 0x0001D41C
		public void ShowMenu(int MenuIndex)
		{
			bool flag = !this.AllowOverStepping && (MenuIndex < 0 || MenuIndex > this.Index);
			if (!flag)
			{
				foreach (QMScrollMenu.ScrollObject scrollObject in this.QMButtons)
				{
					bool flag2 = scrollObject.Index == MenuIndex;
					if (flag2)
					{
						QMButtonBase buttonBase = scrollObject.ButtonBase;
						if (buttonBase != null)
						{
							buttonBase.SetActive(true);
						}
					}
					else
					{
						QMButtonBase buttonBase2 = scrollObject.ButtonBase;
						if (buttonBase2 != null)
						{
							buttonBase2.SetActive(false);
						}
					}
				}
				this.currentMenuIndex = MenuIndex;
				this.IndexButton.SetButtonText("Page:\n" + (this.currentMenuIndex + 1).ToString() + " of " + (this.Index + 1).ToString());
			}
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0001F30C File Offset: 0x0001D50C
		public void SetAction(Action<QMScrollMenu> Open, bool shouldClear = true)
		{
			try
			{
				this.OpenAction = Open;
				this.BaseMenu.GetMainButton().SetAction(delegate
				{
					bool shouldClear2 = shouldClear;
					if (shouldClear2)
					{
						this.Clear();
					}
					this.OpenAction(this);
					this.BaseMenu.OpenMe();
					this.ShowMenu(0);
				});
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x0001F374 File Offset: 0x0001D574
		public void Refresh()
		{
			this.Clear();
			Action<QMScrollMenu> openAction = this.OpenAction;
			if (openAction != null)
			{
				openAction(this);
			}
			this.BaseMenu.OpenMe();
			this.ShowMenu(0);
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x0001F3A8 File Offset: 0x0001D5A8
		public void DestroyMe()
		{
			foreach (QMScrollMenu.ScrollObject scrollObject in this.QMButtons)
			{
				Object.Destroy(scrollObject.ButtonBase.GetGameObject());
			}
			this.QMButtons.Clear();
			bool flag = this.BaseMenu.GetBackButton() != null;
			if (flag)
			{
				Object.Destroy(this.BaseMenu.GetBackButton());
			}
			bool flag2 = this.IndexButton != null;
			if (flag2)
			{
				this.IndexButton.DestroyMe();
			}
			bool flag3 = this.BackButton != null;
			if (flag3)
			{
				this.BackButton.DestroyMe();
			}
			bool flag4 = this.NextButton != null;
			if (flag4)
			{
				this.NextButton.DestroyMe();
			}
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0001F48C File Offset: 0x0001D68C
		public void Clear()
		{
			try
			{
				foreach (QMScrollMenu.ScrollObject scrollObject in this.QMButtons)
				{
					Object.Destroy(scrollObject.ButtonBase.GetGameObject());
				}
				this.QMButtons.Clear();
				this.Posx = 0;
				this.Posy = 0;
				this.Index = 0;
				this.currentMenuIndex = 0;
			}
			catch
			{
			}
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0001F52C File Offset: 0x0001D72C
		public void Add(QMSingleButton Button)
		{
			bool flag = this.Posx < 4;
			if (flag)
			{
				this.Posx++;
			}
			bool flag2 = this.Posx == 4;
			if (flag2)
			{
				this.Posx = 1;
				this.Posy++;
			}
			bool flag3 = this.Posy == 4;
			if (flag3)
			{
				this.Posy = 0;
				this.Index++;
			}
			bool shouldChangePos = this.ShouldChangePos;
			if (shouldChangePos)
			{
				Button.SetLocation((float)this.Posx, (float)this.Posy);
			}
			Button.SetActive(false);
			this.QMButtons.Add(new QMScrollMenu.ScrollObject
			{
				ButtonBase = Button,
				Index = this.Index
			});
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x0001F5EC File Offset: 0x0001D7EC
		public void Add(QMButtonBase Button, int Page, float POSX = 0f, float POSY = 0f)
		{
			bool shouldChangePos = this.ShouldChangePos;
			if (shouldChangePos)
			{
				Button.SetLocation((float)this.Posx, (float)this.Posy);
			}
			Button.SetActive(false);
			this.QMButtons.Add(new QMScrollMenu.ScrollObject
			{
				ButtonBase = Button,
				Index = Page
			});
			bool flag = !this.IgnoreEverything;
			if (flag)
			{
				bool flag2 = Page > this.Index;
				if (flag2)
				{
					this.Index = Page;
				}
			}
		}

		// Token: 0x0400026B RID: 619
		public QMNestedButton BaseMenu;

		// Token: 0x0400026C RID: 620
		public QMSingleButton NextButton;

		// Token: 0x0400026D RID: 621
		public QMSingleButton BackButton;

		// Token: 0x0400026E RID: 622
		public QMSingleButton IndexButton;

		// Token: 0x0400026F RID: 623
		public QMSingleButton RefreshButton;

		// Token: 0x04000270 RID: 624
		public List<QMScrollMenu.ScrollObject> QMButtons = new List<QMScrollMenu.ScrollObject>();

		// Token: 0x04000271 RID: 625
		private int Posx = 0;

		// Token: 0x04000272 RID: 626
		private int Posy = 0;

		// Token: 0x04000273 RID: 627
		private int Index = 0;

		// Token: 0x04000274 RID: 628
		private Action<QMScrollMenu> OpenAction;

		// Token: 0x04000275 RID: 629
		public int currentMenuIndex = 0;

		// Token: 0x04000276 RID: 630
		public bool ShouldChangePos = true;

		// Token: 0x04000277 RID: 631
		public bool AllowOverStepping = false;

		// Token: 0x04000278 RID: 632
		public bool IgnoreEverything = false;

		// Token: 0x0200014A RID: 330
		public class ScrollObject
		{
			// Token: 0x04000713 RID: 1811
			public QMButtonBase ButtonBase;

			// Token: 0x04000714 RID: 1812
			public int Index;
		}
	}
}
