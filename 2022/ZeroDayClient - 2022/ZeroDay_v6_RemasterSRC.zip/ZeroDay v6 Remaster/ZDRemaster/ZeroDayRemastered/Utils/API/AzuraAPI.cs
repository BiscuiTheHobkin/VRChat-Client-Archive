﻿using System;
using System.Collections.Generic;
using ZeroDayRemastered.API.QM;
using ZeroDayRemastered.API.SM;

namespace ZeroDayRemastered.Utils.API
{
	// Token: 0x02000081 RID: 129
	internal static class AzuraAPI
	{
		// Token: 0x04000260 RID: 608
		internal const string Identifier = "Azura.Best";

		// Token: 0x04000261 RID: 609
		internal static List<QMSingleButton> allQMSingleButtons = new List<QMSingleButton>();

		// Token: 0x04000262 RID: 610
		internal static List<QMSinglePanel> allPanels = new List<QMSinglePanel>();

		// Token: 0x04000263 RID: 611
		internal static List<QMNestedButton> allQMNestedButtons = new List<QMNestedButton>();

		// Token: 0x04000264 RID: 612
		internal static List<QMToggleButton> allQMToggleButtons = new List<QMToggleButton>();

		// Token: 0x04000265 RID: 613
		internal static List<QMInfo> allQMInfos = new List<QMInfo>();

		// Token: 0x04000266 RID: 614
		internal static List<QMSlider> allQMSliders = new List<QMSlider>();

		// Token: 0x04000267 RID: 615
		internal static List<QMLabel> allQMLabels = new List<QMLabel>();

		// Token: 0x04000268 RID: 616
		internal static List<SMButton> allSMButtons = new List<SMButton>();

		// Token: 0x04000269 RID: 617
		internal static List<SMList> allSMLists = new List<SMList>();

		// Token: 0x0400026A RID: 618
		internal static List<SMText> allSMTexts = new List<SMText>();
	}
}
