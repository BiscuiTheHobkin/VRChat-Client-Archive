﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.SM
{
	// Token: 0x02000088 RID: 136
	internal class SMButton
	{
		// Token: 0x060003C3 RID: 963 RVA: 0x00020278 File Offset: 0x0001E478
		public SMButton(SMButton.SMButtonType type, string location, float PosX, float PosY, string buttonText, Action buttonAction, float sizeX = 1f, float sizeY = 1f)
		{
			this.Initialize(type, APIStuff.GetSocialMenuInstance().transform.Find(location), PosX, PosY, buttonText, buttonAction, sizeX, sizeY);
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x000202B0 File Offset: 0x0001E4B0
		public SMButton(SMButton.SMButtonType type, Transform location, float PosX, float PosY, string buttonText, Action buttonAction, float sizeX = 1f, float sizeY = 1f)
		{
			this.Initialize(type, location, PosX, PosY, buttonText, buttonAction, sizeX, sizeY);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x000202DC File Offset: 0x0001E4DC
		private void Initialize(SMButton.SMButtonType type, Transform location, float PosX, float PosY, string buttonText, Action buttonAction, float XSize, float YSize)
		{
			switch (type)
			{
			case SMButton.SMButtonType.EditStatus:
				this.button = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").gameObject, location);
				this.text = this.button.transform.Find("Text").GetComponent<Text>();
				this.text.transform.SetAsLastSibling();
				break;
			case SMButton.SMButtonType.ChangeAvatar:
				this.button = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("Avatar/Change Button").gameObject, location);
				this.text = this.button.transform.Find("Label").GetComponent<Text>();
				break;
			case SMButton.SMButtonType.ExitVRChat:
				this.button = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("Settings/Footer/Exit").gameObject, location);
				this.text = this.button.transform.Find("Text").GetComponent<Text>();
				break;
			case SMButton.SMButtonType.DropPortal:
				this.button = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("WorldInfo/WorldButtons/PortalButton").gameObject, location);
				this.text = this.button.transform.Find("Text").GetComponent<Text>();
				break;
			default:
				this.button = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").gameObject, location);
				this.text = this.button.transform.Find("Text").GetComponent<Text>();
				break;
			}
			this.button.name = string.Format("{0}-SMButton-{1}", "Azura.Best", APIStuff.RandomNumbers());
			ColorBlock colors = this.button.GetComponent<Button>().colors;
			Selectable component = this.button.GetComponent<Button>();
			ColorBlock colors2 = default(ColorBlock);
			colors2.colorMultiplier = colors.colorMultiplier;
			colors2.disabledColor = colors.disabledColor;
			colors2.fadeDuration = colors.fadeDuration;
			colors2.highlightedColor = colors.highlightedColor;
			colors2.normalColor = colors.normalColor;
			colors2.selectedColor = colors.normalColor;
			colors2.pressedColor = colors.pressedColor;
			component.colors = colors2;
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			this.button.GetComponent<Button>().onClick.AddListener(buttonAction);
			this.button.transform.localScale = new Vector3(1f, 1f, 1f);
			this.button.GetComponent<RectTransform>().sizeDelta /= new Vector2(XSize, YSize);
			this.SetText(buttonText);
			this.SetLocation(new Vector2(PosX, PosY));
			this.text.color = Color.white;
			AzuraAPI.allSMButtons.Add(this);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x000205F1 File Offset: 0x0001E7F1
		public void SetInteractable(bool state)
		{
			this.button.GetComponent<Button>().interactable = state;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x00020606 File Offset: 0x0001E806
		public void SetText(string message)
		{
			this.text.supportRichText = true;
			this.text.text = message;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x00020623 File Offset: 0x0001E823
		public void SetLocation(Vector2 location)
		{
			this.button.GetComponent<RectTransform>().anchoredPosition = location;
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00020638 File Offset: 0x0001E838
		public void SetColor(Color color)
		{
			this.button.GetComponentInChildren<Image>().color = color;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0002064D File Offset: 0x0001E84D
		public void SetActive(bool state)
		{
			this.button.SetActive(state);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x00020660 File Offset: 0x0001E860
		public Text GetText()
		{
			return this.text;
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00020678 File Offset: 0x0001E878
		public GameObject GetGameObject()
		{
			return this.button;
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00020690 File Offset: 0x0001E890
		public void SetImage(Sprite image)
		{
			this.button.GetComponentInChildren<Image>().sprite = image;
		}

		// Token: 0x060003CE RID: 974 RVA: 0x000206A8 File Offset: 0x0001E8A8
		public void SetImageColor(Color color)
		{
			ColorBlock colors = this.button.GetComponent<Button>().colors;
			ColorBlock colorBlock = default(ColorBlock);
			colorBlock.colorMultiplier = colors.colorMultiplier;
			colorBlock.disabledColor = colors.disabledColor;
			colorBlock.fadeDuration = colors.fadeDuration;
			colorBlock.highlightedColor = color;
			colorBlock.normalColor = color;
			colorBlock.pressedColor = colors.pressedColor;
			ColorBlock colors2 = colorBlock;
			this.button.GetComponent<Button>().colors = colors2;
		}

		// Token: 0x060003CF RID: 975 RVA: 0x00020734 File Offset: 0x0001E934
		[DebuggerStepThrough]
		public void SetImage(string URL)
		{
			SMButton.<SetImage>d__14 <SetImage>d__ = new SMButton.<SetImage>d__14();
			<SetImage>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SetImage>d__.<>4__this = this;
			<SetImage>d__.URL = URL;
			<SetImage>d__.<>1__state = -1;
			<SetImage>d__.<>t__builder.Start<SMButton.<SetImage>d__14>(ref <SetImage>d__);
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x00020774 File Offset: 0x0001E974
		[DebuggerStepThrough]
		private Task GetRemoteTexture(Image Instance, string url)
		{
			SMButton.<GetRemoteTexture>d__15 <GetRemoteTexture>d__ = new SMButton.<GetRemoteTexture>d__15();
			<GetRemoteTexture>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetRemoteTexture>d__.<>4__this = this;
			<GetRemoteTexture>d__.Instance = Instance;
			<GetRemoteTexture>d__.url = url;
			<GetRemoteTexture>d__.<>1__state = -1;
			<GetRemoteTexture>d__.<>t__builder.Start<SMButton.<GetRemoteTexture>d__15>(ref <GetRemoteTexture>d__);
			return <GetRemoteTexture>d__.<>t__builder.Task;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x000207C8 File Offset: 0x0001E9C8
		public void SetShader(string shaderName)
		{
			Material material = new Material(this.button.GetComponentInChildren<Image>().material);
			material.shader = Shader.Find(shaderName);
			this.button.gameObject.GetComponentInChildren<Image>().material = material;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00020810 File Offset: 0x0001EA10
		public Texture2D getTexture()
		{
			return new Texture2D(this.button.gameObject.GetComponent<Image>().mainTexture.width, this.button.gameObject.GetComponent<Image>().mainTexture.height, 4, false);
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0002085F File Offset: 0x0001EA5F
		public void ToggleTexture(bool state)
		{
			this.button.GetComponentInChildren<Image>().enabled = state;
		}

		// Token: 0x0400029F RID: 671
		public GameObject button;

		// Token: 0x040002A0 RID: 672
		public Text text;

		// Token: 0x02000150 RID: 336
		public enum SMButtonType
		{
			// Token: 0x04000726 RID: 1830
			EditStatus,
			// Token: 0x04000727 RID: 1831
			ChangeAvatar,
			// Token: 0x04000728 RID: 1832
			ExitVRChat,
			// Token: 0x04000729 RID: 1833
			DropPortal,
			// Token: 0x0400072A RID: 1834
			Header
		}
	}
}
