﻿using System;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC.Core;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.SM
{
	// Token: 0x02000089 RID: 137
	internal class SMList
	{
		// Token: 0x060003D4 RID: 980 RVA: 0x00020874 File Offset: 0x0001EA74
		public SMList(Transform parent, string name, int Position = 0)
		{
			this.Initialize(parent, name, Position);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00020888 File Offset: 0x0001EA88
		private void Initialize(Transform parent, string name, int Position = 0)
		{
			this.GameObject = Object.Instantiate<GameObject>(SMList.PublicAvatarList.gameObject, parent);
			this.GameObject.GetComponent<UiAvatarList>().field_Public_Category_0 = 4;
			this.UiVRCList = this.GameObject.GetComponent<UiVRCList>();
			this.Text = this.GameObject.transform.Find("Button").GetComponentInChildren<Text>();
			this.GameObject.transform.SetSiblingIndex(Position);
			this.UiVRCList.clearUnseenListOnCollapse = false;
			this.UiVRCList.usePagination = false;
			this.UiVRCList.hideElementsWhenContracted = false;
			this.UiVRCList.hideWhenEmpty = false;
			this.UiVRCList.field_Protected_Dictionary_2_Int32_List_1_ApiModel_0.Clear();
			this.UiVRCList.pickerPrefab.transform.Find("TitleText").GetComponent<Text>().supportRichText = true;
			this.GameObject.SetActive(true);
			this.GameObject.name = name;
			this.Text.supportRichText = true;
			this.Text.text = name;
			AzuraAPI.allSMLists.Add(this);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x000209AC File Offset: 0x0001EBAC
		public void RenderElement(List<ApiAvatar> AvatarList)
		{
			this.UiVRCList.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(AvatarList, 0, true, null);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x000209C0 File Offset: 0x0001EBC0
		public GameObject GetGameObject()
		{
			return this.GameObject;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x000209D8 File Offset: 0x0001EBD8
		public UiVRCList GetUiVRCList()
		{
			return this.UiVRCList;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x000209F0 File Offset: 0x0001EBF0
		public Text GetText()
		{
			return this.Text;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00020A08 File Offset: 0x0001EC08
		public void DestroyMe()
		{
			try
			{
				Object.Destroy(this.GameObject);
			}
			catch
			{
			}
		}

		// Token: 0x040002A1 RID: 673
		protected GameObject GameObject;

		// Token: 0x040002A2 RID: 674
		protected UiVRCList UiVRCList;

		// Token: 0x040002A3 RID: 675
		protected Text Text;

		// Token: 0x040002A4 RID: 676
		private static GameObject PublicAvatarList = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Public Avatar List");
	}
}
