﻿using System;
using UnityEngine;
using UnityEngine.UI;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.SM
{
	// Token: 0x0200008A RID: 138
	internal class SMText
	{
		// Token: 0x060003DC RID: 988 RVA: 0x00020A4D File Offset: 0x0001EC4D
		public SMText(APIStuff.SMLocations location, float PosX, float PosY, float SizeX, float SizeY, string textLabel, Color? textColor = null)
		{
			this.Initialize(APIStuff.GetSocialMenuInstance().transform.Find(location.ToString()), PosX, PosY, SizeX, SizeY, textLabel, textColor);
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00020A84 File Offset: 0x0001EC84
		public SMText(Transform location, float PosX, float PosY, float SizeX, float SizeY, string textLabel, Color? textColor = null)
		{
			this.Initialize(location, PosX, PosY, SizeX, SizeY, textLabel, textColor);
		}

		// Token: 0x060003DE RID: 990 RVA: 0x00020AA0 File Offset: 0x0001ECA0
		private void Initialize(Transform location, float PosX, float PosY, float SizeX, float SizeY, string textLabel, Color? textColor = null)
		{
			this.textObject = Object.Instantiate<GameObject>(APIStuff.GetSocialMenuInstance().transform.Find("Settings/AudioDevicePanel/MicDeviceText").gameObject, location, false);
			this.text = this.textObject.GetComponent<Text>();
			this.textObject.name = string.Format("{0}-SMText-{1}", "Azura.Best", APIStuff.RandomNumbers());
			this.SetLocation(new Vector2(PosX, PosY));
			this.SetSize(new Vector2(SizeX, SizeY));
			this.SetText(textLabel);
			bool flag = textColor != null;
			if (flag)
			{
				this.SetColor(textColor.Value);
			}
			AzuraAPI.allSMTexts.Add(this);
		}

		// Token: 0x060003DF RID: 991 RVA: 0x00020B56 File Offset: 0x0001ED56
		public void SetLocation(Vector2 location)
		{
			this.textObject.GetComponent<RectTransform>().anchoredPosition = location;
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x00020B6B File Offset: 0x0001ED6B
		public void SetSize(Vector2 size)
		{
			this.textObject.GetComponent<RectTransform>().sizeDelta = size;
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x00020B80 File Offset: 0x0001ED80
		public void SetColor(Color newColor)
		{
			this.text.color = newColor;
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x00020B90 File Offset: 0x0001ED90
		public void SetText(string message)
		{
			this.text.supportRichText = true;
			this.text.text = message;
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x00020BAD File Offset: 0x0001EDAD
		public void SetAnchor(TextAnchor alignment)
		{
			this.text.alignment = alignment;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x00020BBD File Offset: 0x0001EDBD
		public void SetFontSize(int size)
		{
			this.text.fontSize = size;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x00020BD0 File Offset: 0x0001EDD0
		public GameObject GetGameObject()
		{
			return this.textObject;
		}

		// Token: 0x040002A5 RID: 677
		protected GameObject textObject;

		// Token: 0x040002A6 RID: 678
		protected Text text;
	}
}
