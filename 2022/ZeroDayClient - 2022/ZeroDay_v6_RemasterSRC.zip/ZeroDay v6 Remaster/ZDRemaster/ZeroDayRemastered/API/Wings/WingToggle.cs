﻿using System;
using UnityEngine;

namespace ZeroDayRemastered.API.Wings
{
	// Token: 0x02000087 RID: 135
	public class WingToggle
	{
		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060003BD RID: 957 RVA: 0x00020119 File Offset: 0x0001E319
		// (set) Token: 0x060003BE RID: 958 RVA: 0x00020124 File Offset: 0x0001E324
		public bool State
		{
			get
			{
				return this.state;
			}
			set
			{
				bool flag = this.state == value;
				if (!flag)
				{
					this.button.text.color = (value ? this.on : this.off);
					Action<bool> action = this.onClick;
					this.state = value;
					action(value);
				}
			}
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0002017C File Offset: 0x0001E37C
		public WingToggle(BaseWing wing, string name, Transform parent, int pos, Color on, Color off, bool initial, Action<bool> onClick)
		{
			this.wing = wing;
			this.on = on;
			this.off = off;
			this.onClick = onClick;
			this.button = new WingButton(wing, name, parent, pos, delegate()
			{
				this.State = !this.State;
			});
			this.button.text.color = (initial ? on : off);
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x000201E8 File Offset: 0x0001E3E8
		public WingToggle(WingPage page, string name, int index, Color on, Color off, bool initial, Action<bool> onClick)
		{
			this.wing = page.wing;
			this.on = on;
			this.off = off;
			this.onClick = onClick;
			this.button = new WingButton(page, name, index, delegate()
			{
				this.State = !this.State;
			})
			{
				text = 
				{
					color = (initial ? on : off)
				}
			};
		}

		// Token: 0x04000299 RID: 665
		private bool state;

		// Token: 0x0400029A RID: 666
		private readonly Action<bool> onClick;

		// Token: 0x0400029B RID: 667
		public BaseWing wing;

		// Token: 0x0400029C RID: 668
		public WingButton button;

		// Token: 0x0400029D RID: 669
		public Color on;

		// Token: 0x0400029E RID: 670
		public Color off;
	}
}
