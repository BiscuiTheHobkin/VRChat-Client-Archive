﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ZeroDayRemastered.API.Wings
{
	// Token: 0x02000084 RID: 132
	public class BaseWing
	{
		// Token: 0x060003B5 RID: 949 RVA: 0x0001FA90 File Offset: 0x0001DC90
		internal void Setup(Transform wing)
		{
			this.Wing = wing;
			this.WingOpen = wing.Find("Button");
			this.WingPages = wing.Find("Container/InnerContainer");
			this.WingMenu = this.WingPages.Find("WingMenu");
			this.WingButtons = this.WingPages.Find("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup");
			this.ProfilePage = this.WingPages.Find("Profile");
			this.ProfileButton = this.WingButtons.Find("Button_Profile");
		}

		// Token: 0x04000289 RID: 649
		public readonly List<WingPage> openedPages = new List<WingPage>();

		// Token: 0x0400028A RID: 650
		public Transform Wing;

		// Token: 0x0400028B RID: 651
		public Transform WingOpen;

		// Token: 0x0400028C RID: 652
		public Transform WingPages;

		// Token: 0x0400028D RID: 653
		public Transform WingMenu;

		// Token: 0x0400028E RID: 654
		public Transform WingButtons;

		// Token: 0x0400028F RID: 655
		public Transform ProfilePage;

		// Token: 0x04000290 RID: 656
		public Transform ProfileButton;
	}
}
