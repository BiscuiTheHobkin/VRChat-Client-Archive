﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ZeroDayRemastered.API.Wings
{
	// Token: 0x02000085 RID: 133
	public class WingButton
	{
		// Token: 0x060003B7 RID: 951 RVA: 0x0001FB34 File Offset: 0x0001DD34
		public WingButton(BaseWing wing, string name, Transform parent, int pos, Action onClick)
		{
			this.wing = wing;
			this.transform = Object.Instantiate<Transform>(wing.ProfileButton, parent);
			this.transform.GetComponent<RectTransform>().sizeDelta = new Vector2(420f, 144f);
			this.transform.transform.localPosition = new Vector3(0f, (float)pos, this.transform.transform.localPosition.z);
			(this.text = this.transform.GetComponentInChildren<TextMeshProUGUI>()).text = name;
			Button component = this.transform.GetComponent<Button>();
			component.onClick = new Button.ButtonClickedEvent();
			component.onClick.AddListener(onClick);
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0001FBFC File Offset: 0x0001DDFC
		public WingButton(WingPage page, string name, int index, Action onClick)
		{
			this.wing = page.wing;
			Transform transform = Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			transform.GetComponent<RectTransform>().sizeDelta = new Vector2(420f, 144f);
			transform.transform.localPosition = new Vector3(0f, (float)(320 - index * 120), transform.transform.localPosition.z);
			(this.text = transform.GetComponentInChildren<TextMeshProUGUI>()).text = name;
			Button component = transform.GetComponent<Button>();
			component.onClick = new Button.ButtonClickedEvent();
			component.onClick.AddListener(onClick);
		}

		// Token: 0x04000291 RID: 657
		public BaseWing wing;

		// Token: 0x04000292 RID: 658
		public TextMeshProUGUI text;

		// Token: 0x04000293 RID: 659
		public Transform transform;
	}
}
