﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ZeroDayRemastered.API.Wings
{
	// Token: 0x02000086 RID: 134
	public class WingPage
	{
		// Token: 0x060003B9 RID: 953 RVA: 0x0001FCBC File Offset: 0x0001DEBC
		public WingPage(BaseWing wing, string name)
		{
			WingPage <>4__this = this;
			this.wing = wing;
			this.transform = Object.Instantiate<Transform>(wing.ProfilePage, wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.gameObject.SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				Object.Destroy(transform.GetChild(i).gameObject);
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().text = name;
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.onClick = new Button.ButtonClickedEvent();
			this.closeButton.onClick.AddListener(delegate()
			{
				<>4__this.transform.gameObject.SetActive(false);
				wing.openedPages.RemoveAt(wing.openedPages.Count - 1);
				bool flag = wing.openedPages.Count > 0;
				if (flag)
				{
					WingPage wingPage = wing.openedPages[wing.openedPages.Count - 1];
					wingPage.transform.gameObject.SetActive(true);
				}
				else
				{
					wing.WingMenu.gameObject.SetActive(true);
				}
			});
			Transform transform2 = Object.Instantiate<Transform>(wing.ProfileButton, wing.WingButtons);
			(this.text = transform2.GetComponentInChildren<TextMeshProUGUI>()).text = name;
			this.openButton = transform2.GetComponent<Button>();
			this.openButton.onClick = new Button.ButtonClickedEvent();
			this.openButton.onClick.AddListener(delegate()
			{
				<>4__this.transform.gameObject.SetActive(true);
				wing.openedPages.Add(<>4__this);
				bool flag = wing.openedPages.Count > 1;
				if (flag)
				{
					WingPage wingPage = wing.openedPages[wing.openedPages.Count - 2];
					wingPage.transform.gameObject.SetActive(false);
				}
				else
				{
					wing.WingMenu.gameObject.SetActive(false);
				}
			});
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0001FE28 File Offset: 0x0001E028
		public WingPage(WingPage page, string name, int index)
		{
			this.wing = page.wing;
			this.transform = Object.Instantiate<Transform>(this.wing.ProfilePage, this.wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.gameObject.SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				Object.Destroy(transform.GetChild(i).gameObject);
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().text = name;
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.onClick = new Button.ButtonClickedEvent();
			this.closeButton.onClick.AddListener(delegate()
			{
				this.transform.gameObject.SetActive(false);
				this.wing.openedPages.RemoveAt(this.wing.openedPages.Count - 1);
				bool flag = this.wing.openedPages.Count > 0;
				if (flag)
				{
					WingPage wingPage = this.wing.openedPages[this.wing.openedPages.Count - 1];
					wingPage.transform.gameObject.SetActive(true);
				}
				else
				{
					this.wing.WingMenu.gameObject.SetActive(true);
				}
			});
			Transform transform2 = Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			(this.text = transform2.GetComponentInChildren<TextMeshProUGUI>()).text = name;
			this.openButton = transform2.GetComponent<Button>();
			this.openButton.GetComponent<RectTransform>().sizeDelta = new Vector2(420f, 144f);
			this.openButton.transform.localPosition = new Vector3(0f, (float)(320 - index * 120), this.transform.transform.localPosition.z);
			this.openButton.onClick = new Button.ButtonClickedEvent();
			this.openButton.onClick.AddListener(delegate()
			{
				this.transform.gameObject.SetActive(true);
				this.wing.openedPages.Add(this);
				bool flag = this.wing.openedPages.Count > 1;
				if (flag)
				{
					WingPage wingPage = this.wing.openedPages[this.wing.openedPages.Count - 2];
					wingPage.transform.gameObject.SetActive(false);
				}
				else
				{
					this.wing.WingMenu.gameObject.SetActive(false);
				}
			});
		}

		// Token: 0x04000294 RID: 660
		public BaseWing wing;

		// Token: 0x04000295 RID: 661
		public Transform transform;

		// Token: 0x04000296 RID: 662
		public TextMeshProUGUI text;

		// Token: 0x04000297 RID: 663
		public Button closeButton;

		// Token: 0x04000298 RID: 664
		public Button openButton;
	}
}
