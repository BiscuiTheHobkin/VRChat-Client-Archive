﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ZDBase;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x02000093 RID: 147
	public class QMToggleButton : QMButtonBase
	{
		// Token: 0x06000424 RID: 1060 RVA: 0x00022239 File Offset: 0x00020439
		public QMToggleButton(QMNestedButton location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			this.btnQMLoc = location.GetMenuName();
			this.Initialize(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00022262 File Offset: 0x00020462
		public QMToggleButton(string location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			this.btnQMLoc = location;
			this.Initialize(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x00022288 File Offset: 0x00020488
		private void Initialize(float btnXLocation, float btnYLocation, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState)
		{
			this.btnType = "ToggleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/" + this.btnQMLoc).transform, true);
			this.button.name = string.Format("ZD-{0}-{1}", this.btnType, APIStuff.RandomNumbers());
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.btnTextComp = this.button.GetComponentInChildren<TextMeshProUGUI>(true);
			this.btnComp = this.button.GetComponentInChildren<Button>(true);
			this.btnComp.onClick = new Button.ButtonClickedEvent();
			this.btnComp.onClick.AddListener(new Action(this.HandleClick));
			this.btnImageComp = this.button.transform.Find("Icon").GetComponentInChildren<Image>(true);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			this.button.transform.Find("Background").GetComponent<Image>().color = Color.black;
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText("<color=#8A2BE2>" + btnText);
			this.SetButtonActions(onAction, offAction);
			base.SetToolTip("<color=#8A2BE2>" + btnToolTip);
			base.SetActive(true);
			this.currentState = defaultState;
			Sprite sprite = this.currentState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
			this.btnImageComp.sprite = sprite;
			this.btnImageComp.overrideSprite = sprite;
			AzuraAPI.allQMToggleButtons.Add(this);
			Logs.LogSuccess(string.Format("Created [{0}] Toggles!", AzuraAPI.allQMToggleButtons.Count), false);
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x00022488 File Offset: 0x00020688
		private void HandleClick()
		{
			this.currentState = !this.currentState;
			Sprite sprite = this.currentState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
			this.btnImageComp.sprite = sprite;
			this.btnImageComp.overrideSprite = sprite;
			bool flag = this.currentState;
			if (flag)
			{
				this.OnAction();
			}
			else
			{
				this.OffAction();
			}
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x000224FC File Offset: 0x000206FC
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x00022511 File Offset: 0x00020711
		public void SetButtonActions(Action onAction, Action offAction)
		{
			this.OnAction = onAction;
			this.OffAction = offAction;
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x00022524 File Offset: 0x00020724
		public void SetToggleState(bool newState, bool shouldInvoke = false)
		{
			try
			{
				Sprite sprite = newState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
				this.btnImageComp.sprite = sprite;
				this.btnImageComp.overrideSprite = sprite;
				if (shouldInvoke)
				{
					if (newState)
					{
						this.OnAction();
					}
					else
					{
						this.OffAction();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x000225A0 File Offset: 0x000207A0
		public void ClickMe()
		{
			this.HandleClick();
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x000225AC File Offset: 0x000207AC
		public bool GetCurrentState()
		{
			return this.currentState;
		}

		// Token: 0x040002C2 RID: 706
		protected TextMeshProUGUI btnTextComp;

		// Token: 0x040002C3 RID: 707
		protected Button btnComp;

		// Token: 0x040002C4 RID: 708
		protected Image btnImageComp;

		// Token: 0x040002C5 RID: 709
		protected bool currentState;

		// Token: 0x040002C6 RID: 710
		protected Action OnAction;

		// Token: 0x040002C7 RID: 711
		protected Action OffAction;
	}
}
