﻿using System;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x02000092 RID: 146
	public class QMTablmao
	{
	}
}
