﻿using System;
using UnityEngine;
using VRC.UI.Elements.Tooltips;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x0200008B RID: 139
	public class QMButtonBase
	{
		// Token: 0x060003E6 RID: 998 RVA: 0x00020BE8 File Offset: 0x0001EDE8
		public GameObject GetGameObject()
		{
			return this.button;
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00020C00 File Offset: 0x0001EE00
		public void SetActive(bool state)
		{
			this.button.gameObject.SetActive(state);
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x00020C18 File Offset: 0x0001EE18
		public void SetLocation(float buttonXLoc, float buttonYLoc)
		{
			this.button.GetComponent<RectTransform>().anchoredPosition += Vector2.right * (232f * (buttonXLoc + (float)this.initShift[0]));
			this.button.GetComponent<RectTransform>().anchoredPosition += Vector2.down * (210f * (buttonYLoc + (float)this.initShift[1]));
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00020C94 File Offset: 0x0001EE94
		public void SetToolTip(string buttonToolTip)
		{
			this.button.GetComponent<UiTooltip>().field_Public_String_0 = buttonToolTip;
			this.button.GetComponent<UiTooltip>().field_Public_String_1 = buttonToolTip;
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00020CBC File Offset: 0x0001EEBC
		public void DestroyMe()
		{
			try
			{
				Object.Destroy(this.button);
			}
			catch
			{
			}
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00020CF0 File Offset: 0x0001EEF0
		internal virtual void SetBackgroundColor(Color buttonBackgroundColor, bool save = true)
		{
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x00020CF3 File Offset: 0x0001EEF3
		internal virtual void SetTextColor(Color buttonTextColor, bool save = true)
		{
		}

		// Token: 0x040002A7 RID: 679
		protected GameObject button;

		// Token: 0x040002A8 RID: 680
		protected string btnQMLoc;

		// Token: 0x040002A9 RID: 681
		protected string btnType;

		// Token: 0x040002AA RID: 682
		protected string btnTag;

		// Token: 0x040002AB RID: 683
		protected int[] initShift = new int[2];

		// Token: 0x040002AC RID: 684
		protected Color OrigBackground;

		// Token: 0x040002AD RID: 685
		protected Color OrigText;
	}
}
