﻿using System;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.UI.Core.Styles;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x0200008F RID: 143
	public class QMSinglePanel : QMButtonBase
	{
		// Token: 0x06000409 RID: 1033 RVA: 0x000215DC File Offset: 0x0001F7DC
		public QMSinglePanel(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0002167C File Offset: 0x0001F87C
		public QMSinglePanel(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00021714 File Offset: 0x0001F914
		private protected void InitButton(float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null)
		{
			this.btnType = "SingleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/" + this.btnQMLoc).transform, true);
			this.button.name = string.Format("AZURA-{0}-{1}", this.btnType, APIStuff.RandomNumbers());
			this.button.GetComponentInChildren<TextMeshProUGUI>().fontSize = 30f;
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().gameObject.SetActive(false);
			this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition += new Vector2(0f, 50f);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText("<color=#ffc0cb>" + btnText + "</color>");
			base.SetToolTip(btnToolTip);
			this.SetAction(btnAction);
			bool flag = btnBackgroundColor != null;
			if (flag)
			{
				this.SetBackgroundColor(btnBackgroundColor.Value, true);
			}
			else
			{
				this.OrigBackground = this.button.GetComponentInChildren<Image>().color;
			}
			bool flag2 = btnTextColor != null;
			if (flag2)
			{
				this.SetTextColor(btnTextColor.Value, true);
			}
			else
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().color;
			}
			base.SetActive(true);
			Object.Destroy(this.button.gameObject.GetComponent<StyleElement>());
			this.button.gameObject.transform.Find("Background").transform.localScale = new Vector3(1f, 0.5f, 1f);
			AzuraAPI.allPanels.Add(this);
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00021938 File Offset: 0x0001FB38
		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.transform.Find("Background").GetComponent<Image>().sprite = newImg;
			this.button.transform.Find("Background").GetComponent<Image>().overrideSprite = newImg;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00021988 File Offset: 0x0001FB88
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x000219A0 File Offset: 0x0001FBA0
		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			bool flag = buttonAction != null;
			if (flag)
			{
				this.button.GetComponent<Button>().onClick.AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x000219E8 File Offset: 0x0001FBE8
		public void ClickMe()
		{
			this.button.GetComponent<Button>().onClick.Invoke();
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00021A01 File Offset: 0x0001FC01
		internal override void SetBackgroundColor(Color buttonBackgroundColor, bool save = true)
		{
			this.button.GetComponentInChildren<Image>().color = buttonBackgroundColor;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00021A18 File Offset: 0x0001FC18
		internal override void SetTextColor(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}
	}
}
