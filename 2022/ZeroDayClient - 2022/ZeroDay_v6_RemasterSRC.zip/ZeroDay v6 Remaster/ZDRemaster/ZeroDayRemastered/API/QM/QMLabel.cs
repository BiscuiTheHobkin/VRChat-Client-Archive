﻿using System;
using TMPro;
using UnityEngine;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x0200008D RID: 141
	internal class QMLabel
	{
		// Token: 0x060003F7 RID: 1015 RVA: 0x00020EB6 File Offset: 0x0001F0B6
		public QMLabel(QMNestedButton location, float posX, float posY, string labelText, Color? textColor)
		{
			this.Initialize(location.GetMenuObject().transform.parent, posX, posY, labelText, textColor);
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x00020EDD File Offset: 0x0001F0DD
		public QMLabel(Transform location, float posX, float posY, string labelText, Color? textColor)
		{
			this.Initialize(location, posX, posY, labelText, textColor);
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x00020EF8 File Offset: 0x0001F0F8
		private void Initialize(Transform location, float posX, float posY, string labelText, Color? textColor)
		{
			this.gameObject = Object.Instantiate<GameObject>(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks/LeftItemContainer/Text_Title"), location, false);
			this.gameObject.name = string.Format("AZURA-QMLabel-{0}", APIStuff.RandomNumbers());
			this.text = this.gameObject.GetComponent<TextMeshProUGUI>();
			this.text.alignment = 514;
			this.text.autoSizeTextContainer = true;
			this.text.enableWordWrapping = false;
			this.text.fontSize = 32f;
			this.text.richText = true;
			this.SetPosition(new Vector2(posX, posY));
			this.SetText(labelText);
			bool flag = textColor != null;
			if (flag)
			{
				this.SetTextColor(textColor.Value);
			}
			AzuraAPI.allQMLabels.Add(this);
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00020FD4 File Offset: 0x0001F1D4
		public GameObject GetGameObject()
		{
			return this.gameObject;
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00020FEC File Offset: 0x0001F1EC
		public TextMeshProUGUI GetText()
		{
			return this.text;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00021004 File Offset: 0x0001F204
		public void SetText(string newText)
		{
			this.text.text = newText;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00021014 File Offset: 0x0001F214
		public void SetTextColor(Color newColor)
		{
			this.text.color = newColor;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00021024 File Offset: 0x0001F224
		public void SetPosition(Vector2 newPosition)
		{
			this.gameObject.GetComponent<RectTransform>().anchoredPosition = newPosition;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0002103C File Offset: 0x0001F23C
		public void DestroyMe()
		{
			try
			{
				Object.Destroy(this.gameObject);
				AzuraAPI.allQMLabels.Remove(this);
			}
			catch
			{
			}
		}

		// Token: 0x040002B1 RID: 689
		protected GameObject gameObject;

		// Token: 0x040002B2 RID: 690
		protected TextMeshProUGUI text;
	}
}
