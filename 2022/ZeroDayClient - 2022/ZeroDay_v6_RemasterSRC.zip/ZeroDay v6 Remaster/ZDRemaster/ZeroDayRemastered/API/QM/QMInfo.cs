﻿using System;
using UnityEngine;
using UnityEngine.UI;
using ZDBase;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x0200008C RID: 140
	public class QMInfo
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x00020D0B File Offset: 0x0001EF0B
		public QMInfo(Transform location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			this.Initialize(location, PosX, PosY, SizeX, SizeY, PanelText);
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x00020D25 File Offset: 0x0001EF25
		public QMInfo(QMNestedButton location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			this.Initialize(location.GetMenuObject().transform, PosX, PosY, SizeX, SizeY, PanelText);
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x00020D4C File Offset: 0x0001EF4C
		private void Initialize(Transform location, float PosX, float PosY, float SizeX, float SizeY, string panelText)
		{
			this.InfoObject = Object.Instantiate<GameObject>(APIStuff.GetQMInfoTemplate(), location);
			this.InfoObject.name = string.Format("AZURA-InfoPanel-{0}", APIStuff.RandomNumbers());
			this.InfoText = this.InfoObject.GetComponentInChildren<Text>();
			this.InfoBackground = this.InfoObject.GetComponentInChildren<Image>();
			this.SetSize(new Vector2(SizeX, SizeY));
			this.SetLocation(new Vector3(PosX, PosY, 1f));
			this.SetText(panelText);
			AzuraAPI.allQMInfos.Add(this);
			Logs.LogSuccess(string.Format("Created [{0}] QMPanels!", AzuraAPI.allQMInfos.Count), false);
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x00020E08 File Offset: 0x0001F008
		public void SetSize(Vector2 size)
		{
			this.InfoObject.GetComponent<RectTransform>().sizeDelta = size;
			this.InfoObject.transform.Find("Text").GetComponent<RectTransform>().sizeDelta = new Vector2(-25f, 0f);
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x00020E57 File Offset: 0x0001F057
		public void SetLocation(Vector3 location)
		{
			this.InfoObject.GetComponent<RectTransform>().anchoredPosition = location;
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x00020E71 File Offset: 0x0001F071
		public void SetText(string text)
		{
			this.InfoText.text = text;
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x00020E81 File Offset: 0x0001F081
		public void SetTextColor(Color newColor)
		{
			this.InfoText.color = newColor;
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x00020E91 File Offset: 0x0001F091
		public void ToggleBackground(bool state)
		{
			this.InfoObject.GetComponentInChildren<Image>().enabled = state;
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x00020EA6 File Offset: 0x0001F0A6
		public void SetActive(bool state)
		{
			this.InfoObject.SetActive(state);
		}

		// Token: 0x040002AE RID: 686
		public GameObject InfoObject;

		// Token: 0x040002AF RID: 687
		public Text InfoText;

		// Token: 0x040002B0 RID: 688
		public Image InfoBackground;
	}
}
