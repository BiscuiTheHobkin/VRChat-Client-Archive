﻿using System;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using ZeroDayRemastered.Modules.MenuClass;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x02000094 RID: 148
	public class QMSingleButtonUdon : QMButtonBase
	{
		// Token: 0x0600042D RID: 1069 RVA: 0x000225C4 File Offset: 0x000207C4
		public QMSingleButtonUdon(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, bool activesprite, Sprite sprite, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor, activesprite, sprite);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x00022668 File Offset: 0x00020868
		public QMSingleButtonUdon(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, bool activesprite, Sprite sprite, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, new Color?(Color.black), new Color?(Color.magenta), activesprite, sprite);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x00022714 File Offset: 0x00020914
		private protected void InitButton(float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor, Color? btnTextColor, bool activesprite, Sprite sprite)
		{
			this.btnType = "SingleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find(MainMenu.UdonEvents.BaseMenu.GetMenuName()).transform, true);
			this.button.name = string.Format("UdonManager-{0}-{1}", this.btnType, APIStuff.RandomNumbers());
			this.button.GetComponentInChildren<TextMeshProUGUI>().fontSize = 30f;
			if (activesprite)
			{
				this.button.transform.Find("Text_H4").transform.localPosition += new Vector3(0f, -50f, 0f);
			}
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().gameObject.SetActive(activesprite);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().sprite = sprite;
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().color = new Color(1f, 0.05f, 0.7f);
			this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition += new Vector2(0f, 50f);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			this.SetBackgroundColor(Color.black, true);
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText("<color=yellow>" + btnText);
			base.SetToolTip("<color=yellow>" + btnToolTip);
			this.SetAction(btnAction);
			bool flag = btnTextColor != null;
			if (flag)
			{
				this.SetTextColor(btnTextColor.Value, true);
			}
			else
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().color;
			}
			base.SetActive(true);
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x00022958 File Offset: 0x00020B58
		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.transform.Find("Background").GetComponent<Image>().sprite = newImg;
			this.button.transform.Find("Background").GetComponent<Image>().overrideSprite = newImg;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x000229A8 File Offset: 0x00020BA8
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x000229C0 File Offset: 0x00020BC0
		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			bool flag = buttonAction != null;
			if (flag)
			{
				this.button.GetComponent<Button>().onClick.AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x00022A08 File Offset: 0x00020C08
		public void ClickMe()
		{
			this.button.GetComponent<Button>().onClick.Invoke();
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x00022A21 File Offset: 0x00020C21
		internal override void SetBackgroundColor(Color buttonBackgroundColor, bool save = true)
		{
			this.button.GetComponentInChildren<Image>().color = buttonBackgroundColor;
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x00022A38 File Offset: 0x00020C38
		internal override void SetTextColor(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}
	}
}
