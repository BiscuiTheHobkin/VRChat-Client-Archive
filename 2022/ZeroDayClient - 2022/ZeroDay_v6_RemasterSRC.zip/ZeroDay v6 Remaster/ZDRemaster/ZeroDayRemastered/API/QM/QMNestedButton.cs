﻿using System;
using System.Collections.Generic;
using System.Linq;
using Il2CppSystem.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Menus;
using ZDBase;
using ZDBase.Utils;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x0200008E RID: 142
	public class QMNestedButton
	{
		// Token: 0x06000400 RID: 1024 RVA: 0x0002107C File Offset: 0x0001F27C
		public QMNestedButton(QMNestedButton location, string btnText, float posX, float posY, string toolTipText, string menuTitle, bool spriteactive, Sprite sprite, bool halfBtn = false)
		{
			this.btnQMLoc = location.GetMenuName();
			this.Initialize(false, btnText, posX, posY, toolTipText, menuTitle, spriteactive, sprite);
			if (halfBtn)
			{
				this.MainButton.GetGameObject().GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.MainButton.GetGameObject().GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x00021114 File Offset: 0x0001F314
		public QMNestedButton(string location, string btnText, float posX, float posY, string toolTipText, string menuTitle, bool spriteactive, Sprite sprite, bool halfBtn = false)
		{
			this.btnQMLoc = location;
			this.Initialize(location.StartsWith("Menu_"), btnText, posX, posY, toolTipText, menuTitle, spriteactive, sprite);
			if (halfBtn)
			{
				this.MainButton.GetGameObject().GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.MainButton.GetGameObject().GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x000211B0 File Offset: 0x0001F3B0
		private void Initialize(bool isRoot, string btnText, float btnPosX, float btnPosY, string btnToolTipText, string menuTitle, bool spriteactive, Sprite sprite)
		{
			this.MenuName = string.Format("ZD-Menu-{0}", APIStuff.RandomNumbers());
			this.MenuObject = Object.Instantiate<GameObject>(APIStuff.GetMenuPageTemplate(), APIStuff.GetMenuPageTemplate().transform.parent);
			this.MenuObject.name = this.MenuName;
			this.MenuObject.SetActive(false);
			Object.DestroyImmediate(this.MenuObject.GetComponent<LaunchPadQMMenu>());
			this.MenuPage = this.MenuObject.AddComponent<UIPage>();
			this.MenuPage.field_Public_String_0 = this.MenuName;
			this.MenuPage.field_Private_Boolean_1 = true;
			this.MenuPage.field_Protected_MenuStateController_0 = APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0();
			this.MenuPage.field_Private_List_1_UIPage_0 = new List<UIPage>();
			this.MenuPage.field_Private_List_1_UIPage_0.Add(this.MenuPage);
			APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Private_Dictionary_2_String_UIPage_0.Add(this.MenuName, this.MenuPage);
			bool isRoot2 = isRoot;
			if (isRoot2)
			{
				List<UIPage> list = APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Public_ArrayOf_UIPage_0.ToList<UIPage>();
				list.Add(this.MenuPage);
				APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Public_ArrayOf_UIPage_0 = list.ToArray();
			}
			this.MenuObject.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup").DestroyChildren();
			this.MenuTitleText = this.MenuObject.GetComponentInChildren<TextMeshProUGUI>(true);
			this.MenuTitleText.text = "<color=#8A2BE2>" + menuTitle;
			this.IsMenuRoot = isRoot;
			this.BackButton = this.MenuObject.transform.GetChild(0).Find("LeftItemContainer/Button_Back").gameObject;
			this.BackButton.SetActive(true);
			this.BackButton.transform.Find("Icon").GetComponent<Image>().color = new Color(255f, 20f, 147f);
			this.BackButton.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
			this.BackButton.GetComponentInChildren<Button>().onClick.AddListener(delegate()
			{
				bool isRoot3 = isRoot;
				if (isRoot3)
				{
					bool flag2 = this.btnQMLoc.StartsWith("Menu_");
					if (flag2)
					{
						APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0("QuickMenu" + this.btnQMLoc.Remove(0, 5), false);
					}
					else
					{
						APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(this.btnQMLoc, false);
					}
				}
				else
				{
					this.MenuPage.Method_Protected_Virtual_New_Void_0();
				}
			});
			this.MenuObject.transform.GetChild(0).Find("RightItemContainer/Button_QM_Expand").gameObject.SetActive(false);
			this.MainButton = new QMSingleButton(this.btnQMLoc, btnPosX, btnPosY, "<color=#8A2BE2>" + btnText, delegate()
			{
				this.OpenMe();
				Utilities.StaffNotify("Opened [" + btnText + "]");
			}, "<color=#8A2BE2>" + btnToolTipText, spriteactive, sprite, null, null, false);
			for (int i = 0; i < this.MenuObject.transform.childCount; i++)
			{
				bool flag = this.MenuObject.transform.GetChild(i).name != "Header_H1" && this.MenuObject.transform.GetChild(i).name != "ScrollRect";
				if (flag)
				{
					Object.Destroy(this.MenuObject.transform.GetChild(i).gameObject);
				}
			}
			AzuraAPI.allQMNestedButtons.Add(this);
			Logs.LogSuccess(string.Format("Created [{0}] Menus!", AzuraAPI.allQMNestedButtons.Count), false);
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0002154B File Offset: 0x0001F74B
		public void OpenMe()
		{
			APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_UIContext_Boolean_0(this.MenuPage.field_Public_String_0, null, false);
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0002156B File Offset: 0x0001F76B
		public void CloseMe()
		{
			this.MenuPage.Method_Public_Virtual_New_Void_0();
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0002157C File Offset: 0x0001F77C
		public string GetMenuName()
		{
			return this.MenuName;
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00021594 File Offset: 0x0001F794
		public GameObject GetMenuObject()
		{
			return this.MenuObject;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x000215AC File Offset: 0x0001F7AC
		public QMSingleButton GetMainButton()
		{
			return this.MainButton;
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x000215C4 File Offset: 0x0001F7C4
		public GameObject GetBackButton()
		{
			return this.BackButton;
		}

		// Token: 0x040002B3 RID: 691
		protected string btnQMLoc;

		// Token: 0x040002B4 RID: 692
		protected GameObject MenuObject;

		// Token: 0x040002B5 RID: 693
		protected TextMeshProUGUI MenuTitleText;

		// Token: 0x040002B6 RID: 694
		protected UIPage MenuPage;

		// Token: 0x040002B7 RID: 695
		protected bool IsMenuRoot;

		// Token: 0x040002B8 RID: 696
		protected GameObject BackButton;

		// Token: 0x040002B9 RID: 697
		protected QMSingleButton MainButton;

		// Token: 0x040002BA RID: 698
		protected string MenuName;
	}
}
