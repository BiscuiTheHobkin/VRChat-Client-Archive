﻿using System;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x02000090 RID: 144
	public class QMSingleButton : QMButtonBase
	{
		// Token: 0x06000412 RID: 1042 RVA: 0x00021A4C File Offset: 0x0001FC4C
		public QMSingleButton(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, bool activesprite, Sprite sprite, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor, activesprite, sprite);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00021AF0 File Offset: 0x0001FCF0
		public QMSingleButton(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, bool activesprite, Sprite sprite, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, new Color?(Color.black), new Color?(Color.magenta), activesprite, sprite);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00021B9C File Offset: 0x0001FD9C
		private protected void InitButton(float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor, Color? btnTextColor, bool activesprite, Sprite sprite)
		{
			this.btnType = "SingleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/" + this.btnQMLoc).transform, true);
			this.button.name = string.Format("ZeroDay-{0}-{1}", this.btnType, APIStuff.RandomNumbers());
			this.button.GetComponentInChildren<TextMeshProUGUI>().fontSize = 30f;
			if (activesprite)
			{
				this.button.transform.Find("Text_H4").transform.localPosition += new Vector3(0f, -50f, 0f);
			}
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().gameObject.SetActive(activesprite);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().sprite = sprite;
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().color = new Color(1f, 0.05f, 0.7f);
			this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition += new Vector2(0f, 50f);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			this.SetBackgroundColor(Color.black, true);
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText("<color=#8A2BE2>" + btnText);
			base.SetToolTip("<color=#8A2BE2>" + btnToolTip);
			this.SetAction(btnAction);
			bool flag = btnTextColor != null;
			if (flag)
			{
				this.SetTextColor(btnTextColor.Value, true);
			}
			else
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().color;
			}
			base.SetActive(true);
			AzuraAPI.allQMSingleButtons.Add(this);
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00021DEC File Offset: 0x0001FFEC
		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.transform.Find("Background").GetComponent<Image>().sprite = newImg;
			this.button.transform.Find("Background").GetComponent<Image>().overrideSprite = newImg;
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00021E3C File Offset: 0x0002003C
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00021E54 File Offset: 0x00020054
		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			bool flag = buttonAction != null;
			if (flag)
			{
				this.button.GetComponent<Button>().onClick.AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00021E9C File Offset: 0x0002009C
		public void ClickMe()
		{
			this.button.GetComponent<Button>().onClick.Invoke();
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00021EB5 File Offset: 0x000200B5
		internal override void SetBackgroundColor(Color buttonBackgroundColor, bool save = true)
		{
			this.button.GetComponentInChildren<Image>().color = buttonBackgroundColor;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00021ECC File Offset: 0x000200CC
		internal override void SetTextColor(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}
	}
}
