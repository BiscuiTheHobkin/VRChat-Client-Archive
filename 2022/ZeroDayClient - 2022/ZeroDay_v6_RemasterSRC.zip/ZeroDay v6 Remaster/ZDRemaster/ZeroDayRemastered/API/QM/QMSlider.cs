﻿using System;
using UnityEngine;
using UnityEngine.UI;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.API.QM
{
	// Token: 0x02000091 RID: 145
	internal class QMSlider
	{
		// Token: 0x0600041B RID: 1051 RVA: 0x00021F00 File Offset: 0x00020100
		public QMSlider(QMNestedButton location, float posX, float posY, string sliderLabel, float minValue, float maxValue, float defaultValue, Action<float> sliderAction, Color? labelColor = null)
		{
			this.Initialize(location.GetMenuObject().transform, posX, posY, sliderLabel, minValue, maxValue, defaultValue, sliderAction, labelColor);
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00021F38 File Offset: 0x00020138
		public QMSlider(Transform location, float posX, float posY, string sliderLabel, float minValue, float maxValue, float defaultValue, Action<float> sliderAction, Color? labelColor = null)
		{
			this.Initialize(location, posX, posY, sliderLabel, minValue, maxValue, defaultValue, sliderAction, labelColor);
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00021F64 File Offset: 0x00020164
		private void Initialize(Transform location, float posX, float posY, string sliderLabel, float minValue, float maxValue, float defaultValue, Action<float> sliderAction, Color? labelColor = null)
		{
			this.slider = Object.Instantiate<GameObject>(APIStuff.GetSliderTemplate(), location);
			this.slider.transform.localScale = new Vector3(1f, 1f, 1f);
			this.slider.name = string.Format("AZURA-QMSlider-{0}", APIStuff.RandomNumbers());
			this.label = Object.Instantiate<GameObject>(GameObject.Find("UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/LevelText"), this.slider.transform);
			this.label.name = "QMSlider-Label";
			this.label.transform.localScale = new Vector3(1f, 1f, 1f);
			this.label.GetComponent<RectTransform>().sizeDelta = new Vector2(360f, 50f);
			this.label.GetComponent<RectTransform>().anchoredPosition = new Vector2(10.4f, 55f);
			this.label.AddComponent<Button>().onClick.AddListener(delegate()
			{
			});
			this.sliderComp = this.slider.GetComponent<Slider>();
			this.sliderComp.wholeNumbers = false;
			this.sliderComp.onValueChanged = new Slider.SliderEvent();
			this.sliderComp.onValueChanged.AddListener(sliderAction);
			this.sliderComp.onValueChanged.AddListener(delegate(float f)
			{
				this.slider.transform.Find("Fill Area/Label").GetComponent<Text>().text = string.Format("{0}%", this.sliderComp.value / maxValue * 100f);
			});
			this.text = this.label.GetComponent<Text>();
			this.text.resizeTextForBestFit = false;
			bool flag = labelColor != null;
			if (flag)
			{
				this.SetLabelColor(labelColor.Value);
			}
			this.SetLocation(new Vector2(posX, posY));
			this.SetLabelText(sliderLabel);
			this.SetValue(minValue, maxValue, this.currentValue);
			AzuraAPI.allQMSliders.Add(this);
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00022185 File Offset: 0x00020385
		public void SetLocation(Vector2 location)
		{
			this.slider.GetComponent<RectTransform>().anchoredPosition = location;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0002219A File Offset: 0x0002039A
		public void SetLabelText(string label)
		{
			this.text.text = label;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x000221AA File Offset: 0x000203AA
		public void SetLabelColor(Color color)
		{
			this.text.color = color;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x000221BC File Offset: 0x000203BC
		public void SetValue(float min, float max, float current)
		{
			this.minValue = min;
			this.maxValue = max;
			this.currentValue = current;
			this.sliderComp.minValue = this.minValue;
			this.sliderComp.maxValue = this.maxValue;
			this.sliderComp.value = this.currentValue;
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00022218 File Offset: 0x00020418
		public GameObject GetGameObject()
		{
			return this.slider;
		}

		// Token: 0x040002BB RID: 699
		protected GameObject slider;

		// Token: 0x040002BC RID: 700
		protected GameObject label;

		// Token: 0x040002BD RID: 701
		protected Slider sliderComp;

		// Token: 0x040002BE RID: 702
		protected Text text;

		// Token: 0x040002BF RID: 703
		protected float minValue;

		// Token: 0x040002C0 RID: 704
		protected float maxValue;

		// Token: 0x040002C1 RID: 705
		protected float currentValue;
	}
}
