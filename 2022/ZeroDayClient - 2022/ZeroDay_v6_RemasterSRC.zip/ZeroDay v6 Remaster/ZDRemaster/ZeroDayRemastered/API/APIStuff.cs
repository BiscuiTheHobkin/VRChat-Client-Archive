﻿using System;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;
using ZeroDayRemastered.API.Wings;

namespace ZeroDayRemastered.API
{
	// Token: 0x02000083 RID: 131
	internal static class APIStuff
	{
		// Token: 0x060003A7 RID: 935 RVA: 0x0001F68C File Offset: 0x0001D88C
		internal static QuickMenu GetQuickMenuInstance()
		{
			bool flag = APIStuff.QuickMenuInstance == null;
			if (flag)
			{
				APIStuff.QuickMenuInstance = Resources.FindObjectsOfTypeAll<QuickMenu>()[0];
			}
			return APIStuff.QuickMenuInstance;
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0001F6C4 File Offset: 0x0001D8C4
		internal static GameObject GetSocialMenuInstance()
		{
			bool flag = APIStuff.SocialMenuInstance == null;
			if (flag)
			{
				APIStuff.SocialMenuInstance = GameObject.Find("UserInterface/MenuContent/Screens");
			}
			return APIStuff.SocialMenuInstance;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x0001F6FC File Offset: 0x0001D8FC
		internal static GameObject SingleButtonTemplate()
		{
			bool flag = APIStuff.SingleButtonReference == null;
			if (flag)
			{
				Il2CppArrayBase<Button> componentsInChildren = APIStuff.GetQuickMenuInstance().GetComponentsInChildren<Button>(true);
				foreach (Button button in componentsInChildren)
				{
					bool flag2 = button.name == "Button_Screenshot";
					if (flag2)
					{
						APIStuff.SingleButtonReference = button.gameObject;
					}
				}
			}
			return APIStuff.SingleButtonReference;
		}

		// Token: 0x060003AA RID: 938 RVA: 0x0001F790 File Offset: 0x0001D990
		internal static GameObject GetMenuPageTemplate()
		{
			bool flag = APIStuff.MenuPageReference == null;
			if (flag)
			{
				APIStuff.MenuPageReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard").gameObject;
			}
			return APIStuff.MenuPageReference;
		}

		// Token: 0x060003AB RID: 939 RVA: 0x0001F7DC File Offset: 0x0001D9DC
		internal static GameObject GetQMInfoTemplate()
		{
			bool flag = APIStuff.QMInfoReference == null;
			if (flag)
			{
				APIStuff.QMInfoReference = GameObject.Find("UserInterface").transform.Find("MenuContent/Popups/PerformanceSettingsPopup/Popup/Pages/Page_LimitAvatarPerformance/Tooltip_Details").gameObject;
			}
			return APIStuff.QMInfoReference;
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0001F828 File Offset: 0x0001DA28
		internal static GameObject GetSliderTemplate()
		{
			bool flag = APIStuff.SliderReference == null;
			if (flag)
			{
				APIStuff.SliderReference = GameObject.Find("UserInterface").transform.Find("MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider").gameObject;
			}
			return APIStuff.SliderReference;
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001F874 File Offset: 0x0001DA74
		internal static GameObject GetSliderLabelTemplate()
		{
			bool flag = APIStuff.SliderLabelReference == null;
			if (flag)
			{
				APIStuff.SliderLabelReference = GameObject.Find("UserInterface").transform.Find("MenuContent/Screens/Settings/AudioDevicePanel/LevelText").gameObject;
			}
			return APIStuff.SliderLabelReference;
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0001F8C0 File Offset: 0x0001DAC0
		internal static GameObject GetAvatarPreviewBase()
		{
			bool flag = APIStuff.AvatarPreviewReference == null;
			if (flag)
			{
				APIStuff.AvatarPreviewReference = GameObject.Find("UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase");
			}
			return APIStuff.AvatarPreviewReference;
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0001F8F8 File Offset: 0x0001DAF8
		public static Sprite GetOnIconSprite()
		{
			bool flag = APIStuff.OnIconReference == null;
			if (flag)
			{
				APIStuff.OnIconReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Notifications/Panel_NoNotifications_Message/Icon").GetComponent<Image>().sprite;
			}
			return APIStuff.OnIconReference;
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x0001F948 File Offset: 0x0001DB48
		public static Sprite GetOffIconSprite()
		{
			bool flag = APIStuff.OffIconReference == null;
			if (flag)
			{
				APIStuff.OffIconReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Settings/Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/Buttons_UI_Elements_Row_1/Button_ToggleQMInfo/Icon_Off").GetComponent<Image>().sprite;
			}
			return APIStuff.OffIconReference;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0001F998 File Offset: 0x0001DB98
		internal static int RandomNumbers()
		{
			return APIStuff.rnd.Next(10000, 99999);
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x0001F9BE File Offset: 0x0001DBBE
		internal static void DestroyChildren(this Transform transform)
		{
			transform.DestroyChildren(null);
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x0001F9CC File Offset: 0x0001DBCC
		internal static void DestroyChildren(this Transform transform, Func<Transform, bool> exclude)
		{
			for (int i = transform.childCount - 1; i >= 0; i--)
			{
				bool flag = exclude == null || exclude(transform.GetChild(i));
				if (flag)
				{
					Object.DestroyImmediate(transform.GetChild(i).gameObject);
				}
			}
		}

		// Token: 0x04000279 RID: 633
		private static QuickMenu QuickMenuInstance;

		// Token: 0x0400027A RID: 634
		private static GameObject SingleButtonReference;

		// Token: 0x0400027B RID: 635
		private static GameObject MenuPageReference;

		// Token: 0x0400027C RID: 636
		private static GameObject QMInfoReference;

		// Token: 0x0400027D RID: 637
		private static GameObject SliderReference;

		// Token: 0x0400027E RID: 638
		private static GameObject SliderLabelReference;

		// Token: 0x0400027F RID: 639
		private static GameObject SocialMenuInstance;

		// Token: 0x04000280 RID: 640
		private static GameObject AvatarPreviewReference;

		// Token: 0x04000281 RID: 641
		private static Sprite OnIconReference;

		// Token: 0x04000282 RID: 642
		private static Sprite OffIconReference;

		// Token: 0x04000283 RID: 643
		private static Random rnd = new Random();

		// Token: 0x04000284 RID: 644
		internal static BaseWing Left = new BaseWing();

		// Token: 0x04000285 RID: 645
		internal static BaseWing Right = new BaseWing();

		// Token: 0x04000286 RID: 646
		internal static Action<BaseWing> OnWingInit = delegate(BaseWing _)
		{
		};

		// Token: 0x04000287 RID: 647
		internal static Action Init_L = delegate()
		{
			APIStuff.Init_L = delegate()
			{
			};
			APIStuff.OnWingInit(APIStuff.Left);
		};

		// Token: 0x04000288 RID: 648
		internal static Action Init_R = delegate()
		{
			APIStuff.Init_R = delegate()
			{
			};
			APIStuff.OnWingInit(APIStuff.Right);
		};

		// Token: 0x0200014D RID: 333
		public enum SMLocations
		{
			// Token: 0x0400071A RID: 1818
			Worlds,
			// Token: 0x0400071B RID: 1819
			Avatars,
			// Token: 0x0400071C RID: 1820
			Social,
			// Token: 0x0400071D RID: 1821
			Settings,
			// Token: 0x0400071E RID: 1822
			Safety,
			// Token: 0x0400071F RID: 1823
			UserInfo
		}
	}
}
