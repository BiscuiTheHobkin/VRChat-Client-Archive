﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI.Elements;
using ZDBase;
using ZDBase.Discord;
using ZDBase.Modules;
using ZDBase.Modules.JarGames;
using ZDBase.Utils;
using ZeroDayRemastered.Modules;
using ZeroDayRemastered.Modules.Coloring;
using ZeroDayRemastered.Modules.MenuClass;

namespace ZeroDayRemastered
{
	// Token: 0x02000053 RID: 83
	public class ZeroDayMain : MelonMod
	{
		// Token: 0x0600025E RID: 606 RVA: 0x00011EF4 File Offset: 0x000100F4
		public override void OnApplicationStart()
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine("(   *                    (  ( (             .                                  \r\n                                                                                \r\n                      ,                                                         \r\n           *                                                     (              \r\n             ,                                                                  \r\n                            *                     (*   ##                       \r\n                          (                       ((((((#    ##                 \r\n           *                                      (( (((( ((##     (            \r\n                        *            .     (     (((((((((((((((###             \r\n                                                .((((((((((((((((((             \r\n                                                (((((((((((((((( ((((.     ,    \r\n                      #################(((((((((((((( ,((((((((((               \r\n            (         #################(((((((((((((((((( ((((                  \r\n                                 ######( (((((     ((((((((                     \r\n                        ##############(  (((((        ((((((                    \r\n         (              #############  ( ((((((((((((((((((((                   \r\n                (           #######      ((((((((((((((((((((        (/         \r\n                          #############  (((((          (((((      *     (      \r\n                        ###############  ((((( (      ((((((                    \r\n               *      (######            (((((    (((((((((                     \r\n                     ##################(((((((((((((((((                        \r\n         /   (      ###################((((((((((((/                *           \r\n                                            (         /                    (    \r\n      (                 *       (                                               \r\n                                                                                \r\n                                                      *                         \r\n                                    (       * ,                      (          \r\n                                                                                \r\n                                                                                \r\n                                                                                \r\n                                            *                          (        \r\n         (                                                                      ");
			Console.ForegroundColor = ConsoleColor.DarkMagenta;
			Console.WriteLine("");
			Console.WriteLine("");
			Console.WriteLine();
			Console.WriteLine("                 ============================================================");
			Console.WriteLine("                 ===========================KeyBind==========================");
			Console.WriteLine("                 ============================================================");
			Console.WriteLine("                 ===                Ctrl + T (Third Person)               ===");
			Console.WriteLine("                 ===                Ctrl + F (Flight)                     ===");
			Console.WriteLine("                 ===                Ctrl + D (Hands Of Death)             ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ===                                                      ===");
			Console.WriteLine("                 ============================================================");
			Console.WriteLine("                 ===========================KeyBind==========================");
			Console.WriteLine("                 ============================================================");
			Console.ForegroundColor = ConsoleColor.White;
			ModFiles.Initialize();
			MelonCoroutines.Start(Optimizations.Loop());
			Patches.Initialize();
			MelonCoroutines.Start(ZeroDayMain.WaitForVRCUI());
			ClassInjector.RegisterTypeInIl2Cpp<ZDNameplates>();
			ClassInjector.RegisterTypeInIl2Cpp<Enderpearl>();
			ClassInjector.RegisterTypeInIl2Cpp<PickUpBoom>();
			ClassInjector.RegisterTypeInIl2Cpp<sitonpickups>();
			ClassInjector.RegisterTypeInIl2Cpp<touchpickups>();
			ClassInjector.RegisterTypeInIl2Cpp<touchstuff>();
			MelonCoroutines.Start(ZeroDayMain.Check());
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0001205D File Offset: 0x0001025D
		public static IEnumerator Check()
		{
			yield return new WaitForSeconds(1f);
			while (APIUser.CurrentUser == null)
			{
				yield return new WaitForEndOfFrame();
			}
			bool flag = APIUser.CurrentUser.id == "usr_c36a095c-9c9d-4db9-8bc7-e48200256bb2";
			if (flag)
			{
				ZeroDayMain.IsAdmin = true;
			}
			else
			{
				ZeroDayMain.IsAdmin = false;
			}
			yield break;
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00012065 File Offset: 0x00010265
		public override void OnLevelWasLoaded(int level)
		{
			this.worldloadid = true;
			MelonCoroutines.Start(this.DelayedActionFORIDS());
		}

		// Token: 0x06000261 RID: 609 RVA: 0x0001207B File Offset: 0x0001027B
		private IEnumerator DelayedActionFORIDS()
		{
			yield return new WaitForSeconds(5f);
			bool flag = !this.worldloadid;
			if (flag)
			{
				yield break;
			}
			this.worldloadid = false;
			try
			{
				string Name = RoomManager.field_Internal_Static_ApiWorld_0.name;
				string Jointime = DateTime.Now.ToString("h:mm:ss tt");
				string Id = RoomManager.Method_Internal_Static_get_String_0();
				string worldInfo = "world Name :" + RoomManager.field_Internal_Static_ApiWorld_0.name + "\nworld ID :" + RoomManager.field_Internal_Static_ApiWorld_0.id;
				Logs.Log("[World History Log Debug]\n" + worldInfo, true);
				this.worldInNow = new WorldObjects(Name, Id, Jointime);
				Config_World_Histoy.Instance.WorldHist.Insert(0, new WorldObjects(Name, Id, Jointime));
				Config_World_Histoy.Instance.SaveConfig();
				Name = null;
				Jointime = null;
				Id = null;
				worldInfo = null;
				yield break;
			}
			catch
			{
				Logs.Log("world didnt load in time to catch the info", true);
				yield break;
			}
			yield break;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x0001208C File Offset: 0x0001028C
		internal static Image GetImageFromResources(string imageName)
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			string[] manifestResourceNames = executingAssembly.GetManifestResourceNames();
			string[] array = manifestResourceNames;
			foreach (string text in array)
			{
				bool flag = text.EndsWith(".png") && text.Contains(imageName);
				if (flag)
				{
					Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(text);
					MemoryStream memoryStream = new MemoryStream();
					manifestResourceStream.CopyTo(memoryStream);
					return Image.FromStream(memoryStream);
				}
			}
			return null;
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00012114 File Offset: 0x00010314
		internal static Sprite MakeSpriteFromImage(Image image)
		{
			bool flag = image == null;
			Sprite result;
			if (flag)
			{
				result = null;
			}
			else
			{
				MemoryStream memoryStream = new MemoryStream();
				image.Save(memoryStream, ImageFormat.Png);
				Texture2D texture2D = new Texture2D(1024, 1024);
				bool flag2 = !ImageConversion.LoadImage(texture2D, memoryStream.ToArray());
				Sprite sprite;
				if (flag2)
				{
					sprite = null;
				}
				else
				{
					Sprite sprite2 = Sprite.CreateSprite(texture2D, new Rect(0f, 0f, (float)texture2D.width, (float)texture2D.height), new Vector2((float)(texture2D.width / 2), (float)(texture2D.height / 2)), 100000f, 1000U, 0, default(Vector4), false);
					sprite = sprite2;
				}
				result = sprite;
			}
			return result;
		}

		// Token: 0x06000264 RID: 612 RVA: 0x000121D4 File Offset: 0x000103D4
		public override void OnUpdate()
		{
			bool uidone = ZeroDayMain.UIDone;
			if (uidone)
			{
				bool beyBlade = ZeroDayMain.BeyBlade;
				if (beyBlade)
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.transform.Rotate(0f, 10f, 0f);
				}
				bool uidone2 = ZeroDayMain.UIDone;
				if (uidone2)
				{
					bool key = Input.GetKey(308);
					if (key)
					{
						Camera.main.fieldOfView = 20f;
					}
					else
					{
						Camera.main.fieldOfView = 60f;
					}
				}
				bool pickupsOrbit = MainConfigSettings.PickupsOrbit;
				if (pickupsOrbit)
				{
					Nazis.PickupsOrbit();
				}
				bool flashAnnoy = ZDBase.Modules.JarGames.Murder.FlashAnnoy;
				if (flashAnnoy)
				{
					ZDBase.Modules.JarGames.Murder.KnifeShield();
				}
				Networking.LocalPlayer.SetRunSpeed(Movement.RunSpeed);
				Networking.LocalPlayer.SetJumpImpulse(Movement.JumpPower);
				Networking.LocalPlayer.SetWalkSpeed(Movement.WalkSpeed);
				try
				{
					ZeroDayMain.time += Time.deltaTime;
					bool flag = ZeroDayMain.time <= 1f;
					if (flag)
					{
						return;
					}
					string text = "";
					List<Player>.Enumerator enumerator = PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0.GetEnumerator();
					while (enumerator.MoveNext())
					{
						text = string.Concat(new string[]
						{
							text,
							"\n",
							Playerlist.PlayerName(enumerator.current),
							Playerlist.PlayerPING(enumerator.current),
							Playerlist.PlayerFPS(enumerator.current),
							Playerlist.PlayerisFristring(enumerator.current),
							Playerlist.Playerisvr(enumerator.current),
							Playerlist.Playerisquet(enumerator.current),
							Playerlist.Playerismaster(enumerator.current),
							Playerlist.TrustRank(enumerator.current)
						});
						MainMenu.playerlist.InfoText.text = text;
						MainMenu.playerlist.InfoText.fontSize = 28;
					}
				}
				catch (Exception ex)
				{
					Logs.LogError("Failed To Update PlayerList", false);
					throw;
				}
				bool flag2 = VRCPlayer.field_Internal_Static_VRCPlayer_0 != null;
				if (flag2)
				{
					bool flag3 = MainConfigSettings.Instance.InfiniteJump && VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Boolean_1() && !Networking.LocalPlayer.IsPlayerGrounded();
					if (flag3)
					{
						Vector3 velocity = Networking.LocalPlayer.GetVelocity();
						velocity.y = Networking.LocalPlayer.GetJumpImpulse();
						Networking.LocalPlayer.SetVelocity(velocity);
					}
					bool flag4 = MainConfigSettings.Instance.Rock_jump && VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Single_0() == 1f;
					if (flag4)
					{
						Vector3 velocity2 = Networking.LocalPlayer.GetVelocity();
						velocity2.y = Networking.LocalPlayer.GetJumpImpulse();
						Networking.LocalPlayer.SetVelocity(velocity2);
					}
				}
				bool uidone3 = ZeroDayMain.UIDone;
				if (uidone3)
				{
					KeyBinds.Initialize();
				}
				Color highlightColor = Highlights._friendsHighlights.highlightColor;
				bool flag5 = true;
				if (flag5)
				{
					bool rgbfriends = MainConfigSettings.Instance.RGBFriends;
					if (rgbfriends)
					{
						Highlights._friendsHighlights.highlightColor = ZDBase.Utils.Utilities.GetRainbow();
					}
				}
				bool spotfyLogs = MainConfigSettings.Instance.SpotfyLogs;
				if (spotfyLogs)
				{
					StringBuilder stringBuilder = new StringBuilder(ZeroDayMain.GetWindowTextLength(ZeroDayMain._spotifyWindow) * 2 + 1);
					ZeroDayMain.GetWindowText(ZeroDayMain._spotifyWindow, stringBuilder, stringBuilder.Capacity);
					string text2 = stringBuilder.ToString();
					bool flag6 = this._currentSong != text2;
					if (flag6)
					{
						bool hudLog = MainConfigSettings.Instance.HudLog;
						if (hudLog)
						{
							ZDBase.Utils.Utilities.StaffNotify("<color=#7CFC00>Now Playing on Spotify:\n" + text2 + "</color>");
						}
						Logs.LogSuccess("Spotify Now Playing: " + text2, true);
					}
					this._currentSong = text2;
				}
			}
		}

		// Token: 0x06000265 RID: 613
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool IsWindow(IntPtr hWnd);

		// Token: 0x06000266 RID: 614
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int GetWindowTextLength(IntPtr hWnd);

		// Token: 0x06000267 RID: 615
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

		// Token: 0x06000268 RID: 616 RVA: 0x000125B0 File Offset: 0x000107B0
		public override void OnSceneWasInitialized(int buildIndex, string sceneName)
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine(" /$$$$$$$$                               /$$$$$$$                      /$$    /$$ /$$   /$$\r\n|_____ $$                               | $$__  $$                    | $$   | $$| $$  | $$\r\n     /$$/   /$$$$$$   /$$$$$$   /$$$$$$ | $$  \\ $$  /$$$$$$  /$$   /$$| $$   | $$| $$  | $$\r\n    /$$/   /$$__  $$ /$$__  $$ /$$__  $$| $$  | $$ |____  $$| $$  | $$|  $$ / $$/| $$$$$$$$\r\n   /$$/   | $$$$$$$$| $$  \\__/| $$  \\ $$| $$  | $$  /$$$$$$$| $$  | $$ \\  $$ $$/ |_____  $$\r\n  /$$/    | $$_____/| $$      | $$  | $$| $$  | $$ /$$__  $$| $$  | $$  \\  $$$/        | $$\r\n /$$$$$$$$|  $$$$$$$| $$      |  $$$$$$/| $$$$$$$/|  $$$$$$$|  $$$$$$$   \\  $/         | $$\r\n|________/ \\_______/|__/       \\______/ |_______/  \\_______/ \\____  $$    \\_/          |__/\r\n                                                             /$$  | $$                     \r\n                                                            |  $$$$$$/                     \r\n                                                             \\______/   ");
			Console.WriteLine("");
			Console.WriteLine("");
			Logs.LogSuccess("[UNITY] Initialized Scene [" + sceneName + "]", false);
			Console.Title = "Azure Engine - Logged In As [" + APIUser.CurrentUser.displayName + "]";
			Console.ForegroundColor = ConsoleColor.White;
			PickupSword.array1 = Resources.FindObjectsOfTypeAll<VRC_Pickup>();
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0001263A File Offset: 0x0001083A
		public override void OnSceneWasLoaded(int buildIndex, string sceneName)
		{
			Logs.LogSuccess("[UNITY] Loaded Scene [" + sceneName + "]", false);
		}

		// Token: 0x0600026A RID: 618 RVA: 0x00012654 File Offset: 0x00010854
		public override void OnSceneWasUnloaded(int buildIndex, string sceneName)
		{
			Logs.LogSuccess("[UNITY] UnLoaded Scene [" + sceneName + "]", false);
		}

		// Token: 0x0600026B RID: 619 RVA: 0x00012670 File Offset: 0x00010870
		internal static void SocialMenuInitialized()
		{
			Logs.Log("Found SocialMenu Local.", false);
			GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").active = false;
			MelonCoroutines.Start(LoadingScreen.StartLoadingScreenUI());
			MelonCoroutines.Start(LoadingScreen.StartSong());
			MelonCoroutines.Start(ZDBase.Utils.Utilities.loadparticles());
			Logs.LogSuccess("Succesfully Applied SocialMenu Items!", false);
		}

		// Token: 0x0600026C RID: 620 RVA: 0x000126C8 File Offset: 0x000108C8
		internal static void HudInitialized()
		{
			Logs.Log("Found HUD Local.", false);
			DiscordManager.Init();
			ZDBase.Utils.Utilities.window = ZeroDayMain.FindWindow(null, "VRChat");
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Darkness").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Rectangle").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/MidRing").GetComponent<Image>().color = Color.magenta;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/InnerDashRing").GetComponent<Image>().color = new Color(0.5f, 0f, 1f);
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonMiddle").GetComponent<Button>().image.color = Color.magenta;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/RingGlow").GetComponent<Image>().color = new Color(0.5f, 0f, 1f);
			MelonCoroutines.Start(ZDBase.Utils.Utilities.animation());
			MelonCoroutines.Start(ZDBase.Utils.Utilities.loadbundle());
			Logs.LogSuccess("Succesfully Added HUD Items!", false);
		}

		// Token: 0x0600026D RID: 621 RVA: 0x000127D9 File Offset: 0x000109D9
		public override void OnApplicationQuit()
		{
		}

		// Token: 0x0600026E RID: 622
		[DllImport("user32.dll")]
		internal static extern IntPtr FindWindow(string className, string windowName);

		// Token: 0x0600026F RID: 623 RVA: 0x000127DC File Offset: 0x000109DC
		private static void QuickMenuInitialized()
		{
			foreach (Text text in GameObject.Find("/UserInterface").GetComponentsInChildren<Text>(true))
			{
				text.color = Color.magenta;
			}
			foreach (TextMeshProUGUI textMeshProUGUI in GameObject.Find("/UserInterface/Canvas_QuickMenu(Clone)").GetComponentsInChildren<TextMeshProUGUI>(true))
			{
				textMeshProUGUI.color = Color.magenta;
			}
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Darkness").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Rectangle").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/MidRing").GetComponent<Image>().color = Color.red;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/InnerDashRing").GetComponent<Image>().color = Color.red;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonMiddle").GetComponent<Button>().image.color = Color.red;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/RingGlow").GetComponent<Image>().color = Color.red;
			BugMenuShit.MenuBullshit();
			MainMenu.StartMenus();
			ThirdPerson.Initiliaze();
			Logs.Log("Found QuickMenu Local.", false);
			Logs.LogSuccess("Succesfully Created QuickMenu!", false);
			MainMenu.MainLogoMenu.GetMainButton().SetBackgroundColor(Color.white, true);
			MelonCoroutines.Start(ZeroDayMain.<QuickMenuInitialized>g__starttextures|35_0());
			ZeroDayMain.UIDone = true;
			MainMenu.playerlist.InfoText.text = "Initializing Playerlist...";
			HighlightsFX field_Private_Static_HighlightsFX_ = HighlightsFX.field_Private_Static_HighlightsFX_0;
			Highlights._friendsHighlights = field_Private_Static_HighlightsFX_.gameObject.AddComponent<HighlightsFXStandalone>();
			Highlights._othersHighlights = field_Private_Static_HighlightsFX_.gameObject.AddComponent<HighlightsFXStandalone>();
			Highlights._othersHighlights.highlightColor = Color.red;
			Highlights._friendsHighlights.highlightColor = Color.green;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/UserProfileAndStatusSection/TitlePanel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/InRoom/ViewPort/test_Panel (1)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendRequests/ViewPort/test_Panel (3)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/OnlineFriends/ViewPort/test_Panel (2)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup1/ViewPort/test_Panel (3)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup2/ViewPort/test_Panel (3)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup3/ViewPort/test_Panel (4)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/OfflineFriends/ViewPort/test_Panel (4)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/Active/ViewPort/test_Panel (5)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Avatar/TitlePanel (1)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Favorite Avatar List/Button/Panel").active = false;
			Object.Destroy(GameObject.Find("UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport").GetComponent<Image>());
			GameObject.Find("UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Personal Avatar List/Button/Panel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Personal Avatar List/ViewPort/test_Panel (1)").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/SocialRankBG").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Settings_Safety/TitlePanel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Worlds/Current Room/TitlePanel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Gallery/TitlePanel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Gallery/Vertical Scroll View/Viewport/Content/My User Icons List/ViewPort/test_Panel").active = false;
			GameObject.Find("UserInterface/MenuContent/Screens/Gallery/Vertical Scroll View/Viewport/Content/My Images List/ViewPort/test_Panel").active = false;
			Process process = Process.GetProcessesByName("Spotify").FirstOrDefault<Process>();
			ZeroDayMain._spotifyWindow = new MainWindowFinder().FindMainWindow(process.Id);
			Logs.LogSuccess("Found Spotify! " + process.ProcessName, false);
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Darkness").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Rectangle").GetComponent<Image>().color = Color.clear;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/MidRing").GetComponent<Image>().color = Color.magenta;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/InnerDashRing").GetComponent<Image>().color = new Color(0.5f, 0f, 1f);
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonMiddle").GetComponent<Button>().image.color = Color.magenta;
			GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/RingGlow").GetComponent<Image>().color = new Color(0.5f, 0f, 1f);
			Logs.LogSuccess(MainMenu.UdonEvents.BaseMenu.GetMenuName(), true);
			ZeroDayMain.changeuicolors();
		}

		// Token: 0x06000270 RID: 624 RVA: 0x00012C50 File Offset: 0x00010E50
		public static void changeuicolors()
		{
			GameObject gameObject = GameObject.Find("/UserInterface").transform.Find("MenuContent").gameObject;
			foreach (Button button in gameObject.GetComponentsInChildren<Button>(true))
			{
				ColorBlock colors = button.colors;
				colors.normalColor = new Color(0.5f, 0f, 1f, 1f);
				colors.highlightedColor = new Color(1f, 0f, 1f, 1f);
				colors.pressedColor = Color.gray;
				colors.disabledColor = Color.gray;
				colors.selectedColor = new Color(0.5f, 0f, 1f, 1f);
				button.colors = colors;
			}
			foreach (Slider slider in GameObject.Find("/UserInterface").transform.Find("MenuContent/Screens").GetComponentsInChildren<Slider>(true))
			{
				try
				{
					slider.transform.Find("Fill Area/Fill").gameObject.GetComponent<Image>().color = new Color(0.5f, 0f, 1f, 1f);
					slider.gameObject.GetComponent<Image>().color = new Color(0.5f, 0f, 1f, 1f);
				}
				catch
				{
				}
			}
			foreach (Button button2 in GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)").gameObject.GetComponentsInChildren<Button>(true))
			{
				try
				{
					string text = button2.transform.Find("Text_H4").GetComponent<TextMeshProUGUI>().text;
					TextMeshProUGUI component = button2.transform.Find("Text_H4").GetComponent<TextMeshProUGUI>();
					component.text = "<color=#FF1493>" + text;
				}
				catch
				{
				}
				try
				{
					Image component2 = button2.transform.Find("Background").GetComponent<Image>();
					component2.color = new Color(0.5f, 0f, 1f, 1f);
				}
				catch
				{
				}
				try
				{
					Image component3 = button2.transform.Find("Container/Background").GetComponent<Image>();
					component3.color = new Color(0.5f, 0f, 1f, 1f);
				}
				catch
				{
				}
			}
			foreach (Toggle toggle in GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)").gameObject.GetComponentsInChildren<Toggle>(true))
			{
				try
				{
					Image component4 = toggle.transform.Find("Background").GetComponent<Image>();
					component4.color = new Color(0.5f, 0f, 1f, 1f);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000271 RID: 625 RVA: 0x0001302C File Offset: 0x0001122C
		private static IEnumerator WaitForVRCUI()
		{
			while (GameObject.Find("UserInterface/MenuContent/Screens") == null)
			{
				yield return null;
			}
			ZeroDayMain.SocialMenuInitialized();
			while (GameObject.Find("UserInterface/UnscaledUI/HudContent/Hud") == null)
			{
				yield return null;
			}
			ZeroDayMain.HudInitialized();
			while (Object.FindObjectOfType<QuickMenu>() == null)
			{
				yield return null;
			}
			ZeroDayMain.QuickMenuInitialized();
			yield break;
		}

		// Token: 0x06000273 RID: 627 RVA: 0x00013048 File Offset: 0x00011248
		[CompilerGenerated]
		internal static IEnumerator <QuickMenuInitialized>g__starttextures|35_0()
		{
			new Sprite();
			UnityWebRequest request = UnityWebRequestTexture.GetTexture("https://i.imgur.com/x71qljn.png");
			yield return request.SendWebRequest();
			bool flag = request.isNetworkError || request.isHttpError;
			if (flag)
			{
				MelonLogger.LogError(request.error);
			}
			else
			{
				Texture2D text = DownloadHandlerTexture.GetContent(request);
				Sprite mfsprite = Sprite.CreateSprite(text, new Rect(0f, 0f, (float)text.width, (float)text.height), new Vector2((float)(text.width / 2), (float)(text.height / 2)), 100000f, 1000U, 0, Vector4.zero, false);
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer02").GetComponent<Image>().sprite = mfsprite;
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer02").GetComponent<Image>().color = Color.white;
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer02").transform.localScale = new Vector3(1.09f, 1.22f, 1f);
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer01").GetComponent<Image>().sprite = ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("ZD_Shadow"));
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer01").GetComponent<Image>().color = Color.white;
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer01");
				text = null;
				mfsprite = null;
			}
			yield break;
		}

		// Token: 0x04000191 RID: 401
		public static bool IsAdmin;

		// Token: 0x04000192 RID: 402
		public bool worldloadid;

		// Token: 0x04000193 RID: 403
		public WorldObjects worldInNow;

		// Token: 0x04000194 RID: 404
		internal static IntPtr _spotifyWindow;

		// Token: 0x04000195 RID: 405
		private static IntPtr _chromewindow;

		// Token: 0x04000196 RID: 406
		internal static bool UIDone;

		// Token: 0x04000197 RID: 407
		internal float FOV = 60f;

		// Token: 0x04000198 RID: 408
		internal static float time;

		// Token: 0x04000199 RID: 409
		internal static bool BeyBlade;

		// Token: 0x0400019A RID: 410
		internal static bool Swastika;

		// Token: 0x0400019B RID: 411
		internal string _currentSong;

		// Token: 0x0400019C RID: 412
		internal string _currentSong1;

		// Token: 0x0400019D RID: 413
		private float _timer;

		// Token: 0x0400019E RID: 414
		private static GameObject m_particlesMuzzleFlash;

		// Token: 0x0400019F RID: 415
		private static GameObject self;

		// Token: 0x040001A0 RID: 416
		private static List<string> gmjlist;

		// Token: 0x040001A1 RID: 417
		private static List<string> gmjlist2;

		// Token: 0x020000F3 RID: 243
		// (Invoke) Token: 0x060005D6 RID: 1494
		private delegate void FindAndLoadUnityPlugin(IntPtr name, out IntPtr loadedModule, byte bEnableSomeDebug);
	}
}
