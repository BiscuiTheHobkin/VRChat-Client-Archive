﻿using System;
using UnityEngine;
using VRC.Udon;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000059 RID: 89
	internal class GHOSTV1
	{
		// Token: 0x060002A7 RID: 679 RVA: 0x00014670 File Offset: 0x00012870
		internal static void hurthumans()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag2 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)");
				if (flag2)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag3 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)");
				if (flag3)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag4 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)");
				if (flag4)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag5 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)");
				if (flag5)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag6 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)");
				if (flag6)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag7 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)");
				if (flag7)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag8 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)");
				if (flag8)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag9 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)");
				if (flag9)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag10 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)");
				if (flag10)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag11 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)");
				if (flag11)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag12 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)");
				if (flag12)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag13 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)");
				if (flag13)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag14 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)");
				if (flag14)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag15 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)");
				if (flag15)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag16 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)");
				if (flag16)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				bool flag17 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)");
				if (flag17)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
			}
		}

		// Token: 0x060002A8 RID: 680 RVA: 0x00014994 File Offset: 0x00012B94
		internal static void hurthumanslocal()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag2 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)");
				if (flag2)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag3 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)");
				if (flag3)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag4 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)");
				if (flag4)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag5 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)");
				if (flag5)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag6 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)");
				if (flag6)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag7 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)");
				if (flag7)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag8 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)");
				if (flag8)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag9 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)");
				if (flag9)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag10 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)");
				if (flag10)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag11 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)");
				if (flag11)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag12 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)");
				if (flag12)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag13 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)");
				if (flag13)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag14 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)");
				if (flag14)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag15 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)");
				if (flag15)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag16 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)");
				if (flag16)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				bool flag17 = gameObject.name.Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)");
				if (flag17)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
			}
		}
	}
}
