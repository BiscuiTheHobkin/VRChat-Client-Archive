﻿using System;
using System.Collections;
using UnityEngine;
using VRC.SDKBase;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000062 RID: 98
	internal class Movement
	{
		// Token: 0x0600030F RID: 783 RVA: 0x000179B9 File Offset: 0x00015BB9
		public static IEnumerator InfJump(bool state)
		{
			for (;;)
			{
				bool flag = Movement.infinitejump && VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Boolean_1() && !Networking.LocalPlayer.IsPlayerGrounded();
				if (flag)
				{
					Vector3 velocity = Networking.LocalPlayer.GetVelocity();
					velocity.y = Networking.LocalPlayer.GetJumpImpulse();
					Networking.LocalPlayer.SetVelocity(velocity);
					velocity = default(Vector3);
				}
				yield return new WaitForSeconds(0.01f);
			}
			yield break;
		}

		// Token: 0x06000310 RID: 784 RVA: 0x000179C8 File Offset: 0x00015BC8
		internal static void set_speeds(bool state)
		{
			bool speed = Movement.Speed;
			if (speed)
			{
				Networking.LocalPlayer.SetWalkSpeed(Movement.WalkSpeed);
				Networking.LocalPlayer.SetRunSpeed(Movement.RunSpeed);
				Networking.LocalPlayer.SetStrafeSpeed(Movement.WalkSpeed);
			}
			else
			{
				Networking.LocalPlayer.SetWalkSpeed(2f);
				Networking.LocalPlayer.SetRunSpeed(4f);
				Networking.LocalPlayer.SetStrafeSpeed(2f);
			}
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00017A48 File Offset: 0x00015C48
		internal static void set_jumppower(bool state)
		{
			bool jump = Movement.Jump;
			if (jump)
			{
				Networking.LocalPlayer.SetJumpImpulse(Movement.JumpPower);
			}
			else
			{
				Networking.LocalPlayer.SetJumpImpulse(3f);
			}
		}

		// Token: 0x040001EA RID: 490
		public static bool Fly = false;

		// Token: 0x040001EB RID: 491
		public static bool NoClip = false;

		// Token: 0x040001EC RID: 492
		public static bool Speed = false;

		// Token: 0x040001ED RID: 493
		public static bool Jump = false;

		// Token: 0x040001EE RID: 494
		public static float RunSpeed = 4f;

		// Token: 0x040001EF RID: 495
		public static float WalkSpeed = 3f;

		// Token: 0x040001F0 RID: 496
		public static float JumpPower = 4f;

		// Token: 0x040001F1 RID: 497
		public static float FlySpeed = 6f;

		// Token: 0x040001F2 RID: 498
		public static bool infinitejump = false;
	}
}
