﻿using System;
using System.Runtime.InteropServices;

namespace ZeroDayRemastered.Modules.MediaControl
{
	// Token: 0x0200007F RID: 127
	internal class MediaControl
	{
		// Token: 0x0600038F RID: 911
		[DllImport("user32.dll", SetLastError = true)]
		private static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

		// Token: 0x06000390 RID: 912 RVA: 0x0001EE7C File Offset: 0x0001D07C
		internal static void PlayPause()
		{
			MediaControl.keybd_event(MediaControl.mediaPlayPause, MediaControl.mediaPlayPause, 0, 0);
			MediaControl.keybd_event(MediaControl.mediaPlayPause, MediaControl.mediaPlayPause, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0001EEA7 File Offset: 0x0001D0A7
		internal static void PrevTrack()
		{
			MediaControl.keybd_event(MediaControl.mediaPreviousTrack, MediaControl.mediaPreviousTrack, 0, 0);
			MediaControl.keybd_event(MediaControl.mediaPreviousTrack, MediaControl.mediaPreviousTrack, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0001EED2 File Offset: 0x0001D0D2
		internal static void NextTrack()
		{
			MediaControl.keybd_event(MediaControl.mediaNextTrack, MediaControl.mediaNextTrack, 0, 0);
			MediaControl.keybd_event(MediaControl.mediaNextTrack, MediaControl.mediaNextTrack, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0001EEFD File Offset: 0x0001D0FD
		internal static void Stop()
		{
			MediaControl.keybd_event(MediaControl.mediaStop, MediaControl.mediaStop, 0, 0);
			MediaControl.keybd_event(MediaControl.mediaStop, MediaControl.mediaStop, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0001EF28 File Offset: 0x0001D128
		internal static void VolumeUp()
		{
			MediaControl.keybd_event(MediaControl.volUp, MediaControl.volUp, 0, 0);
			MediaControl.keybd_event(MediaControl.volUp, MediaControl.volUp, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000395 RID: 917 RVA: 0x0001EF53 File Offset: 0x0001D153
		internal static void VolumeDown()
		{
			MediaControl.keybd_event(MediaControl.volDown, MediaControl.volDown, 0, 0);
			MediaControl.keybd_event(MediaControl.volDown, MediaControl.volDown, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x06000396 RID: 918 RVA: 0x0001EF7E File Offset: 0x0001D17E
		internal static void VolumeMute()
		{
			MediaControl.keybd_event(MediaControl.volMute, MediaControl.volMute, 0, 0);
			MediaControl.keybd_event(MediaControl.volMute, MediaControl.volMute, MediaControl.KEYEVENTF_KEYUP, 0);
		}

		// Token: 0x04000255 RID: 597
		private static int KEYEVENTF_KEYUP = 2;

		// Token: 0x04000256 RID: 598
		private static byte mediaPlayPause = 179;

		// Token: 0x04000257 RID: 599
		private static byte mediaNextTrack = 176;

		// Token: 0x04000258 RID: 600
		private static byte mediaPreviousTrack = 177;

		// Token: 0x04000259 RID: 601
		private static byte mediaStop = 178;

		// Token: 0x0400025A RID: 602
		private static byte volUp = 175;

		// Token: 0x0400025B RID: 603
		private static byte volDown = 174;

		// Token: 0x0400025C RID: 604
		private static byte volMute = 173;
	}
}
