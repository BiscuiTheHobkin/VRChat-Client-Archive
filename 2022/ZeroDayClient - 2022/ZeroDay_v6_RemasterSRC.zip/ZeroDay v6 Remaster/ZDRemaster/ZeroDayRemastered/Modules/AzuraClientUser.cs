﻿using System;
using System.Collections.Generic;
using VRC;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000063 RID: 99
	internal class AzuraClientUser : ModuleBase
	{
		// Token: 0x06000314 RID: 788 RVA: 0x00017AE3 File Offset: 0x00015CE3
		public override void Start()
		{
		}

		// Token: 0x06000315 RID: 789 RVA: 0x00017AE6 File Offset: 0x00015CE6
		public override void PlayerJoined(Player player)
		{
			AzuraClientUser.CachedPlayers.Add(player.gameObject.AddComponent<ZDNameplates>());
		}

		// Token: 0x040001F3 RID: 499
		internal static List<ZDNameplates> CachedPlayers = new List<ZDNameplates>();
	}
}
