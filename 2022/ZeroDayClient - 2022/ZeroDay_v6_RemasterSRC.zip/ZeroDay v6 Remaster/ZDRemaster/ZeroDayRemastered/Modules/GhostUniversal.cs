﻿using System;
using UnityEngine;
using VRC.Udon;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x0200005F RID: 95
	public class GhostUniversal
	{
		// Token: 0x060002EA RID: 746 RVA: 0x00016E74 File Offset: 0x00015074
		public static void KillHumans()
		{
			GameObject @object = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject/DamageSync");
			GameObject object2 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (1)/DamageSync");
			GameObject object3 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (2)/DamageSync");
			GameObject object4 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (3)/DamageSync");
			GameObject object5 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (4)/DamageSync");
			GameObject object6 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (5)/DamageSync");
			GameObject object7 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (6)/DamageSync");
			GameObject object8 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (7)/DamageSync");
			GameObject object9 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (8)/DamageSync");
			GameObject object10 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (9)/DamageSync");
			GameObject object11 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (10)/DamageSync");
			GameObject object12 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (11)/DamageSync");
			GameObject object13 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (12)/DamageSync");
			GameObject object14 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (13)/DamageSync");
			GameObject object15 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (14)/DamageSync");
			GameObject object16 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (15)/DamageSync");
			GameObject object17 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (16)/DamageSync");
			Exploits.SendUdonRPC(@object, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object2, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object3, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object4, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object5, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object6, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object7, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object8, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object9, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object10, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object11, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object12, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object13, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object14, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object15, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object16, "BackStabDamage", null, false);
			Exploits.SendUdonRPC(object17, "BackStabDamage", null, false);
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00017048 File Offset: 0x00015248
		public static void GiveSelfMaxCurrency()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("GameManager");
				if (flag)
				{
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
					Exploits.SendUdonRPC(gameObject, "OnSuspiciousKill", null, true);
				}
			}
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00017110 File Offset: 0x00015310
		public static void Spawn50CalHouse()
		{
			GameObject @object = GameObject.Find("/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_M107/Reward_M107");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002ED RID: 749 RVA: 0x00017170 File Offset: 0x00015370
		public static void SpawnRiotShieldHouse()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_RiotShield/RewardC_RiotShield");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000171F4 File Offset: 0x000153F4
		public static void SpawnShotgunHouse()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_Shotgun/RewardB_Shotgun");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00017278 File Offset: 0x00015478
		public static void SpawnVectorHouse()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x000172FC File Offset: 0x000154FC
		public static void UnlockArmory()
		{
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/ArmoryRoom/LockDoor");
			Exploits.SendUdonRPC(@object, "Local_AddOneMoreKey", null, false);
			Exploits.SendUdonRPC(@object, "Local_AddOneMoreKey", null, false);
			Exploits.SendUdonRPC(@object, "Local_AddOneMoreKey", null, false);
			Exploits.SendUdonRPC(@object, "Local_AddOneMoreKey", null, false);
			Exploits.SendUdonRPC(@object, "Local_AddOneMoreKey", null, false);
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.localPosition = new Vector3(41.9873f, 4.8675f, 541.7313f);
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x00017380 File Offset: 0x00015580
		public static void Spawn50CalPolice()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x00017404 File Offset: 0x00015604
		public static void SpawnRiotShieldPolice()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_RiotShield/Reward_RiotShield");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x00017488 File Offset: 0x00015688
		public static void SpawnShotgunPolice()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_RiotShield/Reward _Shotgun");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x0001750C File Offset: 0x0001570C
		public static void SpawnVectorPolice()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward _Shotgun/Reward _Shotgun");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00017590 File Offset: 0x00015790
		public static void SpawnDeaglePolice()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_DesertEagle/Reward_DEagle");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x00017614 File Offset: 0x00015814
		public static void SpawnP90Police()
		{
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = new Vector3(0.0614f, -0.005f, 503.5013f);
			GameObject @object = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_P90/Reward_P90");
			Exploits.SendUdonRPC(@object, "Net_SpawnObject", null, false);
			GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
			gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
		}
	}
}
