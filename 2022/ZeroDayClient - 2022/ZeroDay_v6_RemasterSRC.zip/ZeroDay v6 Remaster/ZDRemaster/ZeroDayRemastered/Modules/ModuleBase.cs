﻿using System;
using VRC;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000061 RID: 97
	public abstract class ModuleBase
	{
		// Token: 0x06000301 RID: 769 RVA: 0x0001798C File Offset: 0x00015B8C
		public virtual void OnStart()
		{
		}

		// Token: 0x06000302 RID: 770 RVA: 0x0001798F File Offset: 0x00015B8F
		public virtual void OnUpdate()
		{
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00017992 File Offset: 0x00015B92
		public virtual void OnGUI()
		{
		}

		// Token: 0x06000304 RID: 772 RVA: 0x00017995 File Offset: 0x00015B95
		public virtual void QuickMenuInitialized()
		{
		}

		// Token: 0x06000305 RID: 773 RVA: 0x00017998 File Offset: 0x00015B98
		public virtual void SocialMenuInitialized()
		{
		}

		// Token: 0x06000306 RID: 774 RVA: 0x0001799B File Offset: 0x00015B9B
		public virtual void HudInitialized()
		{
		}

		// Token: 0x06000307 RID: 775 RVA: 0x0001799E File Offset: 0x00015B9E
		public virtual void PlayerJoined(Player player)
		{
		}

		// Token: 0x06000308 RID: 776 RVA: 0x000179A1 File Offset: 0x00015BA1
		public virtual void PlayerLeft(Player player)
		{
		}

		// Token: 0x06000309 RID: 777 RVA: 0x000179A4 File Offset: 0x00015BA4
		public virtual void SceneInitialized(int buildIndex, string sceneName)
		{
		}

		// Token: 0x0600030A RID: 778 RVA: 0x000179A7 File Offset: 0x00015BA7
		public virtual void SceneLoaded(int buildIndex, string sceneName)
		{
		}

		// Token: 0x0600030B RID: 779 RVA: 0x000179AA File Offset: 0x00015BAA
		public virtual void SceneUnloaded(int buildIndex, string sceneName)
		{
		}

		// Token: 0x0600030C RID: 780
		public abstract void Start();

		// Token: 0x0600030D RID: 781 RVA: 0x000179AD File Offset: 0x00015BAD
		public void OnUiInit()
		{
		}
	}
}
