﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using ZDBase;
using ZDBase.Utils;
using ZDBase.Utils.Wrappers;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000064 RID: 100
	public class ZDNameplates : MonoBehaviour
	{
		// Token: 0x06000318 RID: 792 RVA: 0x00017B14 File Offset: 0x00015D14
		public ZDNameplates(IntPtr id) : base(id)
		{
		}

		// Token: 0x06000319 RID: 793 RVA: 0x00017B31 File Offset: 0x00015D31
		public void Start()
		{
			this.SetupPlayerInfo();
			this.SetupLowerNameplate();
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00017B42 File Offset: 0x00015D42
		public void OnDestroy()
		{
			AzuraClientUser.CachedPlayers.Remove(this);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x00017B54 File Offset: 0x00015D54
		public static float GetFrames(Player player)
		{
			return (player._playerNet.Method_Public_get_Byte_0() != 0) ? Mathf.Floor(1000f / (float)player._playerNet.Method_Public_get_Byte_0()) : -1f;
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00017B94 File Offset: 0x00015D94
		public void Update()
		{
			bool flag = (float)this.frames == ZDNameplates.GetFrames(this.player) && this.ping == this.player._playerNet.field_Private_Byte_1;
			bool flag2 = flag;
			if (flag2)
			{
				this.noUpdateCount++;
			}
			else
			{
				this.noUpdateCount = 0;
			}
			this.frames = (byte)ZDNameplates.GetFrames(this.player);
			this.ping = this.player._playerNet.field_Private_Byte_1;
			string text = "<color=green>Stable</color>";
			bool flag3 = this.noUpdateCount > 35;
			bool flag4 = flag3;
			if (flag4)
			{
				text = "<color=yellow>Lagging</color>";
			}
			bool flag5 = this.noUpdateCount > 375;
			bool flag6 = flag5;
			if (flag6)
			{
				text = "<color=red>Crashed</color>";
			}
			bool flag7 = this.player == null || this.vrcPlayer == null || this.playerNet == null || this.vrcPlayerApi == null || this.apiUser == null;
			if (flag7)
			{
				this.SetupPlayerInfo();
			}
			bool flag8 = this.lowerNamePlate != null;
			if (flag8)
			{
				bool isOnMobile = this.player.Method_Internal_get_APIUser_0().IsOnMobile;
				if (isOnMobile)
				{
					this.namePlateText.text = string.Concat(new string[]
					{
						"[<color=green>",
						this.player.GetPlatform(),
						"</color>] |[",
						text,
						"] |<color=white>Ping:</color> ",
						this.player.GetPingColord(),
						" |<color=white>FPS</color>: ",
						this.player.GetFramesColord()
					});
				}
				else
				{
					this.namePlateText.text = string.Concat(new string[]
					{
						"[<color=green>",
						this.player.GetPlatform(),
						"</color>] |[",
						text,
						"] |<color=white>Ping:</color> ",
						this.player.GetPingColord(),
						" |<color=white>FPS</color>: ",
						this.player.GetFramesColord(),
						this.player.ClientDetect() ? " | [<color=red>Possible ClientUser</color>]" : ""
					});
				}
			}
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00017DC4 File Offset: 0x00015FC4
		public void SetupPlayerInfo()
		{
			this.tagsTransform = base.gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents");
			this.player = base.gameObject.GetComponent<Player>();
			this.vrcPlayer = base.gameObject.GetComponent<VRCPlayer>();
			this.playerNet = base.gameObject.GetComponent<PlayerNet>();
			this.vrcPlayerApi = this.player.Method_Public_get_VRCPlayerApi_0();
			this.apiUser = this.player.Method_Internal_get_APIUser_0();
			this.tagsTransform.Find("Main/Background").GetComponent<ImageThreeSlice>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Main/Pulse").GetComponent<ImageThreeSlice>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Main/Glow").GetComponent<ImageThreeSlice>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Icon/Background").GetComponent<Image>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Icon/Pulse").GetComponent<Image>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Icon/Glow").GetComponent<Image>().color = this.player.GetTrustColor();
			this.tagsTransform.Find("Quick Stats").GetComponent<ImageThreeSlice>().color = this.player.GetTrustColor();
		}

		// Token: 0x0600031E RID: 798 RVA: 0x00017F4C File Offset: 0x0001614C
		public void SetupLowerNameplate()
		{
			try
			{
				this.lowerNamePlate = Object.Instantiate<GameObject>(this.tagsTransform.Find("Quick Stats").gameObject, this.tagsTransform, false);
			}
			catch (Exception ex)
			{
				Logs.LogError("Failed To Find Nameplate!", false);
				throw;
			}
			this.lowerNamePlate.name = "AzureX Nameplate";
			for (int i = this.lowerNamePlate.transform.childCount; i > 0; i--)
			{
				Transform child = this.lowerNamePlate.transform.GetChild(i - 1);
				bool flag = child.name == "Trust Text";
				if (flag)
				{
					this.namePlateText = child.GetComponent<TextMeshProUGUI>();
					this.namePlateText.color = Color.white;
				}
				else
				{
					Object.Destroy(child.gameObject);
				}
			}
			this.lowerNamePlate.gameObject.SetActive(true);
			this.lowerNamePlate.GetComponent<RectTransform>().localPosition = new Vector3(0f, -60f, 0f);
			this.player.transform.Find("Player Nameplate/Canvas/Avatar Progress").GetComponent<RectTransform>().localPosition = new Vector3(0f, -45f, 0f);
		}

		// Token: 0x0600031F RID: 799 RVA: 0x0001809C File Offset: 0x0001629C
		public void DestroyLowerNameplate()
		{
			bool flag = this.lowerNamePlate == null;
			if (!flag)
			{
				Object.Destroy(this.lowerNamePlate);
				this.lowerNamePlate = null;
			}
		}

		// Token: 0x06000320 RID: 800 RVA: 0x000180D0 File Offset: 0x000162D0
		public void ResetNameplates()
		{
			bool flag = this.lowerNamePlate != null;
			if (flag)
			{
				Object.Destroy(this.lowerNamePlate);
			}
			this.tagsTransform.Find("Main/Background").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Main/Pulse").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Main/Glow").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Icon/Background").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Icon/Pulse").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Icon/Glow").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Quick Stats").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Quick Stats").localPosition = new Vector3(0f, 30f, 0f);
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00018208 File Offset: 0x00016408
		public void ResetNameplateColors()
		{
			bool flag = this.lowerNamePlate != null;
			if (flag)
			{
				this.lowerNamePlate.GetComponent<ImageThreeSlice>().color = Color.white;
			}
			this.tagsTransform.Find("Main/Background").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Main/Pulse").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Main/Glow").GetComponent<ImageThreeSlice>().color = Color.white;
			this.tagsTransform.Find("Icon/Background").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Icon/Pulse").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Icon/Glow").GetComponent<Image>().color = Color.white;
			this.tagsTransform.Find("Quick Stats").GetComponent<ImageThreeSlice>().color = Color.white;
		}

		// Token: 0x040001F4 RID: 500
		internal Player player;

		// Token: 0x040001F5 RID: 501
		internal VRCPlayer vrcPlayer;

		// Token: 0x040001F6 RID: 502
		internal PlayerNet playerNet;

		// Token: 0x040001F7 RID: 503
		internal VRCPlayerApi vrcPlayerApi;

		// Token: 0x040001F8 RID: 504
		internal APIUser apiUser;

		// Token: 0x040001F9 RID: 505
		internal Transform tagsTransform;

		// Token: 0x040001FA RID: 506
		internal GameObject lowerNamePlate;

		// Token: 0x040001FB RID: 507
		internal TextMeshProUGUI namePlateText;

		// Token: 0x040001FC RID: 508
		public static Sprite tagbackground;

		// Token: 0x040001FD RID: 509
		private byte frames;

		// Token: 0x040001FE RID: 510
		private byte ping;

		// Token: 0x040001FF RID: 511
		private int noUpdateCount = 0;

		// Token: 0x04000200 RID: 512
		private string UserID = "";
	}
}
