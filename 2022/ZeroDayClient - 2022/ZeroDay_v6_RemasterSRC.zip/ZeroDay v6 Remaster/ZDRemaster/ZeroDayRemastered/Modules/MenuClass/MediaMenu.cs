﻿using System;
using ZeroDayRemastered.API.QM;
using ZeroDayRemastered.Modules.MediaControl;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000074 RID: 116
	public class MediaMenu
	{
		// Token: 0x06000366 RID: 870 RVA: 0x0001C60C File Offset: 0x0001A80C
		public static void StartMediaMenu()
		{
			QMNestedButton mediaMenu = MainMenu.MediaMenu;
			new QMSingleButton(mediaMenu, 1f, 0f, "Play/Pause", delegate()
			{
				MediaControl.PlayPause();
			}, "", false, null, null, null, false);
			new QMSingleButton(mediaMenu, 2f, 0f, "Stop", delegate()
			{
				MediaControl.Stop();
			}, "", false, null, null, null, false);
			new QMSingleButton(mediaMenu, 4f, 3f, "Track ->", delegate()
			{
				MediaControl.NextTrack();
			}, "", false, null, null, null, false);
			new QMSingleButton(mediaMenu, 1f, 3f, "<- Track", delegate()
			{
				MediaControl.PrevTrack();
			}, "", false, null, null, null, false);
		}
	}
}
