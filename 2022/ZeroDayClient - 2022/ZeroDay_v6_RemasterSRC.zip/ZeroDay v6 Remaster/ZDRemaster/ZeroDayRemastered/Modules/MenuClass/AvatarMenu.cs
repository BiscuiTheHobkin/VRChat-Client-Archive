﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using RealisticEyeMovements;
using RootMotion.FinalIK;
using UnityEngine;
using VRC.Core;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000068 RID: 104
	public class AvatarMenu
	{
		// Token: 0x06000332 RID: 818 RVA: 0x00018CA0 File Offset: 0x00016EA0
		public static void StartAvatarUtils()
		{
			new QMSingleButton(MainMenu.AvatarUtils, 1f, 0f, "Clone Self", delegate()
			{
				GameObject gameObject = Object.Instantiate<GameObject>(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCAvatarManager_0().field_Private_GameObject_0, null, true);
				Animator component = gameObject.GetComponent<Animator>();
				bool flag = component != null && component.isHuman;
				if (flag)
				{
					Transform boneTransform = component.GetBoneTransform(10);
					bool flag2 = boneTransform != null;
					if (flag2)
					{
						boneTransform.localScale = Vector3.one;
					}
				}
				gameObject.name = "Cloned";
				component.enabled = false;
				gameObject.GetComponent<FullBodyBipedIK>().enabled = false;
				gameObject.GetComponent<LimbIK>().enabled = false;
				gameObject.GetComponent<VRIK>().enabled = false;
				gameObject.GetComponent<LookTargetController>().enabled = false;
				gameObject.transform.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position;
				gameObject.transform.rotation = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.rotation;
				AvatarMenu.AllClones.Add(gameObject);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.AvatarUtils, 1f, 1f, "Destroy All Clone(s)", delegate()
			{
				foreach (GameObject gameObject in AvatarMenu.AllClones)
				{
					Object.Destroy(gameObject);
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.AvatarUtils, 1f, 2f, "Download \n VRCA", delegate()
			{
				Process.Start(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1().assetUrl);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.AvatarUtils, 1f, 3f, "Copy \n A-ID", delegate()
			{
				Clipboard.SetText(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1().id);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.AvatarUtils, 2f, 0f, "Copy Asset Link", delegate()
			{
				Clipboard.SetText(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1().assetUrl);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.AvatarUtils, 2f, 1f, "Download Avi Information ", delegate()
			{
				ApiAvatar apiAvatar = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1();
				string contents = string.Format("Name: {0}\nDescription: {1}\nID: {2}\nPlatform: {3}\nRelease: {4}\nAuthor name: {5}\nAuthor UserID: {6}\nVersion: {7}\nMade in: unity {8}\nAsset url: {9}\nThumbnail url: {10}", new object[]
				{
					apiAvatar.name,
					apiAvatar.description,
					apiAvatar.id,
					apiAvatar.platform,
					apiAvatar.releaseStatus,
					apiAvatar.authorName,
					apiAvatar.authorId,
					apiAvatar.version,
					apiAvatar.unityVersion,
					apiAvatar.assetUrl,
					apiAvatar.imageUrl
				});
				File.WriteAllText(apiAvatar.name + ".txt", contents);
			}, "Downloads All Info Of Current Avatar To TXT file", false, null, null, null, false);
		}

		// Token: 0x04000206 RID: 518
		public static List<GameObject> AllClones = new List<GameObject>();
	}
}
