﻿using System;
using System.Collections.Generic;
using UnhollowerBaseLib;
using UnityEngine;
using ZDBase;
using ZDBase.Utils;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200007A RID: 122
	public class Protections
	{
		// Token: 0x0600037B RID: 891 RVA: 0x0001E444 File Offset: 0x0001C644
		public static void PostprocessSkinnedRenderers(List<SkinnedMeshRenderer> renderers)
		{
			foreach (SkinnedMeshRenderer skinnedMeshRenderer in renderers)
			{
				bool flag = !(skinnedMeshRenderer == null);
				if (flag)
				{
					skinnedMeshRenderer.material.shader = Shader.Find("VRChat/PC/Toon Lit Cutout");
					Transform transform = null;
					Il2CppReferenceArray<Transform> bones = skinnedMeshRenderer.bones;
					for (int i = 0; i < bones.Count; i++)
					{
						bool flag2 = !(bones[i] != null);
						if (flag2)
						{
							bool flag3 = transform == null;
							if (flag3)
							{
								transform = new GameObject("zero-scale").transform;
								transform.SetParent(skinnedMeshRenderer.rootBone, false);
								transform.localScale = Vector3.zero;
							}
							bones[i] = transform;
						}
					}
					bool flag4 = transform != null;
					if (flag4)
					{
						skinnedMeshRenderer.bones = bones;
					}
				}
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x0001E560 File Offset: 0x0001C760
		public static void StartProtectionsMenu()
		{
			QMNestedButton protections = MainMenu.Protections;
			new QMSingleButton(protections, 3f, 0f, "Test", delegate()
			{
				List<SkinnedMeshRenderer> renderers = new List<SkinnedMeshRenderer>();
				Protections.PostprocessSkinnedRenderers(renderers);
			}, "", false, null, null, null, false);
			new QMToggleButton(protections, 1f, 0f, "Rate\nLimit\nEvents", delegate()
			{
				MainConfigSettings.Instance.EventBlock = true;
			}, delegate()
			{
				MainConfigSettings.Instance.EventBlock = false;
			}, "", false);
			new QMToggleButton(protections, 2f, 0f, "Anti\nUdon", delegate()
			{
				MainConfigSettings.AntiUdon = true;
				Utilities.StaffNotify("Udon Protection Enabled!");
			}, delegate()
			{
				MainConfigSettings.AntiUdon = false;
				Utilities.StaffNotify("Udon Protection Disabled!");
			}, "", false);
		}
	}
}
