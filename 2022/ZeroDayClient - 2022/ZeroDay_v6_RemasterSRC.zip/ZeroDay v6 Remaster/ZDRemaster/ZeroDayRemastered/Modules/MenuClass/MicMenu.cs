﻿using System;
using MelonLoader;
using UnityEngine;
using ZeroDayRemastered.API.QM;
using ZeroDayRemastered.PhotonEvents;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000075 RID: 117
	public class MicMenu
	{
		// Token: 0x06000368 RID: 872 RVA: 0x0001C768 File Offset: 0x0001A968
		public static void StartMicMenu()
		{
			QMNestedButton micMenu = MainMenu.MicMenu;
			new QMSingleButton(micMenu, 1f, 0f, "+10 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 += 10f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 1f, 0.5f, "+5 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 += 5f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 1f, 1f, "Default", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 = 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 1f, 1.5f, "+3 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 += 3f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 1f, 2f, "+1 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 += 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 4f, 0f, "-10 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 -= 10f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 4f, 0.5f, "-5 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 -= 5f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 4f, 1f, "Default", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 = 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 4f, 1.5f, "-3 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 -= 3f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(micMenu, 4f, 2f, "-1 gain", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 -= 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMToggleButton(micMenu, 1f, 3f, "Earrape", delegate()
			{
				USpeaker.field_Internal_Static_Single_1 = float.MaxValue;
			}, delegate()
			{
				USpeaker.field_Internal_Static_Single_1 = 1f;
			}, "Will Make Your Microphone Super Loud!", false);
			new QMToggleButton(micMenu, 2f, 3f, "USpeak\nExploit", delegate()
			{
				PhotonEvents.Earrape = true;
				MelonCoroutines.Start(PhotonEvents.EarrapeEvent());
			}, delegate()
			{
				PhotonEvents.Earrape = false;
			}, "Will Fuck Other Users Audio In The World!", false);
			new QMToggleButton(micMenu, 3f, 3f, "Low Quality", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_USpeaker_0().field_Public_BitRate_0 = 0;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_USpeaker_0().field_Public_BitRate_0 = 9;
			}, "Will Make Your Microphone Sound Like A Kinect!", false);
		}
	}
}
