﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using Il2CppSystem;
using MelonLoader;
using UnityEngine;
using VRC.SDKBase;
using VRCSDK2;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000071 RID: 113
	public class LobbyMenu
	{
		// Token: 0x06000356 RID: 854 RVA: 0x0001AEE8 File Offset: 0x000190E8
		public static void StartLobby()
		{
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 0f, "Destroy\nPortals", delegate()
			{
				bool flag = Resources.FindObjectsOfTypeAll<PortalInternal>().Any<PortalInternal>();
				if (flag)
				{
					foreach (PortalInternal portalInternal in Resources.FindObjectsOfTypeAll<PortalInternal>())
					{
						Object.Destroy(portalInternal.gameObject);
					}
				}
			}, "Will destroy all portals in the lobby", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 0.5f, "Destroy\nPickups", delegate()
			{
				bool flag = Resources.FindObjectsOfTypeAll<VRC_Pickup>().Count<VRC_Pickup>() > 0;
				if (flag)
				{
					foreach (VRC_Pickup vrc_Pickup in Resources.FindObjectsOfTypeAll<VRC_Pickup>())
					{
						Object.Destroy(vrc_Pickup.gameObject);
					}
				}
			}, "Will destroy all portals in the lobby", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 1f, "Crash\nLobby", delegate()
			{
				VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.Alert("AzureX", "Are You Sure You Want To Do This?", "Yes", delegate()
				{
					MelonCoroutines.Start(LobbyMenu.LobbyCrash());
					VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.HideCurrentPopUp();
				}, "Nah G", delegate()
				{
					VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.HideCurrentPopUp();
				}, null);
			}, "Will Crash the lobby with quest or pc avatars", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 1.5f, "Rejoin", delegate()
			{
				Networking.GoToRoom(RoomManager.field_Internal_Static_ApiWorld_0.id);
			}, "Rejoins the current world!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 2f, "Join ID", delegate()
			{
				Among_Us.InputeText("Enter World ID", "Confirm", delegate(string s)
				{
					Networking.GoToRoom(s);
				});
			}, "Joins you to the room of selected ID", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 2.5f, "Copy ID", delegate()
			{
				Clipboard.SetText(RoomManager.field_Internal_Static_ApiWorldInstance_0.id);
			}, "Copy's The Current World's ID!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 3f, "Download\nVRCW", delegate()
			{
				Process.Start(RoomManager.field_Internal_Static_ApiWorld_0.assetUrl);
			}, "Downloads The Current Worlds API File!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.LobbyMenu, 1f, 3.5f, "Portal ID", delegate()
			{
				Among_Us.InputeText("Enter the world id", "Confirm", delegate(string a)
				{
					string worldID = a.Split(new char[]
					{
						':'
					})[0];
					string instanceID = a.Split(new char[]
					{
						':'
					})[1];
					LobbyMenu.DropPortal(worldID, instanceID, 0, VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.forward * 1.5f, Quaternion.identity, false);
				});
			}, "Drops A Portal To Entered Instance ID!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}

		// Token: 0x06000357 RID: 855 RVA: 0x0001B1A0 File Offset: 0x000193A0
		public static void DropPortal(string WorldID, string InstanceID, int players, Vector3 vector3, Quaternion quaternion, bool FreeFall = false)
		{
			GameObject gameObject = Networking.Instantiate(0, "Portals/PortalInternalDynamic", vector3, quaternion);
			GameObject gameObject2 = gameObject;
			string text = "ConfigurePortal";
			Object[] array = new Object[3];
			array[0] = WorldID;
			array[1] = InstanceID;
			Object[] array2 = array;
			int num = 2;
			Object[] array3 = array2;
			int num2 = num;
			Int32 @int = default(Int32);
			@int.m_value = players;
			array3[num2] = @int.BoxIl2CppObject();
			Networking.RPC(7, gameObject2, text, array2);
		}

		// Token: 0x06000358 RID: 856 RVA: 0x0001B20B File Offset: 0x0001940B
		public static IEnumerator LobbyCrash()
		{
			yield return new WaitForSeconds(2f);
			UserInteractionMenu.ChangeToCrash("avtr_d7aa3097-2c2e-41de-8901-96887d29038c", 10);
			yield break;
		}
	}
}
