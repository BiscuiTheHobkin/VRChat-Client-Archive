﻿using System;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;
using VRC;
using VRC.SDKBase;
using ZDBase;
using ZDBase.Utils;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200006F RID: 111
	public class HighlightsClass
	{
		// Token: 0x06000352 RID: 850 RVA: 0x0001A534 File Offset: 0x00018734
		public static void HighlightsComponent()
		{
			QMNestedButton espmenu = MainMenu.ESPMenu;
			new QMToggleButton(espmenu, 1f, 0f, "Toggle \n Highlights", delegate()
			{
				MainConfigSettings.Instance.PlayerESP = true;
				Highlights.ToggleESP(true);
			}, delegate()
			{
				MainConfigSettings.Instance.PlayerESP = false;
				Highlights.ToggleESP(false);
			}, "Introduces A Player Wallhack Into The Enviroment", MainConfigSettings.Instance.PlayerESP);
			new QMToggleButton(espmenu, 2f, 0f, "CSGO\nCHEAT", delegate()
			{
				MainConfigSettings.CSGO = true;
				PlayerLineEsp.Enable();
			}, delegate()
			{
				MainConfigSettings.CSGO = false;
				PlayerLineEsp.Disable();
			}, "CSGO!?!", false);
			new QMToggleButton(espmenu, 3f, 0f, "Better\nHighlights", delegate()
			{
				MainConfigSettings.Instance.BetterHighlights = true;
				List<Player>.Enumerator enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
				while (enumerator.MoveNext())
				{
					Highlights.PlayerMeshEsp(enumerator.current, true);
				}
			}, delegate()
			{
				MainConfigSettings.Instance.BetterHighlights = false;
				List<Player>.Enumerator enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
				while (enumerator.MoveNext())
				{
					Highlights.PlayerMeshEsp(enumerator.current, false);
				}
			}, "Player Mesh Esp", MainConfigSettings.Instance.BetterHighlights);
			new QMToggleButton(espmenu, 4f, 0f, "Item\nHighlights", delegate()
			{
				PickupSword.array1 = Resources.FindObjectsOfTypeAll<VRC_Pickup>();
				MelonCoroutines.Start(Highlights.itemsespref());
				MainConfigSettings.Instance.ItemEsp = true;
			}, delegate()
			{
				MainConfigSettings.Instance.ItemEsp = false;
			}, "Will See All Items Through Walls!", MainConfigSettings.Instance.BetterHighlights);
			QMNestedButton friendsMenuESP = MainMenu.FriendsMenuESP;
			new QMSingleButton(friendsMenuESP, 1f, 0f, "Red", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.red;
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 2f, 0f, "Orange", delegate()
			{
				Highlights._friendsHighlights.highlightColor = new Color(1f, 0.5f, 0f);
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 3f, 0f, "Yellow", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.yellow;
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 4f, 0f, "Green", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.green;
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 1f, 1f, "Blue", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.blue;
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 2f, 1f, "Purple", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.magenta;
			}, "", false, null, null, null, false);
			new QMSingleButton(friendsMenuESP, 3f, 1f, "White", delegate()
			{
				Highlights._friendsHighlights.highlightColor = Color.white;
			}, "", false, null, null, null, false);
			new QMToggleButton(friendsMenuESP, 4f, 1f, "RGB", delegate()
			{
				MainConfigSettings.Instance.RGBFriends = true;
			}, delegate()
			{
				MainConfigSettings.Instance.RGBFriends = false;
			}, "", MainConfigSettings.Instance.RGBFriends);
			QMNestedButton othersMenuESP = MainMenu.OthersMenuESP;
			new QMSingleButton(othersMenuESP, 1f, 0f, "Red", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.red;
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 2f, 0f, "Orange", delegate()
			{
				Highlights._othersHighlights.highlightColor = new Color(1f, 0.5f, 0f);
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 3f, 0f, "Yellow", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.yellow;
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 4f, 0f, "Green", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.green;
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 1f, 1f, "Blue", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.blue;
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 2f, 1f, "Purple", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.magenta;
			}, "", false, null, null, null, false);
			new QMSingleButton(othersMenuESP, 3f, 1f, "White", delegate()
			{
				Highlights._othersHighlights.highlightColor = Color.white;
			}, "", false, null, null, null, false);
		}
	}
}
