﻿using System;
using RootMotion.FinalIK;
using UnityEngine;
using VRC;
using ZDBase;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000070 RID: 112
	public class IKTweaks
	{
		// Token: 0x06000354 RID: 852 RVA: 0x0001AB98 File Offset: 0x00018D98
		public static void IKTweaksPanel()
		{
			QMNestedButton iktweaks = MainMenu.IKTweaks;
			new QMToggleButton(iktweaks, 1f, 0f, "Fuck\nYour\nIK", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasNeck = false;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasChest = false;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasShoulders = false;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasLegs = false;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasToes = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasNeck = true;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasChest = true;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasLegs = true;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasShoulders = true;
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasToes = true;
			}, "Makes You Have Weird And Unusual Movements.", false);
			new QMToggleButton(iktweaks, 2f, 0f, "Desktop\nT-POSE", delegate()
			{
				Animator field_Internal_Animator_ = Player.Method_Internal_Static_get_Player_0()._vrcplayer.field_Internal_Animator_0;
				field_Internal_Animator_.enabled = false;
			}, delegate()
			{
				Animator field_Internal_Animator_ = Player.Method_Internal_Static_get_Player_0()._vrcplayer.field_Internal_Animator_0;
				field_Internal_Animator_.enabled = true;
			}, "Makes You T-POSE in Desktop Mode", false);
			new QMToggleButton(iktweaks, 3f, 0f, "FBT Slide", delegate()
			{
				Animator field_Internal_Animator_ = Player.Method_Internal_Static_get_Player_0()._vrcplayer.field_Internal_Animator_0;
				field_Internal_Animator_.enabled = false;
			}, delegate()
			{
				Animator field_Internal_Animator_ = Player.Method_Internal_Static_get_Player_0()._vrcplayer.field_Internal_Animator_0;
				field_Internal_Animator_.enabled = true;
			}, "Makes You Slide In Full Body!", false);
			new QMToggleButton(iktweaks, 4f, 0f, "Fuck\nNeck", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasNeck = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasNeck = true;
			}, "", false);
			new QMToggleButton(iktweaks, 1f, 1f, "Fuck\nChest", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasChest = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasChest = true;
			}, "", false);
			new QMToggleButton(iktweaks, 2f, 1f, "Fuck\nShoulders", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasShoulders = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasShoulders = true;
			}, "", false);
			new QMToggleButton(iktweaks, 3f, 1f, "Fuck\nLegs", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasLegs = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasLegs = true;
			}, "", false);
			new QMToggleButton(iktweaks, 4f, 1f, "Fuck\nToes", delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasToes = false;
			}, delegate()
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponentInChildren<VRIK>().solver.hasToes = true;
			}, "", false);
			new QMToggleButton(iktweaks, 1f, 2f, "FBT\nSaving", delegate()
			{
				MainConfigSettings.Instance.CalibrationSaverEnabled = true;
			}, delegate()
			{
				MainConfigSettings.Instance.CalibrationSaverEnabled = false;
			}, "Saves Your Avatar Calibrations By Writing A Json File With Calibration Points!", MainConfigSettings.Instance.CalibrationSaverEnabled);
		}
	}
}
