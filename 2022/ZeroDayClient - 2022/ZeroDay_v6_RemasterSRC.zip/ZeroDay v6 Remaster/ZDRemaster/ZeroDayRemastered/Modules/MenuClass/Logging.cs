﻿using System;
using ZDBase;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000072 RID: 114
	public class Logging
	{
		// Token: 0x0600035A RID: 858 RVA: 0x0001B21C File Offset: 0x0001941C
		public static void StartLoggingMenu()
		{
			new QMToggleButton(MainMenu.Logging, 1f, 0f, "Log JOIN/LEAVE", delegate()
			{
				MainConfigSettings.Instance.joinleavelogger = true;
			}, delegate()
			{
				MainConfigSettings.Instance.joinleavelogger = false;
			}, "", MainConfigSettings.Instance.joinleavelogger);
			new QMToggleButton(MainMenu.Logging, 1f, 1f, "Log Moderations", delegate()
			{
				MainConfigSettings.Instance.ModerationLogs = true;
			}, delegate()
			{
				MainConfigSettings.Instance.ModerationLogs = false;
			}, "", MainConfigSettings.Instance.ModerationLogs);
			new QMToggleButton(MainMenu.Logging, 1f, 2f, "Log Events", delegate()
			{
				MainConfigSettings.Instance.EventLog = true;
			}, delegate()
			{
				MainConfigSettings.Instance.EventLog = false;
			}, "", MainConfigSettings.Instance.EventLog);
			new QMToggleButton(MainMenu.Logging, 1f, 3f, "Log Udon", delegate()
			{
				MainConfigSettings.Instance.UdonLogger = true;
			}, delegate()
			{
				MainConfigSettings.Instance.UdonLogger = false;
			}, "", MainConfigSettings.Instance.UdonLogger);
			new QMToggleButton(MainMenu.Logging, 2f, 0f, "Log\nTo\nHud", delegate()
			{
				MainConfigSettings.Instance.HudLog = true;
			}, delegate()
			{
				MainConfigSettings.Instance.HudLog = false;
			}, "", MainConfigSettings.Instance.HudLog);
			new QMToggleButton(MainMenu.Logging, 3f, 0f, "Log\nSpotify", delegate()
			{
				MainConfigSettings.Instance.SpotfyLogs = true;
			}, delegate()
			{
				MainConfigSettings.Instance.SpotfyLogs = false;
			}, "", MainConfigSettings.Instance.SpotfyLogs);
		}
	}
}
