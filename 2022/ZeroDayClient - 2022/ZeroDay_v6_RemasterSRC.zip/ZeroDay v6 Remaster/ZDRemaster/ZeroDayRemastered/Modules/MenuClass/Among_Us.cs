﻿using System;
using System.Collections;
using System.Windows.Forms;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;
using VRC.Udon;
using ZDBase.Modules.JarGames;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000066 RID: 102
	public class Among_Us
	{
		// Token: 0x0600032A RID: 810 RVA: 0x000183DB File Offset: 0x000165DB
		public static IEnumerator AutoBystander()
		{
			VRCPlayer playerComp = VRCPlayer.field_Internal_Static_VRCPlayer_0;
			string playerName = playerComp._player.ToString();
			int i = 0;
			while (i < 24)
			{
				string playerNode = "Player Node (" + i.ToString() + ")";
				string playerEntry = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(playerEntry).GetComponent<Text>().text.Equals(playerName);
				if (flag)
				{
					MelonLogger.Msg(playerNode);
					UdonBehaviour playerKiller = GameObject.Find(playerNode).GetComponent<UdonBehaviour>();
					bool flag2 = !playerName.Equals("Penswer");
					if (flag2)
					{
						for (;;)
						{
							playerKiller.SendCustomNetworkEvent(0, "SyncAssignB");
							yield return new WaitForSeconds(0.3f);
						}
					}
					else
					{
						playerKiller = null;
					}
				}
				int num = i + 1;
				i = num;
				playerNode = null;
				playerEntry = null;
			}
			yield break;
		}

		// Token: 0x0600032B RID: 811 RVA: 0x000183E3 File Offset: 0x000165E3
		public static IEnumerator AutoMurderer()
		{
			VRCPlayer playerComp = VRCPlayer.field_Internal_Static_VRCPlayer_0;
			string playerName = playerComp._player.ToString();
			int i = 0;
			while (i < 24)
			{
				string playerNode = "Player Node (" + i.ToString() + ")";
				string playerEntry = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(playerEntry).GetComponent<Text>().text.Equals(playerName);
				if (flag)
				{
					MelonLogger.Msg(playerNode);
					UdonBehaviour playerKiller = GameObject.Find(playerNode).GetComponent<UdonBehaviour>();
					bool flag2 = !playerName.Equals("Penswer");
					if (flag2)
					{
						for (;;)
						{
							playerKiller.SendCustomNetworkEvent(0, "SyncAssignM");
							yield return new WaitForSeconds(0.3f);
						}
					}
					else
					{
						playerKiller = null;
					}
				}
				int num = i + 1;
				i = num;
				playerNode = null;
				playerEntry = null;
			}
			yield break;
		}

		// Token: 0x0600032C RID: 812 RVA: 0x000183EC File Offset: 0x000165EC
		public static void StartAmigos()
		{
			new QMSingleButton(MainMenu.amongus, 1f, 0f, "Sabotage All", delegate()
			{
				AmongUs.Sussy();
			}, "Sabotage Everything", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 0.5f, "Sabotage Doors", delegate()
			{
				AmongUs.CloseDoors();
			}, "Sabotage The Doors", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 1f, "Sabotage Reactor", delegate()
			{
				AmongUs.Reactor();
			}, "Sabotage The Reactor", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 1.5f, "Sabotage Lights", delegate()
			{
				AmongUs.Lights();
			}, "Sabotage The Lights", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 2f, "Sabotage Oxygen", delegate()
			{
				AmongUs.Oxygen();
			}, "Sabotage The Oxygen", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 2.5f, "Repair All", delegate()
			{
				AmongUs.RepairAl();
			}, "Repairs Everything", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 1f, 3f, "Become Crew", delegate()
			{
				AmongUs.BecomeCrew();
			}, "Assigns Your Role Crewmate (GAME BREAKING)", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 0f, "Become Imposter", delegate()
			{
				AmongUs.BecomeImposter();
			}, "Assigns Your Role Imposter (GAME BREAKING)", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 0.5f, "Abort", delegate()
			{
				AmongUs.Abort();
			}, "Aborts The Game", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 1f, "Start", delegate()
			{
				AmongUs.Start();
			}, "Starts The Game", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 1.5f, "Crewmates \n Win", delegate()
			{
				AmongUs.CrewWin();
			}, "Makes The Crewmates Win", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 2f, "Imposters \n Win", delegate()
			{
				AmongUs.InpostWin();
			}, "Makes The Imposters Win", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 2.5f, "Vote Out All", delegate()
			{
				AmongUs.VoteOutAll();
			}, "Will Throw Everybody Outside The Map", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 2f, 3f, "Kill All", delegate()
			{
				AmongUs.KillAll();
			}, "Will Kill All Players", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 3f, 0f, "Complete Tasks", delegate()
			{
				foreach (UdonBehaviour udonBehaviour in Object.FindObjectsOfType<UdonBehaviour>())
				{
					udonBehaviour.SendCustomNetworkEvent(0, "OnLocalPlayerCompletedTask");
				}
			}, "Complete All Tasks (GLOBAL)", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 3f, 0.5f, "Emergency Meeting", delegate()
			{
				AmongUs.Em();
			}, "Calls A Meeting Anonymously", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 3f, 1f, "Skip Vote", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "SyncVoteResultSkip", null, false);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "SyncEndVotingPhase", null, false);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "SyncCloseVoting", null, false);
			}, "Skips All Votes", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 3f, 1.5f, "Vote Kick\nID", delegate()
			{
				bool flag = Clipboard.ContainsText();
				if (flag)
				{
					string text = Clipboard.GetText();
					VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.Alert("AzureX", "Found Clipboard Text\nClipboard Text Is " + text + "\nWould You Like To Use This?\n Press Yes To Continue, If Not Close This Menu.", "Yes", delegate()
					{
						GameObject gameObject = GameObject.Find("Player Nodes");
						foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
						{
							bool flag2 = transform.name != gameObject.name;
							if (flag2)
							{
								Exploits.SendUdonRPC(transform.gameObject, "SyncVotedFor" + Clipboard.GetText(), null, false);
							}
						}
						Popups.CloseCurrentPopup();
					}, "No", delegate()
					{
						Among_Us.InputeText("Enter ID, Max: 31", "Comfirm", delegate(string ID)
						{
							GameObject gameObject = GameObject.Find("Player Nodes");
							foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
							{
								bool flag2 = transform.name != gameObject.name;
								if (flag2)
								{
									Exploits.SendUdonRPC(transform.gameObject, "SyncVotedFor" + ID, null, false);
								}
							}
						});
						Popups.CloseCurrentPopup();
					}, null);
				}
				else
				{
					Among_Us.InputeText("Enter ID, Max: 31", "Comfirm", delegate(string ID)
					{
						GameObject gameObject = GameObject.Find("Player Nodes");
						foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
						{
							bool flag2 = transform.name != gameObject.name;
							if (flag2)
							{
								Exploits.SendUdonRPC(transform.gameObject, "SyncVotedFor" + ID, null, false);
							}
						}
					});
				}
			}, "Vote kick ID", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.amongus, 3f, 2f, "Find Body", delegate()
			{
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
				{
					bool flag = transform.name != gameObject.name;
					if (flag)
					{
						Exploits.SendUdonRPC(transform.gameObject, "SyncBodyFound", null, false);
					}
				}
			}, "Vote kick ID", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x00018A4C File Offset: 0x00016C4C
		public static void InputeText(string title, string text, Action<string> okaction)
		{
			VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Method_Public_Void_String_String_InputType_Boolean_String_Action_3_String_List_1_KeyCode_Text_Action_String_Boolean_Action_1_VRCUiPopup_Boolean_Int32_0(title, "", 0, false, text, DelegateSupport.ConvertDelegate<Action<string, List<KeyCode>, Text>>(new Action<string, List<KeyCode>, Text>(delegate(string s, List<KeyCode> k, Text t)
			{
				okaction(s);
			})), null, "...", true, null, false, 0);
		}

		// Token: 0x04000203 RID: 515
		public static QMNestedButton page2;

		// Token: 0x04000204 RID: 516
		public static object AutoBystanderCoro;

		// Token: 0x04000205 RID: 517
		public static object AutoMurdererCoro;
	}
}
