﻿using System;
using UnityEngine;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200007C RID: 124
	public class STD
	{
		// Token: 0x06000380 RID: 896 RVA: 0x0001E6F8 File Offset: 0x0001C8F8
		public static void StartSuperTower()
		{
			QMNestedButton std = MainMenu.STD;
			new QMSingleButton(std, 1f, 0f, "Refill Health", delegate()
			{
				GameObject @object = GameObject.Find("HealthController");
				Exploits.SendUdonRPC(@object, "Revive", null, false);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(std, 1f, 0.5f, "Give Money", delegate()
			{
				GameObject @object = GameObject.Find("TowerManager");
				Exploits.SendUdonRPC(@object, "CreateTower", null, false);
				Exploits.SendUdonRPC(@object, "TrySellTower", null, false);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}
	}
}
