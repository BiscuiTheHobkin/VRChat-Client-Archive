﻿using System;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200006E RID: 110
	public class Ghost
	{
		// Token: 0x06000350 RID: 848 RVA: 0x0001A090 File Offset: 0x00018290
		public static void StartGhostMenu()
		{
			new QMSingleButton(MainMenu.ghost, 3f, 0f, "Give Self Currency", delegate()
			{
				GhostUniversal.GiveSelfMaxCurrency();
			}, "Will Give Your Player Max Currency!", false, null, null, null, false);
			new QMSingleButton(MainMenu.ghost, 4f, 0f, "Kill Humans \n (End Game)", delegate()
			{
				GhostUniversal.KillHumans();
			}, "Will Give Your Player Max Currency!", false, null, null, null, false);
			Ghost.Home = new QMNestedButton(MainMenu.ghost, "House", 1f, 0f, "This opens the menu for the House Map!", "House", false, null, false);
			Ghost.Policestation = new QMNestedButton(MainMenu.ghost, "Police\nStation", 2f, 0f, "This opens the menu for the PoliceStation Map!", "PoliceStation", false, null, false);
			new QMSingleButton(Ghost.Home, 1f, 0f, "Spawn 50. Cal", delegate()
			{
				GhostUniversal.Spawn50CalHouse();
			}, "Opens a locker with a 50. Cal inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Home, 2f, 0f, "Spawn Vector", delegate()
			{
				GhostUniversal.SpawnVectorHouse();
			}, "Opens a locker with a Vector inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Home, 3f, 0f, "Spawn Shotgun", delegate()
			{
				GhostUniversal.SpawnShotgunHouse();
			}, "Opens a locker with a Shotgun inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Home, 4f, 0f, "Spawn Riotshield", delegate()
			{
				GhostUniversal.SpawnRiotShieldHouse();
			}, "Opens a locker with a RiotShield inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 1f, 0f, "Spawn 50. Cal", delegate()
			{
				GhostUniversal.Spawn50CalPolice();
			}, "Opens a locker with a 50. Cal inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 2f, 0f, "Spawn Riotshield", delegate()
			{
				GhostUniversal.SpawnRiotShieldPolice();
			}, "Opens a locker with a Riotshield inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 3f, 0f, "Spawn Shotgun", delegate()
			{
				GhostUniversal.SpawnShotgunPolice();
			}, "Opens a locker with a Shotgun inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 4f, 0f, "Spawn Vector", delegate()
			{
				GhostUniversal.SpawnVectorPolice();
			}, "Opens a locker with a Vector inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 1f, 1f, "Spawn Deagle", delegate()
			{
				GhostUniversal.SpawnDeaglePolice();
			}, "Opens a locker with a Deagle inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 2f, 1f, "Spawn P90", delegate()
			{
				GhostUniversal.SpawnP90Police();
			}, "Opens a locker with a P90 inside!", false, null, null, null, false);
			new QMSingleButton(Ghost.Policestation, 3f, 1f, "Unlock Room", delegate()
			{
				GhostUniversal.UnlockArmory();
			}, "Opens the armory room by force!", false, null, null, null, false);
		}

		// Token: 0x04000213 RID: 531
		public static QMNestedButton Home;

		// Token: 0x04000214 RID: 532
		public static QMNestedButton Policestation;
	}
}
