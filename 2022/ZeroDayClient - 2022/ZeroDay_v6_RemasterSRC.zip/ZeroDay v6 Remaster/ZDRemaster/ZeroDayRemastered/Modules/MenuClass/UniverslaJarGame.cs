﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Udon;
using ZDBase;
using ZDBase.Modules;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200007D RID: 125
	public class UniverslaJarGame
	{
		// Token: 0x06000382 RID: 898 RVA: 0x0001E7B7 File Offset: 0x0001C9B7
		private static IEnumerator TouchOfLife()
		{
			VRCHandGrasper[] hand = Object.FindObjectsOfType<VRCHandGrasper>();
			bool stopperRight = false;
			for (;;)
			{
				bool flag = hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperRight && hand[0].field_Internal_VRCInput_2.field_Public_Single_0 == 1f;
				if (flag)
				{
					float playerDistance = 999f;
					Player playerToKill = null;
					Player[] players = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
					int num;
					for (int i = 0; i < players.Length; i = num)
					{
						bool flag2 = Vector3.Distance(players[i].gameObject.transform.position, hand[0].gameObject.transform.position) < playerDistance && !players[i].gameObject.name.Contains("Local");
						if (flag2)
						{
							playerDistance = Vector3.Distance(players[i].gameObject.transform.position, hand[0].gameObject.transform.position);
							playerToKill = players[i];
						}
						num = i + 1;
					}
					int j = 0;
					while (j < 31)
					{
						string playerNode = "Player Node (" + j.ToString() + ")";
						string playerEntry = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + j.ToString() + ")/Player Name Text";
						bool flag3 = GameObject.Find(playerEntry).GetComponent<Text>().text.Equals(playerToKill.Method_Internal_get_APIUser_0().displayName);
						if (flag3)
						{
							Logs.LogSuccess("[" + j.ToString() + "]", false);
							UdonBehaviour playerKiller = GameObject.Find(playerNode).GetComponent<UdonBehaviour>();
							playerKiller.SendCustomNetworkEvent(0, "SyncAssignB");
							playerKiller = null;
						}
						int num2 = j + 1;
						j = num2;
						playerNode = null;
						playerEntry = null;
					}
					stopperRight = true;
					playerToKill = null;
					players = null;
				}
				else
				{
					bool flag4 = hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 0f;
					if (flag4)
					{
						stopperRight = false;
					}
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0001E7C0 File Offset: 0x0001C9C0
		public static void ConsoleInstructions()
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.DarkRed;
			Console.WriteLine("                          (                                                     \r\n       #                                                                      / \r\n                                                        (                       \r\n                                                                                \r\n     #       #      #                                                           \r\n          #                                                                     \r\n         #                    (                                                /\r\n                   #                                                            \r\n                                      (                       /                 \r\n                                                                                \r\n#         .#############################.    /////////////////////////          \r\n#         ,#############################.   ./////////////////////////.         \r\n        # *############################*    ,/////////////////////////.         \r\n          ,############################,    //////////////////////////.         \r\n          ,########*,,,,,,,,,,,*#######.    .................,////////.         \r\n          ,###########################,    ///////////////////////////.         \r\n          ,###########################.   .///////////////////////////.         \r\n          ,##########################(    .///////////////////////////.         \r\n          ,########,.         .,#####,                      ..////////.         \r\n          ,########.           ,#####.   .////////////////////////////.         \r\n          ,########.           ,####,    /////////////////////////////.         \r\n          ,########.           ,####.   ./////////////////////////////.         \r\n           ........             ....       /                             /      \r\n                                                                 /              \r\n                                                     .                 /        \r\n                #                                                               \r\n                                                                                \r\n                                                                       /        \r\n                                                  (    (                        \r\n     *                                                                          \r\n                                               (                                \r\n                                                                                ");
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("                   ___                     _____            _            ");
			Console.WriteLine("                 / _ \\                   |  ___|          (_)           ");
			Console.ForegroundColor = ConsoleColor.DarkRed;
			Console.WriteLine("                / /_\\ \\_____   _ _ __ ___| |__ _ __   __ _ _ _ __   ___ ");
			Console.ForegroundColor = ConsoleColor.DarkMagenta;
			Console.WriteLine("                |  _  |_  / | | | '__/ _ \\  __| '_ \\ / _` | | '_ \\ / _ \\");
			Console.WriteLine("                | | | |/ /| |_| | | |  __/ |__| | | | (_| | | | | |  __/");
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine("                 \\_| |_/___|\\__,_|_|  \\___\\____/_| |_|\\__, |_|_| |_|\\___|");
			Console.WriteLine("                                                        __/ |             ");
			Console.WriteLine("                                                       |___/              ");
			Console.WriteLine("");
			Console.WriteLine("");
			Console.ForegroundColor = ConsoleColor.White;
			Logs.Log("Have fun with this feature while it works.\n These two exclusive features are called Hand Of Death, and Hand Of Life.\nThese features depend on VR to work, and you can activate them with your left and right triggers after having them toggled. \n However, If you are a desktop player you can press E to kill or revive the player closest to you.", false);
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0001E886 File Offset: 0x0001CA86
		private static IEnumerator TouchOfDeath()
		{
			VRCHandGrasper[] hand = Object.FindObjectsOfType<VRCHandGrasper>();
			bool stopperLeft = false;
			for (;;)
			{
				bool flag = hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperLeft && hand[1].field_Internal_VRCInput_2.field_Public_Single_0 == 1f;
				if (flag)
				{
					float playerDistance = 999f;
					Player playerToKill = null;
					Player[] players = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
					int num;
					for (int i = 0; i < players.Length; i = num)
					{
						bool flag2 = Vector3.Distance(players[i].gameObject.transform.position, hand[1].gameObject.transform.position) < playerDistance && !players[i].gameObject.name.Contains("Local");
						if (flag2)
						{
							playerDistance = Vector3.Distance(players[i].gameObject.transform.position, hand[1].gameObject.transform.position);
							playerToKill = players[i];
						}
						num = i + 1;
					}
					int j = 0;
					while (j < 31)
					{
						string playerNode = "Player Node (" + j.ToString() + ")";
						string playerEntry = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + j.ToString() + ")/Player Name Text";
						bool flag3 = GameObject.Find(playerEntry).GetComponent<Text>().text.Equals(playerToKill.Method_Internal_get_APIUser_0().displayName);
						if (flag3)
						{
							UdonBehaviour playerKiller = GameObject.Find(playerNode).GetComponent<UdonBehaviour>();
							playerKiller.SendCustomNetworkEvent(0, "SyncKill");
							playerKiller = null;
						}
						int num2 = j + 1;
						j = num2;
						playerNode = null;
						playerEntry = null;
					}
					stopperLeft = true;
					playerToKill = null;
					players = null;
				}
				else
				{
					bool flag4 = hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 0f;
					if (flag4)
					{
						stopperLeft = false;
					}
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0001E890 File Offset: 0x0001CA90
		public static void StartUniversal()
		{
			QMNestedButton universalJarGame = MainMenu.UniversalJarGame;
			new QMToggleButton(universalJarGame, 1f, 0f, "Hands\nOf\nDeath", delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncKill";
					GameObject gameObject = GameObject.CreatePrimitive(3);
					gameObject.name = "AzureEngineLmfao";
					gameObject.transform.localScale = new Vector3(0.06f, 0.06f, 0.06f);
					gameObject.transform.parent = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject.transform;
					gameObject.transform.localPosition = new Vector3(0f, 0.005f, 0f);
					gameObject.AddComponent<touchstuff>();
					gameObject.GetComponent<MeshRenderer>().material.color = Color.red;
					gameObject.AddComponent<Rigidbody>().isKinematic = true;
					gameObject.layer = 2;
				}
				catch
				{
				}
			}, delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncKill";
					GameObject gameObject = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject;
					Object.Destroy(gameObject.transform.Find("AzureEngineLmfao").gameObject);
				}
				catch
				{
				}
			}, "", false);
			new QMToggleButton(universalJarGame, 2f, 0f, "Hands\nOf\nLife\n(Bystand)", delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncAssignB";
					GameObject gameObject = GameObject.CreatePrimitive(3);
					gameObject.name = "AzureEngineLmfao";
					gameObject.transform.localScale = new Vector3(0.06f, 0.06f, 0.06f);
					gameObject.transform.parent = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject.transform;
					gameObject.transform.localPosition = new Vector3(0f, 0.005f, 0f);
					gameObject.AddComponent<touchstuff>();
					gameObject.GetComponent<MeshRenderer>().material.color = Color.blue;
					gameObject.AddComponent<Rigidbody>().isKinematic = true;
					gameObject.layer = 2;
				}
				catch
				{
				}
			}, delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncKill";
					GameObject gameObject = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject;
					Object.Destroy(gameObject.transform.Find("AzureEngineLmfao").gameObject);
				}
				catch
				{
				}
			}, "", false);
			new QMToggleButton(universalJarGame, 3f, 0f, "Hands\nOf\nLife\n(Murder)", delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncAssignM";
					GameObject gameObject = GameObject.CreatePrimitive(3);
					gameObject.name = "AzureEngineLmfao";
					gameObject.transform.localScale = new Vector3(0.06f, 0.06f, 0.06f);
					gameObject.transform.parent = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject.transform;
					gameObject.transform.localPosition = new Vector3(0f, 0.005f, 0f);
					gameObject.AddComponent<touchstuff>();
					gameObject.GetComponent<MeshRenderer>().material.color = Color.red;
					gameObject.AddComponent<Rigidbody>().isKinematic = true;
					gameObject.layer = 2;
				}
				catch
				{
				}
			}, delegate()
			{
				try
				{
					touchstuff.actionforontap = "SyncKill";
					GameObject gameObject = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCPlayerApi_0().GetBoneTransform(18).gameObject;
					Object.Destroy(gameObject.transform.Find("AzureEngineLmfao").gameObject);
				}
				catch
				{
				}
			}, "", false);
		}

		// Token: 0x0400024E RID: 590
		private static object touchOfDeathCor;

		// Token: 0x0400024F RID: 591
		private static object touchOfLifeCor;

		// Token: 0x04000250 RID: 592
		private static object touchOfDeathCor1;

		// Token: 0x04000251 RID: 593
		private static object touchOfLifeCor1;
	}
}
