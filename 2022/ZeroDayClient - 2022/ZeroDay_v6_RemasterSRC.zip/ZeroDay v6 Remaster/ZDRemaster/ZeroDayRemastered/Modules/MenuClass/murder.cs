﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using MelonLoader;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using ZDBase.Modules.JarGames;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000077 RID: 119
	public class murder
	{
		// Token: 0x0600036C RID: 876 RVA: 0x0001CFAE File Offset: 0x0001B1AE
		private static IEnumerator GoldenGunForYou()
		{
			VRCPickup revolver = GameObject.Find("Revolver").GetComponent<VRCPickup>();
			for (;;)
			{
				bool flag = revolver.currentPlayer != null;
				if (flag)
				{
					VRCPlayerApi playerVrcPlayerApi = revolver.currentPlayer;
					bool flag2 = playerVrcPlayerApi.displayName.Equals(APIUser.CurrentUser.displayName) && GameObject.Find("geo (patron)") == null;
					if (flag2)
					{
						UdonBehaviour[] revolverEvent = GameObject.Find("Revolver").GetComponents<UdonBehaviour>();
						revolverEvent[0].SendCustomNetworkEvent(0, "PatronSkin");
						revolverEvent = null;
					}
					yield return null;
					playerVrcPlayerApi = null;
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0001CFB6 File Offset: 0x0001B1B6
		public static IEnumerator InfiniteRevolvere()
		{
			GameObject revolver = GameObject.Find("Revolver");
			VRCHandGrasper[] hand = Object.FindObjectsOfType<VRCHandGrasper>();
			UdonBehaviour revolverUdon = revolver.GetComponent<UdonBehaviour>();
			GameObject luger0 = GameObject.Find("Luger (0)");
			UdonBehaviour luger0Udon = luger0.GetComponent<UdonBehaviour>();
			GameObject shotgun = GameObject.Find("Shotgun (0)");
			UdonBehaviour shotgunUdon = shotgun.GetComponent<UdonBehaviour>();
			GameObject camera = GameObject.Find("FlashCamera");
			UdonBehaviour cameraUdon = camera.GetComponent<UdonBehaviour>();
			bool stopperRight = false;
			bool stopperLeft = false;
			for (;;)
			{
				bool flag = hand[0].field_Internal_VRC_Pickup_0 != null;
				if (flag)
				{
					bool flag2 = hand[0].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Revolver") && hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperRight;
					if (flag2)
					{
						revolverUdon.SendCustomEvent("Fire");
						stopperRight = true;
					}
					else
					{
						bool flag3 = hand[0].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Luger (0)") && hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperRight;
						if (flag3)
						{
							luger0Udon.SendCustomEvent("Fire");
							stopperRight = true;
						}
						else
						{
							bool flag4 = hand[0].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Shotgun (0)") && hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperRight;
							if (flag4)
							{
								shotgunUdon.SendCustomEvent("Fire");
								stopperRight = true;
							}
							else
							{
								bool flag5 = hand[0].field_Internal_VRC_Pickup_0.gameObject.name.Equals("FlashCamera") && hand[0].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperRight;
								if (flag5)
								{
									cameraUdon.SendCustomNetworkEvent(0, "SyncPhoto");
									stopperRight = true;
								}
								else
								{
									bool flag6 = hand[0].field_Internal_VRCInput_1.field_Public_Single_0 != 1f;
									if (flag6)
									{
										stopperRight = false;
									}
								}
							}
						}
					}
				}
				bool flag7 = hand[1].field_Internal_VRC_Pickup_0 != null;
				if (flag7)
				{
					bool flag8 = hand[1].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Revolver") && hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperLeft;
					if (flag8)
					{
						revolverUdon.SendCustomEvent("Fire");
						stopperLeft = true;
					}
					else
					{
						bool flag9 = hand[1].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Luger (0)") && hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperLeft;
						if (flag9)
						{
							luger0Udon.SendCustomEvent("Fire");
							stopperLeft = true;
						}
						else
						{
							bool flag10 = hand[1].field_Internal_VRC_Pickup_0.gameObject.name.Equals("Shotgun (0)") && hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperLeft;
							if (flag10)
							{
								shotgunUdon.SendCustomEvent("Fire");
								stopperLeft = true;
							}
							else
							{
								bool flag11 = hand[1].field_Internal_VRC_Pickup_0.gameObject.name.Equals("FlashCamera") && hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 1f && !stopperLeft;
								if (flag11)
								{
									cameraUdon.SendCustomNetworkEvent(0, "SyncPhoto");
									stopperLeft = true;
								}
								else
								{
									bool flag12 = hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 0f;
									if (flag12)
									{
										stopperLeft = false;
									}
								}
							}
						}
					}
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0001CFBE File Offset: 0x0001B1BE
		public static IEnumerator TouchOfDeath()
		{
			VRCHandGrasper[] hand = Object.FindObjectsOfType<VRCHandGrasper>();
			for (;;)
			{
				yield return new WaitForSeconds(0.1f);
				bool killAuraLeft = murder.KillAuraLeft;
				if (killAuraLeft)
				{
					bool flag = Input.GetAxis("Oculus_CrossPlatform_PrimaryIndexTrigger") > 0f;
					if (flag)
					{
						float playerDistance = 999f;
						Player playerToKill = null;
						Player[] players = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
						int num;
						for (int i = 0; i < players.Length; i = num)
						{
							bool flag2 = Vector3.Distance(players[i].gameObject.transform.position, hand[1].gameObject.transform.position) < playerDistance && !players[i].gameObject.name.Contains("Local");
							if (flag2)
							{
								playerDistance = Vector3.Distance(players[i].gameObject.transform.position, hand[1].gameObject.transform.position);
								playerToKill = players[i];
							}
							num = i + 1;
						}
						int j = 0;
						while (j < 24)
						{
							string playerNode = "Player Node (" + j.ToString() + ")";
							string playerEntry = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + j.ToString() + ")/Player Name Text";
							bool flag3 = GameObject.Find(playerEntry).GetComponent<Text>().text.Equals(playerToKill.Method_Internal_get_APIUser_0().displayName);
							if (flag3)
							{
								UdonBehaviour playerKiller = GameObject.Find(playerNode).GetComponent<UdonBehaviour>();
								playerKiller.SendCustomNetworkEvent(0, "SyncKill");
								playerKiller = null;
							}
							int num2 = j + 1;
							j = num2;
							playerNode = null;
							playerEntry = null;
						}
						playerToKill = null;
						players = null;
					}
					else
					{
						bool flag4 = hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 0f;
						if (flag4)
						{
						}
					}
					yield return null;
				}
				bool killAuraRight = murder.KillAuraRight;
				if (killAuraRight)
				{
					bool flag5 = Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f;
					if (flag5)
					{
						float playerDistance2 = 999f;
						Player playerToKill2 = null;
						Player[] players2 = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
						int num3;
						for (int k = 0; k < players2.Length; k = num3)
						{
							bool flag6 = Vector3.Distance(players2[k].gameObject.transform.position, hand[1].gameObject.transform.position) < playerDistance2 && !players2[k].gameObject.name.Contains("Local");
							if (flag6)
							{
								playerDistance2 = Vector3.Distance(players2[k].gameObject.transform.position, hand[1].gameObject.transform.position);
								playerToKill2 = players2[k];
							}
							num3 = k + 1;
						}
						int l = 0;
						while (l < 24)
						{
							string playerNode2 = "Player Node (" + l.ToString() + ")";
							string playerEntry2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + l.ToString() + ")/Player Name Text";
							bool flag7 = GameObject.Find(playerEntry2).GetComponent<Text>().text.Equals(playerToKill2.Method_Internal_get_APIUser_0().displayName);
							if (flag7)
							{
								UdonBehaviour playerKiller2 = GameObject.Find(playerNode2).GetComponent<UdonBehaviour>();
								playerKiller2.SendCustomNetworkEvent(0, "SyncKill");
								playerKiller2 = null;
							}
							int num4 = l + 1;
							l = num4;
							playerNode2 = null;
							playerEntry2 = null;
						}
						playerToKill2 = null;
						players2 = null;
					}
					else
					{
						bool flag8 = hand[1].field_Internal_VRCInput_1.field_Public_Single_0 == 0f;
						if (flag8)
						{
						}
					}
					yield return null;
				}
			}
			yield break;
		}

		// Token: 0x0600036F RID: 879 RVA: 0x0001CFC6 File Offset: 0x0001B1C6
		public static IEnumerator ShowMurdererOnNamePlate()
		{
			Transform[] allObjects = Resources.FindObjectsOfTypeAll<Transform>();
			GameObject murdererName = null;
			int num;
			for (int i = 0; i < allObjects.Length; i = num)
			{
				bool flag = allObjects[i].gameObject.name.Equals("Murderer Name");
				if (flag)
				{
					murdererName = allObjects[i].gameObject;
				}
				num = i + 1;
			}
			Object.Destroy(murder.murdererNameInstance);
			for (;;)
			{
				Player[] players = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
				int num2;
				for (int j = 0; j < players.Length; j = num2)
				{
					while (players[j].Method_Internal_get_APIUser_0() == null)
					{
						yield return null;
					}
					bool flag2 = players[j].Method_Internal_get_APIUser_0().displayName.Equals(murdererName.GetComponent<Text>().text);
					if (flag2)
					{
						Object.Destroy(murder.murdererNameInstance);
						murder.murdererNameInstance = Object.Instantiate<Transform>(players[j].gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container/Name")).gameObject;
						murder.murdererNameInstance.GetComponent<TextMeshProUGUI>().text = "Murderer";
						murder.murdererNameInstance.transform.parent = players[j].gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").gameObject.transform;
						murder.murdererNameInstance.transform.localPosition = players[j].gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").gameObject.transform.localPosition;
						murder.murdererNameInstance.transform.localRotation = players[j].gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").gameObject.transform.localRotation;
						murder.murdererNameInstance.transform.localScale = players[j].gameObject.transform.Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").gameObject.transform.localScale;
						murder.murdererNameInstance.GetComponent<TextMeshProUGUI>().color = Color.red;
						while (players[j].Method_Internal_get_APIUser_0().displayName.Equals(murdererName.GetComponent<Text>().text))
						{
							yield return null;
						}
						yield return null;
					}
					num2 = j + 1;
				}
				yield return new WaitForSeconds(2f);
				players = null;
			}
			yield break;
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0001CFCE File Offset: 0x0001B1CE
		private static IEnumerator ClueEsp()
		{
			List<Renderer> cluesFound = new List<Renderer>();
			Transform[] allObjects = Resources.FindObjectsOfTypeAll<Transform>();
			Transform[] array = allObjects;
			foreach (Transform transform in array)
			{
				bool flag = transform.gameObject.name.Equals("Clue (photograph)") || transform.gameObject.name.Equals("Clue (notebook)") || transform.gameObject.name.Equals("Clue (locket)") || transform.gameObject.name.Equals("Clue (pocketwatch)") || transform.gameObject.name.Equals("Clue (postcard)");
				if (flag)
				{
					cluesFound.Add(transform.GetChild(0).gameObject.GetComponent<Renderer>());
				}
				transform = null;
			}
			Transform[] array2 = null;
			for (;;)
			{
				foreach (Renderer renderer in cluesFound)
				{
					bool flag2 = renderer != null;
					if (flag2)
					{
						bool activeInHierarchy = renderer.gameObject.activeInHierarchy;
						if (activeInHierarchy)
						{
							HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(renderer, true);
						}
						else
						{
							HighlightsFX.field_Private_Static_HighlightsFX_0.Method_Public_Void_Renderer_Boolean_0(renderer, false);
						}
					}
					yield return new WaitForSeconds(0.2f);
					renderer = null;
				}
				List<Renderer>.Enumerator enumerator = default(List<Renderer>.Enumerator);
				yield return new WaitForSeconds(2f);
			}
			yield break;
			yield break;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x0001CFD6 File Offset: 0x0001B1D6
		public static IEnumerator DuhDuhDuh()
		{
			for (;;)
			{
				yield return new WaitForSeconds(1.7f);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
			}
			yield break;
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0001CFE0 File Offset: 0x0001B1E0
		public static void StartMurder()
		{
			new QMSingleButton(MainMenu.murder, 1f, 0f, "TP REVOLVER", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.bringRevolver();
			}, "Teleports the [Revolver] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 0.5f, "TP LUGER", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.bringLuger();
			}, "Teleports the [Luger] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 1f, "TP SHOTGUN", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.bringShotgun();
			}, "Teleports the [Shotgun] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 1.5f, "TP FRAG", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.bringFrag();
			}, "Teleports the [FRAG] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 2f, "TP SMOKE", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.BringSmoke();
			}, "Teleports the [SMOKE] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 2.5f, "TP KNIFE", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.bringKnife();
			}, "Teleports the [Knife] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 3f, "TP TRAP", delegate()
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Murder.BringTrap();
			}, "Teleports the [Trap] To your position!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 1f, 3.5f, "Infinite Ammo", delegate()
			{
				MelonCoroutines.Start(murder.InfiniteRevolvere());
			}, "Gives You Infinite Shots for Every Gun including Flash Camera", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 0f, "Show Murd \n On Plates", delegate()
			{
				MelonCoroutines.Start(murder.ShowMurdererOnNamePlate());
			}, "Shows Who The Murderer Is On Their Nameplate!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 0.5f, "FFA (BREAKS GAME)", delegate()
			{
				Murder.StartFFA();
			}, "Set's The GameMode To Free-For-All", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 1f, "OP\nRevolver", delegate()
			{
				GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/Laser Sight").active = true;
			}, "Gives you a local laser on the revolver!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 1.5f, "Turn Lights ON", delegate()
			{
				Murder.LightsON();
			}, "Turns On The Lights For Everyone.", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 2f, "Turn Lights OFF", delegate()
			{
				Murder.LightsOFF();
			}, "Turns Off The Lights For Everyone. ", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 2.5f, "Abort", delegate()
			{
				Murder.Abort();
			}, "Aborts The Game (MAY TAKE A MINUTE)", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 2f, 3f, "Start", delegate()
			{
				Murder.Start();
			}, "Starts The Game!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 0f, "Blind All", delegate()
			{
				Murder.BlindAll();
			}, "Blind's Every Player Via Bystander Kill", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 0.5f, "Kill All", delegate()
			{
				Murder.KillAll();
			}, "Kill's Everyone Using Udon Commands", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 1f, "Murderer\nWin", delegate()
			{
				Murder.MurderWin();
			}, "Makes The Murderer Win", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 1.5f, "Bystanders\nWin", delegate()
			{
				Murder.ByStandWin();
			}, "Makes The Bystander Win", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 2f, "LOCK DOORS", delegate()
			{
				Murder.LockDoors();
			}, "Locks All Doors", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 2.5f, "UNLOCK DOORS", delegate()
			{
				Murder.UnlockDoors();
			}, "Unlock's All Doors", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 3f, 3f, "OPEN DOORS", delegate()
			{
				Murder.OpenDoors();
			}, "Opens All Doors", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 0f, "CLOSE DOORS", delegate()
			{
				Murder.CloseDoors();
			}, "Close's All Doors", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 0.5f, "Become Bystander", delegate()
			{
				Murder.SelfBystander();
			}, "Assigns Your Role Bystander Locally!", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 1f, "Become Murderer", delegate()
			{
				Murder.SeldMurderer();
			}, "Assigns Your Role Murderer Locally! ", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 1.5f, "No Kill Screen", delegate()
			{
				MelonCoroutines.Start(murder.<StartMurder>g__Loop|11_23());
			}, "Will remove that annoying bystander kill screen ", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 2f, "Clue\nHighlights", delegate()
			{
				MelonCoroutines.Start(murder.ClueEsp());
			}, "Allows you to see clues through walls! ", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.murder, 4f, 2.5f, "GoldenGun", delegate()
			{
				MelonCoroutines.Start(murder.GoldenGunForYou());
			}, "Gives You The Golden Gun! ", false, null, new Color?(Color.magenta), new Color?(Color.magenta), true);
			new QMToggleButton(MainMenu.murder, 4f, 3f, "Annoy\nLobby", delegate()
			{
				murder.BoopDeathCor = MelonCoroutines.Start(murder.DuhDuhDuh());
			}, delegate()
			{
				MelonCoroutines.Stop(murder.BoopDeathCor);
			}, "Will Go Brrrrr", false);
			MainMenu.SpicyPineapple = new QMNestedButton(MainMenu.murder, "Spicy\nPineapple", 2f, 3.5f, "Spicy Pineapple Party!", "Spicy Pineapple (Grenade)", false, null, true);
			MainMenu.Henry = new QMNestedButton(MainMenu.murder, "Henry", 3f, 3.5f, "Henry", "Henry", false, null, true);
			new QMSingleButton(MainMenu.SpicyPineapple, 1f, 0f, "Reset", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("Frag (0)").GetComponents<UdonBehaviour>();
				array[0].SendCustomNetworkEvent(0, "Reset");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.SpicyPineapple, 2f, 0f, "Arm", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("Frag (0)").GetComponents<UdonBehaviour>();
				array[0].SendCustomNetworkEvent(0, "SyncArm");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.SpicyPineapple, 3f, 0f, "Explode", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("Frag (0)").GetComponents<UdonBehaviour>();
				array[0].SendCustomNetworkEvent(0, "Explode");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.SpicyPineapple, 4f, 0f, "Respawn", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("Frag (0)").GetComponents<UdonBehaviour>();
				array[1].SendCustomNetworkEvent(0, "Respawn");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Henry, 1f, 0f, "Reset", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("SnakeDispenser").GetComponents<UdonBehaviour>();
				array[0].SendCustomNetworkEvent(0, "Reset");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Henry, 2f, 0f, "Release", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("SnakeDispenser").GetComponents<UdonBehaviour>();
				array[0].SendCustomNetworkEvent(0, "DispenseSnake");
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Henry, 3f, 0f, "Respawn", delegate()
			{
				UdonBehaviour[] array = GameObject.Find("SnakeDispenser").GetComponents<UdonBehaviour>();
				array[1].SendCustomNetworkEvent(0, "Respawn");
			}, "", false, null, null, null, false);
		}

		// Token: 0x06000374 RID: 884 RVA: 0x0001DC40 File Offset: 0x0001BE40
		[CompilerGenerated]
		internal static IEnumerator <StartMurder>g__Loop|11_23()
		{
			GameObject FlashBang = GameObject.Find("Flashbang HUD Anim");
			GameObject BlindHub = GameObject.Find("Blind HUD Anim");
			bool active = FlashBang.active;
			if (active)
			{
				FlashBang.SetActive(false);
			}
			bool active2 = BlindHub.active;
			if (active2)
			{
				BlindHub.SetActive(false);
			}
			yield return new WaitForEndOfFrame();
			yield break;
		}

		// Token: 0x04000245 RID: 581
		private static GameObject murdererNameInstance;

		// Token: 0x04000246 RID: 582
		public static QMNestedButton page2;

		// Token: 0x04000247 RID: 583
		public static bool KillAuraRight;

		// Token: 0x04000248 RID: 584
		public static bool KillAuraLeft;

		// Token: 0x04000249 RID: 585
		public static bool WaypointMurderer;

		// Token: 0x0400024A RID: 586
		public static object BoopDeathCor;
	}
}
