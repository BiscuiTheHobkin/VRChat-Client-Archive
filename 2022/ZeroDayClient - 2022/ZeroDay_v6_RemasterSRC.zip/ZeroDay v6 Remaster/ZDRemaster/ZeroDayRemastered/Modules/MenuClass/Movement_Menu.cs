﻿using System;
using MelonLoader;
using UnityEngine;
using ZDBase;
using ZDBase.Utils;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000076 RID: 118
	public class Movement_Menu
	{
		// Token: 0x0600036A RID: 874 RVA: 0x0001CBC0 File Offset: 0x0001ADC0
		public static void StartMovement()
		{
			Movement_Menu.flighttoggle = new QMToggleButton(MainMenu.Movement, 1f, 0f, "Direct\nFlight", delegate()
			{
				MainConfigSettings.flight = true;
				KeyBinds.flycor = MelonCoroutines.Start(KeyBinds.Fly());
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = false;
			}, delegate()
			{
				MainConfigSettings.flight = false;
				MelonCoroutines.Stop(KeyBinds.flycor);
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = true;
			}, "", MainConfigSettings.flight);
			new QMToggleButton(MainMenu.Movement, 2f, 0f, "Infinite Jump", delegate()
			{
				MainConfigSettings.Instance.InfiniteJump = true;
			}, delegate()
			{
				MainConfigSettings.Instance.InfiniteJump = false;
			}, "  ", MainConfigSettings.Instance.InfiniteJump);
			new QMToggleButton(MainMenu.Movement, 2f, 1f, "Rocket Jump", delegate()
			{
				MainConfigSettings.Instance.Rock_jump = true;
			}, delegate()
			{
				MainConfigSettings.Instance.Rock_jump = false;
			}, "  ", MainConfigSettings.Instance.Rock_jump);
			new QMToggleButton(MainMenu.Movement, 3f, 1f, "Speed Hack", delegate()
			{
				Time.timeScale = 4f;
			}, delegate()
			{
				Time.timeScale = 1f;
			}, "  ", false);
			new QMSingleButton(MainMenu.Movement, 2f, 2f, "Set\nJumpPower", delegate()
			{
				Popups.PopupCall("Azura", "Apply", "Enter Number", true, delegate(string text)
				{
					Utilities.StaffNotify("Jump Power: " + text);
					Movement.JumpPower = Convert.ToSingle(text);
					MainConfigSettings.Instance.SaveConfig();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 3f, 0f, "Set\nRunSpeed", delegate()
			{
				Popups.PopupCall("Azura", "Apply", "Enter Number", true, delegate(string text)
				{
					Logs.Log(text, false);
					Utilities.StaffNotify("RunSpeed: " + text);
					Movement.RunSpeed = Convert.ToSingle(text);
					MainConfigSettings.Instance.SaveConfig();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 4f, 0f, "Set\nWalkSpeed", delegate()
			{
				Popups.PopupCall("Azura", "Apply", "Enter Number", false, delegate(string text)
				{
					Logs.Log(text, false);
					Utilities.StaffNotify("WalkSpeed: " + text + "f");
					Movement.WalkSpeed = Convert.ToSingle(text + "f");
					MainConfigSettings.Instance.SaveConfig();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 1f, 1f, "Set\nFlySpeed", delegate()
			{
				Popups.PopupCall("Azura", "Apply", "Enter Number", true, delegate(string text)
				{
					Logs.Log(text, false);
					Utilities.StaffNotify("FlySpeed: " + text);
					Movement.FlySpeed = Convert.ToSingle(text);
					MainConfigSettings.Instance.SaveConfig();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 3f, 3f, "Reset\nRunSpeed", delegate()
			{
				VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Alert("Azura", "Reset FlySpeed?", "yes", delegate()
				{
					Movement.RunSpeed = 4f;
				}, "no", delegate()
				{
					Popups.CloseCurrentPopup();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 4f, 3f, "Reset\nWalkSpeed", delegate()
			{
				VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Alert("Azura", "Reset FlySpeed?", "yes", delegate()
				{
					Movement.WalkSpeed = 3f;
				}, "no", delegate()
				{
					Popups.CloseCurrentPopup();
				}, null);
			}, "", false, null, null, null, false);
			new QMSingleButton(MainMenu.Movement, 2f, 3f, "Reset\nFlySpeed", delegate()
			{
				VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Alert("Azura", "Reset FlySpeed?", "yes", delegate()
				{
					Movement.FlySpeed = 6f;
				}, "no", delegate()
				{
					Popups.CloseCurrentPopup();
				}, null);
			}, "", false, null, null, null, false);
		}

		// Token: 0x04000244 RID: 580
		public static QMToggleButton flighttoggle;
	}
}
