﻿using System;
using VRC;
using ZDBase;
using ZDBase.Utils;
using ZDBase.Utils.Wrappers;
using ZeroDayAPI.Modules;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200006B RID: 107
	public static class DynBones
	{
		// Token: 0x06000339 RID: 825 RVA: 0x000191D2 File Offset: 0x000173D2
		public static void ReloadAvatar(this Player Instance)
		{
			Instance.GetVRCPlayer().ReloadAvatar();
		}

		// Token: 0x0600033A RID: 826 RVA: 0x000191E1 File Offset: 0x000173E1
		public static void ReloadAvatar(this VRCPlayer Instance)
		{
			VRCPlayer.Method_Public_Static_Void_APIUser_0(Instance.GetAPIUser());
		}

		// Token: 0x0600033B RID: 827 RVA: 0x000191F0 File Offset: 0x000173F0
		public static void StartDynBones()
		{
			new QMToggleButton(MainMenu.GlobalDynBones, 1f, 0f, "Touch Bones", delegate()
			{
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player player in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					GlobalDynamicBones.Users.Add(player.Method_Internal_get_APIUser_0().id);
					GlobalDynamicBones.ProcessDynamicBones(player._vrcplayer.Method_Public_get_VRCAvatarManager_0(), null);
				}
			}, delegate()
			{
				GlobalDynamicBones.Users.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
			}, "Enable or disable touch in general", false);
			new QMToggleButton(MainMenu.GlobalDynBones, 1f, 1f, "Hand Colliders", delegate()
			{
				MainConfigSettings.Instance.HandColliders = true;
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
				GlobalDynamicBones.ProcessDynamicBones(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCAvatarManager_0(), null);
			}, delegate()
			{
				MainConfigSettings.Instance.HandColliders = false;
				GlobalDynamicBones.Users.Clear();
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
			}, "Enable or disable hand colliders", MainConfigSettings.Instance.HandColliders);
			new QMToggleButton(MainMenu.GlobalDynBones, 1f, 2f, "Head Bones", delegate()
			{
				MainConfigSettings.Instance.HeadBones = true;
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
				GlobalDynamicBones.ProcessDynamicBones(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCAvatarManager_0(), null);
			}, delegate()
			{
				MainConfigSettings.Instance.HeadBones = false;
				GlobalDynamicBones.Users.Clear();
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
			}, "Enable or disable head colliders", MainConfigSettings.Instance.HeadBones);
			new QMToggleButton(MainMenu.GlobalDynBones, 1f, 3f, "Chest Bones", delegate()
			{
				MainConfigSettings.Instance.ChestBones = true;
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
				GlobalDynamicBones.ProcessDynamicBones(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCAvatarManager_0(), null);
			}, delegate()
			{
				MainConfigSettings.Instance.ChestBones = false;
				GlobalDynamicBones.Users.Clear();
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
			}, "Enable or disable Chest colliders", MainConfigSettings.Instance.ChestBones);
			new QMToggleButton(MainMenu.GlobalDynBones, 2f, 0f, "Hip Bones", delegate()
			{
				MainConfigSettings.Instance.HipBones = true;
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
				GlobalDynamicBones.ProcessDynamicBones(VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_VRCAvatarManager_0(), null);
			}, delegate()
			{
				MainConfigSettings.Instance.HipBones = false;
				GlobalDynamicBones.Users.Clear();
				GlobalDynamicBones.currentWorldDynamicBoneColliders.Clear();
				GlobalDynamicBones.currentWorldDynamicBones.Clear();
				foreach (Player instance in PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers())
				{
					instance.ReloadAvatar();
				}
			}, "Enable or disable Hip colliders", MainConfigSettings.Instance.HipBones);
		}
	}
}
