﻿using System;
using UnityEngine;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200007B RID: 123
	public class Quality
	{
		// Token: 0x0600037E RID: 894 RVA: 0x0001E680 File Offset: 0x0001C880
		public static void StartQuality()
		{
			new QMToggleButton(MainMenu.Qaulity, 1f, 0f, "Flashlight", delegate()
			{
				Funny.StartFlashlight();
			}, delegate()
			{
				Object.Destroy(Funny.FlashlightObject);
			}, "", false);
		}
	}
}
