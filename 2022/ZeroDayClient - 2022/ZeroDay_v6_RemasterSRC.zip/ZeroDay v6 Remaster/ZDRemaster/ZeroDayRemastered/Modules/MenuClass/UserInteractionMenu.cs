﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.Management;
using VRC.SDKBase;
using VRC.UI;
using VRC.UI.Elements.Menus;
using ZDBase.Utils;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200007E RID: 126
	public class UserInteractionMenu
	{
		// Token: 0x06000387 RID: 903 RVA: 0x0001E9BC File Offset: 0x0001CBBC
		public static void StartUserMenu()
		{
			Transform userMenu = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local");
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 0f, "TP", delegate()
			{
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						Networking.LocalPlayer.TeleportTo(PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Public_get_VRCPlayerApi_0().GetPosition(), PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Public_get_VRCPlayerApi_0().GetRotation());
					}
				}
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 0.5f, "Copy Avatar ID", delegate()
			{
				Player player = null;
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(userMenu.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						player = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i];
					}
				}
				Clipboard.SetText(player.Method_Public_get_ApiAvatar_0().id);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 1f, "Force Clone", delegate()
			{
				Player player = null;
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(userMenu.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						player = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i];
					}
				}
				UserInteractionMenu.ChangeAvatar(player.Method_Public_get_ApiAvatar_0().id);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 1.5f, "Download VRC+ Pfp", delegate()
			{
				Process.Start(MainMenu.GetSelectedPlayer(false).Method_Internal_get_APIUser_0().profilePicOverride);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 2f, "Download VRC+ Icon", delegate()
			{
				Process.Start(MainMenu.GetSelectedPlayer(false).Method_Internal_get_APIUser_0().userIcon);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 2.5f, "Copy User ID", delegate()
			{
				Player player = null;
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(userMenu.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						player = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i];
					}
				}
				Clipboard.SetText(player.Method_Internal_get_APIUser_0().id);
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 3f, "Crash PC", delegate()
			{
				MelonCoroutines.Start(UserInteractionMenu.TargetCrash(MainMenu.GetSelectedPlayer(false)._vrcplayer, "avtr_cde31407-ad66-48b8-b4d2-677be6edc101", 10));
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(MainMenu.AvatarOptions, 1f, 3.5f, "Crash Quest", delegate()
			{
				MelonCoroutines.Start(UserInteractionMenu.TargetCrash(MainMenu.GetSelectedPlayer(false)._vrcplayer, "avtr_9a5c7ead-2761-40ba-a993-b42e29e5f862", 6));
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0001EC60 File Offset: 0x0001CE60
		public static void ChangeToCrash(string AvatarID, int SecondsToWait)
		{
			UserInteractionMenu.<>c__DisplayClass4_0 CS$<>8__locals1 = new UserInteractionMenu.<>c__DisplayClass4_0();
			CS$<>8__locals1.SecondsToWait = SecondsToWait;
			UserInteractionMenu.IsCrashing = true;
			UserInteractionMenu.PreviousAvatar = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1().id;
			VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.active = false;
			popshit.avatarbyid(AvatarID);
			MelonCoroutines.Start(CS$<>8__locals1.<ChangeToCrash>g__WaitSeconds|0());
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0001ECBA File Offset: 0x0001CEBA
		public static IEnumerator TargetCrash(VRCPlayer Target, string AvatarID, int SecondsToWait)
		{
			Utilities.StaffNotify("Blocked Players.");
			List<Player>.Enumerator enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
			while (enumerator.MoveNext())
			{
				Player current = enumerator.current;
				PageUserInfo component = GameObject.Find("Screens").transform.Find("UserInfo").GetComponent<PageUserInfo>();
				component.field_Private_APIUser_0 = current.field_Private_APIUser_0;
				bool flag = !UserInteractionMenu.IsBlockedEitherWay(component.field_Private_APIUser_0.id) && component.field_Private_APIUser_0.id != APIUser.CurrentUser.id && component.field_Private_APIUser_0.id != Target.GetAPIUser().id;
				if (flag)
				{
					component.ToggleBlock();
				}
				current = null;
				component = null;
			}
			yield return new WaitForSeconds(6f);
			UserInteractionMenu.PreviousAvatar = VRCPlayer.field_Internal_Static_VRCPlayer_0.Method_Public_get_ApiAvatar_1().id;
			UserInteractionMenu.ChangeToCrash(AvatarID, SecondsToWait);
			yield return new WaitForSeconds((float)SecondsToWait + 2f);
			Utilities.StaffNotify("Unblocked Players.");
			VRCPlayer.field_Internal_Static_VRCPlayer_0.SetHide(true);
			enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
			while (enumerator.MoveNext())
			{
				Player current2 = enumerator.current;
				PageUserInfo component2 = GameObject.Find("Screens").transform.Find("UserInfo").GetComponent<PageUserInfo>();
				component2.field_Private_APIUser_0 = current2.field_Private_APIUser_0;
				bool flag2 = UserInteractionMenu.IsBlockedEitherWay(component2.field_Private_APIUser_0.id) && component2.field_Private_APIUser_0.id != APIUser.CurrentUser.id && component2.field_Private_APIUser_0.id != Target.GetAPIUser().id;
				if (flag2)
				{
					component2.ToggleBlock();
				}
				current2 = null;
				component2 = null;
			}
			yield break;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0001ECD8 File Offset: 0x0001CED8
		public static bool IsBlockedEitherWay(string userId)
		{
			bool flag = ModerationManager.Method_Public_Static_get_ModerationManager_PDM_0() == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = APIUser.CurrentUser.id == userId;
				if (flag2)
				{
					result = false;
				}
				else
				{
					Dictionary<string, List<ApiPlayerModeration>> field_Private_Dictionary_2_String_List_1_ApiPlayerModeration_ = ModerationManager.Method_Public_Static_get_ModerationManager_PDM_0().field_Private_Dictionary_2_String_List_1_ApiPlayerModeration_0;
					bool flag3 = !field_Private_Dictionary_2_String_List_1_ApiPlayerModeration_.ContainsKey(userId);
					if (flag3)
					{
						result = false;
					}
					else
					{
						List<ApiPlayerModeration>.Enumerator enumerator = field_Private_Dictionary_2_String_List_1_ApiPlayerModeration_[userId].GetEnumerator();
						while (enumerator.MoveNext())
						{
							ApiPlayerModeration current = enumerator.current;
							bool flag4 = current != null && current.moderationType == 1;
							if (flag4)
							{
								return true;
							}
						}
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x0600038B RID: 907 RVA: 0x0001ED7C File Offset: 0x0001CF7C
		public static AssetBundle loadAssets(string assetName)
		{
			AssetBundle assetBundle;
			using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AzureX.g.resources." + assetName))
			{
				using (MemoryStream memoryStream = new MemoryStream((int)manifestResourceStream.Length))
				{
					manifestResourceStream.CopyTo(memoryStream);
					assetBundle = AssetBundle.LoadFromMemory_Internal(memoryStream.ToArray(), 0U);
					assetBundle.hideFlags |= 32;
				}
			}
			return assetBundle;
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0001EE14 File Offset: 0x0001D014
		public static void ChangeAvatar(string AvatarID)
		{
			PageAvatar component = GameObject.Find("Screens").transform.Find("Avatar").GetComponent<PageAvatar>();
			component.field_Public_SimpleAvatarPedestal_0.field_Internal_ApiAvatar_0 = new ApiAvatar
			{
				id = AvatarID
			};
			component.ChangeToSelectedAvatar();
		}

		// Token: 0x04000252 RID: 594
		public static string PreviousAvatar;

		// Token: 0x04000253 RID: 595
		public static List<string> UserID = new List<string>();

		// Token: 0x04000254 RID: 596
		public static bool IsCrashing = false;
	}
}
