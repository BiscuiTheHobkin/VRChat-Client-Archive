﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Udon;
using ZDBase;
using ZDBase.Modules.JarGames;
using ZDBase.Utils;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000067 RID: 103
	public class AmongUsInteract
	{
		// Token: 0x0600032F RID: 815 RVA: 0x00018AA0 File Offset: 0x00016CA0
		public static void StartAmongInteract()
		{
			QMNestedButton amongusUSER = MainMenu.AmongusUSER;
			new QMSingleButton(amongusUSER, 1f, 0f, "Assign Crewmate", delegate()
			{
				VRCPlayer component = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 24; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
						component2.SendCustomNetworkEvent(0, "SyncAssignB");
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(amongusUSER, 1f, 1f, "Assign Imposter", delegate()
			{
				VRCPlayer component = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 24; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
						component2.SendCustomNetworkEvent(0, "SyncAssignM");
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(amongusUSER, 1f, 2f, "Force Vote Out", delegate()
			{
				Player selectedPlayer = MainMenu.GetSelectedPlayer(false);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
				{
					bool flag = transform.name != gameObject.name;
					if (flag)
					{
						Exploits.SendUdonRPC(transform.gameObject, "SyncVotedOut", selectedPlayer._vrcplayer._player, false);
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(amongusUSER, 1f, 3f, "Kill Player", delegate()
			{
				VRCPlayer component = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 24; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
						component2.SendCustomNetworkEvent(0, "Btn_Kill");
						component2.SendCustomNetworkEvent(0, "SyncKill");
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(amongusUSER, 2f, 0f, "Node\nID", delegate()
			{
				VRCPlayer component = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 29; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						Clipboard.SetText(i.ToString() ?? "");
						ZDBase.Utils.Utilities.StaffNotify(text);
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(amongusUSER, 2f, 1f, "Process\nVote", delegate()
			{
				VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.Alert("AzureX", "Are you sure you want to do this?", "Yes", delegate()
				{
					MelonCoroutines.Start(AmongUsInteract.VoteEliminationProcess());
					Popups.CloseCurrentPopup();
				}, "No", delegate()
				{
					Popups.CloseCurrentPopup();
				}, null);
			}, "", false, null, null, null, false);
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00018C8E File Offset: 0x00016E8E
		public static IEnumerator VoteEliminationProcess()
		{
			ZDBase.Utils.Utilities.StaffNotify("Starting Vote Process.");
			VRCPlayer component15 = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
			string value6 = component15._player.ToString();
			yield return new WaitForSeconds(2f);
			int num10;
			for (int num9 = 0; num9 < 29; num9 = num10 + 1)
			{
				string text6 = "Player Node (" + num9.ToString() + ")";
				string name10 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + num9.ToString() + ")/Player Name Text";
				bool flag = GameObject.Find(name10).GetComponent<Text>().text.Equals(value6);
				if (flag)
				{
					AmongUs.Em();
					yield return new WaitForSeconds(5f);
					ZDBase.Utils.Utilities.StaffNotify("Adding Votes..");
					GameObject gameObject10 = GameObject.Find("Player Nodes");
					foreach (Transform componentsInChild3 in gameObject10.GetComponentsInChildren<Transform>())
					{
						bool flag2 = componentsInChild3.name != gameObject10.name;
						if (flag2)
						{
							Exploits.SendUdonRPC(componentsInChild3.gameObject, "SyncVotedFor" + num9.ToString(), null, false);
						}
						componentsInChild3 = null;
					}
					IEnumerator<Transform> enumerator = null;
					gameObject10 = null;
				}
				name10 = null;
				num10 = num9;
			}
			yield return new WaitForSeconds(7f);
			ZDBase.Utils.Utilities.StaffNotify("Ending Vote Phase..");
			Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "SyncEndVotingPhase", null, false);
			yield break;
		}
	}
}
