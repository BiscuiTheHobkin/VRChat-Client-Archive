﻿using System;
using MelonLoader;
using UnityEngine;
using ZDBase;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200006D RID: 109
	public class FlightMenu
	{
		// Token: 0x0600034E RID: 846 RVA: 0x00019E24 File Offset: 0x00018024
		public static void StartFlight()
		{
			FlightMenu.flighttoggle = new QMToggleButton(MainMenu.Flight, 1f, 0f, "FLY", delegate()
			{
				MainConfigSettings.flight = true;
				KeyBinds.flycor = MelonCoroutines.Start(KeyBinds.Fly());
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = false;
			}, delegate()
			{
				MainConfigSettings.flight = false;
				MelonCoroutines.Stop(KeyBinds.flycor);
				VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = true;
			}, "", MainConfigSettings.flight);
			QMSingleButton speedcounter = new QMSingleButton(MainMenu.Flight, 2f, 0f, string.Format("Speed: [{0}]", Movement.FlySpeed), delegate()
			{
			}, "This Shows Your Current Speeds", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 1f, 1f, "+5 speed", delegate()
			{
				Movement.FlySpeed += 5f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Increases Your Speed By +5", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 1f, 2f, "+3 speed", delegate()
			{
				Movement.FlySpeed += 3f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Increases Your Speed By +3", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 1f, 3f, "+1", delegate()
			{
				Movement.FlySpeed += 1f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Increases Your Speed By +1", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 4f, 1f, "-5 speed", delegate()
			{
				Movement.FlySpeed -= 5f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Decreases Your Speed By -5", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 4f, 2f, "-3 speed", delegate()
			{
				Movement.FlySpeed -= 3f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Decreases Your Speed By -3", false, null, null, null, false);
			new QMSingleButton(MainMenu.Flight, 4f, 3f, "-1 speed", delegate()
			{
				Movement.FlySpeed -= 1f;
				speedcounter.SetButtonText(string.Format("<color=#FF1493>Speed: [{0}]", Movement.FlySpeed));
			}, "Decreases Your Speed By -1", false, null, null, null, false);
		}

		// Token: 0x04000212 RID: 530
		public static QMToggleButton flighttoggle;
	}
}
