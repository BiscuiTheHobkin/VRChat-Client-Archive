﻿using System;
using MelonLoader;
using UnityEngine;
using ZDBase;
using ZDBase.Modules.AvatarHider;
using ZDBase.Utils;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x0200006A RID: 106
	public class distancehide
	{
		// Token: 0x06000337 RID: 823 RVA: 0x00018F24 File Offset: 0x00017124
		public static void StartDistanceHide()
		{
			QMNestedButton distanceHide = MainMenu.DistanceHide;
			new QMToggleButton(distanceHide, 1f, 0f, "Enabled?", delegate()
			{
				MainConfigSettings.m_HideAvatars = true;
				distancehide.HideAviCor = MelonCoroutines.Start(AviDistanceHide.AvatarScanner());
			}, delegate()
			{
				MainConfigSettings.m_HideAvatars = false;
				MelonCoroutines.Stop(distancehide.HideAviCor);
			}, "This will enable or disable avatar hiding by distance!", false);
			new QMSingleButton(distanceHide, 2f, 0f, "Get\nCurrent\nDistance", delegate()
			{
				Utilities.StaffNotify("Current Distance Is: " + MainConfigSettings.Instance.m_Distance.ToString());
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 1f, 1f, "+1 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance += 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 1f, 1.5f, "+3 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance += 3f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 1f, 2f, "+5 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance += 5f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 4f, 1f, "-1 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance -= 1f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 4f, 1.5f, "-3 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance -= 3f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new QMSingleButton(distanceHide, 4f, 2f, "-5 Distance", delegate()
			{
				MainConfigSettings.Instance.m_Distance -= 5f;
			}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}

		// Token: 0x04000207 RID: 519
		public static object HideAviCor;
	}
}
