﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Blaze.API.QM;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.SDKBase;
using VRC.Udon;
using ZDBase;
using ZDBase.Utils;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered.API.QM;
using ZeroDayRemastered.Utils.API;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000073 RID: 115
	internal class MainMenu
	{
		// Token: 0x0600035C RID: 860 RVA: 0x0001B4A0 File Offset: 0x000196A0
		internal static void logjoin(string text)
		{
			MainMenu.linecheck += 1f;
			bool flag = MainMenu.linecheck > 40f;
			if (flag)
			{
				MainMenu.console.InfoText.text = "";
				MainMenu.linecheck = 0f;
			}
			Text infoText = MainMenu.console.InfoText;
			infoText.text = string.Concat(new string[]
			{
				infoText.text,
				"[<color=#8A2BE2>",
				DateTime.Now.ToString("[hh:mm:ss.ms]"),
				"</color>] [<color=#8A2BE2>ZD REMASTERED</color>] [<color=#DC143C>+</color>]:    ",
				text,
				"\n"
			});
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0001B548 File Offset: 0x00019748
		internal static void logleave(string text)
		{
			MainMenu.linecheck += 1f;
			bool flag = MainMenu.linecheck > 40f;
			if (flag)
			{
				MainMenu.console.InfoText.text = "";
				MainMenu.linecheck = 0f;
			}
			Text infoText = MainMenu.console.InfoText;
			infoText.text = string.Concat(new string[]
			{
				infoText.text,
				"[<color=#8A2BE2>",
				DateTime.Now.ToString("[hh:mm:ss.ms]"),
				"</color>] [<color=#8A2BE2>ZD REMASTERED</color>] [<color=#D3D3D3>-</color>]:    ",
				text,
				"\n"
			});
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0001B5F0 File Offset: 0x000197F0
		internal static void LogAPIDEBUGGER(string text)
		{
			MainMenu.linecheck += 1f;
			bool flag = MainMenu.linecheck > 40f;
			if (flag)
			{
				MainMenu.console.InfoText.text = "";
				MainMenu.linecheck = 0f;
			}
			Text infoText = MainMenu.console.InfoText;
			infoText.text = string.Concat(new string[]
			{
				infoText.text,
				"[<color=#8A2BE2>",
				DateTime.Now.ToString("[hh:mm:ss.ms]"),
				"</color>] [<color=#8A2BE2>ZD REMASTERED</color>]:    ",
				text,
				"\n"
			});
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0001B698 File Offset: 0x00019898
		internal static void LogMODERATIONDEBUGGER(string text)
		{
			MainMenu.linecheck += 1f;
			bool flag = MainMenu.linecheck > 40f;
			if (flag)
			{
				MainMenu.console.InfoText.text = "";
				MainMenu.linecheck = 0f;
			}
			Text infoText = MainMenu.console.InfoText;
			infoText.text = string.Concat(new string[]
			{
				infoText.text,
				"[<color=#8A2BE2>",
				DateTime.Now.ToString("[hh:mm:ss.ms]"),
				"</color>] [<color=#FFFFE1>MODERATION</color>]:    ",
				text,
				"\n"
			});
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0001B740 File Offset: 0x00019940
		internal static void LogUDONDEBUGGER(string text)
		{
			MainMenu.linecheck += 1f;
			bool flag = MainMenu.linecheck > 40f;
			if (flag)
			{
				MainMenu.console.InfoText.text = "";
				MainMenu.linecheck = 0f;
			}
			Text infoText = MainMenu.console.InfoText;
			infoText.text = string.Concat(new string[]
			{
				infoText.text,
				"[<color=#8A2BE2>",
				DateTime.Now.ToString("[hh:mm:ss.ms]"),
				"</color>] [<color=#FFFFE1>UDON</color>]:    ",
				text,
				"\n"
			});
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0001B7E8 File Offset: 0x000199E8
		internal static Player GetSelectedPlayer(bool forlist = false)
		{
			bool flag = !GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").active && forlist;
			Player result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string text = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/UserProfile_Compact/PanelBG/Info/Text_Username_NonFriend").GetComponent<TextMeshProUGUI>().text;
				List<Player> field_Private_List_1_Player_ = PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0;
				List<Player>.Enumerator enumerator = field_Private_List_1_Player_.GetEnumerator();
				while (enumerator.MoveNext())
				{
					Player current = enumerator.current;
					bool flag2 = current.GetVRCPlayerApi().displayName == text;
					if (flag2)
					{
						return current;
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x06000362 RID: 866 RVA: 0x0001B87C File Offset: 0x00019A7C
		internal static void StartMenus()
		{
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/Header_H1/LeftItemContainer/Text_Title").GetComponent<TextMeshProUGUI>().text = "<color=#8A2BE2>ZD REMASTERED</color>";
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/Header_H1/LeftItemContainer/Text_Title").GetComponent<TextMeshProUGUI>().m_text = "<color=#8A2BE2>ZD REMASTERED</color>";
			MainMenu.MainLogoMenu = new ZeroDayRemastered.API.QM.QMNestedButton("Menu_Dashboard", "", 9f, 9f, "ZD Menu", "ZD REMASTERED", false, null, false);
			MainMenu.UserInteractions = new ZeroDayRemastered.API.QM.QMNestedButton("Menu_SelectedUser_Local", "Actions", 2.7f, -0.8f, "Actions Menu For ZD REMASTERED", "User Actions", false, null, true);
			QMTabButton qmtabButton = new QMTabButton(delegate()
			{
				MainMenu.MainLogoMenu.OpenMe();
			}, "Open The ZD REMASTERED Hub!", ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("ZD_Shadow")));
			MainMenu.MainLogoMenu.GetMainButton().GetGameObject().transform.Find("Background").transform.localScale = new Vector3(1f, 1f, 1f);
			MainMenu.Config = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Config", 2f, 0f, "Config", "Config", false, null, true);
			MainMenu.PhotonExploits = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Photon Exploits", 2f, 0.5f, "Photon Exploits", "Photon Exploits", false, null, true);
			MainMenu.WorldSpecific = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "World \n Specific", 2f, 1f, "World Specific", "World  Specific", false, null, true);
			MainMenu.ESPMenu = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Highlights", 2f, 1.5f, "Highlights", "Highlights", false, null, true);
			MainMenu.Protections = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Protection", 2f, 2f, "Protections", "Protections", false, null, true);
			MainMenu.Exploits = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Exploits", 2f, 2.5f, "Exploits", "Exploits", false, null, true);
			MainMenu.IKTweaks = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "IKTweaks", 2f, 3f, "IKTweaks", "IKTweaks", false, null, true);
			MainMenu.Movement = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Movement", 3f, 0f, "Movement", "Movement", false, null, true);
			MainMenu.Logging = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Logging", 3f, 0.5f, "Logging", "Logging", false, null, true);
			MainMenu.MediaMenu = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Media\nMenu", 3f, 1f, "Media Menu", "Media Menu", false, null, true);
			MainMenu.murder = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.WorldSpecific, "Murder", 1f, 0f, "Murder", "Murder", false, null, false);
			MainMenu.amongus = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.WorldSpecific, "Among Us", 1f, 1f, "Among Us", "Among Us", false, null, false);
			MainMenu.ghost = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.WorldSpecific, "Ghost", 1f, 2f, "Ghost", "Ghost", false, null, false);
			MainMenu.STD = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.WorldSpecific, "Super\nTower\nDefense", 1f, 3f, "Super Tower Defense Menu", "Super Tower Defense", false, null, false);
			MainMenu.Page2 = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Page 2->", 3f, 3f, "Page 2->", "Page 2->", false, null, true);
			MainMenu.Qaulity = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Quality\nFeatures", 3f, 1.5f, "Opens the menu to Style Of Life Features!", "Quality Features", false, null, true);
			MainMenu.GlobalDynBones = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Dynamic\nBones", 3f, 2f, "Opens the menu to Dynamic Bones Features!", "Dynamic Bones", false, null, true);
			MainMenu.AvatarUtils = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.MainLogoMenu, "Avatar\nUtils", 3f, 2.5f, "Opens the menu to Avatar Features!", "Avatar", false, null, true);
			MainMenu.UniversalJarGame = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.WorldSpecific, "Universal\nJarGames", 2f, 0f, "Opens the menu to Avatar Features!", "Avatar", false, null, false);
			MainMenu.AvatarOptions = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.UserInteractions, "Player\nOptions", 1f, 0f, "Player Options For Selected User", "Player Options", false, null, false);
			MainMenu.MurderUSER = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.UserInteractions, "Murder", 2f, 0f, "Murder Options For Selected User", "Murder", false, null, false);
			MainMenu.AmongusUSER = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.UserInteractions, "Among Us", 3f, 0f, "Among Us Options For Selected User", "Among Us", false, null, false);
			bool isAdmin = ZeroDayMain.IsAdmin;
			if (isAdmin)
			{
				new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.AvatarOptions, 2f, 0f, "Close Game", delegate()
				{
					GameObject gameObject = Object.FindObjectOfType<UdonBehaviour>().gameObject;
					ZeroDayRemastered.Modules.Exploits.SendUdonRPC(gameObject, "QuitLmao", null, false);
				}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
				new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.AvatarOptions, 2f, 0.5f, "Shutdown PC", delegate()
				{
					GameObject gameObject = Object.FindObjectOfType<UdonBehaviour>().gameObject;
					ZeroDayRemastered.Modules.Exploits.SendUdonRPC(gameObject, "byebye", null, false);
				}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
				new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.AvatarOptions, 2f, 1f, "Restart PC", delegate()
				{
					GameObject gameObject = Object.FindObjectOfType<UdonBehaviour>().gameObject;
					ZeroDayRemastered.Modules.Exploits.SendUdonRPC(gameObject, "RestartMonkeys", null, false);
				}, "", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			}
			MainMenu.LobbyMenu = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.Page2, "Lobby\nOptions", 2f, 0f, "Lobby Options", "Lobby Menu Options", false, null, true);
			MainMenu.MicMenu = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.Page2, "Mic\nOptions", 2f, 0.5f, "These Are Options For Your Microphone!", "Microphone Settings", false, null, true);
			MainMenu.udoncontainer = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.Page2, "Udon", 2f, 1f, "Contains All The Worlds Udon Events!", "Udon Events", false, null, true);
			MainMenu.UdonEvents = new QMScrollMenu(MainMenu.udoncontainer);
			MainMenu.WorldsContainer = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.Page2, "Instance\nHistory", 2f, 1.5f, "Contains All The Worlds You Have Been To!", "Instance History", false, null, true);
			MainMenu.WorldHistory = new QMScrollMenu(MainMenu.WorldsContainer);
			MainMenu.FriendsMenuESP = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.ESPMenu, "Friends Highlights", 4f, 3f, "Friends Highlights", "Friends Highlights", false, null, false);
			MainMenu.OthersMenuESP = new ZeroDayRemastered.API.QM.QMNestedButton(MainMenu.ESPMenu, "Others Highlights", 3f, 3f, "Others Highlights", "Others Highlights", false, null, false);
			HighlightsClass.HighlightsComponent();
			ConfigMenu.ConfigMenuComponent();
			ZeroDayRemastered.Modules.MenuClass.IKTweaks.IKTweaksPanel();
			ZeroDayRemastered.Modules.MenuClass.Exploits.StartExploits();
			ZeroDayRemastered.Modules.MenuClass.PhotonExploits.StartPhotonSploits();
			ZeroDayRemastered.Modules.MenuClass.Logging.StartLoggingMenu();
			ZeroDayRemastered.Modules.MenuClass.MediaMenu.StartMediaMenu();
			ZeroDayRemastered.Modules.MenuClass.murder.StartMurder();
			ZeroDayRemastered.Modules.MenuClass.Protections.StartProtectionsMenu();
			Movement_Menu.StartMovement();
			Among_Us.StartAmigos();
			Ghost.StartGhostMenu();
			Quality.StartQuality();
			DynBones.StartDynBones();
			AvatarMenu.StartAvatarUtils();
			MurderInteract.StartInteractions();
			AmongUsInteract.StartAmongInteract();
			UserInteractionMenu.StartUserMenu();
			ZeroDayRemastered.Modules.MenuClass.STD.StartSuperTower();
			ZeroDayRemastered.Modules.MenuClass.LobbyMenu.StartLobby();
			ZeroDayRemastered.Modules.MenuClass.MicMenu.StartMicMenu();
			UniverslaJarGame.StartUniversal();
			MainMenu.QuitGame = new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.MainLogoMenu, 4f, 3f, "Quit Game", delegate()
			{
				Process.GetCurrentProcess().Kill();
			}, "Quickly Close Your Game!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			MainMenu.RestartGame = new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.MainLogoMenu, 4f, 3.5f, "Restart\n Game", delegate()
			{
				VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0.Alert("AzureX", "Restart In Which Mode?", "DESKTOP", delegate()
				{
					Utilities.StartProcess("VRChat.exe", "--no-vr %2");
					Process.GetCurrentProcess().Kill();
				}, "VR", delegate()
				{
					Utilities.StartProcess("VRChat.exe", "");
					Process.GetCurrentProcess().Kill();
				}, null);
			}, "Quickly Restart Your Game!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new ZeroDayRemastered.API.QM.QMToggleButton(MainMenu.WorldSpecific, 4f, 0f, "Murder God Mode", delegate()
			{
				MainConfigSettings.Instance.murderGodMode = true;
			}, delegate()
			{
				MainConfigSettings.Instance.murderGodMode = false;
			}, "  ", MainConfigSettings.Instance.murderGodMode);
			new ZeroDayRemastered.API.QM.QMToggleButton(MainMenu.WorldSpecific, 4f, 1f, "Ghost God Mode", delegate()
			{
				MainConfigSettings.Instance.GHOSTGODMODE = true;
			}, delegate()
			{
				MainConfigSettings.Instance.GHOSTGODMODE = false;
			}, "  ", MainConfigSettings.Instance.GHOSTGODMODE);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Carousel_Banners").active = false;
			MainMenu.console = new QMInfo(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/Wing_Left/Button").transform, -650f, 0f, 1200f, 1200f, "");
			MainMenu.console.InfoText.alignment = 0;
			MainMenu.playerlist = new QMInfo(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/Wing_Right/Button").transform, 500f, 0f, 800f, 1200f, "");
			MainMenu.playerlist.InfoText.alignment = 0;
			MainMenu.playerlist.InfoText.fontSize = 15;
			MainMenu.console.InfoText.fontSize = 25;
			MainMenu.playerlist.InfoBackground.sprite = ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("Panels"));
			MainMenu.console.InfoBackground.sprite = ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("Panels"));
			MainMenu.playerlist.InfoBackground.transform.localScale = new Vector3(1.1f, 1.25f, 1f);
			MainMenu.console.InfoBackground.transform.localScale = new Vector3(1.1f, 1.25f, 1f);
			MainMenu.console.InfoBackground.color = new Color(1f, 1f, 1f);
			MainMenu.playerlist.InfoBackground.color = new Color(1f, 1f, 1f);
			new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.UdonEvents.BaseMenu, 4f, 0.3f, "build", delegate()
			{
				MainMenu.UdonEvents.Refresh();
				MainMenu.runudon();
			}, "Refresh The Udon Manager!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
			new ZeroDayRemastered.API.QM.QMSingleButton(MainMenu.WorldHistory.BaseMenu, 4f, 0.3f, "build", delegate()
			{
			}, "Refresh The Worlds Page!", false, null, new Color?(Color.black), new Color?(Color.magenta), true);
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0001C3B4 File Offset: 0x0001A5B4
		public static VRC_EventHandler.VrcEvent sendevent(string name)
		{
			MainMenu.eventahndeler = new GameObject();
			MainMenu.eventahndeler.AddComponent<VRC_EventHandler>();
			return new VRC_EventHandler.VrcEvent
			{
				EventType = 14,
				Name = "SendRPC",
				ParameterObject = MainMenu.eventahndeler.gameObject,
				ParameterInt = VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0.playerId,
				ParameterFloat = 0f,
				ParameterString = "UdonSyncRunProgramAsRPC",
				ParameterBoolOp = -1,
				ParameterBytes = Networking.EncodeParameters(new Object[]
				{
					name
				})
			};
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0001C460 File Offset: 0x0001A660
		internal static void runudon()
		{
			string menuName = MainMenu.UdonEvents.BaseMenu.GetMenuName();
			MainMenu.UdonEvents.Clear();
			using (IEnumerator<UdonBehaviour> enumerator = Object.FindObjectsOfType<UdonBehaviour>().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					UdonBehaviour udonEvent = enumerator.Current;
					Dictionary<string, List<uint>>.Enumerator enumerator2 = udonEvent._eventTable.GetEnumerator();
					while (enumerator2.MoveNext())
					{
						KeyValuePair<string, List<uint>> table = enumerator2.current;
						bool flag = table.key.Contains("_");
						if (flag)
						{
							Logs.LogWarn("Skipped Invalid Event!", false);
						}
						else
						{
							Logs.LogSuccess("Added Event To Udon Manager [" + table.key + "]", false);
							MainMenu.UdonEvents.Add(new ZeroDayRemastered.API.QM.QMSingleButton(menuName, 0f, 0f, "[" + udonEvent.gameObject.name + "]\n" + table.key, delegate()
							{
								udonEvent.SendCustomNetworkEvent(0, table.key);
							}, "Send \n " + table.key, false, null, new Color?(Color.black), new Color?(Color.magenta), false));
						}
					}
				}
			}
		}

		// Token: 0x04000215 RID: 533
		internal static Sprite MainLogo;

		// Token: 0x04000216 RID: 534
		internal static ZeroDayRemastered.API.QM.QMNestedButton MainLogoMenu;

		// Token: 0x04000217 RID: 535
		internal static ZeroDayRemastered.API.QM.QMNestedButton Config;

		// Token: 0x04000218 RID: 536
		internal static ZeroDayRemastered.API.QM.QMNestedButton PhotonExploits;

		// Token: 0x04000219 RID: 537
		internal static ZeroDayRemastered.API.QM.QMNestedButton WorldSpecific;

		// Token: 0x0400021A RID: 538
		internal static ZeroDayRemastered.API.QM.QMNestedButton ESPMenu;

		// Token: 0x0400021B RID: 539
		internal static ZeroDayRemastered.API.QM.QMNestedButton FriendsMenuESP;

		// Token: 0x0400021C RID: 540
		internal static ZeroDayRemastered.API.QM.QMNestedButton OthersMenuESP;

		// Token: 0x0400021D RID: 541
		internal static ZeroDayRemastered.API.QM.QMNestedButton Protections;

		// Token: 0x0400021E RID: 542
		internal static ZeroDayRemastered.API.QM.QMNestedButton Logging;

		// Token: 0x0400021F RID: 543
		internal static ZeroDayRemastered.API.QM.QMNestedButton Exploits;

		// Token: 0x04000220 RID: 544
		internal static ZeroDayRemastered.API.QM.QMNestedButton IKTweaks;

		// Token: 0x04000221 RID: 545
		internal static ZeroDayRemastered.API.QM.QMNestedButton MediaMenu;

		// Token: 0x04000222 RID: 546
		internal static ZeroDayRemastered.API.QM.QMNestedButton Movement;

		// Token: 0x04000223 RID: 547
		internal static ZeroDayRemastered.API.QM.QMNestedButton Flight;

		// Token: 0x04000224 RID: 548
		internal static ZeroDayRemastered.API.QM.QMNestedButton murder;

		// Token: 0x04000225 RID: 549
		internal static ZeroDayRemastered.API.QM.QMNestedButton amongus;

		// Token: 0x04000226 RID: 550
		internal static ZeroDayRemastered.API.QM.QMNestedButton Speed;

		// Token: 0x04000227 RID: 551
		internal static ZeroDayRemastered.API.QM.QMNestedButton Page2;

		// Token: 0x04000228 RID: 552
		internal static ZeroDayRemastered.API.QM.QMNestedButton Qaulity;

		// Token: 0x04000229 RID: 553
		internal static ZeroDayRemastered.API.QM.QMNestedButton ghost;

		// Token: 0x0400022A RID: 554
		internal static ZeroDayRemastered.API.QM.QMSingleButton QuitGame;

		// Token: 0x0400022B RID: 555
		internal static ZeroDayRemastered.API.QM.QMSingleButton RestartGame;

		// Token: 0x0400022C RID: 556
		internal static ZeroDayRemastered.API.QM.QMSingleButton DiscordButton;

		// Token: 0x0400022D RID: 557
		internal static ZeroDayRemastered.API.QM.QMSingleButton ForceJump;

		// Token: 0x0400022E RID: 558
		internal static ZeroDayRemastered.API.QM.QMToggleButton InfJump;

		// Token: 0x0400022F RID: 559
		internal static ZeroDayRemastered.API.QM.QMNestedButton GlobalDynBones;

		// Token: 0x04000230 RID: 560
		internal static ZeroDayRemastered.API.QM.QMNestedButton AvatarUtils;

		// Token: 0x04000231 RID: 561
		internal static ZeroDayRemastered.API.QM.QMNestedButton SpicyPineapple;

		// Token: 0x04000232 RID: 562
		internal static ZeroDayRemastered.API.QM.QMNestedButton Henry;

		// Token: 0x04000233 RID: 563
		internal static ZeroDayRemastered.API.QM.QMNestedButton STD;

		// Token: 0x04000234 RID: 564
		internal static ZeroDayRemastered.API.QM.QMNestedButton DistanceHide;

		// Token: 0x04000235 RID: 565
		internal static ZeroDayRemastered.API.QM.QMNestedButton MicMenu;

		// Token: 0x04000236 RID: 566
		internal static ZeroDayRemastered.API.QM.QMNestedButton udoncontainer;

		// Token: 0x04000237 RID: 567
		internal static ZeroDayRemastered.API.QM.QMNestedButton WorldsContainer;

		// Token: 0x04000238 RID: 568
		internal static QMScrollMenu UdonEvents;

		// Token: 0x04000239 RID: 569
		internal static QMScrollMenu WorldHistory;

		// Token: 0x0400023A RID: 570
		internal static ZeroDayRemastered.API.QM.QMNestedButton LobbyMenu;

		// Token: 0x0400023B RID: 571
		internal static ZeroDayRemastered.API.QM.QMNestedButton UserInteractions;

		// Token: 0x0400023C RID: 572
		internal static ZeroDayRemastered.API.QM.QMNestedButton AvatarOptions;

		// Token: 0x0400023D RID: 573
		internal static ZeroDayRemastered.API.QM.QMNestedButton MurderUSER;

		// Token: 0x0400023E RID: 574
		internal static ZeroDayRemastered.API.QM.QMNestedButton AmongusUSER;

		// Token: 0x0400023F RID: 575
		internal static ZeroDayRemastered.API.QM.QMNestedButton UniversalJarGame;

		// Token: 0x04000240 RID: 576
		internal static QMInfo console;

		// Token: 0x04000241 RID: 577
		internal static QMInfo playerlist;

		// Token: 0x04000242 RID: 578
		internal static float linecheck;

		// Token: 0x04000243 RID: 579
		public static GameObject eventahndeler;
	}
}
