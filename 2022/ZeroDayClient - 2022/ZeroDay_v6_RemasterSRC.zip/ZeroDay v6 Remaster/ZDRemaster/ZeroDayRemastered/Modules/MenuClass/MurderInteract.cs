﻿using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.SDKBase;
using VRC.Udon;
using VRC.UI.Elements.Menus;
using ZDBase;
using ZDBase.Modules.JarGames;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000078 RID: 120
	public class MurderInteract
	{
		// Token: 0x06000375 RID: 885 RVA: 0x0001DC58 File Offset: 0x0001BE58
		public static void StartInteractions()
		{
			QMNestedButton murderUSER = MainMenu.MurderUSER;
			new QMSingleButton(murderUSER, 1f, 0f, "Assign Bystander", delegate()
			{
				VRCPlayer component = MainMenu.GetSelectedPlayer(false).gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 24; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
						component2.SendCustomNetworkEvent(0, "SyncAssignB");
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 1f, 1f, "Assign Murderer", delegate()
			{
				VRCPlayer component = VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<VRCPlayer>();
				string value = component._player.ToString();
				for (int i = 0; i < 24; i++)
				{
					string text = "Player Node (" + i.ToString() + ")";
					string text2 = "Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (" + i.ToString() + ")/Player Name Text";
					bool flag = GameObject.Find(text2).GetComponent<Text>().text.Equals(value);
					if (flag)
					{
						Logs.LogSuccess(text, true);
						UdonBehaviour component2 = GameObject.Find(text).GetComponent<UdonBehaviour>();
						component2.SendCustomNetworkEvent(0, "SyncAssignM");
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 1f, 2f, "Kill Player", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Player istargeted = Exploits.istargeted;
				foreach (Transform transform in new List<Transform>
				{
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (0)"),
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (1)"),
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (2)"),
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (3)"),
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (4)"),
					GameObject.Find("Game Logic").transform.Find("Weapons/Knife (5)")
				})
				{
					Transform transform2 = transform;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
					transform2.transform.position = Exploits.istargeted.transform.position;
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 1f, 3f, "Give Revolver", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.bringRevolver1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 2f, 0f, "Give Luger", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.bringLuger1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 2f, 1f, "Give Shotgun", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.bringShotgun1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 2f, 2f, "Give Frag", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.bringFrag1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 2f, 3f, "Give Smoke", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.BringSmoke1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 3f, 0f, "Give Knife", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.bringKnife1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 3f, 1f, "Give Trap", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				Funny.BringTrap1();
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 3f, 2f, "Gas' Em", delegate()
			{
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						Player player = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i];
						MurderInteract.SmokeEm(player);
					}
				}
			}, "", false, null, null, null, false);
			new QMSingleButton(murderUSER, 3f, 3f, "Nade' Em", delegate()
			{
				for (int i = 0; i < PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0().Length; i++)
				{
					bool flag = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i].Method_Internal_get_APIUser_0().id.Equals(GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0());
					if (flag)
					{
						Player player = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0()[i];
						MurderInteract.NadeEm(player);
					}
				}
			}, "", false, null, null, null, false);
			new QMToggleButton(murderUSER, 4f, 0f, "Annoy\nUser", delegate()
			{
				string userid = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				string text = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").gameObject.GetComponent<SelectedUserMenuQM>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_0();
				Exploits.targetuser(userid);
				MurderInteract.Cor1 = MelonCoroutines.Start(Murder.Flashes());
				Murder.FlashAnnoy = true;
			}, delegate()
			{
				MelonCoroutines.Stop(MurderInteract.Cor1);
				Murder.FlashAnnoy = false;
			}, "", false);
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0001E07C File Offset: 0x0001C27C
		public static void NadeEm(Player player)
		{
			GameObject gameObject = GameObject.Find("Frag (0)");
			bool flag = player != null;
			if (flag)
			{
				bool flag2 = Networking.GetOwner(gameObject) != Networking.LocalPlayer;
				if (flag2)
				{
					Networking.SetOwner(Networking.LocalPlayer, gameObject);
				}
				gameObject.gameObject.transform.position = new Vector3(player.gameObject.transform.position.x, player.gameObject.transform.position.y + 1f, player.gameObject.transform.position.z);
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Explode");
			}
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0001E134 File Offset: 0x0001C334
		public static void SmokeEm(Player player)
		{
			GameObject gameObject = GameObject.Find("Smoke (0)");
			bool flag = player != null;
			if (flag)
			{
				bool flag2 = Networking.GetOwner(gameObject) != Networking.LocalPlayer;
				if (flag2)
				{
					Networking.SetOwner(Networking.LocalPlayer, gameObject);
				}
				gameObject.gameObject.transform.position = new Vector3(player.gameObject.transform.position.x, player.gameObject.transform.position.y + 1f, player.gameObject.transform.position.z);
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Explode");
			}
		}

		// Token: 0x0400024B RID: 587
		public static object Cor1;
	}
}
