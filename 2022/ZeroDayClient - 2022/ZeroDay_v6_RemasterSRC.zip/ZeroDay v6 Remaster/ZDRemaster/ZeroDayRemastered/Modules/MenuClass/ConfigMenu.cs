﻿using System;
using ZDBase;
using ZeroDayRemastered.API.QM;

namespace ZeroDayRemastered.Modules.MenuClass
{
	// Token: 0x02000069 RID: 105
	public class ConfigMenu
	{
		// Token: 0x06000335 RID: 821 RVA: 0x00018EB8 File Offset: 0x000170B8
		public static void ConfigMenuComponent()
		{
			QMNestedButton config = MainMenu.Config;
			new QMSingleButton(config, 4f, 3f, "Save Config", delegate()
			{
				MainConfigSettings.Instance.SaveConfig();
				Logs.LogSuccess("Saved Config!", false);
			}, "", false, null, null, null, false);
		}
	}
}
