﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRCSDK2;
using ZDBase;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000057 RID: 87
	internal class Enderpearl : MonoBehaviour
	{
		// Token: 0x0600028B RID: 651 RVA: 0x00013A58 File Offset: 0x00011C58
		public Enderpearl(IntPtr ptr) : base(ptr)
		{
		}

		// Token: 0x0600028C RID: 652 RVA: 0x00013A63 File Offset: 0x00011C63
		public void Start()
		{
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00013A68 File Offset: 0x00011C68
		public void Update()
		{
			bool isHeld = base.gameObject.GetComponent<VRC_Pickup>().IsHeld;
			if (isHeld)
			{
				Enderpearl.Held = true;
			}
			bool held = Enderpearl.Held;
			if (held)
			{
				base.gameObject.GetComponent<Rigidbody>().useGravity = true;
				base.gameObject.GetComponent<BoxCollider>().isTrigger = false;
			}
			Enderpearl.time = 0f;
		}

		// Token: 0x0600028E RID: 654 RVA: 0x00013ACB File Offset: 0x00011CCB
		public void OnDisable()
		{
			Enderpearl.Held = false;
		}

		// Token: 0x0600028F RID: 655 RVA: 0x00013AD4 File Offset: 0x00011CD4
		public void OnEnable()
		{
			Enderpearl.Held = false;
		}

		// Token: 0x06000290 RID: 656 RVA: 0x00013AE0 File Offset: 0x00011CE0
		private void OnCollisionEnter(Collision collision)
		{
			Logs.LogSuccess("Warp!", true);
			bool flag = collision.transform.name.Contains("VRCPlayer");
			if (!flag)
			{
				foreach (ContactPoint contactPoint in collision.contacts)
				{
					bool held = Enderpearl.Held;
					if (held)
					{
						Vector3 position;
						position..ctor(contactPoint.point.x, contactPoint.point.y, contactPoint.point.z);
						Enderpearl.GetLocalPlayer().transform.position = position;
						Object.Destroy(base.gameObject);
					}
				}
			}
		}

		// Token: 0x06000291 RID: 657 RVA: 0x00013BAC File Offset: 0x00011DAC
		private void OnCollisionExit(Collision other)
		{
		}

		// Token: 0x06000292 RID: 658 RVA: 0x00013BAF File Offset: 0x00011DAF
		private void OnDestroy()
		{
			Enderpearl.Held = false;
		}

		// Token: 0x06000293 RID: 659 RVA: 0x00013BB8 File Offset: 0x00011DB8
		internal static GameObject GetLocalPlayer()
		{
			GameObject[] allGameObjects = Enderpearl.GetAllGameObjects();
			foreach (GameObject gameObject in allGameObjects)
			{
				bool flag = gameObject.name.StartsWith("VRCPlayer[Local]");
				if (flag)
				{
					return gameObject;
				}
			}
			return new GameObject();
		}

		// Token: 0x06000294 RID: 660 RVA: 0x00013C0C File Offset: 0x00011E0C
		internal static GameObject[] GetAllGameObjects()
		{
			return SceneManager.GetActiveScene().GetRootGameObjects();
		}

		// Token: 0x040001B9 RID: 441
		public static bool Held;

		// Token: 0x040001BA RID: 442
		public static float time;
	}
}
