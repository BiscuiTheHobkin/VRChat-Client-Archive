﻿using System;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;
using ZDBase;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000060 RID: 96
	internal class PickUpBoom : MonoBehaviour
	{
		// Token: 0x060002F8 RID: 760 RVA: 0x000176A0 File Offset: 0x000158A0
		public PickUpBoom(IntPtr ptr) : base(ptr)
		{
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x000176AB File Offset: 0x000158AB
		public void Start()
		{
		}

		// Token: 0x060002FA RID: 762 RVA: 0x000176B0 File Offset: 0x000158B0
		public void Update()
		{
			bool isHeld = base.gameObject.GetComponent<VRC_Pickup>().IsHeld;
			if (isHeld)
			{
				PickUpBoom.Held = true;
			}
			bool held = PickUpBoom.Held;
			if (held)
			{
				base.gameObject.GetComponent<Rigidbody>().useGravity = true;
				base.gameObject.GetComponent<BoxCollider>().isTrigger = false;
			}
			PickUpBoom.time = 0f;
		}

		// Token: 0x060002FB RID: 763 RVA: 0x00017713 File Offset: 0x00015913
		public void OnDisable()
		{
			PickUpBoom.Held = false;
		}

		// Token: 0x060002FC RID: 764 RVA: 0x0001771C File Offset: 0x0001591C
		public void OnEnable()
		{
			PickUpBoom.Held = false;
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00017728 File Offset: 0x00015928
		private void OnCollisionEnter(Collision collision)
		{
			Logs.LogSuccess("BOOM!", true);
			bool flag = collision.transform.name.Contains("VRCPlayer");
			if (!flag)
			{
				foreach (ContactPoint contactPoint in collision.contacts)
				{
					bool held = PickUpBoom.Held;
					if (held)
					{
						Vector3 vector;
						vector..ctor(contactPoint.point.x, contactPoint.point.y, contactPoint.point.z);
						PickUpBoom.bringpickupsTOaVector(vector);
						Object.Destroy(base.gameObject);
					}
				}
			}
		}

		// Token: 0x060002FE RID: 766 RVA: 0x000177E8 File Offset: 0x000159E8
		private void OnCollisionExit(Collision other)
		{
		}

		// Token: 0x060002FF RID: 767 RVA: 0x000177EB File Offset: 0x000159EB
		private void OnDestroy()
		{
			PickUpBoom.Held = false;
		}

		// Token: 0x06000300 RID: 768 RVA: 0x000177F4 File Offset: 0x000159F4
		internal static void bringpickupsTOaVector(Vector3 vector)
		{
			VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = array[i].gameObject;
				if (flag)
				{
					Networking.LocalPlayer.TakeOwnership(array[i].gameObject);
					array[i].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform = array[i].transform;
					transform.position = vector;
				}
			}
			VRC_Pickup[] array2 = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int j = 0; j < array2.Length; j++)
			{
				bool flag2 = array2[j].gameObject;
				if (flag2)
				{
					Networking.LocalPlayer.TakeOwnership(array2[j].gameObject);
					array2[j].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform2 = array2[j].transform;
					transform2.position = vector;
				}
			}
			VRCPickup[] array3 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < array3.Length; k++)
			{
				bool flag3 = array3[k].gameObject;
				if (flag3)
				{
					Networking.LocalPlayer.TakeOwnership(array3[k].gameObject);
					array3[k].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform3 = array3[k].transform;
					transform3.position = vector;
				}
			}
		}

		// Token: 0x040001E8 RID: 488
		public static bool Held;

		// Token: 0x040001E9 RID: 489
		public static float time;
	}
}
