﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Networking;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;
using ZDBase.Modules;
using ZDBase.Utils;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000058 RID: 88
	internal class Nazis
	{
		// Token: 0x06000295 RID: 661 RVA: 0x00013C30 File Offset: 0x00011E30
		public static IEnumerator getimpostor()
		{
			GameObject Playonscreen = GameObject.Find("/Game Logic").transform.Find("Game Canvas/Game In Progress/Spectate Screen/Spectate Enabled/Mask/Map Image/Spectate Map Players").gameObject;
			foreach (Player player2 in PlayerManager.Method_Public_Static_get_PlayerManager_0().field_Private_List_1_Player_0.ToArray())
			{
				try
				{
					player2.gameObject.transform.Find("Ismurdericon").gameObject.SetActive(false);
				}
				catch
				{
				}
				player2 = null;
			}
			IEnumerator<Player> enumerator = null;
			GameObject.Find("/Game Logic").transform.Find("Game Canvas/Game In Progress/Spectate Screen/Spectate Disabled/Enable Button").GetComponent<Button>().Press();
			foreach (Text plcolor in Playonscreen.GetComponentsInChildren<Text>())
			{
				bool flag = plcolor.color == new Color(0.5377358f, 0.1648718f, 0.1728278f, 1f);
				if (flag)
				{
					string text = plcolor.gameObject.GetComponentInChildren<Text>().m_Text;
					bool target = false;
					string targetplayer = "NOTHING";
					bool flag2 = targetplayer != text;
					if (flag2)
					{
						target = true;
					}
					bool flag3 = target;
					if (flag3)
					{
						foreach (Player player3 in PlayerManager.Method_Public_Static_get_PlayerManager_0().field_Private_List_1_Player_0.ToArray())
						{
							bool flag4 = player3.field_Private_APIUser_0.displayName == text;
							if (flag4)
							{
								try
								{
									string displayName = player3.field_Private_APIUser_0.displayName;
									GameObject issetact = player3.gameObject.transform.Find("Ismurdericon").gameObject;
									issetact.SetActive(true);
									issetact = null;
								}
								catch
								{
								}
							}
							else
							{
								try
								{
									player3.gameObject.transform.Find("Ismurdericon").gameObject.SetActive(false);
								}
								catch
								{
								}
							}
							yield return null;
							player3 = null;
						}
						IEnumerator<Player> enumerator3 = null;
					}
					text = null;
					targetplayer = null;
				}
				yield return null;
				plcolor = null;
			}
			IEnumerator<Text> enumerator2 = null;
			yield break;
			yield break;
		}

		// Token: 0x06000296 RID: 662 RVA: 0x00013C38 File Offset: 0x00011E38
		public static void StartItemLag(bool value)
		{
			Nazis._ItemLagEnabled = value;
			bool itemLagEnabled = Nazis._ItemLagEnabled;
			if (itemLagEnabled)
			{
				MelonLogger.Msg("Item Lag enabled!");
				MelonCoroutines.Start(Nazis.PerformItemLag());
				MelonCoroutines.Start(Nazis.InfinitePickups());
			}
			bool flag = !Nazis._ItemLagEnabled;
			if (flag)
			{
				MelonLogger.Msg("Item Lag disabled!");
				MelonCoroutines.Stop(Nazis.PerformItemLag());
				MelonCoroutines.Stop(Nazis.InfinitePickups());
			}
		}

		// Token: 0x06000297 RID: 663 RVA: 0x00013CA7 File Offset: 0x00011EA7
		public static IEnumerator PerformItemLag()
		{
			while (Nazis._ItemLagEnabled)
			{
				foreach (VRC_Pickup item in Object.FindObjectsOfType<VRC_Pickup>())
				{
					Networking.LocalPlayer.TakeOwnership(item.gameObject);
					item.transform.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.35f, 0f);
					item = null;
				}
				IEnumerator<VRC_Pickup> enumerator = null;
				yield return new WaitForSeconds(0.05f);
			}
			yield break;
		}

		// Token: 0x06000298 RID: 664 RVA: 0x00013CB0 File Offset: 0x00011EB0
		public static void murdersetup(VRCPlayer player)
		{
			bool flag = player != VRCPlayer.field_Internal_Static_VRCPlayer_0;
			if (flag)
			{
				Transform transform = Object.Instantiate<Transform>(GameObject.Find("Game Logic").transform.Find("Showdown Waypoint/waypoint quad"), player.transform);
				transform.name = "Ismurdericon";
				transform.position = player.transform.position + new Vector3(0f, 1f, 0f);
				Material material = transform.gameObject.GetComponentInChildren<MeshRenderer>().material;
				MelonCoroutines.Start(switchimageapi.loadtexts(material, "http://nocturnal-client.xyz/cl/Download/Media/Murder.png"));
				transform.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);
				transform.gameObject.SetActive(false);
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x00013D7D File Offset: 0x00011F7D
		public static IEnumerator sitonobj(object cols)
		{
			while (sitonpickups.sitonobj)
			{
				try
				{
					VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = ((Collision)cols).gameObject.transform.position + new Vector3(0f, 0.1f, 0f);
					VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = false;
				}
				catch
				{
				}
				yield return null;
			}
			VRCPlayer.field_Internal_Static_VRCPlayer_0.gameObject.GetComponent<CharacterController>().enabled = true;
			yield break;
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00013D8C File Offset: 0x00011F8C
		public static IEnumerator InfinitePickups()
		{
			while (Nazis._ItemLagEnabled)
			{
				foreach (VRC_Pickup item in Object.FindObjectsOfType<VRC_Pickup>())
				{
					Networking.LocalPlayer.TakeOwnership(item.gameObject);
					item.transform.position = new Vector3(VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position.x, 99980000f, VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position.z);
					item = null;
				}
				IEnumerator<VRC_Pickup> enumerator = null;
				yield return new WaitForSeconds(0.05f);
			}
			yield break;
		}

		// Token: 0x0600029B RID: 667 RVA: 0x00013D94 File Offset: 0x00011F94
		public static void PickupsOrbit()
		{
			Nazis.AllPickups = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToList<VRC_Pickup>();
			Nazis.AllUdonPickups = Resources.FindObjectsOfTypeAll<VRCPickup>().ToList<VRCPickup>();
			Nazis.AllSyncPickups = Resources.FindObjectsOfTypeAll<VRC_ObjectSync>().ToList<VRC_ObjectSync>();
			Nazis.AllTriggers = Resources.FindObjectsOfTypeAll<VRC_Trigger>().ToList<VRC_Trigger>();
			GameObject gameObject = new GameObject();
			float num = 0f;
			bool flag = false;
			float num2 = 0.03f;
			bool flag2 = !flag;
			if (flag2)
			{
				num += 0.01f;
				num2 += 0.005f;
				bool flag3 = num > 3f;
				if (flag3)
				{
				}
			}
			else
			{
				num -= 0.01f;
				num2 -= 0.005f;
				bool flag4 = num <= -3f;
				if (flag4)
				{
				}
			}
			gameObject.transform.position = Vector3.Lerp(gameObject.transform.position, VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0.GetBonePosition(0), Time.deltaTime * 3.3f);
			gameObject.transform.Rotate(new Vector3(0f, num, 0f));
			foreach (VRC_Pickup vrc_Pickup in Nazis.AllPickups)
			{
				VRC_Pickup vrc_Pickup2 = (VRC_Pickup)vrc_Pickup;
				Collider component = vrc_Pickup2.GetComponent<Collider>();
				bool flag5 = component != null;
				if (flag5)
				{
					component.enabled = false;
				}
				Nazis.TakeOwnershipIfNecessary(vrc_Pickup2.gameObject);
				vrc_Pickup2.transform.position = gameObject.transform.position + gameObject.transform.forward * num2;
				vrc_Pickup2.transform.LookAt(VRCPlayer.field_Internal_Static_VRCPlayer_0.transform);
				gameObject.transform.Rotate(new Vector3(0f, 360f / (float)Nazis.AllPickups.Count, 0f));
			}
			foreach (VRCPickup vrcpickup in Nazis.AllUdonPickups)
			{
				Collider component2 = vrcpickup.GetComponent<Collider>();
				bool flag6 = component2 != null;
				if (flag6)
				{
					component2.enabled = false;
				}
				Nazis.TakeOwnershipIfNecessary(vrcpickup.gameObject);
				vrcpickup.transform.position = gameObject.transform.position + gameObject.transform.forward * num2;
				gameObject.transform.Rotate(new Vector3(0f, 360f / (float)Nazis.AllUdonPickups.Count, 0f));
			}
			foreach (VRC_ObjectSync vrc_ObjectSync in Nazis.AllSyncPickups)
			{
				Collider component3 = vrc_ObjectSync.GetComponent<Collider>();
				bool flag7 = component3 != null;
				if (flag7)
				{
					component3.enabled = false;
				}
				Nazis.TakeOwnershipIfNecessary(vrc_ObjectSync.gameObject);
				vrc_ObjectSync.transform.position = gameObject.transform.position + gameObject.transform.forward * num2;
				gameObject.transform.Rotate(new Vector3(0f, 360f / (float)Nazis.AllSyncPickups.Count, 0f));
			}
			foreach (VRC_Pickup vrc_Pickup3 in Nazis.AllPickups)
			{
				VRC_Pickup vrc_Pickup4 = (VRC_Pickup)vrc_Pickup3;
				Collider component4 = vrc_Pickup4.GetComponent<Collider>();
				bool flag8 = component4 != null;
				if (flag8)
				{
					component4.enabled = true;
				}
			}
			foreach (VRCPickup vrcpickup2 in Nazis.AllUdonPickups)
			{
				Collider component5 = vrcpickup2.GetComponent<Collider>();
				bool flag9 = component5 != null;
				if (flag9)
				{
					component5.enabled = true;
				}
			}
			foreach (VRC_ObjectSync vrc_ObjectSync2 in Nazis.AllSyncPickups)
			{
				Collider component6 = vrc_ObjectSync2.GetComponent<Collider>();
				bool flag10 = component6 != null;
				if (flag10)
				{
					component6.enabled = true;
				}
			}
			Object.Destroy(gameObject);
		}

		// Token: 0x0600029C RID: 668 RVA: 0x00014260 File Offset: 0x00012460
		public static void TakeOwnershipIfNecessary(GameObject gameObject)
		{
			bool flag = Nazis.getOwnerOfGameObject(gameObject) != VRCPlayer.field_Internal_Static_VRCPlayer_0._player;
			if (flag)
			{
				Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, gameObject);
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0001429C File Offset: 0x0001249C
		public static Player getOwnerOfGameObject(GameObject gameObject)
		{
			List<Player>.Enumerator enumerator = PlayerManager.Method_Public_Static_get_PlayerManager_0().AllPlayers().GetEnumerator();
			while (enumerator.MoveNext())
			{
				Player current = enumerator.current;
				bool flag = current.field_Private_VRCPlayerApi_0.IsOwner(gameObject);
				if (flag)
				{
					return current;
				}
			}
			return null;
		}

		// Token: 0x0600029E RID: 670 RVA: 0x000142EC File Offset: 0x000124EC
		public static GameObject getplayernode(Player A)
		{
			Il2CppReferenceArray<Player> il2CppReferenceArray = GameObject.Find("PlayerManager").GetComponent<PlayerManager>().Method_Public_get_ArrayOf_Player_0();
			int num = 0;
			int num2 = 0;
			foreach (Player player in il2CppReferenceArray)
			{
				bool flag = player == A;
				if (flag)
				{
					num2 = num;
				}
				else
				{
					num++;
				}
			}
			IEnumerable<GameObject> enumerable = from G in Resources.FindObjectsOfTypeAll<GameObject>()
			where G.GetComponent<UdonBehaviour>() != null && G.GetComponent<UdonSync>() != null && G.name.StartsWith("Player Node")
			select G;
			foreach (GameObject gameObject in enumerable)
			{
				bool flag2 = gameObject.name.Contains("(" + num2.ToString() + ")");
				if (flag2)
				{
					return gameObject;
				}
			}
			return null;
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00014408 File Offset: 0x00012608
		public static bool Inworld()
		{
			return RoomManager.Method_Internal_Static_get_String_0().Contains(Nazis.WORLDID);
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x0001442C File Offset: 0x0001262C
		public static void DisableUpstairs()
		{
			bool flag = Nazis.Inworld();
			if (flag)
			{
				GameObject gameObject = GameObject.Find("Midnight Rooftop/Logic/Upstairs Toggles");
				gameObject.GetComponent<VRC_Trigger>().ExecuteCustomTrigger("DisableUpstairs");
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00014464 File Offset: 0x00012664
		public static void DisableDownstairs()
		{
			bool flag = Nazis.Inworld();
			if (flag)
			{
				GameObject gameObject = GameObject.Find("Midnight Rooftop/Logic/Downstairs Toggles");
				gameObject.GetComponent<VRC_Trigger>().ExecuteCustomTrigger("DisableDownstairs");
			}
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x0001449C File Offset: 0x0001269C
		public static void EnableUpstairs()
		{
			bool flag = Nazis.Inworld();
			if (flag)
			{
				GameObject gameObject = GameObject.Find("Midnight Rooftop/Logic/Upstairs Toggles");
				gameObject.GetComponent<VRC_Trigger>().ExecuteCustomTrigger("EnableUpstairs");
			}
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x000144D4 File Offset: 0x000126D4
		public static void EnableDownstairs()
		{
			bool flag = Nazis.Inworld();
			if (flag)
			{
				GameObject gameObject = GameObject.Find("Midnight Rooftop/Logic/Downstairs Toggles");
				gameObject.GetComponent<VRC_Trigger>().ExecuteCustomTrigger("EnableDownstairs");
			}
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x0001450C File Offset: 0x0001270C
		public static IEnumerator NaziSymbol()
		{
			VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC_Pickup>();
			List<VRC_Pickup> list = new List<VRC_Pickup>();
			VRC_Pickup[] array2 = array;
			foreach (VRC_Pickup vrc_Pickup in array2)
			{
				bool flag = !vrc_Pickup.gameObject.name.Equals("ViewFinder") && !vrc_Pickup.gameObject.name.Equals("AvatarDebugConsole");
				if (flag)
				{
					list.Add(vrc_Pickup);
				}
			}
			for (;;)
			{
				foreach (VRC_Pickup vrc_Pickup2 in list)
				{
					Networking.SetOwner(Networking.LocalPlayer, vrc_Pickup2.gameObject);
					vrc_Pickup2.transform.position = new Vector3(VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position.x + 1f, VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position.y);
				}
			}
		}

		// Token: 0x040001BB RID: 443
		public static bool _ItemLagEnabled;

		// Token: 0x040001BC RID: 444
		public static List<VRC_Pickup> AllPickups = new List<VRC_Pickup>();

		// Token: 0x040001BD RID: 445
		public static List<VRCPickup> AllUdonPickups = new List<VRCPickup>();

		// Token: 0x040001BE RID: 446
		public static List<VRC_Trigger> AllTriggers = new List<VRC_Trigger>();

		// Token: 0x040001BF RID: 447
		public static List<VRC_ObjectSync> AllSyncPickups = new List<VRC_ObjectSync>();

		// Token: 0x040001C0 RID: 448
		public static string WORLDID = "wrld_d29bb0d0-d268-42dc-8365-926f9d485505";
	}
}
