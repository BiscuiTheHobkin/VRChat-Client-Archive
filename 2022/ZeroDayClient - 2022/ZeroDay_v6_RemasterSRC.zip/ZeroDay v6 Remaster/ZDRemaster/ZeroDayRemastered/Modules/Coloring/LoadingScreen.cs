﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace ZeroDayRemastered.Modules.Coloring
{
	// Token: 0x02000080 RID: 128
	public class LoadingScreen
	{
		// Token: 0x06000399 RID: 921 RVA: 0x0001F00D File Offset: 0x0001D20D
		public static IEnumerator StartSong()
		{
			string[] array = new string[]
			{
				"//music.wixstatic.com/preview/bcf284_e90ec1b661334e69b594f31dbe2c0bc3-128.mp3"
			};
			Random rand = new Random();
			for (;;)
			{
				GameObject obj = GameObject.Find("/UserInterface");
				bool flag = obj == null;
				object obj2;
				if (flag)
				{
					obj2 = null;
				}
				else
				{
					Transform obj3 = obj.transform.Find("MenuContent/Popups/LoadingPopup/LoadingSound");
					obj2 = ((obj3 != null) ? obj3.GetComponent<AudioSource>() : null);
					obj3 = null;
				}
				bool flag2 = obj2 != null;
				if (flag2)
				{
					break;
				}
				for (;;)
				{
					GameObject obj4 = GameObject.Find("/UserInterface");
					bool flag3 = obj4 == null;
					object obj5;
					if (flag3)
					{
						obj5 = null;
					}
					else
					{
						Transform obj6 = obj4.transform.Find("LoadingBackground_TealGradient_Music/LoadingSound");
						obj5 = ((obj6 != null) ? obj6.GetComponent<AudioSource>() : null);
						obj6 = null;
					}
					bool flag4 = obj5 != null;
					if (flag4)
					{
						break;
					}
					yield return null;
					obj4 = null;
					obj5 = null;
				}
				obj = null;
				obj2 = null;
			}
			LoadingScreen._audioSource = GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>();
			LoadingScreen._audioSource1 = GameObject.Find("UserInterface/LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>();
			UnityWebRequest www = UnityWebRequest.Get("//music.wixstatic.com/preview/bcf284_56d95a9d977f4a3b89102a63973791e5-128.mp3");
			www.SendWebRequest();
			while (!www.isDone)
			{
				yield return null;
			}
			bool flag5 = !www.isHttpError;
			if (flag5)
			{
				AudioClip t = WebRequestWWW.InternalCreateAudioClipUsingDH(www.downloadHandler, www.url, false, false, 0);
				LoadingScreen._audioSource.clip = t;
				LoadingScreen._audioSource1.clip = t;
				t.name = "Ebola Sound";
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().clip = t;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().clip = t;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().maxVolume = 3000f;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().maxVolume = 3000f;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().volume = 2999f;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().volume = 2999f;
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().Play();
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().transform.Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().Play();
				t = null;
			}
			yield break;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0001F015 File Offset: 0x0001D215
		public static IEnumerator StartLoadingScreenUI()
		{
			GameObject.Find("UserInterface/LoadingBackground_TealGradient_Music/SkyCube_Baked").active = false;
			MeshRenderer Border = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN/mainFrame").GetComponent<MeshRenderer>();
			Light PointLight = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Point light").GetComponent<Light>();
			ReflectionProbe ReflectionProbe = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Reflection Probe").GetComponent<ReflectionProbe>();
			while (Border == null)
			{
				yield return null;
			}
			while (PointLight == null)
			{
				yield return null;
			}
			while (ReflectionProbe == null)
			{
				yield return null;
			}
			ReflectionProbe.mode = 1;
			ReflectionProbe.backgroundColor = new Color(1f, 1f, 1f, 0f);
			Material material = Border.material = new Material(Shader.Find("Standard"));
			Border.material.color = Color.black;
			Border.material.SetFloat("_Metallic", 1f);
			Border.material.SetFloat("_SmoothnessTextureChar", 1f);
			PointLight.color = Color.white;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/SkyCube_Baked").active = false;
			GameObject particles = Object.Instantiate<GameObject>(GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow"), GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles").transform);
			particles.GetComponent<ParticleSystem>().trails.mode = 1;
			particles.GetComponent<ParticleSystem>().emissionRate = 2f;
			GameObject SCREEN = GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN/mainFrame");
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN/mainScreen").active = false;
			Object.Destroy(GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/LoadingSceen_2_Sstatic_colliders"));
			Object.Destroy(SCREEN.GetComponent<MeshRenderer>());
			Image image = SCREEN.AddComponent<Image>();
			SCREEN.transform.localScale = new Vector3(0.01f, 0.01f, 0f);
			SCREEN.transform.localPosition = new Vector3(0f, 0f, -0.2797f);
			image.sprite = ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("ZD_Shadow"));
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/ICON").active = false;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/TITLE").active = false;
			ParticleSystem Snow = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystem>();
			ParticleSystemRenderer Snow2 = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystemRenderer>();
			while (Snow == null)
			{
				yield return null;
			}
			while (Snow2 == null)
			{
				yield return null;
			}
			Snow.gameObject.SetActive(false);
			Snow.gameObject.transform.position -= new Vector3(0f, 5f, 0f);
			ParticleSystemRenderer particleSystemRenderer = Snow2;
			Material material2 = new Material(Shader.Find("UI/Default"));
			material2.color = Color.white;
			material = material2;
			particleSystemRenderer.trailMaterial = material2;
			Material TrailMaterial = material;
			Snow2.material.color = Color.white;
			Snow.trails.enabled = true;
			Snow.trails.mode = 0;
			Snow.trails.ratio = 1f;
			Snow.trails.lifetime = 0.04f;
			Snow.trails.minVertexDistance = 0f;
			Snow.trails.worldSpace = false;
			Snow.trails.dieWithParticles = true;
			Snow.trails.textureMode = 0;
			Snow.trails.sizeAffectsWidth = true;
			Snow.trails.sizeAffectsLifetime = false;
			Snow.trails.inheritParticleColor = false;
			Snow.trails.colorOverLifetime = new Color(0.5f, 0f, 1f, 1f);
			Snow.trails.widthOverTrail = 0.1f;
			Snow.trails.colorOverTrail = new Color(1f, 0f, 1f, 1f);
			Snow.shape.scale = new Vector3(1f, 1f, 1.82f);
			Snow.main.startColor.mode = 0;
			Snow.colorOverLifetime.enabled = false;
			Snow.main.prewarm = false;
			Snow.playOnAwake = true;
			Snow.startColor = new Color(1f, 0f, 1f, 1f);
			Snow.noise.frequency = 1f;
			Snow.noise.strength = 0.5f;
			Snow.maxParticles = 250;
			Snow.gameObject.SetActive(true);
			GameObject CloseParticles = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_CloseParticles");
			while (CloseParticles == null)
			{
				yield return null;
			}
			CloseParticles.GetComponent<ParticleSystem>().startColor = new Color(1f, 0f, 1f, 1f);
			GameObject Floor = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_floor");
			while (Floor == null)
			{
				yield return null;
			}
			Floor.GetComponent<ParticleSystem>().startColor = new Color(1f, 0f, 1f, 1f);
			ParticleSystem Snow3 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystem>();
			ParticleSystemRenderer Snow4 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystemRenderer>();
			while (Snow3 == null)
			{
				yield return null;
			}
			while (Snow4 == null)
			{
				yield return null;
			}
			Snow3.gameObject.SetActive(false);
			Snow3.gameObject.transform.position -= new Vector3(0f, 5f, 0f);
			TrailMaterial.color = new Color(0.5f, 0f, 1f, 1f);
			Snow4.trailMaterial = TrailMaterial;
			Snow4.material.color = new Color(1f, 0f, 1f, 1f);
			Snow3.trails.enabled = true;
			Snow3.trails.mode = 0;
			Snow3.trails.ratio = 1f;
			Snow3.trails.lifetime = 0.04f;
			Snow3.trails.minVertexDistance = 0f;
			Snow3.trails.worldSpace = false;
			Snow3.trails.dieWithParticles = true;
			Snow3.trails.textureMode = 0;
			Snow3.trails.sizeAffectsWidth = true;
			Snow3.trails.sizeAffectsLifetime = false;
			Snow3.trails.inheritParticleColor = false;
			Snow3.trails.colorOverLifetime = new Color(0.5f, 0f, 1f, 1f);
			Snow3.trails.widthOverTrail = 0.1f;
			Snow3.trails.colorOverTrail = new Color(1f, 0f, 1f, 1f);
			Snow3.shape.scale = new Vector3(1f, 1f, 1.82f);
			Snow3.main.startColor.mode = 0;
			Snow3.colorOverLifetime.enabled = false;
			Snow3.main.prewarm = false;
			Snow3.playOnAwake = true;
			Snow3.startColor = new Color(1f, 0f, 1f, 1f);
			Snow3.noise.frequency = 1f;
			Snow3.noise.strength = 0.5f;
			Snow3.maxParticles = 250;
			Snow3.gameObject.SetActive(true);
			GameObject CloseParticles2 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_CloseParticles");
			while (CloseParticles2 == null)
			{
				yield return null;
			}
			CloseParticles2.GetComponent<ParticleSystem>().startColor = new Color(1f, 0f, 1f, 1f);
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Left").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Right").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/GoButton").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/GoButton").GetComponent<Image>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/ButtonMiddle").GetComponent<Text>().color = Color.red;
			GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements").active = false;
			yield break;
		}

		// Token: 0x0400025D RID: 605
		public static AudioSource _audioSource;

		// Token: 0x0400025E RID: 606
		public static AudioSource _audioSourcejoin;

		// Token: 0x0400025F RID: 607
		private static AudioSource _audioSource1;
	}
}
