﻿using System;
using System.Runtime.InteropServices;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x02000065 RID: 101
	internal class MainWindowFinder
	{
		// Token: 0x06000322 RID: 802
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool IsWindowVisible(IntPtr hWnd);

		// Token: 0x06000323 RID: 803
		[DllImport("user32.dll", SetLastError = true)]
		private static extern IntPtr GetWindow(IntPtr hWnd, MainWindowFinder.GetWindowType uCmd);

		// Token: 0x06000324 RID: 804
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool EnumWindows(MainWindowFinder.CallBackPtr lpEnumFunc, int lParam);

		// Token: 0x06000325 RID: 805
		[DllImport("user32.dll", SetLastError = true)]
		private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

		// Token: 0x06000326 RID: 806 RVA: 0x00018320 File Offset: 0x00016520
		public IntPtr FindMainWindow(int processId)
		{
			this._bestHandle = IntPtr.Zero;
			this._processId = processId;
			MainWindowFinder.EnumWindows(new MainWindowFinder.CallBackPtr(this.EnumWindowsThunk), this._processId);
			return this._bestHandle;
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00018364 File Offset: 0x00016564
		private bool EnumWindowsThunk(IntPtr hWnd, int processId)
		{
			uint num;
			MainWindowFinder.GetWindowThreadProcessId(hWnd, out num);
			bool flag = (ulong)num != (ulong)((long)processId) || !MainWindowFinder.IsMainWindow(hWnd);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				this._bestHandle = hWnd;
				result = false;
			}
			return result;
		}

		// Token: 0x06000328 RID: 808 RVA: 0x000183A4 File Offset: 0x000165A4
		private static bool IsMainWindow(IntPtr hWnd)
		{
			return MainWindowFinder.GetWindow(hWnd, MainWindowFinder.GetWindowType.GW_OWNER) == IntPtr.Zero && MainWindowFinder.IsWindowVisible(hWnd);
		}

		// Token: 0x04000201 RID: 513
		private IntPtr _bestHandle;

		// Token: 0x04000202 RID: 514
		private int _processId;

		// Token: 0x02000110 RID: 272
		// (Invoke) Token: 0x06000687 RID: 1671
		private delegate bool CallBackPtr(IntPtr hwnd, int lParam);

		// Token: 0x02000111 RID: 273
		private enum GetWindowType : uint
		{
			// Token: 0x040004D4 RID: 1236
			GW_HWNDFIRST,
			// Token: 0x040004D5 RID: 1237
			GW_HWNDLAST,
			// Token: 0x040004D6 RID: 1238
			GW_HWNDNEXT,
			// Token: 0x040004D7 RID: 1239
			GW_HWNDPREV,
			// Token: 0x040004D8 RID: 1240
			GW_OWNER,
			// Token: 0x040004D9 RID: 1241
			GW_CHILD,
			// Token: 0x040004DA RID: 1242
			GW_ENABLEDPOPUP
		}
	}
}
