﻿using System;
using UnityEngine;
using VRC.Udon;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x0200005B RID: 91
	internal class Movies
	{
		// Token: 0x060002B7 RID: 695 RVA: 0x000150BC File Offset: 0x000132BC
		public static void TeleportALL()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Udon");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "_TeleportToBedroomOutside1");
				}
			}
		}
	}
}
