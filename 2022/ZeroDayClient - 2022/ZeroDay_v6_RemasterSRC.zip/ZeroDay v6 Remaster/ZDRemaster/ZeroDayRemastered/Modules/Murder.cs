﻿using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x0200005A RID: 90
	internal class Murder
	{
		// Token: 0x060002AA RID: 682 RVA: 0x00014CC4 File Offset: 0x00012EC4
		public static bool Inworld()
		{
			return RoomManager.Method_Internal_Static_get_String_0().Contains(Murder.Worldid);
		}

		// Token: 0x060002AB RID: 683 RVA: 0x00014CF0 File Offset: 0x00012EF0
		internal static void ForcePickups()
		{
			foreach (VRC_Pickup vrc_Pickup in Object.FindObjectsOfType<VRC_Pickup>())
			{
				vrc_Pickup.pickupable = true;
				vrc_Pickup.DisallowTheft = false;
				vrc_Pickup.proximity = 99999f;
			}
		}

		// Token: 0x060002AC RID: 684 RVA: 0x00014D58 File Offset: 0x00012F58
		public static IEnumerable<WaitForSeconds> LoopTeleport(bool state)
		{
			foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = item.name.Contains("Game Logic");
				if (flag)
				{
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAssignM");
				}
				item = null;
			}
			IEnumerator<GameObject> enumerator = null;
			yield return new WaitForSeconds(5f);
			yield break;
		}

		// Token: 0x060002AD RID: 685 RVA: 0x00014D68 File Offset: 0x00012F68
		public static void KillAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
				}
			}
		}

		// Token: 0x060002AE RID: 686 RVA: 0x00014DDC File Offset: 0x00012FDC
		internal static IEnumerator smethod_3()
		{
			VRCPickup DetectiveGun = GameObject.Find("Game Logic").transform.Find("Weapons/Revolver").GetComponent<VRCPickup>();
			UdonBehaviour Behaviour = DetectiveGun.gameObject.GetComponent<UdonBehaviour>();
			while (Murder.Miniguntoggle)
			{
				yield return new WaitForSeconds(0.3f);
				bool flag = DetectiveGun.IsHeld && Networking.IsOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, DetectiveGun.gameObject);
				if (flag)
				{
					Behaviour.SendCustomEvent("Fire");
				}
			}
			yield break;
		}

		// Token: 0x060002AF RID: 687 RVA: 0x00014DE4 File Offset: 0x00012FE4
		public static IEnumerator KillAuraAlarm(bool state)
		{
			for (;;)
			{
				Exploits.SendUdonRPC(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
			}
			yield break;
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x00014DF4 File Offset: 0x00012FF4
		public static void BlindAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerBlinded");
				}
			}
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00014E68 File Offset: 0x00013068
		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncStartGame");
				}
			}
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00014EDC File Offset: 0x000130DC
		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
				}
			}
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00014F50 File Offset: 0x00013150
		public static void MurderWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
				}
			}
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x00014FC4 File Offset: 0x000131C4
		public static void ByStandWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
				}
			}
		}

		// Token: 0x040001C1 RID: 449
		public static bool TeleportLoopBool = false;

		// Token: 0x040001C2 RID: 450
		public static bool BlindLoopBool = false;

		// Token: 0x040001C3 RID: 451
		public static bool KillLoopBool = false;

		// Token: 0x040001C4 RID: 452
		public static List<VRC_Pickup> AllPickups = new List<VRC_Pickup>();

		// Token: 0x040001C5 RID: 453
		public static List<VRCObjectSync> AllUdonPickups = new List<VRCObjectSync>();

		// Token: 0x040001C6 RID: 454
		public static List<VRC_Trigger> AllTriggers = new List<VRC_Trigger>();

		// Token: 0x040001C7 RID: 455
		public static List<VRC_ObjectSync> AllSyncPickups = new List<VRC_ObjectSync>();

		// Token: 0x040001C8 RID: 456
		public static string Worldid = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";

		// Token: 0x040001C9 RID: 457
		public static bool AntiGunDrop = false;

		// Token: 0x040001CA RID: 458
		public static bool AntiSmokeNade = false;

		// Token: 0x040001CB RID: 459
		public static bool GodMode = false;

		// Token: 0x040001CC RID: 460
		public static bool Rock_Jump = false;

		// Token: 0x040001CD RID: 461
		public static bool Miniguntoggle = false;

		// Token: 0x040001CE RID: 462
		public static bool KillAlarm = false;
	}
}
