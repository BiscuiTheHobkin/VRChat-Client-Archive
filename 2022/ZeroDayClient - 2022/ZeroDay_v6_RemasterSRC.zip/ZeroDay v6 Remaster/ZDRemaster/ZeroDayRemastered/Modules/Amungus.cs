﻿using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x0200005C RID: 92
	internal class Amungus
	{
		// Token: 0x060002B9 RID: 697 RVA: 0x0001513C File Offset: 0x0001333C
		public static bool Inworld()
		{
			return RoomManager.Method_Internal_Static_get_String_0().Contains(Amungus.Worldid);
		}

		// Token: 0x060002BA RID: 698 RVA: 0x00015168 File Offset: 0x00013368
		public static void Sussy()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
				}
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x000152B8 File Offset: 0x000134B8
		public static void CloseDoors()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				}
			}
		}

		// Token: 0x060002BC RID: 700 RVA: 0x000153B4 File Offset: 0x000135B4
		public static IEnumerable<WaitForSeconds> CloseDoors1(bool state)
		{
			foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = item.name.Contains("Game Logic");
				if (flag)
				{
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				}
				item = null;
			}
			IEnumerator<GameObject> enumerator = null;
			yield return new WaitForSeconds(5f);
			yield break;
		}

		// Token: 0x060002BD RID: 701 RVA: 0x000153C4 File Offset: 0x000135C4
		public static void Lights()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
				}
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00015438 File Offset: 0x00013638
		public static void Comms()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
				}
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x000154AC File Offset: 0x000136AC
		public static void Reactor()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
				}
			}
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x00015520 File Offset: 0x00013720
		public static void Oxygen()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
				}
			}
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00015594 File Offset: 0x00013794
		public static IEnumerable<WaitForSeconds> VoteAll(bool state)
		{
			foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = item.name.Contains("Game Logic");
				if (flag)
				{
					item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVotedOut");
				}
				item = null;
			}
			IEnumerator<GameObject> enumerator = null;
			yield return new WaitForSeconds(1f);
			yield break;
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x000155A4 File Offset: 0x000137A4
		public static void Taskcomplet()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerCompletedTask");
				}
			}
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00015618 File Offset: 0x00013818
		public static void SkipVote()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_SkipVoting");
				}
			}
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x0001568C File Offset: 0x0001388C
		public static void Em()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "StartMeeting");
				}
			}
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00015700 File Offset: 0x00013900
		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_Start");
				}
			}
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00015774 File Offset: 0x00013974
		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
				}
			}
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x000157E8 File Offset: 0x000139E8
		public static void InpostWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
				}
			}
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x0001585C File Offset: 0x00013A5C
		public static void CrewWin()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
				}
			}
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x000158D0 File Offset: 0x00013AD0
		public static void KillAll()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				bool flag = gameObject.name.Contains("Game Logic");
				if (flag)
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
				}
			}
		}

		// Token: 0x040001CF RID: 463
		public static bool AntiVoteOut = false;

		// Token: 0x040001D0 RID: 464
		public static string Worldid = "wrld_dd036610-a246-4f52-bf01-9d7cea3405d7";
	}
}
