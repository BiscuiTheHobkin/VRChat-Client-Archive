﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace ZeroDayRemastered.Modules
{
	// Token: 0x0200005E RID: 94
	internal class Funny
	{
		// Token: 0x060002D0 RID: 720 RVA: 0x00015AF4 File Offset: 0x00013CF4
		public static void StartFlashlight()
		{
			GameObject gameObject = GameObject.CreatePrimitive(2);
			gameObject.GetComponent<Renderer>().material.color = Color.black;
			gameObject.GetComponent<Collider>().isTrigger = true;
			gameObject.transform.localScale = new Vector3(0.05f, 0.125f, 0.05f);
			gameObject.transform.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 1f, 0f);
			Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
			rigidbody.useGravity = false;
			rigidbody.isKinematic = true;
			gameObject.AddComponent<VRC_Pickup>().AutoHold = 1;
			GameObject gameObject2 = new GameObject("LightBase");
			gameObject2.transform.SetParent(gameObject.transform);
			gameObject2.transform.localPosition = Vector3.zero;
			Light light = gameObject2.AddComponent<Light>();
			light.color = Color.white;
			gameObject2.transform.Rotate(90f, 0f, 0f);
			GameObject gameObject3 = GameObject.CreatePrimitive(2);
			gameObject3.GetComponent<Renderer>().material.color = Color.black;
			gameObject3.transform.SetParent(gameObject.transform);
			gameObject3.transform.localPosition = new Vector3(0f, -0.75f, 0f);
			gameObject3.transform.localScale = new Vector3(1.5f, 0.25f, 1.5f);
			gameObject3.GetComponent<Collider>().isTrigger = true;
			light.type = 0;
			light.range = 50f;
			gameObject.transform.Rotate(90f, 0f, 0f);
			Funny.FlashlightObject = gameObject;
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00015CB7 File Offset: 0x00013EB7
		public static IEnumerator DIO()
		{
			while (Funny.DIO2)
			{
				foreach (GameObject item in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					bool flag = item.name.Contains("Game Logic");
					if (flag)
					{
						item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "PlaySong4");
						item.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "PlayContinue");
					}
					item = null;
				}
				IEnumerator<GameObject> enumerator = null;
				yield return new WaitForSeconds(0.2f);
			}
			yield break;
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00015CC0 File Offset: 0x00013EC0
		internal static GameObject[] GetAllGameObjects()
		{
			return SceneManager.GetActiveScene().GetRootGameObjects();
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00015CE4 File Offset: 0x00013EE4
		public static void targetuser(string userid)
		{
			foreach (Player player in PlayerManager.Method_Public_Static_get_PlayerManager_0().field_Private_List_1_Player_0.ToArray())
			{
				bool flag = player.field_Private_APIUser_0.id == userid;
				if (flag)
				{
				}
			}
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00015D54 File Offset: 0x00013F54
		public static void bringRevolver()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Revolver";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00015E18 File Offset: 0x00014018
		public static void bringKnife()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Knife (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00015EDC File Offset: 0x000140DC
		public static void bringLuger()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Luger (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x00015FA0 File Offset: 0x000141A0
		public static void bringFrag()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Frag (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00016064 File Offset: 0x00014264
		public static void bringShotgun()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Shotgun (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x00016128 File Offset: 0x00014328
		public static void bringRevolver1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Revolver";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002DA RID: 730 RVA: 0x000161EC File Offset: 0x000143EC
		public static void bringKnife1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Knife (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002DB RID: 731 RVA: 0x000162B0 File Offset: 0x000144B0
		public static void bringLuger1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Luger (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002DC RID: 732 RVA: 0x00016374 File Offset: 0x00014574
		public static void bringFrag1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Frag (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002DD RID: 733 RVA: 0x00016438 File Offset: 0x00014638
		public static void bringShotgun1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Shotgun (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002DE RID: 734 RVA: 0x000164FC File Offset: 0x000146FC
		public static void TPall()
		{
			while (Funny.TPallMurderamong)
			{
				Thread.Sleep(70);
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					bool flag = gameObject.name.Contains("Game Logic");
					if (flag)
					{
						gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAssingB");
					}
				}
			}
		}

		// Token: 0x060002DF RID: 735 RVA: 0x00016584 File Offset: 0x00014784
		public static void yes()
		{
			bool godMode = Murder.GodMode;
			if (godMode)
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").active = false;
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").active = false;
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").active = false;
			}
			else
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").active = true;
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").active = true;
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").active = true;
			}
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x00016608 File Offset: 0x00014808
		public static void ForcePickups(bool state)
		{
			foreach (VRC_Pickup vrc_Pickup in Object.FindObjectsOfType<VRC_Pickup>())
			{
				vrc_Pickup.pickupable = true;
				vrc_Pickup.DisallowTheft = false;
			}
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x00016664 File Offset: 0x00014864
		public static void BringSmoke()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Smoke (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x00016728 File Offset: 0x00014928
		public static void BringTrap()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Bear Trap (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x000167EC File Offset: 0x000149EC
		public static void BringSmoke1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Smoke (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x000168B0 File Offset: 0x00014AB0
		public static void BringTrap1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			bool flag = !gameObject;
			if (!flag)
			{
				for (int i = 0; i < gameObject.transform.childCount; i++)
				{
					Transform child = gameObject.transform.GetChild(i);
					bool flag2 = child && child.name == "Bear Trap (0)";
					if (flag2)
					{
						Networking.SetOwner(VRCPlayer.field_Internal_Static_VRCPlayer_0.field_Private_VRCPlayerApi_0, child.gameObject);
						child.position = Exploits.istargeted.transform.position + new Vector3(0f, 0.2f, 0f);
					}
				}
			}
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00016974 File Offset: 0x00014B74
		internal static void itemorbit()
		{
			VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = array[i].gameObject;
				if (flag)
				{
					Networking.LocalPlayer.TakeOwnership(array[i].gameObject);
					array[i].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform = array[i].transform;
					transform.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
			VRC_Pickup[] array2 = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int j = 0; j < array2.Length; j++)
			{
				bool flag2 = array2[j].gameObject;
				if (flag2)
				{
					Networking.LocalPlayer.TakeOwnership(array2[j].gameObject);
					array2[j].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform2 = array2[j].transform;
					transform2.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
			VRCPickup[] array3 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < array3.Length; k++)
			{
				bool flag3 = array3[k].gameObject;
				if (flag3)
				{
					Networking.LocalPlayer.TakeOwnership(array3[k].gameObject);
					array3[k].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform3 = array3[k].transform;
					transform3.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00016B94 File Offset: 0x00014D94
		internal static void bringpickups()
		{
			VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = array[i].gameObject;
				if (flag)
				{
					Networking.LocalPlayer.TakeOwnership(array[i].gameObject);
					array[i].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform = array[i].transform;
					transform.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
			VRC_Pickup[] array2 = Resources.FindObjectsOfTypeAll<VRC_Pickup>().ToArray<VRC_Pickup>();
			for (int j = 0; j < array2.Length; j++)
			{
				bool flag2 = array2[j].gameObject;
				if (flag2)
				{
					Networking.LocalPlayer.TakeOwnership(array2[j].gameObject);
					array2[j].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform2 = array2[j].transform;
					transform2.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
			VRCPickup[] array3 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < array3.Length; k++)
			{
				bool flag3 = array3[k].gameObject;
				if (flag3)
				{
					Networking.LocalPlayer.TakeOwnership(array3[k].gameObject);
					array3[k].transform.localPosition = new Vector3(0f, 0.3f, 0f);
					Transform transform3 = array3[k].transform;
					transform3.position = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position + new Vector3(0f, 0.1f, 0f);
				}
			}
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00016DB4 File Offset: 0x00014FB4
		internal static void RespawnPickups()
		{
			foreach (VRC_Pickup vrc_Pickup in Object.FindObjectsOfType<VRC_Pickup>())
			{
				Networking.LocalPlayer.TakeOwnership(vrc_Pickup.gameObject);
				vrc_Pickup.transform.localPosition = new Vector3(0f, -100000f, 0f);
			}
		}

		// Token: 0x040001DE RID: 478
		public static GameObject FlashlightObject;

		// Token: 0x040001DF RID: 479
		public static bool forceinteract = false;

		// Token: 0x040001E0 RID: 480
		public static List<VRC_Pickup> AllPickups = new List<VRC_Pickup>();

		// Token: 0x040001E1 RID: 481
		public static List<VRCObjectSync> AllUdonPickups = new List<VRCObjectSync>();

		// Token: 0x040001E2 RID: 482
		public static bool pickupsteal1;

		// Token: 0x040001E3 RID: 483
		public static bool PlayerESP = false;

		// Token: 0x040001E4 RID: 484
		public static bool PickupsESP = false;

		// Token: 0x040001E5 RID: 485
		public static bool TPallMurderamong = false;

		// Token: 0x040001E6 RID: 486
		public static bool forcepickups = false;

		// Token: 0x040001E7 RID: 487
		public static bool DIO2 = false;
	}
}
