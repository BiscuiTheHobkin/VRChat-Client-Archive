﻿using System;

namespace ZeroDayRemastered
{
	// Token: 0x02000052 RID: 82
	public class BuildInfo
	{
		// Token: 0x0400018A RID: 394
		public const string ModName = "ZeroDay Remastered";

		// Token: 0x0400018B RID: 395
		public const string ModVersion = "1.0.0";

		// Token: 0x0400018C RID: 396
		public const string ModAuthors = "Azuree#0001";

		// Token: 0x0400018D RID: 397
		public const string ModDownloadLink = "Discord.gg/zerodayv4";

		// Token: 0x0400018E RID: 398
		public const string GameName = "VRChat";

		// Token: 0x0400018F RID: 399
		public const string GameDeveloper = "VRChat";

		// Token: 0x04000190 RID: 400
		public const ConsoleColor ModColor = ConsoleColor.DarkMagenta;
	}
}
