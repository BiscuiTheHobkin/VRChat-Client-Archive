﻿using System;
using System.Collections.Generic;
using System.Linq;
using Il2CppSystem.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Menus;

namespace Blaze.API.QM
{
	// Token: 0x02000099 RID: 153
	public class QMNestedButton
	{
		// Token: 0x06000452 RID: 1106 RVA: 0x000234C4 File Offset: 0x000216C4
		public QMNestedButton(QMNestedButton location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			this.btnQMLoc = location.GetMenuName();
			this.Initialize(false, btnText, posX, posY, toolTipText, menuTitle);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x000234EA File Offset: 0x000216EA
		public QMNestedButton(string location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			this.btnQMLoc = location;
			this.Initialize(location.StartsWith("Menu_"), btnText, posX, posY, toolTipText, menuTitle);
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00023518 File Offset: 0x00021718
		private void Initialize(bool isRoot, string btnText, float btnPosX, float btnPosY, string btnToolTipText, string menuTitle)
		{
			this.MenuName = string.Format("{0}-Menu-{1}", "CoreX", APIStuff.RandomNumbers());
			this.MenuObject = Object.Instantiate<GameObject>(APIStuff.GetMenuPageTemplate(), APIStuff.GetMenuPageTemplate().transform.parent);
			this.MenuObject.name = this.MenuName;
			this.MenuObject.SetActive(false);
			Object.DestroyImmediate(this.MenuObject.GetComponent<LaunchPadQMMenu>());
			this.MenuPage = this.MenuObject.AddComponent<UIPage>();
			this.MenuPage.field_Public_String_0 = this.MenuName;
			this.MenuPage.field_Private_Boolean_1 = true;
			this.MenuPage.field_Protected_MenuStateController_0 = APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0();
			this.MenuPage.field_Private_List_1_UIPage_0 = new List<UIPage>();
			this.MenuPage.field_Private_List_1_UIPage_0.Add(this.MenuPage);
			APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Private_Dictionary_2_String_UIPage_0.Add(this.MenuName, this.MenuPage);
			bool isRoot2 = isRoot;
			if (isRoot2)
			{
				List<UIPage> list = APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Public_ArrayOf_UIPage_0.ToList<UIPage>();
				list.Add(this.MenuPage);
				APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().field_Public_ArrayOf_UIPage_0 = list.ToArray();
			}
			this.MenuObject.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup").DestroyChildren();
			this.MenuTitleText = this.MenuObject.GetComponentInChildren<TextMeshProUGUI>(true);
			this.MenuTitleText.text = menuTitle;
			this.IsMenuRoot = isRoot;
			this.BackButton = this.MenuObject.transform.GetChild(0).Find("LeftItemContainer/Button_Back").gameObject;
			this.BackButton.SetActive(true);
			this.BackButton.GetComponentInChildren<Button>().onClick = new Button.ButtonClickedEvent();
			this.BackButton.GetComponentInChildren<Button>().onClick.AddListener(delegate()
			{
				bool isRoot3 = isRoot;
				if (isRoot3)
				{
					bool flag2 = this.btnQMLoc.StartsWith("Menu_");
					if (flag2)
					{
						APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0("QuickMenu" + this.btnQMLoc.Remove(0, 5), false);
					}
					else
					{
						APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(this.btnQMLoc, false);
					}
				}
				else
				{
					this.MenuPage.Method_Protected_Virtual_New_Void_0();
				}
			});
			this.MenuObject.transform.GetChild(0).Find("RightItemContainer/Button_QM_Expand").gameObject.SetActive(false);
			this.MainButton = new QMSingleButton(this.btnQMLoc, btnPosX, btnPosY, btnText, new Action(this.OpenMe), btnToolTipText, null, false);
			for (int i = 0; i < this.MenuObject.transform.childCount; i++)
			{
				bool flag = this.MenuObject.transform.GetChild(i).name != "Header_H1" && this.MenuObject.transform.GetChild(i).name != "ScrollRect";
				if (flag)
				{
					Object.Destroy(this.MenuObject.transform.GetChild(i).gameObject);
				}
			}
			BlazesAPI.allQMNestedButtons.Add(this);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0002382D File Offset: 0x00021A2D
		public void OpenMe()
		{
			APIStuff.GetQuickMenuInstance().Method_Public_get_MenuStateController_0().Method_Public_Void_String_UIContext_Boolean_0(this.MenuPage.field_Public_String_0, null, false);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0002384D File Offset: 0x00021A4D
		public void CloseMe()
		{
			this.MenuPage.Method_Public_Virtual_New_Void_0();
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0002385C File Offset: 0x00021A5C
		public string GetMenuName()
		{
			return this.MenuName;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00023874 File Offset: 0x00021A74
		public GameObject GetMenuObject()
		{
			return this.MenuObject;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0002388C File Offset: 0x00021A8C
		public QMSingleButton GetMainButton()
		{
			return this.MainButton;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x000238A4 File Offset: 0x00021AA4
		public GameObject GetBackButton()
		{
			return this.BackButton;
		}

		// Token: 0x040002DD RID: 733
		protected string btnQMLoc;

		// Token: 0x040002DE RID: 734
		protected GameObject MenuObject;

		// Token: 0x040002DF RID: 735
		protected TextMeshProUGUI MenuTitleText;

		// Token: 0x040002E0 RID: 736
		protected UIPage MenuPage;

		// Token: 0x040002E1 RID: 737
		protected bool IsMenuRoot;

		// Token: 0x040002E2 RID: 738
		protected GameObject BackButton;

		// Token: 0x040002E3 RID: 739
		protected QMSingleButton MainButton;

		// Token: 0x040002E4 RID: 740
		protected string MenuName;
	}
}
