﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Blaze.API.QM
{
	// Token: 0x02000098 RID: 152
	public class QMToggleButton : QMButtonBase
	{
		// Token: 0x06000449 RID: 1097 RVA: 0x000231AD File Offset: 0x000213AD
		public QMToggleButton(QMNestedButton location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			this.btnQMLoc = location.GetMenuName();
			this.Initialize(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x000231D6 File Offset: 0x000213D6
		public QMToggleButton(string location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			this.btnQMLoc = location;
			this.Initialize(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x000231FC File Offset: 0x000213FC
		private void Initialize(float btnXLocation, float btnYLocation, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState)
		{
			this.btnType = "ToggleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/" + this.btnQMLoc).transform, true);
			this.RandomNumb = APIStuff.RandomNumbers();
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.btnTextComp = this.button.GetComponentInChildren<TextMeshProUGUI>(true);
			this.btnComp = this.button.GetComponentInChildren<Button>(true);
			this.btnComp.onClick = new Button.ButtonClickedEvent();
			this.btnComp.onClick.AddListener(new Action(this.HandleClick));
			this.btnImageComp = this.button.transform.Find("Icon").GetComponentInChildren<Image>(true);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText(btnText);
			this.SetButtonActions(onAction, offAction);
			base.SetToolTip(btnToolTip);
			base.SetActive(true);
			this.currentState = defaultState;
			Sprite sprite = this.currentState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
			this.btnImageComp.sprite = sprite;
			this.btnImageComp.overrideSprite = sprite;
			BlazesAPI.allQMToggleButtons.Add(this);
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00023388 File Offset: 0x00021588
		private void HandleClick()
		{
			this.currentState = !this.currentState;
			Sprite sprite = this.currentState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
			this.btnImageComp.sprite = sprite;
			this.btnImageComp.overrideSprite = sprite;
			bool flag = this.currentState;
			if (flag)
			{
				this.OnAction();
			}
			else
			{
				this.OffAction();
			}
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x000233FC File Offset: 0x000215FC
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00023411 File Offset: 0x00021611
		public void SetButtonActions(Action onAction, Action offAction)
		{
			this.OnAction = onAction;
			this.OffAction = offAction;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x00023424 File Offset: 0x00021624
		public void SetToggleState(bool newState, bool shouldInvoke = false)
		{
			try
			{
				Sprite sprite = newState ? APIStuff.GetOnIconSprite() : APIStuff.GetOffIconSprite();
				this.btnImageComp.sprite = sprite;
				this.btnImageComp.overrideSprite = sprite;
				if (shouldInvoke)
				{
					if (newState)
					{
						this.OnAction();
					}
					else
					{
						this.OffAction();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x000234A0 File Offset: 0x000216A0
		public void ClickMe()
		{
			this.HandleClick();
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x000234AC File Offset: 0x000216AC
		public bool GetCurrentState()
		{
			return this.currentState;
		}

		// Token: 0x040002D7 RID: 727
		protected TextMeshProUGUI btnTextComp;

		// Token: 0x040002D8 RID: 728
		protected Button btnComp;

		// Token: 0x040002D9 RID: 729
		protected Image btnImageComp;

		// Token: 0x040002DA RID: 730
		protected bool currentState;

		// Token: 0x040002DB RID: 731
		protected Action OnAction;

		// Token: 0x040002DC RID: 732
		protected Action OffAction;
	}
}
