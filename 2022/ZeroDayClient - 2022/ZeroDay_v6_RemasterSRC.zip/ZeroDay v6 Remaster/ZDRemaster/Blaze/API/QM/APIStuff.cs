﻿using System;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;

namespace Blaze.API.QM
{
	// Token: 0x0200009B RID: 155
	public static class APIStuff
	{
		// Token: 0x06000463 RID: 1123 RVA: 0x00023AC4 File Offset: 0x00021CC4
		public static QuickMenu GetQuickMenuInstance()
		{
			bool flag = APIStuff.QuickMenuInstance == null;
			if (flag)
			{
				APIStuff.QuickMenuInstance = Resources.FindObjectsOfTypeAll<QuickMenu>()[0];
			}
			return APIStuff.QuickMenuInstance;
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00023AFC File Offset: 0x00021CFC
		public static GameObject SingleButtonTemplate()
		{
			bool flag = APIStuff.SingleButtonReference == null;
			if (flag)
			{
				Il2CppArrayBase<Button> componentsInChildren = APIStuff.GetQuickMenuInstance().GetComponentsInChildren<Button>(true);
				foreach (Button button in componentsInChildren)
				{
					bool flag2 = button.name == "Button_Screenshot";
					if (flag2)
					{
						APIStuff.SingleButtonReference = button.gameObject;
					}
				}
			}
			return APIStuff.SingleButtonReference;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00023B90 File Offset: 0x00021D90
		public static GameObject GetMenuPageTemplate()
		{
			bool flag = APIStuff.MenuPageReference == null;
			if (flag)
			{
				APIStuff.MenuPageReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard").gameObject;
			}
			return APIStuff.MenuPageReference;
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x00023BDC File Offset: 0x00021DDC
		public static GameObject GetTabButtonTemplate()
		{
			bool flag = APIStuff.TabButtonReference == null;
			if (flag)
			{
				APIStuff.TabButtonReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/Page_Buttons_QM/HorizontalLayoutGroup/Page_Settings").gameObject;
			}
			return APIStuff.TabButtonReference;
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00023C28 File Offset: 0x00021E28
		public static Sprite GetOnIconSprite()
		{
			bool flag = APIStuff.OnIconReference == null;
			if (flag)
			{
				APIStuff.OnIconReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Notifications/Panel_NoNotifications_Message/Icon").GetComponent<Image>().sprite;
			}
			return APIStuff.OnIconReference;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00023C78 File Offset: 0x00021E78
		public static Sprite GetOffIconSprite()
		{
			bool flag = APIStuff.OffIconReference == null;
			if (flag)
			{
				APIStuff.OffIconReference = GameObject.Find("UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Settings/Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/Buttons_UI_Elements_Row_1/Button_ToggleQMInfo/Icon_Off").GetComponent<Image>().sprite;
			}
			return APIStuff.OffIconReference;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00023CC8 File Offset: 0x00021EC8
		public static int RandomNumbers()
		{
			return APIStuff.rnd.Next(10000, 99999);
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00023CEE File Offset: 0x00021EEE
		public static void DestroyChildren(this Transform transform)
		{
			transform.DestroyChildren(null);
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00023CFC File Offset: 0x00021EFC
		public static void DestroyChildren(this Transform transform, Func<Transform, bool> exclude)
		{
			for (int i = transform.childCount - 1; i >= 0; i--)
			{
				bool flag = exclude == null || exclude(transform.GetChild(i));
				if (flag)
				{
					Object.DestroyImmediate(transform.GetChild(i).gameObject);
				}
			}
		}

		// Token: 0x040002E8 RID: 744
		private static QuickMenu QuickMenuInstance;

		// Token: 0x040002E9 RID: 745
		private static GameObject SingleButtonReference;

		// Token: 0x040002EA RID: 746
		private static GameObject TabButtonReference;

		// Token: 0x040002EB RID: 747
		private static GameObject MenuPageReference;

		// Token: 0x040002EC RID: 748
		private static Sprite OnIconReference;

		// Token: 0x040002ED RID: 749
		private static Sprite OffIconReference;

		// Token: 0x040002EE RID: 750
		private static Random rnd = new Random();
	}
}
