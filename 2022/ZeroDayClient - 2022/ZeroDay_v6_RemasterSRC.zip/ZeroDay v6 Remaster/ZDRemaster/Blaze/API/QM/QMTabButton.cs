﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements.Controls;
using VRC.UI.Elements.Tooltips;

namespace Blaze.API.QM
{
	// Token: 0x0200009A RID: 154
	public class QMTabButton
	{
		// Token: 0x0600045B RID: 1115 RVA: 0x000238BC File Offset: 0x00021ABC
		public QMTabButton(Action btnAction, string toolTipText, Sprite img = null)
		{
			this.Initialize(btnAction, toolTipText, img);
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x000238D0 File Offset: 0x00021AD0
		private void Initialize(Action btnAction, string toolTipText, Sprite img = null)
		{
			this.button = Object.Instantiate<GameObject>(APIStuff.GetTabButtonTemplate(), APIStuff.GetTabButtonTemplate().transform.parent);
			this.button.name = string.Format("{0}-{1}", "CoreX", APIStuff.RandomNumbers());
			Object.Destroy(this.button.GetComponent<MenuTab>());
			this.badge = this.button.transform.GetChild(0).gameObject;
			this.badgeText = this.badge.GetComponentInChildren<TextMeshProUGUI>();
			this.SetAction(btnAction);
			this.SetToolTip(toolTipText);
			bool flag = img != null;
			if (flag)
			{
				this.SetImage(img);
			}
			BlazesAPI.allQMTabButtons.Add(this);
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00023994 File Offset: 0x00021B94
		public void SetImage(Sprite newImg)
		{
			this.button.transform.Find("Icon").GetComponent<Image>().sprite = newImg;
			this.button.transform.Find("Icon").GetComponent<Image>().overrideSprite = newImg;
			this.button.transform.Find("Icon").GetComponent<Image>().color = Color.white;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00023A09 File Offset: 0x00021C09
		public void SetToolTip(string newText)
		{
			this.button.GetComponent<UiTooltip>().field_Public_String_0 = newText;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00023A1E File Offset: 0x00021C1E
		public void SetIndex(int newPosition)
		{
			this.button.transform.SetSiblingIndex(newPosition);
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00023A33 File Offset: 0x00021C33
		public void SetAction(Action newAction)
		{
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			this.button.GetComponent<Button>().onClick.AddListener(newAction);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00023A68 File Offset: 0x00021C68
		public void SetActive(bool newState)
		{
			this.button.SetActive(newState);
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00023A78 File Offset: 0x00021C78
		public void SetBadge(bool showing = true, string text = "")
		{
			bool flag = this.badge == null || this.badgeText == null;
			if (!flag)
			{
				this.badge.SetActive(showing);
				this.badgeText.text = text;
			}
		}

		// Token: 0x040002E5 RID: 741
		protected GameObject button;

		// Token: 0x040002E6 RID: 742
		protected GameObject badge;

		// Token: 0x040002E7 RID: 743
		protected TextMeshProUGUI badgeText;
	}
}
