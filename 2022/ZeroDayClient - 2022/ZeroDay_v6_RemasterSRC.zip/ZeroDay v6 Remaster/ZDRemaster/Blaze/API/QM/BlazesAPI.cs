﻿using System;
using System.Collections;
using System.Collections.Generic;
using MelonLoader;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Blaze.API.QM
{
	// Token: 0x02000095 RID: 149
	public class BlazesAPI
	{
		// Token: 0x06000436 RID: 1078 RVA: 0x00022A6C File Offset: 0x00020C6C
		public static GameObject submenuq(object submenuinfo)
		{
			GameObject gameObject = GameObject.Find("/UserInterface").transform.Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/UI(Clone)/Main menu").gameObject;
			GameObject gameObject2 = Object.Instantiate<GameObject>(gameObject, gameObject.transform.parent);
			Object.Destroy(gameObject2.GetComponent<Canvas>());
			Object.Destroy(gameObject2.GetComponent<CanvasScaler>());
			Object.Destroy(gameObject2.GetComponent<GraphicRaycaster>());
			gameObject2.name = "Submenu_" + ((submenuinfo != null) ? submenuinfo.ToString() : null);
			Transform transform = gameObject2.transform.Find("Title");
			Object.Destroy(gameObject2.transform.Find("Main menu Buttons").gameObject);
			transform.gameObject.GetComponent<TextMeshProUGUI>().text = "<color=#800080ff><--</color> <color=#00ffffff>" + ((submenuinfo != null) ? submenuinfo.ToString() : null) + "</color>";
			transform.gameObject.GetComponent<TextMeshProUGUI>().fontSize = 80f;
			transform.gameObject.GetComponent<TextMeshProUGUI>().enableWordWrapping = false;
			transform.gameObject.GetComponent<TextMeshProUGUI>().alignment = 257;
			transform.transform.localScale = new Vector3(0.4f, 0.4f, 0.4f);
			transform.transform.localPosition = new Vector3(-188.7499f, 451.5022f, 0f);
			Button button = transform.gameObject.AddComponent<Button>();
			button.onClick.AddListener(delegate()
			{
				foreach (GameObject gameObject3 in BlazesAPI.menulist)
				{
					bool flag = !(gameObject3.name != "Main menu");
					if (flag)
					{
						gameObject3.SetActive(true);
						MelonCoroutines.Start(BlazesAPI.timedeltaspeed(gameObject3));
					}
					else
					{
						gameObject3.SetActive(false);
					}
				}
			});
			BlazesAPI.menulist.Add(gameObject2);
			gameObject2.SetActive(false);
			return gameObject2;
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x00022C19 File Offset: 0x00020E19
		public static IEnumerator timedeltaspeed(object gmj)
		{
			for (;;)
			{
				BlazesAPI.speed += Time.deltaTime * 7000f;
				bool flag = !(((Object)gmj).name != "Main menu");
				if (flag)
				{
					((GameObject)gmj).transform.localPosition = new Vector3(1000f - BlazesAPI.speed, 637.0978f, 0f);
				}
				else
				{
					((GameObject)gmj).transform.localPosition = new Vector3(1000f - BlazesAPI.speed, 1f, 0f);
				}
				bool flag2 = ((GameObject)gmj).transform.localPosition.x <= 0f;
				if (flag2)
				{
					break;
				}
				yield return new WaitForSeconds(0.01f);
			}
			bool flag3 = ((Object)gmj).name != "Main menu";
			if (flag3)
			{
				((GameObject)gmj).transform.localPosition = new Vector3(0f, 1f, 0f);
			}
			else
			{
				((GameObject)gmj).transform.localPosition = new Vector3(0f, 637.0978f, 0f);
			}
			BlazesAPI.speed = 1f;
			yield break;
		}

		// Token: 0x040002C8 RID: 712
		public const string Identifier = "CoreX";

		// Token: 0x040002C9 RID: 713
		public static List<GameObject> menulist;

		// Token: 0x040002CA RID: 714
		public static float speed;

		// Token: 0x040002CB RID: 715
		public static List<QMSingleButton> allQMSingleButtons = new List<QMSingleButton>();

		// Token: 0x040002CC RID: 716
		public static List<QMNestedButton> allQMNestedButtons = new List<QMNestedButton>();

		// Token: 0x040002CD RID: 717
		public static List<QMToggleButton> allQMToggleButtons = new List<QMToggleButton>();

		// Token: 0x040002CE RID: 718
		public static List<QMTabButton> allQMTabButtons = new List<QMTabButton>();
	}
}
