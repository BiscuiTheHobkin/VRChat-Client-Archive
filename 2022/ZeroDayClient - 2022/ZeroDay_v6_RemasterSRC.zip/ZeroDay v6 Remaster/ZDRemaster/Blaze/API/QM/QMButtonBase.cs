﻿using System;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements.Tooltips;

namespace Blaze.API.QM
{
	// Token: 0x02000096 RID: 150
	public class QMButtonBase
	{
		// Token: 0x0600043A RID: 1082 RVA: 0x00022C5C File Offset: 0x00020E5C
		public GameObject GetGameObject()
		{
			return this.button;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x00022C74 File Offset: 0x00020E74
		public void SetActive(bool state)
		{
			this.button.gameObject.SetActive(state);
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x00022C8C File Offset: 0x00020E8C
		public void SetLocation(float buttonXLoc, float buttonYLoc)
		{
			this.button.GetComponent<RectTransform>().anchoredPosition += Vector2.right * (232f * (buttonXLoc + (float)this.initShift[0]));
			this.button.GetComponent<RectTransform>().anchoredPosition += Vector2.down * (210f * (buttonYLoc + (float)this.initShift[1]));
			this.btnTag = string.Concat(new string[]
			{
				"(",
				buttonXLoc.ToString(),
				",",
				buttonYLoc.ToString(),
				")"
			});
			this.button.GetComponent<Button>().name = string.Format("{0}-{1}{2}-{3}", new object[]
			{
				"CoreX",
				this.btnType,
				this.btnTag,
				this.RandomNumb
			});
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00022D8E File Offset: 0x00020F8E
		public void SetToolTip(string buttonToolTip)
		{
			this.button.GetComponent<UiTooltip>().field_Public_String_0 = buttonToolTip;
			this.button.GetComponent<UiTooltip>().field_Public_String_1 = buttonToolTip;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x00022DB8 File Offset: 0x00020FB8
		public void DestroyMe()
		{
			try
			{
				Object.Destroy(this.button);
			}
			catch
			{
			}
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00022DEC File Offset: 0x00020FEC
		public virtual void SetTextColor(Color buttonTextColor, bool save = true)
		{
		}

		// Token: 0x040002CF RID: 719
		protected GameObject button;

		// Token: 0x040002D0 RID: 720
		protected string btnQMLoc;

		// Token: 0x040002D1 RID: 721
		protected string btnType;

		// Token: 0x040002D2 RID: 722
		protected string btnTag;

		// Token: 0x040002D3 RID: 723
		protected int[] initShift = new int[2];

		// Token: 0x040002D4 RID: 724
		protected Color OrigBackground;

		// Token: 0x040002D5 RID: 725
		protected Color OrigText;

		// Token: 0x040002D6 RID: 726
		protected int RandomNumb;
	}
}
