﻿using System;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Blaze.API.QM
{
	// Token: 0x02000097 RID: 151
	public class QMSingleButton : QMButtonBase
	{
		// Token: 0x06000441 RID: 1089 RVA: 0x00022E04 File Offset: 0x00021004
		public QMSingleButton(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnTextColor);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x00022EA0 File Offset: 0x000210A0
		public QMSingleButton(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnTextColor = null, bool halfBtn = false)
		{
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.InitButton(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnTextColor);
			if (halfBtn)
			{
				this.button.GetComponentInChildren<RectTransform>().sizeDelta /= new Vector2(1f, 2f);
				this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition = new Vector2(0f, 22f);
			}
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00022F38 File Offset: 0x00021138
		private protected void InitButton(float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnTextColor = null)
		{
			this.btnType = "SingleButton";
			this.button = Object.Instantiate<GameObject>(APIStuff.SingleButtonTemplate(), GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/" + this.btnQMLoc).transform, true);
			this.RandomNumb = APIStuff.RandomNumbers();
			this.button.GetComponentInChildren<TextMeshProUGUI>().fontSize = 30f;
			this.button.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 176f);
			this.button.GetComponent<RectTransform>().anchoredPosition = new Vector2(-68f, 796f);
			this.button.transform.Find("Icon").GetComponentInChildren<Image>().gameObject.SetActive(false);
			this.button.GetComponentInChildren<TextMeshProUGUI>().rectTransform.anchoredPosition += new Vector2(0f, 50f);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(btnXLocation, btnYLocation);
			this.SetButtonText(btnText);
			base.SetToolTip(btnToolTip);
			this.SetAction(btnAction);
			bool flag = btnTextColor != null;
			if (flag)
			{
				this.SetTextColor(btnTextColor.Value, true);
			}
			else
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().color;
			}
			base.SetActive(true);
			BlazesAPI.allQMSingleButtons.Add(this);
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x000230B0 File Offset: 0x000212B0
		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.transform.Find("Background").GetComponent<Image>().sprite = newImg;
			this.button.transform.Find("Background").GetComponent<Image>().overrideSprite = newImg;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x00023100 File Offset: 0x00021300
		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().text = buttonText;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00023118 File Offset: 0x00021318
		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().onClick = new Button.ButtonClickedEvent();
			bool flag = buttonAction != null;
			if (flag)
			{
				this.button.GetComponent<Button>().onClick.AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x00023160 File Offset: 0x00021360
		public void ClickMe()
		{
			this.button.GetComponent<Button>().onClick.Invoke();
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0002317C File Offset: 0x0002137C
		public override void SetTextColor(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}
	}
}
