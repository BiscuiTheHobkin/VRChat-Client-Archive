﻿using System;
using UnityEngine;

// Token: 0x02000021 RID: 33
internal class ThirdPerson
{
	// Token: 0x060000BE RID: 190 RVA: 0x00007924 File Offset: 0x00005B24
	public static void Initiliaze()
	{
		GameObject gameObject = GameObject.Find("Camera (eye)");
		bool flag = gameObject == null;
		if (flag)
		{
			gameObject = GameObject.Find("CenterEyeAnchor");
		}
		ThirdPerson.MainCamera = gameObject.GetComponent<Camera>();
		bool flag2 = ThirdPerson.CameraObject1 != null;
		if (flag2)
		{
			Object.Destroy(ThirdPerson.CameraObject1);
		}
		ThirdPerson.CameraObject1 = GameObject.CreatePrimitive(3);
		Object.Destroy(ThirdPerson.CameraObject1.GetComponent<MeshRenderer>());
		ThirdPerson.CameraObject1.transform.localScale = gameObject.transform.localScale;
		ThirdPerson.CameraObject1.AddComponent<Rigidbody>();
		ThirdPerson.CameraObject1.GetComponent<Rigidbody>().isKinematic = true;
		ThirdPerson.CameraObject1.GetComponent<Rigidbody>().useGravity = false;
		bool flag3 = ThirdPerson.CameraObject1.GetComponent<Collider>();
		if (flag3)
		{
			ThirdPerson.CameraObject1.GetComponent<Collider>().enabled = false;
		}
		ThirdPerson.CameraObject1.GetComponent<Renderer>().enabled = false;
		ThirdPerson.CameraObject1.AddComponent<Camera>();
		ThirdPerson.CameraObject1.GetComponent<Camera>().fieldOfView = gameObject.GetComponent<Camera>().fieldOfView;
		ThirdPerson.CameraObject1.GetComponent<Camera>().nearClipPlane = gameObject.GetComponent<Camera>().nearClipPlane / 4f;
		ThirdPerson.CameraObject1.transform.parent = gameObject.transform;
		ThirdPerson.CameraObject1.transform.position = gameObject.transform.position;
		ThirdPerson.CameraObject1.transform.position -= ThirdPerson.CameraObject1.transform.forward * 2f;
		ThirdPerson.CameraObject1.transform.rotation = gameObject.transform.rotation;
		ThirdPerson.CameraObject1.GetComponent<Camera>().enabled = false;
		bool flag4 = ThirdPerson.CameraObject2 != null;
		if (flag4)
		{
			Object.Destroy(ThirdPerson.CameraObject2);
		}
		ThirdPerson.CameraObject2 = GameObject.CreatePrimitive(3);
		Object.Destroy(ThirdPerson.CameraObject2.GetComponent<MeshRenderer>());
		ThirdPerson.CameraObject2.transform.localScale = gameObject.transform.localScale;
		ThirdPerson.CameraObject2.AddComponent<Rigidbody>();
		ThirdPerson.CameraObject2.GetComponent<Rigidbody>().isKinematic = true;
		ThirdPerson.CameraObject2.GetComponent<Rigidbody>().useGravity = false;
		bool flag5 = ThirdPerson.CameraObject2.GetComponent<Collider>();
		if (flag5)
		{
			ThirdPerson.CameraObject2.GetComponent<Collider>().enabled = false;
		}
		ThirdPerson.CameraObject2.GetComponent<Renderer>().enabled = false;
		ThirdPerson.CameraObject2.AddComponent<Camera>();
		ThirdPerson.CameraObject2.GetComponent<Camera>().fieldOfView = gameObject.GetComponent<Camera>().fieldOfView;
		ThirdPerson.CameraObject2.GetComponent<Camera>().nearClipPlane = gameObject.GetComponent<Camera>().nearClipPlane / 4f;
		ThirdPerson.CameraObject2.transform.parent = gameObject.transform;
		ThirdPerson.CameraObject2.transform.position = gameObject.transform.position;
		ThirdPerson.CameraObject2.transform.position += ThirdPerson.CameraObject2.transform.forward * 2f;
		ThirdPerson.CameraObject2.transform.rotation = gameObject.transform.rotation;
		ThirdPerson.CameraObject2.transform.Rotate(0f, 180f, 0f);
		ThirdPerson.CameraObject2.GetComponent<Camera>().enabled = false;
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00007C9F File Offset: 0x00005E9F
	public static void First()
	{
		ThirdPerson.Enabled = true;
		ThirdPerson.IsFirst = true;
		ThirdPerson.MainCamera.enabled = false;
		ThirdPerson.CameraObject1.GetComponent<Camera>().enabled = true;
		ThirdPerson.CameraObject2.GetComponent<Camera>().enabled = false;
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x00007CDC File Offset: 0x00005EDC
	public static void Second()
	{
		ThirdPerson.Enabled = true;
		ThirdPerson.IsSecond = true;
		ThirdPerson.MainCamera.enabled = false;
		ThirdPerson.CameraObject1.GetComponent<Camera>().enabled = false;
		ThirdPerson.CameraObject2.GetComponent<Camera>().enabled = true;
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x00007D1C File Offset: 0x00005F1C
	public static void Third()
	{
		ThirdPerson.Enabled = false;
		ThirdPerson.IsFirst = false;
		ThirdPerson.IsSecond = false;
		ThirdPerson.MainCamera.enabled = true;
		ThirdPerson.CameraObject1.GetComponent<Camera>().enabled = false;
		ThirdPerson.CameraObject2.GetComponent<Camera>().enabled = false;
	}

	// Token: 0x04000080 RID: 128
	public static GameObject CameraObject1;

	// Token: 0x04000081 RID: 129
	public static GameObject CameraObject2;

	// Token: 0x04000082 RID: 130
	public static Camera MainCamera;

	// Token: 0x04000083 RID: 131
	public static bool IsFirst = false;

	// Token: 0x04000084 RID: 132
	public static bool IsSecond = false;

	// Token: 0x04000085 RID: 133
	public static float Speed = 0.1f;

	// Token: 0x04000086 RID: 134
	public static float Time = 0.1f;

	// Token: 0x04000087 RID: 135
	public static bool Enabled = false;
}
