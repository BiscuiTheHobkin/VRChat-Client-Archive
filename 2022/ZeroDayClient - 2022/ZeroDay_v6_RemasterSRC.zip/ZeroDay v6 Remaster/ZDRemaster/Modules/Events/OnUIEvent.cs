﻿using System;

namespace Modules.Events
{
	// Token: 0x0200002D RID: 45
	internal interface OnUIEvent
	{
		// Token: 0x06000132 RID: 306
		void UI();
	}
}
