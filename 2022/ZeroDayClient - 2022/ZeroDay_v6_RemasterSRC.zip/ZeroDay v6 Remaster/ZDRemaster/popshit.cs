﻿using System;
using System.Windows.Forms;
using UnityEngine;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI;

// Token: 0x02000019 RID: 25
internal class popshit
{
	// Token: 0x06000078 RID: 120 RVA: 0x00006D1C File Offset: 0x00004F1C
	public static bool JoinWorldById(string id)
	{
		bool flag = Networking.GoToRoom(id);
		bool result;
		if (flag)
		{
			result = true;
		}
		else
		{
			string[] array = id.Split(new char[]
			{
				':'
			});
			bool flag2 = array.Length != 2;
			if (flag2)
			{
				result = false;
			}
			else
			{
				new PortalInternal().Method_Private_Void_String_String_PDM_0(array[0], array[1]);
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00006D74 File Offset: 0x00004F74
	internal static void avatarbyid(string AVI)
	{
		PageAvatar component = GameObject.Find("Screens").transform.Find("Avatar").GetComponent<PageAvatar>();
		component.field_Public_SimpleAvatarPedestal_0.field_Internal_ApiAvatar_0 = new ApiAvatar
		{
			id = AVI
		};
		component.ChangeToSelectedAvatar();
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00006DC4 File Offset: 0x00004FC4
	internal static string GetClipboard()
	{
		return Clipboard.ContainsText() ? Clipboard.GetText() : null;
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00006DE8 File Offset: 0x00004FE8
	internal static void SetClipboard(string Set)
	{
		bool flag = Clipboard.ContainsText();
		if (flag)
		{
			Clipboard.Clear();
			Clipboard.SetText(Set);
		}
		else
		{
			Clipboard.SetText(Set);
		}
	}
}
