﻿using System;

// Token: 0x02000026 RID: 38
public class WorldObjects
{
	// Token: 0x1700001C RID: 28
	// (get) Token: 0x060000D9 RID: 217 RVA: 0x00008A9D File Offset: 0x00006C9D
	// (set) Token: 0x060000DA RID: 218 RVA: 0x00008AA5 File Offset: 0x00006CA5
	public string name { get; set; }

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x060000DB RID: 219 RVA: 0x00008AAE File Offset: 0x00006CAE
	// (set) Token: 0x060000DC RID: 220 RVA: 0x00008AB6 File Offset: 0x00006CB6
	public string id { get; set; }

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x060000DD RID: 221 RVA: 0x00008ABF File Offset: 0x00006CBF
	// (set) Token: 0x060000DE RID: 222 RVA: 0x00008AC7 File Offset: 0x00006CC7
	public string Type { get; set; }

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x060000DF RID: 223 RVA: 0x00008AD0 File Offset: 0x00006CD0
	// (set) Token: 0x060000E0 RID: 224 RVA: 0x00008AD8 File Offset: 0x00006CD8
	public string TimeJoin { get; set; }

	// Token: 0x060000E1 RID: 225 RVA: 0x00008AE1 File Offset: 0x00006CE1
	public WorldObjects(string WorldName, string ID, string time)
	{
		this.name = WorldName;
		this.id = ID;
		this.TimeJoin = time;
	}
}
