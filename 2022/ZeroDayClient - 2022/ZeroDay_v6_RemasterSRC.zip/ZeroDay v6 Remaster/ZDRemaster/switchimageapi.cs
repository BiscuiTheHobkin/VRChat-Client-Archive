﻿using System;
using System.Collections;
using System.IO;
using MelonLoader;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

// Token: 0x02000020 RID: 32
internal class switchimageapi
{
	// Token: 0x060000B9 RID: 185 RVA: 0x000078C1 File Offset: 0x00005AC1
	public static IEnumerator loadtexts(Material Instance, string url)
	{
		UnityWebRequest www = UnityWebRequestTexture.GetTexture(url);
		DownloadHandler downloadHandler = www.downloadHandler;
		UnityWebRequestAsyncOperation asyncOperation = www.SendWebRequest();
		Func<bool> func = () => asyncOperation.isDone;
		yield return new WaitUntil(func);
		int num = 0;
		bool flag = num != 1;
		if (flag)
		{
			yield break;
		}
		bool flag2 = !www.isHttpError && !www.isNetworkError;
		if (flag2)
		{
			Texture2D content = DownloadHandlerTexture.GetContent(www);
			bool flag3 = content != null;
			if (flag3)
			{
				Instance.mainTexture = content;
			}
			yield break;
		}
		MelonLogger.Error("Error1 : " + www.error);
		yield break;
	}

	// Token: 0x060000BA RID: 186 RVA: 0x000078D7 File Offset: 0x00005AD7
	public static IEnumerator loadfromcacheoveridecolors(object Instance, object url)
	{
		byte[] fileData = File.ReadAllBytes((string)url);
		Texture2D tex = new Texture2D(2, 2);
		ImageConversion.LoadImage(tex, fileData);
		Sprite sprite4 = ((Image)Instance).sprite = Sprite.CreateSprite(tex, new Rect(0f, 0f, (float)tex.width, (float)tex.height), new Vector2(0f, 0f), 100000f, 1000U, 0, Vector4.zero, false);
		Sprite sprite5 = sprite4;
		((Graphic)Instance).color = Color.white;
		bool flag = sprite5 != null;
		if (flag)
		{
			((Image)Instance).sprite = sprite5;
		}
		yield return null;
		yield break;
	}

	// Token: 0x060000BB RID: 187 RVA: 0x000078ED File Offset: 0x00005AED
	public static IEnumerator loadfromcache(object Instance, object url)
	{
		byte[] fileData = File.ReadAllBytes((string)url);
		Texture2D tex = new Texture2D(2, 2);
		ImageConversion.LoadImage(tex, fileData);
		Sprite sprite4 = ((Image)Instance).sprite = Sprite.CreateSprite(tex, new Rect(0f, 0f, (float)tex.width, (float)tex.height), new Vector2(0f, 0f), 100000f, 1000U, 0, Vector4.zero, false);
		Sprite sprite5 = sprite4;
		bool flag = sprite5 != null;
		if (flag)
		{
			((Image)Instance).sprite = sprite5;
		}
		yield return null;
		yield break;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00007903 File Offset: 0x00005B03
	public static IEnumerator loadtexturefromcache(object Instance, object url)
	{
		byte[] fileData = File.ReadAllBytes((string)url);
		Texture2D tex = new Texture2D(2, 2);
		ImageConversion.LoadImage(tex, fileData);
		bool flag = tex != null;
		if (flag)
		{
			((Material)Instance).mainTexture = tex;
		}
		yield return null;
		yield break;
	}

	// Token: 0x0400007F RID: 127
	private static switchimageapi wiBfxxeSccroDZQgB0b;
}
