﻿using System;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using HarmonyLib;
using MelonLoader;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using ZDBase.Utils;

// Token: 0x0200000A RID: 10
internal class DynamicPerformances
{
	// Token: 0x0600001A RID: 26 RVA: 0x00002698 File Offset: 0x00000898
	public static void OnApplicationStart()
	{
		string str = "DSolver.dll";
		bool flag = !SolverApi.Initialize(Directory.GetCurrentDirectory() + "\\Dependencies\\" + str);
		if (flag)
		{
			DynamicPerformances.ourDynBoneCollideEntryPoint = Marshal.ReadIntPtr((IntPtr)UnhollowerUtils.GetIl2CppMethodInfoPointerFieldForGeneratedMethod(typeof(DynamicBoneCollider).GetMethod("Method_Public_Void_byref_Vector3_Single_0")).GetValue(null));
		}
		DynamicPerformances.ourDynBoneUpdateEntryPoint = Marshal.ReadIntPtr((IntPtr)UnhollowerUtils.GetIl2CppMethodInfoPointerFieldForGeneratedMethod(typeof(DynamicBone).GetMethod("Method_Private_Void_Single_Boolean_0")).GetValue(null));
		DynamicPerformances.<>c__DisplayClass7_0 CS$<>8__locals1;
		CS$<>8__locals1.isCollidePatched = false;
		bool flag2 = DynamicPerformances.enableCollisionChecks;
		if (flag2)
		{
			DynamicPerformances.<OnApplicationStart>g__PatchCollide|7_1(ref CS$<>8__locals1);
		}
		DynamicPerformances.<OnApplicationStart>g__RepatchUpdate|7_2(DynamicPerformances.enableUpdate, DynamicPerformances.updateMultiThread);
		SolverApi.SetNumThreads(Math.Max(Math.Min(DynamicPerformances.threadCount, 32), 1));
		Patches.Instance.Patch(typeof(DynamicBone).GetMethod("OnEnable"), new HarmonyMethod(typeof(DynamicPerformances), "OnEnablePrefix", null), null, null, null, null);
		Patches.Instance.Patch(typeof(DynamicBone).GetMethod("OnDisable"), new HarmonyMethod(typeof(DynamicPerformances), "OnDisablePrefix", null), null, null, null, null);
		Patches.Instance.Patch(typeof(AvatarClone).GetMethod("LateUpdate"), new HarmonyMethod(typeof(DynamicPerformances), "LateUpdatePrefix", null), null, null, null, null);
		Patches.Instance.Patch(XrefScanner.XrefScan(typeof(DynamicBone).GetMethod("OnEnable")).Single((XrefInstance it) => it.Type == 1 && it.TryResolve() != null).TryResolve(), new HarmonyMethod(typeof(DynamicPerformances), "ResetParticlesPatch", null), null, null, null, null);
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002882 File Offset: 0x00000A82
	public static void ResetParticlesPatch(DynamicBone __instance)
	{
		SolverApi.ResetParticlePositions(((Il2CppObjectBase)__instance).Pointer);
	}

	// Token: 0x0600001C RID: 28 RVA: 0x0000289C File Offset: 0x00000A9C
	public static void OnUpdate()
	{
		try
		{
			SolverApi.FlushColliderCache();
		}
		catch
		{
		}
	}

	// Token: 0x0600001D RID: 29 RVA: 0x000028D0 File Offset: 0x00000AD0
	public static void LateUpdatePrefix()
	{
		SolverApi.JoinMultithreadedJobs();
	}

	// Token: 0x0600001E RID: 30 RVA: 0x000028E0 File Offset: 0x00000AE0
	public static void OnEnablePrefix(DynamicBone __instance)
	{
		SolverApi.DynamicBoneOnEnablePatch(((Il2CppObjectBase)__instance).Pointer);
		bool flag = ((Component)__instance).gameObject.GetComponent<BoneDeleteHandler>() == null;
		if (flag)
		{
			((Component)__instance).gameObject.AddComponent<BoneDeleteHandler>();
		}
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00002931 File Offset: 0x00000B31
	public static void OnDisablePrefix(DynamicBone __instance)
	{
		SolverApi.DynamicBoneOnDisablePatch(((Il2CppObjectBase)__instance).Pointer);
	}

	// Token: 0x06000020 RID: 32 RVA: 0x0000294A File Offset: 0x00000B4A
	public static void OnStartSuffix(DynamicBone __instance)
	{
		SolverApi.DynamicBoneStartPatch(((Il2CppObjectBase)__instance).Pointer);
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002963 File Offset: 0x00000B63
	public static void OnDestroyInjected(DynamicBone __instance)
	{
		SolverApi.DynamicBoneOnDestroyPatch(((Il2CppObjectBase)__instance).Pointer);
	}

	// Token: 0x06000024 RID: 36 RVA: 0x000029B0 File Offset: 0x00000BB0
	[CompilerGenerated]
	internal unsafe static void <OnApplicationStart>g__PatchCollide|7_1(ref DynamicPerformances.<>c__DisplayClass7_0 A_0)
	{
		bool flag = !A_0.isCollidePatched;
		if (flag)
		{
			fixed (IntPtr* ptr = &DynamicPerformances.ourDynBoneCollideEntryPoint)
			{
				IntPtr* value = ptr;
				MelonUtils.NativeHookAttach((IntPtr)((void*)value), SolverApi.LibDynBoneCollideEntryPoint);
			}
			A_0.isCollidePatched = true;
		}
	}

	// Token: 0x06000025 RID: 37 RVA: 0x000029F4 File Offset: 0x00000BF4
	[CompilerGenerated]
	internal unsafe static void <OnApplicationStart>g__RepatchUpdate|7_2(bool useFast, bool useMt)
	{
		bool flag = DynamicPerformances.ourLastPatchPointer != IntPtr.Zero;
		if (flag)
		{
			fixed (IntPtr* ptr = &DynamicPerformances.ourDynBoneUpdateEntryPoint)
			{
				IntPtr* value = ptr;
				MelonUtils.NativeHookDetach((IntPtr)((void*)value), DynamicPerformances.ourLastPatchPointer);
			}
			DynamicPerformances.ourLastPatchPointer = IntPtr.Zero;
		}
		if (useFast)
		{
			DynamicPerformances.ourLastPatchPointer = (useMt ? SolverApi.LibDynBoneUpdateMultiThreaded : SolverApi.LibDynBoneUpdateSingleThreaded);
			fixed (IntPtr* ptr2 = &DynamicPerformances.ourDynBoneUpdateEntryPoint)
			{
				IntPtr* value2 = ptr2;
				MelonUtils.NativeHookAttach((IntPtr)((void*)value2), DynamicPerformances.ourLastPatchPointer);
			}
		}
		else
		{
			DynamicPerformances.ourLastPatchPointer = SolverApi.DynamicBoneUpdateNotifyPatch;
			fixed (IntPtr* ptr3 = &DynamicPerformances.ourDynBoneUpdateEntryPoint)
			{
				IntPtr* value3 = ptr3;
				MelonUtils.NativeHookAttach((IntPtr)((void*)value3), DynamicPerformances.ourLastPatchPointer);
			}
			SolverApi.SetOriginalBoneUpdateDelegate(DynamicPerformances.ourDynBoneUpdateEntryPoint);
		}
	}

	// Token: 0x04000006 RID: 6
	private static IntPtr ourDynBoneCollideEntryPoint;

	// Token: 0x04000007 RID: 7
	private static IntPtr ourDynBoneUpdateEntryPoint;

	// Token: 0x04000008 RID: 8
	private static IntPtr ourLastPatchPointer;

	// Token: 0x04000009 RID: 9
	public static bool enableCollisionChecks = true;

	// Token: 0x0400000A RID: 10
	public static bool enableUpdate = true;

	// Token: 0x0400000B RID: 11
	public static bool updateMultiThread = true;

	// Token: 0x0400000C RID: 12
	public static int threadCount = Math.Max(1, Environment.ProcessorCount / 2 - 1);
}
