﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using MelonLoader;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000014 RID: 20
internal class RotationSystem
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x0600004B RID: 75 RVA: 0x0000506F File Offset: 0x0000326F
	public static bool Rotating
	{
		get
		{
			return RotationSystem.rotating;
		}
	}

	// Token: 0x0600004C RID: 76 RVA: 0x00005076 File Offset: 0x00003276
	private RotationSystem()
	{
	}

	// Token: 0x0600004D RID: 77 RVA: 0x00005080 File Offset: 0x00003280
	internal void Pitch(float inputAmount)
	{
		bool invertPitch = RotationSystem.InvertPitch;
		if (invertPitch)
		{
			inputAmount *= -1f;
		}
		RotationSystem.playerTransform.RotateAround(RotationSystem.originTransform.position, RotationSystem.usePlayerAxis ? RotationSystem.playerTransform.right : RotationSystem.originTransform.right, inputAmount * RotationSystem.RotationSpeed * Time.deltaTime * (RotationSystem.holdingShift ? 2f : 1f));
	}

	// Token: 0x0600004E RID: 78 RVA: 0x000050F8 File Offset: 0x000032F8
	internal void Yaw(float inputAmount)
	{
		RotationSystem.playerTransform.RotateAround(RotationSystem.originTransform.position, RotationSystem.usePlayerAxis ? RotationSystem.playerTransform.up : RotationSystem.originTransform.up, inputAmount * RotationSystem.RotationSpeed * Time.deltaTime * (RotationSystem.holdingShift ? 2f : 1f));
	}

	// Token: 0x0600004F RID: 79 RVA: 0x0000515C File Offset: 0x0000335C
	internal void Roll(float inputAmount)
	{
		RotationSystem.playerTransform.RotateAround(RotationSystem.originTransform.position, RotationSystem.usePlayerAxis ? (-RotationSystem.playerTransform.forward) : (-RotationSystem.originTransform.forward), inputAmount * RotationSystem.RotationSpeed * Time.deltaTime * (RotationSystem.holdingShift ? 2f : 1f));
	}

	// Token: 0x06000050 RID: 80 RVA: 0x000051C8 File Offset: 0x000033C8
	internal void Fly(float inputAmount, Vector3 direction)
	{
		RotationSystem.playerTransform.position += direction * inputAmount * RotationSystem.FlyingSpeed * (RotationSystem.holdingShift ? 2f : 1f) * Time.deltaTime;
	}

	// Token: 0x06000051 RID: 81 RVA: 0x00005220 File Offset: 0x00003420
	internal static bool Initialize()
	{
		bool flag = RotationSystem.Instance != null;
		bool result;
		if (flag)
		{
			result = false;
		}
		else
		{
			RotationSystem.Instance = new RotationSystem();
			MelonCoroutines.Start(RotationSystem.GrabMainCamera());
			result = true;
		}
		return result;
	}

	// Token: 0x06000052 RID: 82 RVA: 0x00005259 File Offset: 0x00003459
	private static IEnumerator GrabMainCamera()
	{
		while (!RotationSystem.cameraTransform)
		{
			yield return new WaitForSeconds(1f);
			foreach (Object component in Object.FindObjectsOfType(Il2CppType.Of<Transform>()))
			{
				yield return null;
				Transform transform;
				bool flag = !((transform = component.TryCast<Transform>()) == null) && transform.name.Equals("Camera (eye)", StringComparison.OrdinalIgnoreCase);
				if (flag)
				{
					RotationSystem.cameraTransform = transform;
					break;
				}
				transform = null;
				component = null;
			}
			IEnumerator<Object> enumerator = null;
		}
		yield break;
		yield break;
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000053 RID: 83 RVA: 0x00005264 File Offset: 0x00003464
	internal static RotationSystem.AlignTrackingToPlayerDelegate GetAlignTrackingToPlayerDelegate
	{
		get
		{
			bool flag = RotationSystem.alignTrackingToPlayerMethod == null;
			if (flag)
			{
				RotationSystem.alignTrackingToPlayerMethod = typeof(VRCPlayer).GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public).First((MethodInfo m) => m.ReturnType == typeof(void) && m.GetParameters().Length == 0 && m.Name.IndexOf("PDM", StringComparison.OrdinalIgnoreCase) == -1 && m.XRefScanForMethod("get_Transform", null) && m.XRefScanForMethod(null, "VRCTrackingManager") && m.XRefScanForMethod(null, "InputStateController"));
			}
			return (RotationSystem.AlignTrackingToPlayerDelegate)Delegate.CreateDelegate(typeof(RotationSystem.AlignTrackingToPlayerDelegate), VRCPlayer.field_Internal_Static_VRCPlayer_0, RotationSystem.alignTrackingToPlayerMethod);
		}
	}

	// Token: 0x06000054 RID: 84 RVA: 0x000052DC File Offset: 0x000034DC
	internal static void Toggle()
	{
		bool flag = !RotationSystem.rotating;
		if (flag)
		{
			RotationSystem.originalGravity = Physics.gravity;
		}
		try
		{
			bool flag2 = RotationSystem.playerTransform == null;
			if (flag2)
			{
				RotationSystem.playerTransform = VRCPlayer.field_Internal_Static_VRCPlayer_0.transform;
			}
			RotationSystem.rotating = !RotationSystem.rotating;
			bool flag3 = RotationSystem.rotating;
			if (flag3)
			{
				RotationSystem.originalGravity = Physics.gravity;
				Physics.gravity = Vector3.zero;
				bool flag4 = RotationSystem.alignTrackingToPlayer == null;
				if (flag4)
				{
					RotationSystem.alignTrackingToPlayer = RotationSystem.GetAlignTrackingToPlayerDelegate;
				}
			}
			else
			{
				Quaternion localRotation = RotationSystem.playerTransform.localRotation;
				RotationSystem.playerTransform.localRotation = new Quaternion(0f, localRotation.y, 0f, localRotation.w);
				Physics.gravity = RotationSystem.originalGravity;
			}
		}
		catch (Exception ex)
		{
			string str = "Error Toggling: ";
			Exception ex2 = ex;
			MelonLogger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			RotationSystem.rotating = false;
		}
		RotationSystem.UpdateSettings();
		bool flag5 = !RotationSystem.rotating;
		if (flag5)
		{
			Physics.gravity = RotationSystem.originalGravity;
			RotationSystem.AlignTrackingToPlayerDelegate alignTrackingToPlayerDelegate = RotationSystem.alignTrackingToPlayer;
			if (alignTrackingToPlayerDelegate != null)
			{
				alignTrackingToPlayerDelegate();
			}
		}
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00005418 File Offset: 0x00003618
	private static void GrabOriginTransform()
	{
		RotationSystem.<>c__DisplayClass31_0 CS$<>8__locals1;
		CS$<>8__locals1.isHumanoid = false;
		switch (RotationSystem.RotationOrigin)
		{
		case RotationSystem.RotationOriginEnum.Hips:
			RotationSystem.<GrabOriginTransform>g__GetHumanBoneTransform|31_0(0, ref CS$<>8__locals1);
			break;
		case RotationSystem.RotationOriginEnum.ViewPoint:
			RotationSystem.originTransform = RotationSystem.cameraTransform;
			break;
		case RotationSystem.RotationOriginEnum.RightHand:
			RotationSystem.<GrabOriginTransform>g__GetHumanBoneTransform|31_0(18, ref CS$<>8__locals1);
			break;
		case RotationSystem.RotationOriginEnum.LeftHand:
			RotationSystem.<GrabOriginTransform>g__GetHumanBoneTransform|31_0(17, ref CS$<>8__locals1);
			break;
		default:
			throw new ArgumentOutOfRangeException("RotationOrigin", RotationSystem.RotationOrigin, "What kind of dinkleberry thing did you do to my enum?");
		}
		RotationSystem.usePlayerAxis = (RotationSystem.RotationOrigin == RotationSystem.RotationOriginEnum.Hips & CS$<>8__locals1.isHumanoid);
	}

	// Token: 0x06000056 RID: 86 RVA: 0x000054AC File Offset: 0x000036AC
	internal static void UpdateSettings()
	{
		bool flag = !RotationSystem.playerTransform;
		if (!flag)
		{
			CharacterController component = RotationSystem.playerTransform.GetComponent<CharacterController>();
			bool flag2 = component;
			if (flag2)
			{
				bool flag3 = RotationSystem.rotating;
				if (flag3)
				{
					RotationSystem.GrabOriginTransform();
				}
				bool flag4 = RotationSystem.rotating && !XRDevice.isPresent;
				if (flag4)
				{
					component.enabled = !RotationSystem.NoClipFlying;
				}
				else
				{
					bool flag5 = !component.enabled;
					if (flag5)
					{
						component.enabled = true;
					}
				}
				bool isPresent = XRDevice.isPresent;
				if (isPresent)
				{
					VRCPlayer field_Internal_Static_VRCPlayer_ = VRCPlayer.field_Internal_Static_VRCPlayer_0;
					if (field_Internal_Static_VRCPlayer_ != null)
					{
						field_Internal_Static_VRCPlayer_.Method_Public_get_VRCPlayerApi_0().Immobilize(RotationSystem.rotating);
					}
				}
			}
		}
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00005565 File Offset: 0x00003765
	internal void OnLeftWorld()
	{
		RotationSystem.rotating = false;
		RotationSystem.playerTransform = null;
		RotationSystem.alignTrackingToPlayer = null;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x0000559C File Offset: 0x0000379C
	[CompilerGenerated]
	internal static void <GrabOriginTransform>g__GetHumanBoneTransform|31_0(HumanBodyBones bone, ref RotationSystem.<>c__DisplayClass31_0 A_1)
	{
		VRCPlayer field_Internal_Static_VRCPlayer_ = VRCPlayer.field_Internal_Static_VRCPlayer_0;
		object obj;
		if (field_Internal_Static_VRCPlayer_ == null)
		{
			obj = null;
		}
		else
		{
			VRCAvatarManager vrcavatarManager = field_Internal_Static_VRCPlayer_.Method_Public_get_VRCAvatarManager_0();
			obj = ((vrcavatarManager != null) ? vrcavatarManager.Method_Public_get_GameObject_0() : null);
		}
		object obj2 = obj;
		Animator animator = (obj2 != null) ? obj2.GetComponent<Animator>() : null;
		bool flag = animator != null;
		if (flag)
		{
			A_1.isHumanoid = animator.isHuman;
			RotationSystem.originTransform = (A_1.isHumanoid ? animator.GetBoneTransform(bone) : RotationSystem.cameraTransform);
		}
		else
		{
			RotationSystem.originTransform = RotationSystem.cameraTransform;
		}
	}

	// Token: 0x04000033 RID: 51
	internal static float FlyingSpeed = 5f;

	// Token: 0x04000034 RID: 52
	internal static float RotationSpeed = 180f;

	// Token: 0x04000035 RID: 53
	internal static bool NoClipFlying = true;

	// Token: 0x04000036 RID: 54
	internal static RotationSystem Instance;

	// Token: 0x04000037 RID: 55
	internal static IControlScheme CurrentControlScheme;

	// Token: 0x04000038 RID: 56
	internal static RotationSystem.RotationOriginEnum RotationOrigin = RotationSystem.RotationOriginEnum.Hips;

	// Token: 0x04000039 RID: 57
	internal static bool InvertPitch;

	// Token: 0x0400003A RID: 58
	internal static bool LockRotation;

	// Token: 0x0400003B RID: 59
	private static RotationSystem.AlignTrackingToPlayerDelegate alignTrackingToPlayer;

	// Token: 0x0400003C RID: 60
	private static Transform cameraTransform;

	// Token: 0x0400003D RID: 61
	private static Vector3 originalGravity;

	// Token: 0x0400003E RID: 62
	private static Transform playerTransform;

	// Token: 0x0400003F RID: 63
	private static Transform originTransform;

	// Token: 0x04000040 RID: 64
	public static bool rotating;

	// Token: 0x04000041 RID: 65
	public static bool usePlayerAxis;

	// Token: 0x04000042 RID: 66
	public static bool holdingShift;

	// Token: 0x04000043 RID: 67
	private static MethodInfo alignTrackingToPlayerMethod;

	// Token: 0x020000B8 RID: 184
	internal enum RotationOriginEnum
	{
		// Token: 0x04000357 RID: 855
		Hips,
		// Token: 0x04000358 RID: 856
		ViewPoint,
		// Token: 0x04000359 RID: 857
		RightHand,
		// Token: 0x0400035A RID: 858
		LeftHand
	}

	// Token: 0x020000B9 RID: 185
	// (Invoke) Token: 0x060004B3 RID: 1203
	internal delegate void AlignTrackingToPlayerDelegate();
}
