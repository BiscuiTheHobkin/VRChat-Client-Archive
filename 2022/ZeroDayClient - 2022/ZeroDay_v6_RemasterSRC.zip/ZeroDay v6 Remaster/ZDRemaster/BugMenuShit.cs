﻿using System;
using Il2CppSystem;
using UnityEngine;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI;
using ZDBase;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered.Modules;

// Token: 0x0200001D RID: 29
internal static class BugMenuShit
{
	// Token: 0x06000086 RID: 134 RVA: 0x00007010 File Offset: 0x00005210
	public static APIUser SelectedAPIUser(this VRCUiManager Instance)
	{
		return Instance.GetMenuContent().GetComponentInChildren<PageUserInfo>().GetUser();
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00007034 File Offset: 0x00005234
	internal static APIUser GetUser(this PageUserInfo Instance)
	{
		return Instance.field_Private_APIUser_0;
	}

	// Token: 0x06000088 RID: 136 RVA: 0x0000704C File Offset: 0x0000524C
	internal static GameObject GetMenuContent(this VRCUiManager Instance)
	{
		return Instance.field_Public_GameObject_0;
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00007064 File Offset: 0x00005264
	internal static void MenuBullshit()
	{
		Logs.LogWarn("Starting Social Extras...", false);
		MenuButton menuButton = new MenuButton(MenuButton.MenuType.UserInfo, MenuButton.MenuButtonType.PlaylistButton, "Portal to", 1605f, -550f, delegate()
		{
			string location_k__BackingField = BugMenuShit.GetId.GetComponent<PageUserInfo>().field_Private_APIUser_0._location_k__BackingField;
			bool flag = location_k__BackingField.StartsWith("wrld");
			if (flag)
			{
				BugMenuShit.PortalToInstanceByID(location_k__BackingField);
			}
		});
		MenuButton menuButton2 = new MenuButton(MenuButton.MenuType.UserInfo, MenuButton.MenuButtonType.PlaylistButton, "Teleport", 1605f, -470f, delegate()
		{
			APIUser apiuser = VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().SelectedAPIUser();
			string id = apiuser.id;
			GameObject gameObject = null;
			GameObject[] allGameObjects = Funny.GetAllGameObjects();
			foreach (GameObject gameObject2 in allGameObjects)
			{
				bool flag = gameObject2.name.StartsWith("VRCPlayer[Remote]") && gameObject2.GetComponent<VRCPlayer>().UserID() == id;
				if (flag)
				{
					gameObject = gameObject2;
				}
			}
			bool flag2 = gameObject != null;
			if (flag2)
			{
				VRCPlayer.field_Internal_Static_VRCPlayer_0.transform.position = gameObject.transform.position;
			}
		});
		MenuButton menuButton3 = new MenuButton(MenuButton.MenuType.UserInfo, MenuButton.MenuButtonType.PlaylistButton, "Copy W-Id", 1605f, -630f, delegate()
		{
			string location_k__BackingField = BugMenuShit.GetId.GetComponent<PageUserInfo>().field_Private_APIUser_0._location_k__BackingField;
			popshit.SetClipboard(location_k__BackingField);
			Logs.Log("Player is in : \n" + location_k__BackingField, false);
		});
		new MenuButton(BugMenuShit.WorldsPage.transform, MenuButton.MenuButtonType.PlaylistButton, "Copy W-Id", 1310f, -700f, delegate()
		{
			string id = BugMenuShit.WorldsPage.GetComponent<PageWorldInfo>().field_Public_ApiWorldInstance_0.id;
			popshit.SetClipboard(id);
			Logs.Log("World Id is : \n" + id, false);
		}, 110f, 37f);
		Logs.LogSuccess("Finished Social Extras.", false);
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00007178 File Offset: 0x00005378
	internal static void PortalToInstanceByID(string id)
	{
		VRCPlayer field_Internal_Static_VRCPlayer_ = VRCPlayer.field_Internal_Static_VRCPlayer_0;
		string[] array = id.Split(new char[]
		{
			':'
		});
		GameObject gameObject = Networking.Instantiate(0, "Portals/PortalInternalDynamic", field_Internal_Static_VRCPlayer_.transform.position + field_Internal_Static_VRCPlayer_.transform.forward * 1.5f, field_Internal_Static_VRCPlayer_.transform.rotation);
		string text = array[0];
		string text2 = array[1];
		int value = 0;
		RPC.Destination destination = 7;
		GameObject gameObject2 = gameObject;
		string text3 = "ConfigurePortal";
		Object[] array2 = new Object[3];
		array2[0] = text;
		array2[1] = text2;
		int num = 2;
		Int32 @int = default(Int32);
		@int.m_value = value;
		array2[num] = @int.BoxIl2CppObject();
		Networking.RPC(destination, gameObject2, text3, array2);
	}

	// Token: 0x04000057 RID: 87
	internal static GameObject MenuPed = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/MainRoot/MainModel");

	// Token: 0x04000058 RID: 88
	internal static GameObject GetId = GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo");

	// Token: 0x04000059 RID: 89
	internal static GameObject WorldsPage = GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo");

	// Token: 0x0400005A RID: 90
	internal static GameObject buttonfortem = GameObject.Find("/UserInterface/MenuContent/Popups/InputPopup/ButtonLeft");

	// Token: 0x0400005B RID: 91
	internal static GameObject popupinput = GameObject.Find("/UserInterface/MenuContent/Popups/InputPopup/InputField");

	// Token: 0x0400005C RID: 92
	internal static GameObject OnlinPP = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/OnlineFriends/Button");

	// Token: 0x0400005D RID: 93
	internal static GameObject Flist1 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup1/Button");

	// Token: 0x0400005E RID: 94
	internal static GameObject Flist2 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup2/Button");

	// Token: 0x0400005F RID: 95
	internal static GameObject Flist3 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup3/Button");

	// Token: 0x04000060 RID: 96
	internal static UiUserList FlistUIuserlist1 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup1").GetComponent<UiUserList>();

	// Token: 0x04000061 RID: 97
	internal static UiUserList FlistUIuserlist2 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup2").GetComponent<UiUserList>();

	// Token: 0x04000062 RID: 98
	internal static UiUserList FlistUIuserlist3 = GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View/Viewport/Content/FriendsGroup3").GetComponent<UiUserList>();

	// Token: 0x04000063 RID: 99
	public static string ClipboardShit;
}
