﻿using System;
using System.Collections;
using Il2CppSystem;
using MelonLoader;
using Microsoft.Win32;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;
using ZDBase;

// Token: 0x02000012 RID: 18
public class InfoBarClock
{
	// Token: 0x06000042 RID: 66 RVA: 0x00004D20 File Offset: 0x00002F20
	public static void Initialize()
	{
		InfoBarClock.amPm = Registry.GetValue("HKEY_CURRENT_USER\\Control Panel\\International", "sShortTime", "x").ToString().Contains("h");
		Transform transform = QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0().transform.Find("QuickMenu_NewElements/_InfoBar/PingText");
		bool flag = transform != null;
		if (flag)
		{
			Transform transform2 = new GameObject("AZURAVRCClock", new Type[]
			{
				Il2CppType.Of<RectTransform>(),
				Il2CppType.Of<Text>()
			}).transform;
			transform2.SetParent(transform.parent, false);
			transform2.SetSiblingIndex(transform.GetSiblingIndex() + 1);
			InfoBarClock.clockText = transform2.GetComponent<Text>();
			RectTransform component = transform2.GetComponent<RectTransform>();
			component.localScale = transform.localScale;
			component.anchorMin = transform.GetComponent<RectTransform>().anchorMin;
			component.anchorMax = transform.GetComponent<RectTransform>().anchorMax;
			component.anchoredPosition = transform.GetComponent<RectTransform>().anchoredPosition;
			component.sizeDelta = new Vector2(2000f, 92f);
			component.pivot = transform.GetComponent<RectTransform>().pivot;
			Vector3 localPosition = transform.localPosition;
			localPosition.x -= transform.GetComponent<RectTransform>().sizeDelta.x * 0.5f;
			localPosition.x += 687.5f;
			localPosition.y += -90f;
			component.localPosition = localPosition;
			InfoBarClock.clockText.text = "(00:00:00) NA:NA PM";
			InfoBarClock.clockText.color = transform.GetComponent<Text>().color;
			InfoBarClock.clockText.font = transform.GetComponent<Text>().font;
			InfoBarClock.clockText.fontSize = transform.GetComponent<Text>().fontSize - 8;
			InfoBarClock.clockText.fontStyle = transform.GetComponent<Text>().fontStyle;
			InfoBarClock.clockText.gameObject.SetActive(true);
			MelonCoroutines.Start(InfoBarClock.Loop());
		}
		else
		{
			Logs.LogError("QuickMenu/ShortcutMenu/PingText is null", false);
		}
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00004F28 File Offset: 0x00003128
	private static IEnumerator Loop()
	{
		while (InfoBarClock.Enabled)
		{
			yield return new WaitForSecondsRealtime(1f);
			InfoBarClock.instanceTime += 1U;
			InfoBarClock.clockText.gameObject.SetActive(true);
			string text = DateTime.Now.ToString(InfoBarClock.amPm ? "hh:mm tt" : "HH:mm");
			string text2 = "00:00:00";
			bool flag = RoomManager.field_Internal_Static_ApiWorld_0 != null;
			if (flag)
			{
				TimeSpan timeSpan = TimeSpan.FromSeconds(InfoBarClock.instanceTime);
				text2 = string.Format("{0:D2}:{1:D2}:{2:D2}", timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
				timeSpan = default(TimeSpan);
			}
			InfoBarClock.clockText.text = "(" + text2 + ") " + text;
			text = null;
			text2 = null;
		}
		yield break;
	}

	// Token: 0x0400002C RID: 44
	private static bool Enabled = true;

	// Token: 0x0400002D RID: 45
	public static Text clockText;

	// Token: 0x0400002E RID: 46
	public static uint instanceTime = 0U;

	// Token: 0x0400002F RID: 47
	private static bool amPm = false;
}
