﻿using System;
using System.Collections.Generic;
using BestHTTP;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using TMPro;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.Udon;

// Token: 0x0200002C RID: 44
internal static class PlayerWrapper
{
	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000122 RID: 290 RVA: 0x0000A202 File Offset: 0x00008402
	internal static Transform ShortcutMenuTransform
	{
		get
		{
			return GameObject.Find("/UserInterface/QuickMenu/ShortcutMenu").transform;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000123 RID: 291 RVA: 0x0000A213 File Offset: 0x00008413
	internal static Transform UserInteractMenuTransform
	{
		get
		{
			return GameObject.Find("/UserInterface/QuickMenu/UserInteractMenu").transform;
		}
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000A224 File Offset: 0x00008424
	internal static Player GetSelectedPlayer()
	{
		string text = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/UserProfile_Compact/PanelBG/Info/Text_Username_NonFriend").GetComponent<TextMeshProUGUI>().text;
		List<Player> field_Private_List_1_Player_ = PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0;
		List<Player>.Enumerator enumerator = field_Private_List_1_Player_.GetEnumerator();
		while (enumerator.MoveNext())
		{
			Player current = enumerator.current;
			bool flag = current.Method_Public_get_VRCPlayerApi_0().displayName == text;
			if (flag)
			{
				return current;
			}
		}
		return null;
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000A294 File Offset: 0x00008494
	internal static void QueueHudMessage(string Text, Color? color)
	{
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().field_Public_Text_0.color = color.Value;
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().field_Private_List_1_String_0.Add("[Late Night]\n" + Text);
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000A2C9 File Offset: 0x000084C9
	internal static void CloseAllUI()
	{
		PlayerWrapper.CloseAllSubMenus();
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().Method_Public_Virtual_New_Void_Boolean_0(false);
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000A2F0 File Offset: 0x000084F0
	internal static void CloseAllSubMenus()
	{
		PlayerWrapper.ShortcutMenuTransform.gameObject.SetActive(false);
		PlayerWrapper.UserInteractMenuTransform.gameObject.SetActive(false);
		for (int i = 0; i < PlayerWrapper.SubMenus.Count; i++)
		{
			GameObject gameObject = PlayerWrapper.SubMenus[i];
			gameObject.SetActive(false);
		}
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000A350 File Offset: 0x00008550
	public static List<Player> PlayerList()
	{
		return PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0;
	}

	// Token: 0x06000129 RID: 297 RVA: 0x0000A36C File Offset: 0x0000856C
	public static void SendFriendRequest(string userid)
	{
		string url = "user/" + userid + "/friendRequest";
		ApiDictContainer apiDictContainer = new ApiDictContainer(new string[0]);
		ApiDictContainer callback = apiDictContainer;
		PlayerWrapper.SendRequest(url, 2, callback, true, null);
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000A3AC File Offset: 0x000085AC
	internal static void SendRequest(string url, HTTPMethods method, ApiContainer callback = null, bool noCache = true, Dictionary<string, Object> parms = null)
	{
		API.SendRequest(url, method, callback, parms, true, noCache, 3600f, 2, null, null);
	}

	// Token: 0x0600012B RID: 299 RVA: 0x0000A3D0 File Offset: 0x000085D0
	internal static PlayerManager get_player_manager()
	{
		return PlayerManager.Method_Public_Static_get_PlayerManager_0();
	}

	// Token: 0x0600012C RID: 300 RVA: 0x0000A3E8 File Offset: 0x000085E8
	internal static void PickupESP(bool state)
	{
		Il2CppArrayBase<VRC_Pickup> il2CppArrayBase = Resources.FindObjectsOfTypeAll<VRC_Pickup>();
		foreach (VRC_Pickup vrc_Pickup in il2CppArrayBase)
		{
			bool flag = !(vrc_Pickup == null) && !(vrc_Pickup.gameObject == null) && vrc_Pickup.gameObject.active && vrc_Pickup.enabled && vrc_Pickup.pickupable && !vrc_Pickup.name.Contains("ViewFinder") && !(HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null);
			if (flag)
			{
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vrc_Pickup.GetComponentInChildren<MeshRenderer>(), state);
			}
		}
	}

	// Token: 0x0600012D RID: 301 RVA: 0x0000A4A4 File Offset: 0x000086A4
	internal static void TriggerESP(bool state)
	{
		Il2CppArrayBase<VRC_Trigger> il2CppArrayBase = Resources.FindObjectsOfTypeAll<VRC_Trigger>();
		Il2CppArrayBase<UdonBehaviour> il2CppArrayBase2 = Resources.FindObjectsOfTypeAll<UdonBehaviour>();
		foreach (VRC_Trigger vrc_Trigger in il2CppArrayBase)
		{
			bool flag = !(vrc_Trigger == null) && !(vrc_Trigger.gameObject == null) && vrc_Trigger.gameObject.active && !vrc_Trigger.name.Contains("ViewFinder") && !(HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null);
			if (flag)
			{
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vrc_Trigger.GetComponentInChildren<MeshRenderer>(), state);
			}
		}
		foreach (UdonBehaviour udonBehaviour in il2CppArrayBase2)
		{
			bool flag2 = !(udonBehaviour == null) && !(udonBehaviour.gameObject == null) && udonBehaviour.gameObject.active && !udonBehaviour.name.Contains("ViewFinder") && !(HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null) && udonBehaviour._eventTable.System_Collections_IDictionary_Contains("_interact");
			if (flag2)
			{
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(udonBehaviour.GetComponentInChildren<MeshRenderer>(), state);
			}
		}
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000A614 File Offset: 0x00008814
	internal static void esp_player(bool state)
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("Player");
		for (int i = 0; i < array.Length; i++)
		{
			bool flag = !(array[i] == null) && array[i].transform.Find("SelectRegion");
			if (flag)
			{
				Renderer component = array[i].transform.Find("SelectRegion").GetComponent<Renderer>();
				bool flag2 = !(component == null);
				if (flag2)
				{
					PlayerWrapper.toggle_outline(component, state);
				}
			}
		}
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000A6A8 File Offset: 0x000088A8
	internal static void toggle_outline(Renderer render, bool state)
	{
		bool flag = !(HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null);
		if (flag)
		{
			HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(render, state);
		}
	}

	// Token: 0x06000130 RID: 304 RVA: 0x0000A6D8 File Offset: 0x000088D8
	internal static VRCPlayer GetCurrentPlayer()
	{
		return VRCPlayer.field_Internal_Static_VRCPlayer_0;
	}

	// Token: 0x040000AC RID: 172
	internal static List<string> friend_list = new List<string>();

	// Token: 0x040000AD RID: 173
	private static List<GameObject> SubMenus = new List<GameObject>();
}
