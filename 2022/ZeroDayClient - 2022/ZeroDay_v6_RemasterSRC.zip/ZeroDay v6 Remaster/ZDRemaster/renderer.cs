﻿using System;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using VRC.Core;

// Token: 0x0200001B RID: 27
public static class renderer
{
	// Token: 0x0600007E RID: 126 RVA: 0x00006EA4 File Offset: 0x000050A4
	public static void StartRenderElementsCoroutine(this UiVRCList instance, List<ApiAvatar> avatarList, int offset = 0, bool endOfPickers = true, VRCUiContentButton contentHeaderElement = null)
	{
		bool flag = !instance.gameObject.activeInHierarchy || !instance.isActiveAndEnabled || instance.isOffScreen || !instance.enabled;
		bool flag2 = !flag;
		if (flag2)
		{
			bool flag3 = instance.scrollRect != null;
			bool flag4 = flag3;
			if (flag4)
			{
				instance.scrollRect.normalizedPosition = new Vector2(0f, 0f);
			}
			instance.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(avatarList, offset, endOfPickers, contentHeaderElement);
		}
	}
}
