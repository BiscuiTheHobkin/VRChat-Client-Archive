﻿using System;
using Il2CppSystem.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC.Core;

// Token: 0x0200001E RID: 30
public class VRCList
{
	// Token: 0x17000008 RID: 8
	// (get) Token: 0x0600008C RID: 140 RVA: 0x000072FC File Offset: 0x000054FC
	// (set) Token: 0x0600008D RID: 141 RVA: 0x00007370 File Offset: 0x00005570
	public bool Expanded
	{
		get
		{
			bool flag = this.UiVRCList.field_Private_Int32_0 == this.UiVRCList.expandedCount && this.UiVRCList.field_Protected_Boolean_0;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = this.UiVRCList.field_Private_Int32_0 == this.UiVRCList.collapsedCount && !this.UiVRCList.field_Protected_Boolean_0;
				result = (flag2 && false);
			}
			return result;
		}
		set
		{
			bool flag = this.Expanded != value;
			if (flag)
			{
				this.UiVRCList.ToggleExtend();
			}
		}
	}

	// Token: 0x0600008E RID: 142 RVA: 0x0000739C File Offset: 0x0000559C
	public VRCList(Transform parent, string name, int Position = 0)
	{
		this.GameObject = Object.Instantiate<GameObject>(VRCList.PublicAvatarList.gameObject, parent);
		this.UiAvatarList = this.GameObject.GetComponent<UiAvatarList>();
		this.UiAvatarList.field_Public_Category_0 = 4;
		this.UiAvatarList.field_Protected_Dictionary_2_Int32_List_1_ApiModel_0.Clear();
		this.UiAvatarList.field_Private_Dictionary_2_String_ApiAvatar_0.Clear();
		this.UiAvatarList.disabledOnMobile = false;
		this.UiAvatarList.disabledOnPc = false;
		this.UiVRCList = this.GameObject.GetComponent<UiVRCList>();
		this.Text = this.GameObject.transform.Find("Button").GetComponentInChildren<Text>();
		this.GameObject.transform.SetSiblingIndex(Position);
		this.UiVRCList.clearUnseenListOnCollapse = false;
		this.UiVRCList.usePagination = false;
		this.UiVRCList.hideElementsWhenContracted = false;
		this.UiVRCList.hideWhenEmpty = false;
		this.UiVRCList.startExpanded = false;
		this.GameObject.SetActive(true);
		this.GameObject.name = name;
		this.Text.text = name;
		this.RenderElement(new List<ApiAvatar>());
		this.UiAvatarList.field_Protected_Dictionary_2_Int32_List_1_ApiModel_0.Clear();
		this.UiAvatarList.field_Private_Dictionary_2_String_ApiAvatar_0.Clear();
		this.RenderElement(new List<ApiAvatar>());
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00007508 File Offset: 0x00005708
	public void RenderElement(List<ApiAvatar> AvatarList)
	{
		bool flag = !this.UiVRCList.gameObject.activeInHierarchy || !this.UiVRCList.isActiveAndEnabled || this.UiVRCList.isOffScreen || !this.UiVRCList.enabled;
		bool flag2 = !flag;
		if (flag2)
		{
			bool flag3 = this.UiVRCList.scrollRect != null;
			bool flag4 = flag3;
			if (flag4)
			{
				this.UiVRCList.scrollRect.normalizedPosition = new Vector2(0f, 0f);
			}
			this.UiVRCList.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(AvatarList, 0, true, null);
		}
	}

	// Token: 0x04000064 RID: 100
	public GameObject GameObject;

	// Token: 0x04000065 RID: 101
	public UiVRCList UiVRCList;

	// Token: 0x04000066 RID: 102
	private UiAvatarList UiAvatarList;

	// Token: 0x04000067 RID: 103
	public Text Text;

	// Token: 0x04000068 RID: 104
	public static GameObject PublicAvatarList = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Public Avatar List");
}
