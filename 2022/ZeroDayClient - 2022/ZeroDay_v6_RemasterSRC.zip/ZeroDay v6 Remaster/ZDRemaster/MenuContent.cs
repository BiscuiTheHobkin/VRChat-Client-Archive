﻿using System;
using UnityEngine;

// Token: 0x02000018 RID: 24
public class MenuContent
{
	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000072 RID: 114 RVA: 0x00006CD7 File Offset: 0x00004ED7
	public static GameObject Backdrop
	{
		get
		{
			return GameObject.Find("/UserInterface/MenuContent/Backdrop");
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000073 RID: 115 RVA: 0x00006CE3 File Offset: 0x00004EE3
	public static GameObject Screens
	{
		get
		{
			return GameObject.Find("/UserInterface/MenuContent/Screens");
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000074 RID: 116 RVA: 0x00006CEF File Offset: 0x00004EEF
	public static GameObject Popups
	{
		get
		{
			return GameObject.Find("/UserInterface/MenuContent/Popups");
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000075 RID: 117 RVA: 0x00006CFB File Offset: 0x00004EFB
	public static GameObject Interupts
	{
		get
		{
			return GameObject.Find("/UserInterface/MenuContent/Interupts");
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000076 RID: 118 RVA: 0x00006D07 File Offset: 0x00004F07
	public static GameObject MenuAudio
	{
		get
		{
			return GameObject.Find("/UserInterface/MenuContent/MenuAudio");
		}
	}

	// Token: 0x020000C0 RID: 192
	public class Screens_1
	{
		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x00024B5A File Offset: 0x00022D5A
		public static GameObject Announcement
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement");
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060004C7 RID: 1223 RVA: 0x00024B66 File Offset: 0x00022D66
		public static GameObject Authentication
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication");
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x00024B72 File Offset: 0x00022D72
		public static GameObject Avatar
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar");
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060004C9 RID: 1225 RVA: 0x00024B7E File Offset: 0x00022D7E
		public static GameObject FirstLogin
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin");
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x00024B8A File Offset: 0x00022D8A
		public static GameObject Playlists
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists");
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060004CB RID: 1227 RVA: 0x00024B96 File Offset: 0x00022D96
		public static GameObject Settings_Safety
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety");
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x00024BA2 File Offset: 0x00022DA2
		public static GameObject Settings
		{
			get
			{
				return GameObject.Find("UserInterface/MenuContent/Screens/Settings");
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060004CD RID: 1229 RVA: 0x00024BAE File Offset: 0x00022DAE
		public static GameObject Social
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Social");
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x00024BBA File Offset: 0x00022DBA
		public static GameObject Title
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Title");
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x00024BC6 File Offset: 0x00022DC6
		public static GameObject UpdateRequired
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired");
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x00024BD2 File Offset: 0x00022DD2
		public static GameObject TitleXR
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/TitleXR");
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060004D1 RID: 1233 RVA: 0x00024BDE File Offset: 0x00022DDE
		public static GameObject Gallery
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery");
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060004D2 RID: 1234 RVA: 0x00024BEA File Offset: 0x00022DEA
		public static GameObject ImageDetails
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails");
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060004D3 RID: 1235 RVA: 0x00024BF6 File Offset: 0x00022DF6
		public static GameObject UserInfo
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo");
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x00024C02 File Offset: 0x00022E02
		public static GameObject VRCPlus
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+");
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x00024C0E File Offset: 0x00022E0E
		public static GameObject WorldInfo
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo");
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x00024C1A File Offset: 0x00022E1A
		public static GameObject Worlds
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds");
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060004D7 RID: 1239 RVA: 0x00024C26 File Offset: 0x00022E26
		public static GameObject Menu_wqoRd0FotfW91RAccountswqoRd0FotfW91R
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R");
			}
		}

		// Token: 0x0200015A RID: 346
		public class Announcement_2
		{
			// Token: 0x1700010E RID: 270
			// (get) Token: 0x060008C3 RID: 2243 RVA: 0x00034391 File Offset: 0x00032591
			public static GameObject Panel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel");
				}
			}

			// Token: 0x02000187 RID: 391
			public class Panel_3
			{
				// Token: 0x170001DE RID: 478
				// (get) Token: 0x060009D5 RID: 2517 RVA: 0x000356F2 File Offset: 0x000338F2
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/Text");
					}
				}

				// Token: 0x170001DF RID: 479
				// (get) Token: 0x060009D6 RID: 2518 RVA: 0x000356FE File Offset: 0x000338FE
				public static GameObject ButtonBack
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonBack");
					}
				}

				// Token: 0x170001E0 RID: 480
				// (get) Token: 0x060009D7 RID: 2519 RVA: 0x0003570A File Offset: 0x0003390A
				public static GameObject ButtonDone
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonDone");
					}
				}

				// Token: 0x170001E1 RID: 481
				// (get) Token: 0x060009D8 RID: 2520 RVA: 0x00035716 File Offset: 0x00033916
				public static GameObject Scroll_View
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/Scroll View");
					}
				}

				// Token: 0x02000204 RID: 516
				public class ButtonBack_4
				{
					// Token: 0x170003D5 RID: 981
					// (get) Token: 0x06000C49 RID: 3145 RVA: 0x000372EB File Offset: 0x000354EB
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonBack/Text");
						}
					}

					// Token: 0x170003D6 RID: 982
					// (get) Token: 0x06000C4A RID: 3146 RVA: 0x000372F7 File Offset: 0x000354F7
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonBack/Image");
						}
					}
				}

				// Token: 0x02000205 RID: 517
				public class ButtonDone_4
				{
					// Token: 0x170003D7 RID: 983
					// (get) Token: 0x06000C4C RID: 3148 RVA: 0x0003730C File Offset: 0x0003550C
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonDone/Text");
						}
					}

					// Token: 0x170003D8 RID: 984
					// (get) Token: 0x06000C4D RID: 3149 RVA: 0x00037318 File Offset: 0x00035518
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Announcement/Panel/ButtonDone/Image");
						}
					}
				}
			}
		}

		// Token: 0x0200015B RID: 347
		public class Authentication_2
		{
			// Token: 0x1700010F RID: 271
			// (get) Token: 0x060008C5 RID: 2245 RVA: 0x000343A6 File Offset: 0x000325A6
			public static GameObject Login2FA
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA");
				}
			}

			// Token: 0x17000110 RID: 272
			// (get) Token: 0x060008C6 RID: 2246 RVA: 0x000343B2 File Offset: 0x000325B2
			public static GameObject Login2FARecovery
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery");
				}
			}

			// Token: 0x17000111 RID: 273
			// (get) Token: 0x060008C7 RID: 2247 RVA: 0x000343BE File Offset: 0x000325BE
			public static GameObject LoginPrompt
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt");
				}
			}

			// Token: 0x17000112 RID: 274
			// (get) Token: 0x060008C8 RID: 2248 RVA: 0x000343CA File Offset: 0x000325CA
			public static GameObject LoginUserPass
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass");
				}
			}

			// Token: 0x17000113 RID: 275
			// (get) Token: 0x060008C9 RID: 2249 RVA: 0x000343D6 File Offset: 0x000325D6
			public static GameObject LoginCreateFromWebsite
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite");
				}
			}

			// Token: 0x17000114 RID: 276
			// (get) Token: 0x060008CA RID: 2250 RVA: 0x000343E2 File Offset: 0x000325E2
			public static GameObject StoreLoginPrompt
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt");
				}
			}

			// Token: 0x17000115 RID: 277
			// (get) Token: 0x060008CB RID: 2251 RVA: 0x000343EE File Offset: 0x000325EE
			public static GameObject LoginUpdate
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate");
				}
			}

			// Token: 0x17000116 RID: 278
			// (get) Token: 0x060008CC RID: 2252 RVA: 0x000343FA File Offset: 0x000325FA
			public static GameObject LoginUpdateVS
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS");
				}
			}

			// Token: 0x17000117 RID: 279
			// (get) Token: 0x060008CD RID: 2253 RVA: 0x00034406 File Offset: 0x00032606
			public static GameObject AgreeTermsOfService
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService");
				}
			}

			// Token: 0x17000118 RID: 280
			// (get) Token: 0x060008CE RID: 2254 RVA: 0x00034412 File Offset: 0x00032612
			public static GameObject ViveportStoreLoginPrompt
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt");
				}
			}

			// Token: 0x17000119 RID: 281
			// (get) Token: 0x060008CF RID: 2255 RVA: 0x0003441E File Offset: 0x0003261E
			public static GameObject OculusStoreLoginPrompt
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt");
				}
			}

			// Token: 0x02000188 RID: 392
			public class Login2FA_3
			{
				// Token: 0x170001E2 RID: 482
				// (get) Token: 0x060009DA RID: 2522 RVA: 0x0003572B File Offset: 0x0003392B
				public static GameObject VRChat_LOGO
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/VRChat_LOGO");
					}
				}

				// Token: 0x170001E3 RID: 483
				// (get) Token: 0x060009DB RID: 2523 RVA: 0x00035737 File Offset: 0x00033937
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/TextWelcome");
					}
				}

				// Token: 0x170001E4 RID: 484
				// (get) Token: 0x060009DC RID: 2524 RVA: 0x00035743 File Offset: 0x00033943
				public static GameObject BoxLogin2FA
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA");
					}
				}

				// Token: 0x170001E5 RID: 485
				// (get) Token: 0x060009DD RID: 2525 RVA: 0x0003574F File Offset: 0x0003394F
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/ButtonAboutUs");
					}
				}

				// Token: 0x170001E6 RID: 486
				// (get) Token: 0x060009DE RID: 2526 RVA: 0x0003575B File Offset: 0x0003395B
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/TextVRChat");
					}
				}

				// Token: 0x02000206 RID: 518
				public class BoxLogin2FA_4
				{
					// Token: 0x170003D9 RID: 985
					// (get) Token: 0x06000C4F RID: 3151 RVA: 0x0003732D File Offset: 0x0003552D
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/Panel");
						}
					}

					// Token: 0x170003DA RID: 986
					// (get) Token: 0x06000C50 RID: 3152 RVA: 0x00037339 File Offset: 0x00035539
					public static GameObject Title
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/Title");
						}
					}

					// Token: 0x170003DB RID: 987
					// (get) Token: 0x06000C51 RID: 3153 RVA: 0x00037345 File Offset: 0x00035545
					public static GameObject Instructions
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/Instructions");
						}
					}

					// Token: 0x170003DC RID: 988
					// (get) Token: 0x06000C52 RID: 3154 RVA: 0x00037351 File Offset: 0x00035551
					public static GameObject InputField2FACode
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/InputField2FACode");
						}
					}

					// Token: 0x170003DD RID: 989
					// (get) Token: 0x06000C53 RID: 3155 RVA: 0x0003735D File Offset: 0x0003555D
					public static GameObject ButtonDone
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonDone");
						}
					}

					// Token: 0x170003DE RID: 990
					// (get) Token: 0x06000C54 RID: 3156 RVA: 0x00037369 File Offset: 0x00035569
					public static GameObject ButtonBack
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonBack");
						}
					}

					// Token: 0x170003DF RID: 991
					// (get) Token: 0x06000C55 RID: 3157 RVA: 0x00037375 File Offset: 0x00035575
					public static GameObject ButtonUseRecoveryCode
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonUseRecoveryCode");
						}
					}

					// Token: 0x170003E0 RID: 992
					// (get) Token: 0x06000C56 RID: 3158 RVA: 0x00037381 File Offset: 0x00035581
					public static GameObject ButtonHelp
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonHelp");
						}
					}

					// Token: 0x020002E0 RID: 736
					public class ButtonDone_5
					{
						// Token: 0x170005C6 RID: 1478
						// (get) Token: 0x06000F16 RID: 3862 RVA: 0x000391F3 File Offset: 0x000373F3
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonDone/Text");
							}
						}
					}

					// Token: 0x020002E1 RID: 737
					public class ButtonBack_5
					{
						// Token: 0x170005C7 RID: 1479
						// (get) Token: 0x06000F18 RID: 3864 RVA: 0x00039208 File Offset: 0x00037408
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonBack/Text");
							}
						}
					}

					// Token: 0x020002E2 RID: 738
					public class ButtonUseRecoveryCode_5
					{
						// Token: 0x170005C8 RID: 1480
						// (get) Token: 0x06000F1A RID: 3866 RVA: 0x0003921D File Offset: 0x0003741D
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonUseRecoveryCode/Text");
							}
						}
					}

					// Token: 0x020002E3 RID: 739
					public class ButtonHelp_5
					{
						// Token: 0x170005C9 RID: 1481
						// (get) Token: 0x06000F1C RID: 3868 RVA: 0x00039232 File Offset: 0x00037432
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/BoxLogin2FA/ButtonHelp/Text");
							}
						}
					}
				}

				// Token: 0x02000207 RID: 519
				public class ButtonAboutUs_4
				{
					// Token: 0x170003E1 RID: 993
					// (get) Token: 0x06000C58 RID: 3160 RVA: 0x00037396 File Offset: 0x00035596
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/ButtonAboutUs/Text");
						}
					}

					// Token: 0x170003E2 RID: 994
					// (get) Token: 0x06000C59 RID: 3161 RVA: 0x000373A2 File Offset: 0x000355A2
					public static GameObject About_Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/ButtonAboutUs/About_Panel");
						}
					}

					// Token: 0x020002E4 RID: 740
					public class About_Panel_5
					{
						// Token: 0x170005CA RID: 1482
						// (get) Token: 0x06000F1E RID: 3870 RVA: 0x00039247 File Offset: 0x00037447
						public static GameObject Text_2
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/ButtonAboutUs/About_Panel/Text (2)");
							}
						}

						// Token: 0x170005CB RID: 1483
						// (get) Token: 0x06000F1F RID: 3871 RVA: 0x00039253 File Offset: 0x00037453
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FA/ButtonAboutUs/About_Panel/Text");
							}
						}
					}
				}
			}

			// Token: 0x02000189 RID: 393
			public class Login2FARecovery_3
			{
				// Token: 0x170001E7 RID: 487
				// (get) Token: 0x060009E0 RID: 2528 RVA: 0x00035770 File Offset: 0x00033970
				public static GameObject VRChat_LOGO
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/VRChat_LOGO");
					}
				}

				// Token: 0x170001E8 RID: 488
				// (get) Token: 0x060009E1 RID: 2529 RVA: 0x0003577C File Offset: 0x0003397C
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/TextWelcome");
					}
				}

				// Token: 0x170001E9 RID: 489
				// (get) Token: 0x060009E2 RID: 2530 RVA: 0x00035788 File Offset: 0x00033988
				public static GameObject BoxLogin2FARecovery
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery");
					}
				}

				// Token: 0x170001EA RID: 490
				// (get) Token: 0x060009E3 RID: 2531 RVA: 0x00035794 File Offset: 0x00033994
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/ButtonAboutUs");
					}
				}

				// Token: 0x170001EB RID: 491
				// (get) Token: 0x060009E4 RID: 2532 RVA: 0x000357A0 File Offset: 0x000339A0
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/TextVRChat");
					}
				}

				// Token: 0x02000208 RID: 520
				public class BoxLogin2FARecovery_4
				{
					// Token: 0x170003E3 RID: 995
					// (get) Token: 0x06000C5B RID: 3163 RVA: 0x000373B7 File Offset: 0x000355B7
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/Panel");
						}
					}

					// Token: 0x170003E4 RID: 996
					// (get) Token: 0x06000C5C RID: 3164 RVA: 0x000373C3 File Offset: 0x000355C3
					public static GameObject Title
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/Title");
						}
					}

					// Token: 0x170003E5 RID: 997
					// (get) Token: 0x06000C5D RID: 3165 RVA: 0x000373CF File Offset: 0x000355CF
					public static GameObject Instructions
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/Instructions");
						}
					}

					// Token: 0x170003E6 RID: 998
					// (get) Token: 0x06000C5E RID: 3166 RVA: 0x000373DB File Offset: 0x000355DB
					public static GameObject InputField2FARecoveryCode
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/InputField2FARecoveryCode");
						}
					}

					// Token: 0x170003E7 RID: 999
					// (get) Token: 0x06000C5F RID: 3167 RVA: 0x000373E7 File Offset: 0x000355E7
					public static GameObject ButtonDone
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonDone");
						}
					}

					// Token: 0x170003E8 RID: 1000
					// (get) Token: 0x06000C60 RID: 3168 RVA: 0x000373F3 File Offset: 0x000355F3
					public static GameObject ButtonBack
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonBack");
						}
					}

					// Token: 0x170003E9 RID: 1001
					// (get) Token: 0x06000C61 RID: 3169 RVA: 0x000373FF File Offset: 0x000355FF
					public static GameObject ButtonHelp
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonHelp");
						}
					}

					// Token: 0x020002E5 RID: 741
					public class ButtonDone_5
					{
						// Token: 0x170005CC RID: 1484
						// (get) Token: 0x06000F21 RID: 3873 RVA: 0x00039268 File Offset: 0x00037468
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonDone/Text");
							}
						}
					}

					// Token: 0x020002E6 RID: 742
					public class ButtonBack_5
					{
						// Token: 0x170005CD RID: 1485
						// (get) Token: 0x06000F23 RID: 3875 RVA: 0x0003927D File Offset: 0x0003747D
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonBack/Text");
							}
						}
					}

					// Token: 0x020002E7 RID: 743
					public class ButtonHelp_5
					{
						// Token: 0x170005CE RID: 1486
						// (get) Token: 0x06000F25 RID: 3877 RVA: 0x00039292 File Offset: 0x00037492
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/BoxLogin2FARecovery/ButtonHelp/Text");
							}
						}
					}
				}

				// Token: 0x02000209 RID: 521
				public class ButtonAboutUs_4
				{
					// Token: 0x170003EA RID: 1002
					// (get) Token: 0x06000C63 RID: 3171 RVA: 0x00037414 File Offset: 0x00035614
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/ButtonAboutUs/Text");
						}
					}

					// Token: 0x170003EB RID: 1003
					// (get) Token: 0x06000C64 RID: 3172 RVA: 0x00037420 File Offset: 0x00035620
					public static GameObject About_Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/ButtonAboutUs/About_Panel");
						}
					}

					// Token: 0x020002E8 RID: 744
					public class About_Panel_5
					{
						// Token: 0x170005CF RID: 1487
						// (get) Token: 0x06000F27 RID: 3879 RVA: 0x000392A7 File Offset: 0x000374A7
						public static GameObject Text_2
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/ButtonAboutUs/About_Panel/Text (2)");
							}
						}

						// Token: 0x170005D0 RID: 1488
						// (get) Token: 0x06000F28 RID: 3880 RVA: 0x000392B3 File Offset: 0x000374B3
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/Login2FARecovery/ButtonAboutUs/About_Panel/Text");
							}
						}
					}
				}
			}

			// Token: 0x0200018A RID: 394
			public class LoginPrompt_3
			{
				// Token: 0x170001EC RID: 492
				// (get) Token: 0x060009E6 RID: 2534 RVA: 0x000357B5 File Offset: 0x000339B5
				public static GameObject VRChatButtonLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/VRChatButtonLogin");
					}
				}

				// Token: 0x170001ED RID: 493
				// (get) Token: 0x060009E7 RID: 2535 RVA: 0x000357C1 File Offset: 0x000339C1
				public static GameObject ButtonCreate
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonCreate");
					}
				}

				// Token: 0x170001EE RID: 494
				// (get) Token: 0x060009E8 RID: 2536 RVA: 0x000357CD File Offset: 0x000339CD
				public static GameObject ButtonBypass
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonBypass");
					}
				}

				// Token: 0x170001EF RID: 495
				// (get) Token: 0x060009E9 RID: 2537 RVA: 0x000357D9 File Offset: 0x000339D9
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/TextWelcome");
					}
				}

				// Token: 0x170001F0 RID: 496
				// (get) Token: 0x060009EA RID: 2538 RVA: 0x000357E5 File Offset: 0x000339E5
				public static GameObject VRChat_LOGO
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/VRChat_LOGO");
					}
				}

				// Token: 0x170001F1 RID: 497
				// (get) Token: 0x060009EB RID: 2539 RVA: 0x000357F1 File Offset: 0x000339F1
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/TextVRChat");
					}
				}

				// Token: 0x170001F2 RID: 498
				// (get) Token: 0x060009EC RID: 2540 RVA: 0x000357FD File Offset: 0x000339FD
				public static GameObject TextOr
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/TextOr");
					}
				}

				// Token: 0x170001F3 RID: 499
				// (get) Token: 0x060009ED RID: 2541 RVA: 0x00035809 File Offset: 0x00033A09
				public static GameObject TextLoginWith
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/TextLoginWith");
					}
				}

				// Token: 0x170001F4 RID: 500
				// (get) Token: 0x060009EE RID: 2542 RVA: 0x00035815 File Offset: 0x00033A15
				public static GameObject ButtonAboutUs_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonAboutUs (1)");
					}
				}

				// Token: 0x170001F5 RID: 501
				// (get) Token: 0x060009EF RID: 2543 RVA: 0x00035821 File Offset: 0x00033A21
				public static GameObject StoreButtonLogin_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/StoreButtonLogin (1)");
					}
				}

				// Token: 0x170001F6 RID: 502
				// (get) Token: 0x060009F0 RID: 2544 RVA: 0x0003582D File Offset: 0x00033A2D
				public static GameObject LanguagePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/LanguagePanel");
					}
				}

				// Token: 0x0200020A RID: 522
				public class VRChatButtonLogin_4
				{
					// Token: 0x170003EC RID: 1004
					// (get) Token: 0x06000C66 RID: 3174 RVA: 0x00037435 File Offset: 0x00035635
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/VRChatButtonLogin/Text");
						}
					}
				}

				// Token: 0x0200020B RID: 523
				public class ButtonCreate_4
				{
					// Token: 0x170003ED RID: 1005
					// (get) Token: 0x06000C68 RID: 3176 RVA: 0x0003744A File Offset: 0x0003564A
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonCreate/Text");
						}
					}
				}

				// Token: 0x0200020C RID: 524
				public class ButtonBypass_4
				{
					// Token: 0x170003EE RID: 1006
					// (get) Token: 0x06000C6A RID: 3178 RVA: 0x0003745F File Offset: 0x0003565F
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonBypass/Text");
						}
					}
				}

				// Token: 0x0200020D RID: 525
				public class ButtonAboutUs_1_4
				{
					// Token: 0x170003EF RID: 1007
					// (get) Token: 0x06000C6C RID: 3180 RVA: 0x00037474 File Offset: 0x00035674
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonAboutUs (1)/Text");
						}
					}

					// Token: 0x170003F0 RID: 1008
					// (get) Token: 0x06000C6D RID: 3181 RVA: 0x00037480 File Offset: 0x00035680
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonAboutUs (1)/Image");
						}
					}

					// Token: 0x020002E9 RID: 745
					public class Image_5
					{
						// Token: 0x170005D1 RID: 1489
						// (get) Token: 0x06000F2A RID: 3882 RVA: 0x000392C8 File Offset: 0x000374C8
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonAboutUs (1)/Image/Text");
							}
						}

						// Token: 0x170005D2 RID: 1490
						// (get) Token: 0x06000F2B RID: 3883 RVA: 0x000392D4 File Offset: 0x000374D4
						public static GameObject Text_1
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/ButtonAboutUs (1)/Image/Text (1)");
							}
						}
					}
				}

				// Token: 0x0200020E RID: 526
				public class StoreButtonLogin_1_4
				{
					// Token: 0x170003F1 RID: 1009
					// (get) Token: 0x06000C6F RID: 3183 RVA: 0x00037495 File Offset: 0x00035695
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/StoreButtonLogin (1)/Text");
						}
					}
				}

				// Token: 0x0200020F RID: 527
				public class LanguagePanel_4
				{
					// Token: 0x170003F2 RID: 1010
					// (get) Token: 0x06000C71 RID: 3185 RVA: 0x000374AA File Offset: 0x000356AA
					public static GameObject TitleText_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/LanguagePanel/TitleText (1)");
						}
					}

					// Token: 0x170003F3 RID: 1011
					// (get) Token: 0x06000C72 RID: 3186 RVA: 0x000374B6 File Offset: 0x000356B6
					public static GameObject SelectPrevLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/LanguagePanel/SelectPrevLang");
						}
					}

					// Token: 0x170003F4 RID: 1012
					// (get) Token: 0x06000C73 RID: 3187 RVA: 0x000374C2 File Offset: 0x000356C2
					public static GameObject SelectNextLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/LanguagePanel/SelectNextLang");
						}
					}

					// Token: 0x170003F5 RID: 1013
					// (get) Token: 0x06000C74 RID: 3188 RVA: 0x000374CE File Offset: 0x000356CE
					public static GameObject Language
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginPrompt/LanguagePanel/Language");
						}
					}
				}
			}

			// Token: 0x0200018B RID: 395
			public class LoginUserPass_3
			{
				// Token: 0x170001F7 RID: 503
				// (get) Token: 0x060009F2 RID: 2546 RVA: 0x00035842 File Offset: 0x00033A42
				public static GameObject VRChat_LOGO_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/VRChat_LOGO (1)");
					}
				}

				// Token: 0x170001F8 RID: 504
				// (get) Token: 0x060009F3 RID: 2547 RVA: 0x0003584E File Offset: 0x00033A4E
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/TextWelcome");
					}
				}

				// Token: 0x170001F9 RID: 505
				// (get) Token: 0x060009F4 RID: 2548 RVA: 0x0003585A File Offset: 0x00033A5A
				public static GameObject BoxLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin");
					}
				}

				// Token: 0x170001FA RID: 506
				// (get) Token: 0x060009F5 RID: 2549 RVA: 0x00035866 File Offset: 0x00033A66
				public static GameObject ButtonDone_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonDone (1)");
					}
				}

				// Token: 0x170001FB RID: 507
				// (get) Token: 0x060009F6 RID: 2550 RVA: 0x00035872 File Offset: 0x00033A72
				public static GameObject ButtonBack_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonBack (1)");
					}
				}

				// Token: 0x170001FC RID: 508
				// (get) Token: 0x060009F7 RID: 2551 RVA: 0x0003587E File Offset: 0x00033A7E
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs");
					}
				}

				// Token: 0x170001FD RID: 509
				// (get) Token: 0x060009F8 RID: 2552 RVA: 0x0003588A File Offset: 0x00033A8A
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/TextVRChat");
					}
				}

				// Token: 0x02000210 RID: 528
				public class BoxLogin_4
				{
					// Token: 0x170003F6 RID: 1014
					// (get) Token: 0x06000C76 RID: 3190 RVA: 0x000374E3 File Offset: 0x000356E3
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Panel");
						}
					}

					// Token: 0x170003F7 RID: 1015
					// (get) Token: 0x06000C77 RID: 3191 RVA: 0x000374EF File Offset: 0x000356EF
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Text");
						}
					}

					// Token: 0x170003F8 RID: 1016
					// (get) Token: 0x06000C78 RID: 3192 RVA: 0x000374FB File Offset: 0x000356FB
					public static GameObject InputFieldUser
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldUser");
						}
					}

					// Token: 0x170003F9 RID: 1017
					// (get) Token: 0x06000C79 RID: 3193 RVA: 0x00037507 File Offset: 0x00035707
					public static GameObject InputFieldPassword
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldPassword");
						}
					}
				}

				// Token: 0x02000211 RID: 529
				public class ButtonDone_1_4
				{
					// Token: 0x170003FA RID: 1018
					// (get) Token: 0x06000C7B RID: 3195 RVA: 0x0003751C File Offset: 0x0003571C
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonDone (1)/Text");
						}
					}
				}

				// Token: 0x02000212 RID: 530
				public class ButtonBack_1_4
				{
					// Token: 0x170003FB RID: 1019
					// (get) Token: 0x06000C7D RID: 3197 RVA: 0x00037531 File Offset: 0x00035731
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonBack (1)/Text");
						}
					}
				}

				// Token: 0x02000213 RID: 531
				public class ButtonAboutUs_4
				{
					// Token: 0x170003FC RID: 1020
					// (get) Token: 0x06000C7F RID: 3199 RVA: 0x00037546 File Offset: 0x00035746
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs/Text");
						}
					}

					// Token: 0x170003FD RID: 1021
					// (get) Token: 0x06000C80 RID: 3200 RVA: 0x00037552 File Offset: 0x00035752
					public static GameObject About_Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs/About_Panel");
						}
					}

					// Token: 0x020002EA RID: 746
					public class About_Panel_5
					{
						// Token: 0x170005D3 RID: 1491
						// (get) Token: 0x06000F2D RID: 3885 RVA: 0x000392E9 File Offset: 0x000374E9
						public static GameObject Text_2
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs/About_Panel/Text (2)");
							}
						}

						// Token: 0x170005D4 RID: 1492
						// (get) Token: 0x06000F2E RID: 3886 RVA: 0x000392F5 File Offset: 0x000374F5
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs/About_Panel/Text");
							}
						}
					}
				}
			}

			// Token: 0x0200018C RID: 396
			public class LoginCreateFromWebsite_3
			{
				// Token: 0x170001FE RID: 510
				// (get) Token: 0x060009FA RID: 2554 RVA: 0x0003589F File Offset: 0x00033A9F
				public static GameObject Panel_Backdrop
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/Panel_Backdrop");
					}
				}

				// Token: 0x170001FF RID: 511
				// (get) Token: 0x060009FB RID: 2555 RVA: 0x000358AB File Offset: 0x00033AAB
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonAboutUs");
					}
				}

				// Token: 0x17000200 RID: 512
				// (get) Token: 0x060009FC RID: 2556 RVA: 0x000358B7 File Offset: 0x00033AB7
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/TextWelcome");
					}
				}

				// Token: 0x17000201 RID: 513
				// (get) Token: 0x060009FD RID: 2557 RVA: 0x000358C3 File Offset: 0x00033AC3
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/TextVRChat");
					}
				}

				// Token: 0x17000202 RID: 514
				// (get) Token: 0x060009FE RID: 2558 RVA: 0x000358CF File Offset: 0x00033ACF
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/Panel");
					}
				}

				// Token: 0x17000203 RID: 515
				// (get) Token: 0x060009FF RID: 2559 RVA: 0x000358DB File Offset: 0x00033ADB
				public static GameObject RegisterOnWebsiteText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/RegisterOnWebsiteText");
					}
				}

				// Token: 0x17000204 RID: 516
				// (get) Token: 0x06000A00 RID: 2560 RVA: 0x000358E7 File Offset: 0x00033AE7
				public static GameObject RegisterationCompletedText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/RegisterationCompletedText");
					}
				}

				// Token: 0x17000205 RID: 517
				// (get) Token: 0x06000A01 RID: 2561 RVA: 0x000358F3 File Offset: 0x00033AF3
				public static GameObject ButtonLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonLogin");
					}
				}

				// Token: 0x02000214 RID: 532
				public class ButtonAboutUs_4
				{
					// Token: 0x170003FE RID: 1022
					// (get) Token: 0x06000C82 RID: 3202 RVA: 0x00037567 File Offset: 0x00035767
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonAboutUs/Text");
						}
					}

					// Token: 0x170003FF RID: 1023
					// (get) Token: 0x06000C83 RID: 3203 RVA: 0x00037573 File Offset: 0x00035773
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonAboutUs/Image");
						}
					}

					// Token: 0x020002EB RID: 747
					public class Image_5
					{
						// Token: 0x170005D5 RID: 1493
						// (get) Token: 0x06000F30 RID: 3888 RVA: 0x0003930A File Offset: 0x0003750A
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonAboutUs/Image/Text");
							}
						}
					}
				}

				// Token: 0x02000215 RID: 533
				public class Panel_4
				{
					// Token: 0x17000400 RID: 1024
					// (get) Token: 0x06000C85 RID: 3205 RVA: 0x00037588 File Offset: 0x00035788
					public static GameObject RegisterOnWebsiteText_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/Panel/RegisterOnWebsiteText (1)");
						}
					}
				}

				// Token: 0x02000216 RID: 534
				public class ButtonLogin_4
				{
					// Token: 0x17000401 RID: 1025
					// (get) Token: 0x06000C87 RID: 3207 RVA: 0x0003759D File Offset: 0x0003579D
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonLogin/Text");
						}
					}

					// Token: 0x17000402 RID: 1026
					// (get) Token: 0x06000C88 RID: 3208 RVA: 0x000375A9 File Offset: 0x000357A9
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginCreateFromWebsite/ButtonLogin/Image");
						}
					}
				}
			}

			// Token: 0x0200018D RID: 397
			public class StoreLoginPrompt_3
			{
				// Token: 0x17000206 RID: 518
				// (get) Token: 0x06000A03 RID: 2563 RVA: 0x00035908 File Offset: 0x00033B08
				public static GameObject VRChat_LOGO_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChat_LOGO (1)");
					}
				}

				// Token: 0x17000207 RID: 519
				// (get) Token: 0x06000A04 RID: 2564 RVA: 0x00035914 File Offset: 0x00033B14
				public static GameObject VRChatButtonLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChatButtonLogin");
					}
				}

				// Token: 0x17000208 RID: 520
				// (get) Token: 0x06000A05 RID: 2565 RVA: 0x00035920 File Offset: 0x00033B20
				public static GameObject ButtonCreate
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonCreate");
					}
				}

				// Token: 0x17000209 RID: 521
				// (get) Token: 0x06000A06 RID: 2566 RVA: 0x0003592C File Offset: 0x00033B2C
				public static GameObject ButtonBypass
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonBypass");
					}
				}

				// Token: 0x1700020A RID: 522
				// (get) Token: 0x06000A07 RID: 2567 RVA: 0x00035938 File Offset: 0x00033B38
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome");
					}
				}

				// Token: 0x1700020B RID: 523
				// (get) Token: 0x06000A08 RID: 2568 RVA: 0x00035944 File Offset: 0x00033B44
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextVRChat");
					}
				}

				// Token: 0x1700020C RID: 524
				// (get) Token: 0x06000A09 RID: 2569 RVA: 0x00035950 File Offset: 0x00033B50
				public static GameObject TextOr
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextOr");
					}
				}

				// Token: 0x1700020D RID: 525
				// (get) Token: 0x06000A0A RID: 2570 RVA: 0x0003595C File Offset: 0x00033B5C
				public static GameObject TextLoginWith
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextLoginWith");
					}
				}

				// Token: 0x1700020E RID: 526
				// (get) Token: 0x06000A0B RID: 2571 RVA: 0x00035968 File Offset: 0x00033B68
				public static GameObject ButtonAboutUs_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)");
					}
				}

				// Token: 0x1700020F RID: 527
				// (get) Token: 0x06000A0C RID: 2572 RVA: 0x00035974 File Offset: 0x00033B74
				public static GameObject StoreButtonLogin_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/StoreButtonLogin (1)");
					}
				}

				// Token: 0x17000210 RID: 528
				// (get) Token: 0x06000A0D RID: 2573 RVA: 0x00035980 File Offset: 0x00033B80
				public static GameObject LanguagePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/LanguagePanel");
					}
				}

				// Token: 0x02000217 RID: 535
				public class VRChatButtonLogin_4
				{
					// Token: 0x17000403 RID: 1027
					// (get) Token: 0x06000C8A RID: 3210 RVA: 0x000375BE File Offset: 0x000357BE
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChatButtonLogin/Text");
						}
					}
				}

				// Token: 0x02000218 RID: 536
				public class ButtonCreate_4
				{
					// Token: 0x17000404 RID: 1028
					// (get) Token: 0x06000C8C RID: 3212 RVA: 0x000375D3 File Offset: 0x000357D3
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonCreate/Text");
						}
					}
				}

				// Token: 0x02000219 RID: 537
				public class ButtonBypass_4
				{
					// Token: 0x17000405 RID: 1029
					// (get) Token: 0x06000C8E RID: 3214 RVA: 0x000375E8 File Offset: 0x000357E8
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonBypass/Text");
						}
					}
				}

				// Token: 0x0200021A RID: 538
				public class ButtonAboutUs_1_4
				{
					// Token: 0x17000406 RID: 1030
					// (get) Token: 0x06000C90 RID: 3216 RVA: 0x000375FD File Offset: 0x000357FD
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)/Text");
						}
					}

					// Token: 0x17000407 RID: 1031
					// (get) Token: 0x06000C91 RID: 3217 RVA: 0x00037609 File Offset: 0x00035809
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)/Image");
						}
					}

					// Token: 0x020002EC RID: 748
					public class Image_5
					{
						// Token: 0x170005D6 RID: 1494
						// (get) Token: 0x06000F32 RID: 3890 RVA: 0x0003931F File Offset: 0x0003751F
						public static GameObject Text_2
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)/Image/Text (2)");
							}
						}

						// Token: 0x170005D7 RID: 1495
						// (get) Token: 0x06000F33 RID: 3891 RVA: 0x0003932B File Offset: 0x0003752B
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)/Image/Text");
							}
						}
					}
				}

				// Token: 0x0200021B RID: 539
				public class StoreButtonLogin_1_4
				{
					// Token: 0x17000408 RID: 1032
					// (get) Token: 0x06000C93 RID: 3219 RVA: 0x0003761E File Offset: 0x0003581E
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/StoreButtonLogin (1)/Text");
						}
					}
				}

				// Token: 0x0200021C RID: 540
				public class LanguagePanel_4
				{
					// Token: 0x17000409 RID: 1033
					// (get) Token: 0x06000C95 RID: 3221 RVA: 0x00037633 File Offset: 0x00035833
					public static GameObject TitleText_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/LanguagePanel/TitleText (1)");
						}
					}

					// Token: 0x1700040A RID: 1034
					// (get) Token: 0x06000C96 RID: 3222 RVA: 0x0003763F File Offset: 0x0003583F
					public static GameObject SelectPrevLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/LanguagePanel/SelectPrevLang");
						}
					}

					// Token: 0x1700040B RID: 1035
					// (get) Token: 0x06000C97 RID: 3223 RVA: 0x0003764B File Offset: 0x0003584B
					public static GameObject SelectNextLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/LanguagePanel/SelectNextLang");
						}
					}

					// Token: 0x1700040C RID: 1036
					// (get) Token: 0x06000C98 RID: 3224 RVA: 0x00037657 File Offset: 0x00035857
					public static GameObject Language
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/LanguagePanel/Language");
						}
					}
				}
			}

			// Token: 0x0200018E RID: 398
			public class LoginUpdate_3
			{
				// Token: 0x17000211 RID: 529
				// (get) Token: 0x06000A0F RID: 2575 RVA: 0x00035995 File Offset: 0x00033B95
				public static GameObject VRChat_LOGO_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/VRChat_LOGO (1)");
					}
				}

				// Token: 0x17000212 RID: 530
				// (get) Token: 0x06000A10 RID: 2576 RVA: 0x000359A1 File Offset: 0x00033BA1
				public static GameObject Create
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/Create");
					}
				}

				// Token: 0x17000213 RID: 531
				// (get) Token: 0x06000A11 RID: 2577 RVA: 0x000359AD File Offset: 0x00033BAD
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/TextWelcome");
					}
				}

				// Token: 0x17000214 RID: 532
				// (get) Token: 0x06000A12 RID: 2578 RVA: 0x000359B9 File Offset: 0x00033BB9
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/TextVRChat");
					}
				}

				// Token: 0x17000215 RID: 533
				// (get) Token: 0x06000A13 RID: 2579 RVA: 0x000359C5 File Offset: 0x00033BC5
				public static GameObject ButtonBack
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonBack");
					}
				}

				// Token: 0x17000216 RID: 534
				// (get) Token: 0x06000A14 RID: 2580 RVA: 0x000359D1 File Offset: 0x00033BD1
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonAboutUs");
					}
				}

				// Token: 0x17000217 RID: 535
				// (get) Token: 0x06000A15 RID: 2581 RVA: 0x000359DD File Offset: 0x00033BDD
				public static GameObject ButtonDone
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonDone");
					}
				}

				// Token: 0x0200021D RID: 541
				public class Create_4
				{
					// Token: 0x1700040D RID: 1037
					// (get) Token: 0x06000C9A RID: 3226 RVA: 0x0003766C File Offset: 0x0003586C
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/Create/Panel");
						}
					}

					// Token: 0x1700040E RID: 1038
					// (get) Token: 0x06000C9B RID: 3227 RVA: 0x00037678 File Offset: 0x00035878
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/Create/Text");
						}
					}

					// Token: 0x1700040F RID: 1039
					// (get) Token: 0x06000C9C RID: 3228 RVA: 0x00037684 File Offset: 0x00035884
					public static GameObject InputFieldEmail
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/Create/InputFieldEmail");
						}
					}

					// Token: 0x17000410 RID: 1040
					// (get) Token: 0x06000C9D RID: 3229 RVA: 0x00037690 File Offset: 0x00035890
					public static GameObject InputFieldBirthday
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/Create/InputFieldBirthday");
						}
					}
				}

				// Token: 0x0200021E RID: 542
				public class ButtonBack_4
				{
					// Token: 0x17000411 RID: 1041
					// (get) Token: 0x06000C9F RID: 3231 RVA: 0x000376A5 File Offset: 0x000358A5
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonBack/Text");
						}
					}

					// Token: 0x17000412 RID: 1042
					// (get) Token: 0x06000CA0 RID: 3232 RVA: 0x000376B1 File Offset: 0x000358B1
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonBack/Image");
						}
					}
				}

				// Token: 0x0200021F RID: 543
				public class ButtonAboutUs_4
				{
					// Token: 0x17000413 RID: 1043
					// (get) Token: 0x06000CA2 RID: 3234 RVA: 0x000376C6 File Offset: 0x000358C6
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonAboutUs/Text");
						}
					}

					// Token: 0x17000414 RID: 1044
					// (get) Token: 0x06000CA3 RID: 3235 RVA: 0x000376D2 File Offset: 0x000358D2
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonAboutUs/Image");
						}
					}

					// Token: 0x020002ED RID: 749
					public class Image_5
					{
						// Token: 0x170005D8 RID: 1496
						// (get) Token: 0x06000F35 RID: 3893 RVA: 0x00039340 File Offset: 0x00037540
						public static GameObject Text_
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonAboutUs/Image/Text (3)");
							}
						}

						// Token: 0x170005D9 RID: 1497
						// (get) Token: 0x06000F36 RID: 3894 RVA: 0x0003934C File Offset: 0x0003754C
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonAboutUs/Image/Text");
							}
						}
					}
				}

				// Token: 0x02000220 RID: 544
				public class ButtonDone_4
				{
					// Token: 0x17000415 RID: 1045
					// (get) Token: 0x06000CA5 RID: 3237 RVA: 0x000376E7 File Offset: 0x000358E7
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonDone/Text");
						}
					}

					// Token: 0x17000416 RID: 1046
					// (get) Token: 0x06000CA6 RID: 3238 RVA: 0x000376F3 File Offset: 0x000358F3
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdate/ButtonDone/Image");
						}
					}
				}
			}

			// Token: 0x0200018F RID: 399
			public class LoginUpdateVS_3
			{
				// Token: 0x17000218 RID: 536
				// (get) Token: 0x06000A17 RID: 2583 RVA: 0x000359F2 File Offset: 0x00033BF2
				public static GameObject Create
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/Create");
					}
				}

				// Token: 0x17000219 RID: 537
				// (get) Token: 0x06000A18 RID: 2584 RVA: 0x000359FE File Offset: 0x00033BFE
				public static GameObject ButtonBack
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonBack");
					}
				}

				// Token: 0x1700021A RID: 538
				// (get) Token: 0x06000A19 RID: 2585 RVA: 0x00035A0A File Offset: 0x00033C0A
				public static GameObject ButtonAboutUs
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonAboutUs");
					}
				}

				// Token: 0x1700021B RID: 539
				// (get) Token: 0x06000A1A RID: 2586 RVA: 0x00035A16 File Offset: 0x00033C16
				public static GameObject ButtonDone
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonDone");
					}
				}

				// Token: 0x02000221 RID: 545
				public class Create_4
				{
					// Token: 0x17000417 RID: 1047
					// (get) Token: 0x06000CA8 RID: 3240 RVA: 0x00037708 File Offset: 0x00035908
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/Create/Panel");
						}
					}

					// Token: 0x17000418 RID: 1048
					// (get) Token: 0x06000CA9 RID: 3241 RVA: 0x00037714 File Offset: 0x00035914
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/Create/Text");
						}
					}

					// Token: 0x17000419 RID: 1049
					// (get) Token: 0x06000CAA RID: 3242 RVA: 0x00037720 File Offset: 0x00035920
					public static GameObject InputFieldEmail
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/Create/InputFieldEmail");
						}
					}

					// Token: 0x1700041A RID: 1050
					// (get) Token: 0x06000CAB RID: 3243 RVA: 0x0003772C File Offset: 0x0003592C
					public static GameObject InputFieldBirthday
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/Create/InputFieldBirthday");
						}
					}
				}

				// Token: 0x02000222 RID: 546
				public class ButtonBack_4
				{
					// Token: 0x1700041B RID: 1051
					// (get) Token: 0x06000CAD RID: 3245 RVA: 0x00037741 File Offset: 0x00035941
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonBack/Text");
						}
					}

					// Token: 0x1700041C RID: 1052
					// (get) Token: 0x06000CAE RID: 3246 RVA: 0x0003774D File Offset: 0x0003594D
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonBack/Image");
						}
					}
				}

				// Token: 0x02000223 RID: 547
				public class ButtonAboutUs_4
				{
					// Token: 0x1700041D RID: 1053
					// (get) Token: 0x06000CB0 RID: 3248 RVA: 0x00037762 File Offset: 0x00035962
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonAboutUs/Text");
						}
					}

					// Token: 0x1700041E RID: 1054
					// (get) Token: 0x06000CB1 RID: 3249 RVA: 0x0003776E File Offset: 0x0003596E
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonAboutUs/Image");
						}
					}

					// Token: 0x020002EE RID: 750
					public class Image_5
					{
						// Token: 0x170005DA RID: 1498
						// (get) Token: 0x06000F38 RID: 3896 RVA: 0x00039361 File Offset: 0x00037561
						public static GameObject Text_
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonAboutUs/Image/Text (3)");
							}
						}

						// Token: 0x170005DB RID: 1499
						// (get) Token: 0x06000F39 RID: 3897 RVA: 0x0003936D File Offset: 0x0003756D
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonAboutUs/Image/Text");
							}
						}
					}
				}

				// Token: 0x02000224 RID: 548
				public class ButtonDone_4
				{
					// Token: 0x1700041F RID: 1055
					// (get) Token: 0x06000CB3 RID: 3251 RVA: 0x00037783 File Offset: 0x00035983
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonDone/Text");
						}
					}

					// Token: 0x17000420 RID: 1056
					// (get) Token: 0x06000CB4 RID: 3252 RVA: 0x0003778F File Offset: 0x0003598F
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/LoginUpdateVS/ButtonDone/Image");
						}
					}
				}
			}

			// Token: 0x02000190 RID: 400
			public class AgreeTermsOfService_3
			{
				// Token: 0x1700021C RID: 540
				// (get) Token: 0x06000A1C RID: 2588 RVA: 0x00035A2B File Offset: 0x00033C2B
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel");
					}
				}

				// Token: 0x02000225 RID: 549
				public class Panel_4
				{
					// Token: 0x17000421 RID: 1057
					// (get) Token: 0x06000CB6 RID: 3254 RVA: 0x000377A4 File Offset: 0x000359A4
					public static GameObject Panel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/Panel");
						}
					}

					// Token: 0x17000422 RID: 1058
					// (get) Token: 0x06000CB7 RID: 3255 RVA: 0x000377B0 File Offset: 0x000359B0
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/Text");
						}
					}

					// Token: 0x17000423 RID: 1059
					// (get) Token: 0x06000CB8 RID: 3256 RVA: 0x000377BC File Offset: 0x000359BC
					public static GameObject ButtonBack
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonBack");
						}
					}

					// Token: 0x17000424 RID: 1060
					// (get) Token: 0x06000CB9 RID: 3257 RVA: 0x000377C8 File Offset: 0x000359C8
					public static GameObject ButtonDone
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonDone");
						}
					}

					// Token: 0x17000425 RID: 1061
					// (get) Token: 0x06000CBA RID: 3258 RVA: 0x000377D4 File Offset: 0x000359D4
					public static GameObject ToggleAgree
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ToggleAgree");
						}
					}

					// Token: 0x17000426 RID: 1062
					// (get) Token: 0x06000CBB RID: 3259 RVA: 0x000377E0 File Offset: 0x000359E0
					public static GameObject Scroll_View
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/Scroll View");
						}
					}

					// Token: 0x17000427 RID: 1063
					// (get) Token: 0x06000CBC RID: 3260 RVA: 0x000377EC File Offset: 0x000359EC
					public static GameObject AgreeText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/AgreeText");
						}
					}

					// Token: 0x020002EF RID: 751
					public class ButtonBack_5
					{
						// Token: 0x170005DC RID: 1500
						// (get) Token: 0x06000F3B RID: 3899 RVA: 0x00039382 File Offset: 0x00037582
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonBack/Text");
							}
						}

						// Token: 0x170005DD RID: 1501
						// (get) Token: 0x06000F3C RID: 3900 RVA: 0x0003938E File Offset: 0x0003758E
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonBack/Image");
							}
						}
					}

					// Token: 0x020002F0 RID: 752
					public class ButtonDone_5
					{
						// Token: 0x170005DE RID: 1502
						// (get) Token: 0x06000F3E RID: 3902 RVA: 0x000393A3 File Offset: 0x000375A3
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonDone/Text");
							}
						}

						// Token: 0x170005DF RID: 1503
						// (get) Token: 0x06000F3F RID: 3903 RVA: 0x000393AF File Offset: 0x000375AF
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ButtonDone/Image");
							}
						}
					}

					// Token: 0x020002F1 RID: 753
					public class ToggleAgree_5
					{
						// Token: 0x170005E0 RID: 1504
						// (get) Token: 0x06000F41 RID: 3905 RVA: 0x000393C4 File Offset: 0x000375C4
						public static GameObject Background
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ToggleAgree/Background");
							}
						}

						// Token: 0x170005E1 RID: 1505
						// (get) Token: 0x06000F42 RID: 3906 RVA: 0x000393D0 File Offset: 0x000375D0
						public static GameObject Label
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/ToggleAgree/Label");
							}
						}
					}

					// Token: 0x020002F2 RID: 754
					public class AgreeText_5
					{
						// Token: 0x170005E2 RID: 1506
						// (get) Token: 0x06000F44 RID: 3908 RVA: 0x000393E5 File Offset: 0x000375E5
						public static GameObject Button
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/AgreeTermsOfService/Panel/AgreeText/Button");
							}
						}
					}
				}
			}

			// Token: 0x02000191 RID: 401
			public class ViveportStoreLoginPrompt_3
			{
				// Token: 0x1700021D RID: 541
				// (get) Token: 0x06000A1E RID: 2590 RVA: 0x00035A40 File Offset: 0x00033C40
				public static GameObject VRChat_LOGO_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/VRChat_LOGO (1)");
					}
				}

				// Token: 0x1700021E RID: 542
				// (get) Token: 0x06000A1F RID: 2591 RVA: 0x00035A4C File Offset: 0x00033C4C
				public static GameObject VRChatButtonLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/VRChatButtonLogin");
					}
				}

				// Token: 0x1700021F RID: 543
				// (get) Token: 0x06000A20 RID: 2592 RVA: 0x00035A58 File Offset: 0x00033C58
				public static GameObject ButtonCreate
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonCreate");
					}
				}

				// Token: 0x17000220 RID: 544
				// (get) Token: 0x06000A21 RID: 2593 RVA: 0x00035A64 File Offset: 0x00033C64
				public static GameObject ButtonBypass
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonBypass");
					}
				}

				// Token: 0x17000221 RID: 545
				// (get) Token: 0x06000A22 RID: 2594 RVA: 0x00035A70 File Offset: 0x00033C70
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/TextWelcome");
					}
				}

				// Token: 0x17000222 RID: 546
				// (get) Token: 0x06000A23 RID: 2595 RVA: 0x00035A7C File Offset: 0x00033C7C
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/TextVRChat");
					}
				}

				// Token: 0x17000223 RID: 547
				// (get) Token: 0x06000A24 RID: 2596 RVA: 0x00035A88 File Offset: 0x00033C88
				public static GameObject TextOr
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/TextOr");
					}
				}

				// Token: 0x17000224 RID: 548
				// (get) Token: 0x06000A25 RID: 2597 RVA: 0x00035A94 File Offset: 0x00033C94
				public static GameObject TextLoginWith
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/TextLoginWith");
					}
				}

				// Token: 0x17000225 RID: 549
				// (get) Token: 0x06000A26 RID: 2598 RVA: 0x00035AA0 File Offset: 0x00033CA0
				public static GameObject ButtonAboutUs_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonAboutUs (1)");
					}
				}

				// Token: 0x17000226 RID: 550
				// (get) Token: 0x06000A27 RID: 2599 RVA: 0x00035AAC File Offset: 0x00033CAC
				public static GameObject StoreButtonLogin_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/StoreButtonLogin (1)");
					}
				}

				// Token: 0x17000227 RID: 551
				// (get) Token: 0x06000A28 RID: 2600 RVA: 0x00035AB8 File Offset: 0x00033CB8
				public static GameObject LanguagePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/LanguagePanel");
					}
				}

				// Token: 0x02000226 RID: 550
				public class VRChatButtonLogin_4
				{
					// Token: 0x17000428 RID: 1064
					// (get) Token: 0x06000CBE RID: 3262 RVA: 0x00037801 File Offset: 0x00035A01
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/VRChatButtonLogin/Text");
						}
					}
				}

				// Token: 0x02000227 RID: 551
				public class ButtonCreate_4
				{
					// Token: 0x17000429 RID: 1065
					// (get) Token: 0x06000CC0 RID: 3264 RVA: 0x00037816 File Offset: 0x00035A16
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonCreate/Text");
						}
					}
				}

				// Token: 0x02000228 RID: 552
				public class ButtonBypass_4
				{
					// Token: 0x1700042A RID: 1066
					// (get) Token: 0x06000CC2 RID: 3266 RVA: 0x0003782B File Offset: 0x00035A2B
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonBypass/Text");
						}
					}
				}

				// Token: 0x02000229 RID: 553
				public class ButtonAboutUs_1_4
				{
					// Token: 0x1700042B RID: 1067
					// (get) Token: 0x06000CC4 RID: 3268 RVA: 0x00037840 File Offset: 0x00035A40
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonAboutUs (1)/Text");
						}
					}

					// Token: 0x1700042C RID: 1068
					// (get) Token: 0x06000CC5 RID: 3269 RVA: 0x0003784C File Offset: 0x00035A4C
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonAboutUs (1)/Image");
						}
					}

					// Token: 0x020002F3 RID: 755
					public class Image_5
					{
						// Token: 0x170005E3 RID: 1507
						// (get) Token: 0x06000F46 RID: 3910 RVA: 0x000393FA File Offset: 0x000375FA
						public static GameObject Text_
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonAboutUs (1)/Image/Text (3)");
							}
						}

						// Token: 0x170005E4 RID: 1508
						// (get) Token: 0x06000F47 RID: 3911 RVA: 0x00039406 File Offset: 0x00037606
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/ButtonAboutUs (1)/Image/Text");
							}
						}
					}
				}

				// Token: 0x0200022A RID: 554
				public class StoreButtonLogin_1_4
				{
					// Token: 0x1700042D RID: 1069
					// (get) Token: 0x06000CC7 RID: 3271 RVA: 0x00037861 File Offset: 0x00035A61
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/StoreButtonLogin (1)/Text");
						}
					}
				}

				// Token: 0x0200022B RID: 555
				public class LanguagePanel_4
				{
					// Token: 0x1700042E RID: 1070
					// (get) Token: 0x06000CC9 RID: 3273 RVA: 0x00037876 File Offset: 0x00035A76
					public static GameObject TitleText_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/LanguagePanel/TitleText (1)");
						}
					}

					// Token: 0x1700042F RID: 1071
					// (get) Token: 0x06000CCA RID: 3274 RVA: 0x00037882 File Offset: 0x00035A82
					public static GameObject SelectPrevLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/LanguagePanel/SelectPrevLang");
						}
					}

					// Token: 0x17000430 RID: 1072
					// (get) Token: 0x06000CCB RID: 3275 RVA: 0x0003788E File Offset: 0x00035A8E
					public static GameObject SelectNextLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/LanguagePanel/SelectNextLang");
						}
					}

					// Token: 0x17000431 RID: 1073
					// (get) Token: 0x06000CCC RID: 3276 RVA: 0x0003789A File Offset: 0x00035A9A
					public static GameObject Language
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/ViveportStoreLoginPrompt/LanguagePanel/Language");
						}
					}
				}
			}

			// Token: 0x02000192 RID: 402
			public class OculusStoreLoginPrompt_3
			{
				// Token: 0x17000228 RID: 552
				// (get) Token: 0x06000A2A RID: 2602 RVA: 0x00035ACD File Offset: 0x00033CCD
				public static GameObject VRChat_LOGO_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/VRChat_LOGO (1)");
					}
				}

				// Token: 0x17000229 RID: 553
				// (get) Token: 0x06000A2B RID: 2603 RVA: 0x00035AD9 File Offset: 0x00033CD9
				public static GameObject VRChatButtonLogin
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/VRChatButtonLogin");
					}
				}

				// Token: 0x1700022A RID: 554
				// (get) Token: 0x06000A2C RID: 2604 RVA: 0x00035AE5 File Offset: 0x00033CE5
				public static GameObject ButtonCreate
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonCreate");
					}
				}

				// Token: 0x1700022B RID: 555
				// (get) Token: 0x06000A2D RID: 2605 RVA: 0x00035AF1 File Offset: 0x00033CF1
				public static GameObject ButtonBypass
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonBypass");
					}
				}

				// Token: 0x1700022C RID: 556
				// (get) Token: 0x06000A2E RID: 2606 RVA: 0x00035AFD File Offset: 0x00033CFD
				public static GameObject TextWelcome
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/TextWelcome");
					}
				}

				// Token: 0x1700022D RID: 557
				// (get) Token: 0x06000A2F RID: 2607 RVA: 0x00035B09 File Offset: 0x00033D09
				public static GameObject TextVRChat
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/TextVRChat");
					}
				}

				// Token: 0x1700022E RID: 558
				// (get) Token: 0x06000A30 RID: 2608 RVA: 0x00035B15 File Offset: 0x00033D15
				public static GameObject TextOr_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/TextOr (1)");
					}
				}

				// Token: 0x1700022F RID: 559
				// (get) Token: 0x06000A31 RID: 2609 RVA: 0x00035B21 File Offset: 0x00033D21
				public static GameObject TextLoginWith_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/TextLoginWith (1)");
					}
				}

				// Token: 0x17000230 RID: 560
				// (get) Token: 0x06000A32 RID: 2610 RVA: 0x00035B2D File Offset: 0x00033D2D
				public static GameObject ButtonAboutUs_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonAboutUs (1)");
					}
				}

				// Token: 0x17000231 RID: 561
				// (get) Token: 0x06000A33 RID: 2611 RVA: 0x00035B39 File Offset: 0x00033D39
				public static GameObject StoreButtonLogin_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/StoreButtonLogin (1)");
					}
				}

				// Token: 0x17000232 RID: 562
				// (get) Token: 0x06000A34 RID: 2612 RVA: 0x00035B45 File Offset: 0x00033D45
				public static GameObject LanguagePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/LanguagePanel");
					}
				}

				// Token: 0x0200022C RID: 556
				public class VRChatButtonLogin_4
				{
					// Token: 0x17000432 RID: 1074
					// (get) Token: 0x06000CCE RID: 3278 RVA: 0x000378AF File Offset: 0x00035AAF
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/VRChatButtonLogin/Text");
						}
					}
				}

				// Token: 0x0200022D RID: 557
				public class ButtonCreate_4
				{
					// Token: 0x17000433 RID: 1075
					// (get) Token: 0x06000CD0 RID: 3280 RVA: 0x000378C4 File Offset: 0x00035AC4
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonCreate/Text");
						}
					}
				}

				// Token: 0x0200022E RID: 558
				public class ButtonBypass_4
				{
					// Token: 0x17000434 RID: 1076
					// (get) Token: 0x06000CD2 RID: 3282 RVA: 0x000378D9 File Offset: 0x00035AD9
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonBypass/Text");
						}
					}
				}

				// Token: 0x0200022F RID: 559
				public class ButtonAboutUs_1_4
				{
					// Token: 0x17000435 RID: 1077
					// (get) Token: 0x06000CD4 RID: 3284 RVA: 0x000378EE File Offset: 0x00035AEE
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonAboutUs (1)/Text");
						}
					}

					// Token: 0x17000436 RID: 1078
					// (get) Token: 0x06000CD5 RID: 3285 RVA: 0x000378FA File Offset: 0x00035AFA
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonAboutUs (1)/Image");
						}
					}

					// Token: 0x020002F4 RID: 756
					public class Image_5
					{
						// Token: 0x170005E5 RID: 1509
						// (get) Token: 0x06000F49 RID: 3913 RVA: 0x0003941B File Offset: 0x0003761B
						public static GameObject Text_
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonAboutUs (1)/Image/Text (3)");
							}
						}

						// Token: 0x170005E6 RID: 1510
						// (get) Token: 0x06000F4A RID: 3914 RVA: 0x00039427 File Offset: 0x00037627
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/ButtonAboutUs (1)/Image/Text");
							}
						}
					}
				}

				// Token: 0x02000230 RID: 560
				public class StoreButtonLogin_1_4
				{
					// Token: 0x17000437 RID: 1079
					// (get) Token: 0x06000CD7 RID: 3287 RVA: 0x0003790F File Offset: 0x00035B0F
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/StoreButtonLogin (1)/Text");
						}
					}
				}

				// Token: 0x02000231 RID: 561
				public class LanguagePanel_4
				{
					// Token: 0x17000438 RID: 1080
					// (get) Token: 0x06000CD9 RID: 3289 RVA: 0x00037924 File Offset: 0x00035B24
					public static GameObject TitleText_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/LanguagePanel/TitleText (1)");
						}
					}

					// Token: 0x17000439 RID: 1081
					// (get) Token: 0x06000CDA RID: 3290 RVA: 0x00037930 File Offset: 0x00035B30
					public static GameObject SelectPrevLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/LanguagePanel/SelectPrevLang");
						}
					}

					// Token: 0x1700043A RID: 1082
					// (get) Token: 0x06000CDB RID: 3291 RVA: 0x0003793C File Offset: 0x00035B3C
					public static GameObject SelectNextLang
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/LanguagePanel/SelectNextLang");
						}
					}

					// Token: 0x1700043B RID: 1083
					// (get) Token: 0x06000CDC RID: 3292 RVA: 0x00037948 File Offset: 0x00035B48
					public static GameObject Language
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Authentication/OculusStoreLoginPrompt/LanguagePanel/Language");
						}
					}
				}
			}
		}

		// Token: 0x0200015C RID: 348
		public class Avatar_2
		{
			// Token: 0x1700011A RID: 282
			// (get) Token: 0x060008D1 RID: 2257 RVA: 0x00034433 File Offset: 0x00032633
			public static GameObject TitlePanel_1
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/TitlePanel (1)");
				}
			}

			// Token: 0x1700011B RID: 283
			// (get) Token: 0x060008D2 RID: 2258 RVA: 0x0003443F File Offset: 0x0003263F
			public static GameObject Vertical_Scroll_View
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View");
				}
			}

			// Token: 0x1700011C RID: 284
			// (get) Token: 0x060008D3 RID: 2259 RVA: 0x0003444B File Offset: 0x0003264B
			public static GameObject Ticker
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Ticker");
				}
			}

			// Token: 0x1700011D RID: 285
			// (get) Token: 0x060008D4 RID: 2260 RVA: 0x00034457 File Offset: 0x00032657
			public static GameObject AvatarPreviewBase
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase");
				}
			}

			// Token: 0x1700011E RID: 286
			// (get) Token: 0x060008D5 RID: 2261 RVA: 0x00034463 File Offset: 0x00032663
			public static GameObject Select_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Select Button");
				}
			}

			// Token: 0x1700011F RID: 287
			// (get) Token: 0x060008D6 RID: 2262 RVA: 0x0003446F File Offset: 0x0003266F
			public static GameObject XplatHide_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/XplatHide Button");
				}
			}

			// Token: 0x17000120 RID: 288
			// (get) Token: 0x060008D7 RID: 2263 RVA: 0x0003447B File Offset: 0x0003267B
			public static GameObject Change_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Change Button");
				}
			}

			// Token: 0x17000121 RID: 289
			// (get) Token: 0x060008D8 RID: 2264 RVA: 0x00034487 File Offset: 0x00032687
			public static GameObject Fallback_Info
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Fallback Info");
				}
			}

			// Token: 0x17000122 RID: 290
			// (get) Token: 0x060008D9 RID: 2265 RVA: 0x00034493 File Offset: 0x00032693
			public static GameObject Move_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Move Button");
				}
			}

			// Token: 0x17000123 RID: 291
			// (get) Token: 0x060008DA RID: 2266 RVA: 0x0003449F File Offset: 0x0003269F
			public static GameObject Favorite_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button");
				}
			}

			// Token: 0x17000124 RID: 292
			// (get) Token: 0x060008DB RID: 2267 RVA: 0x000344AB File Offset: 0x000326AB
			public static GameObject Delete_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Delete Button");
				}
			}

			// Token: 0x17000125 RID: 293
			// (get) Token: 0x060008DC RID: 2268 RVA: 0x000344B7 File Offset: 0x000326B7
			public static GameObject AvatarUiPrefab2
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2");
				}
			}

			// Token: 0x17000126 RID: 294
			// (get) Token: 0x060008DD RID: 2269 RVA: 0x000344C3 File Offset: 0x000326C3
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/DepthOverlay");
				}
			}

			// Token: 0x17000127 RID: 295
			// (get) Token: 0x060008DE RID: 2270 RVA: 0x000344CF File Offset: 0x000326CF
			public static GameObject Stats_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Stats Button");
				}
			}

			// Token: 0x02000193 RID: 403
			public class TitlePanel_1_3
			{
				// Token: 0x17000233 RID: 563
				// (get) Token: 0x06000A36 RID: 2614 RVA: 0x00035B5A File Offset: 0x00033D5A
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/TitlePanel (1)/TitleText");
					}
				}
			}

			// Token: 0x02000194 RID: 404
			public class Ticker_3
			{
				// Token: 0x17000234 RID: 564
				// (get) Token: 0x06000A38 RID: 2616 RVA: 0x00035B6F File Offset: 0x00033D6F
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Ticker/Text");
					}
				}

				// Token: 0x17000235 RID: 565
				// (get) Token: 0x06000A39 RID: 2617 RVA: 0x00035B7B File Offset: 0x00033D7B
				public static GameObject TopLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Ticker/TopLine");
					}
				}

				// Token: 0x17000236 RID: 566
				// (get) Token: 0x06000A3A RID: 2618 RVA: 0x00035B87 File Offset: 0x00033D87
				public static GameObject TopLine_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Ticker/TopLine (1)");
					}
				}
			}

			// Token: 0x02000195 RID: 405
			public class AvatarPreviewBase_3
			{
				// Token: 0x17000237 RID: 567
				// (get) Token: 0x06000A3C RID: 2620 RVA: 0x00035B9C File Offset: 0x00033D9C
				public static GameObject MainRoot
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/MainRoot");
					}
				}

				// Token: 0x17000238 RID: 568
				// (get) Token: 0x06000A3D RID: 2621 RVA: 0x00035BA8 File Offset: 0x00033DA8
				public static GameObject FallbackRoot
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/FallbackRoot");
					}
				}

				// Token: 0x17000239 RID: 569
				// (get) Token: 0x06000A3E RID: 2622 RVA: 0x00035BB4 File Offset: 0x00033DB4
				public static GameObject EditPlayerDirLight
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/EditPlayerDirLight");
					}
				}

				// Token: 0x1700023A RID: 570
				// (get) Token: 0x06000A3F RID: 2623 RVA: 0x00035BC0 File Offset: 0x00033DC0
				public static GameObject FallbackThumbnail
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/FallbackThumbnail");
					}
				}

				// Token: 0x02000232 RID: 562
				public class MainRoot_4
				{
					// Token: 0x1700043C RID: 1084
					// (get) Token: 0x06000CDE RID: 3294 RVA: 0x0003795D File Offset: 0x00035B5D
					public static GameObject MainModel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/MainRoot/MainModel");
						}
					}
				}

				// Token: 0x02000233 RID: 563
				public class FallbackRoot_4
				{
					// Token: 0x1700043D RID: 1085
					// (get) Token: 0x06000CE0 RID: 3296 RVA: 0x00037972 File Offset: 0x00035B72
					public static GameObject FallbackModel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/FallbackRoot/FallbackModel");
						}
					}
				}

				// Token: 0x02000234 RID: 564
				public class FallbackThumbnail_4
				{
					// Token: 0x1700043E RID: 1086
					// (get) Token: 0x06000CE2 RID: 3298 RVA: 0x00037987 File Offset: 0x00035B87
					public static GameObject AvatarImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/FallbackThumbnail/AvatarImage");
						}
					}

					// Token: 0x1700043F RID: 1087
					// (get) Token: 0x06000CE3 RID: 3299 RVA: 0x00037993 File Offset: 0x00035B93
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase/FallbackThumbnail/Text");
						}
					}
				}
			}

			// Token: 0x02000196 RID: 406
			public class Select_Button_3
			{
				// Token: 0x1700023B RID: 571
				// (get) Token: 0x06000A41 RID: 2625 RVA: 0x00035BD5 File Offset: 0x00033DD5
				public static GameObject Label
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Select Button/Label");
					}
				}

				// Token: 0x1700023C RID: 572
				// (get) Token: 0x06000A42 RID: 2626 RVA: 0x00035BE1 File Offset: 0x00033DE1
				public static GameObject PlatformIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Select Button/PlatformIcon");
					}
				}
			}

			// Token: 0x02000197 RID: 407
			public class XplatHide_Button_3
			{
				// Token: 0x1700023D RID: 573
				// (get) Token: 0x06000A44 RID: 2628 RVA: 0x00035BF6 File Offset: 0x00033DF6
				public static GameObject Label
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/XplatHide Button/Label");
					}
				}

				// Token: 0x1700023E RID: 574
				// (get) Token: 0x06000A45 RID: 2629 RVA: 0x00035C02 File Offset: 0x00033E02
				public static GameObject PlatformIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/XplatHide Button/PlatformIcon");
					}
				}
			}

			// Token: 0x02000198 RID: 408
			public class Change_Button_3
			{
				// Token: 0x1700023F RID: 575
				// (get) Token: 0x06000A47 RID: 2631 RVA: 0x00035C17 File Offset: 0x00033E17
				public static GameObject Label
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Change Button/Label");
					}
				}

				// Token: 0x17000240 RID: 576
				// (get) Token: 0x06000A48 RID: 2632 RVA: 0x00035C23 File Offset: 0x00033E23
				public static GameObject PlatformAnyIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Change Button/PlatformAnyIcon");
					}
				}
			}

			// Token: 0x02000199 RID: 409
			public class Fallback_Info_3
			{
				// Token: 0x17000241 RID: 577
				// (get) Token: 0x06000A4A RID: 2634 RVA: 0x00035C38 File Offset: 0x00033E38
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Fallback Info/Text");
					}
				}
			}

			// Token: 0x0200019A RID: 410
			public class Move_Button_3
			{
				// Token: 0x17000242 RID: 578
				// (get) Token: 0x06000A4C RID: 2636 RVA: 0x00035C4D File Offset: 0x00033E4D
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Move Button/Text");
					}
				}
			}

			// Token: 0x0200019B RID: 411
			public class Favorite_Button_3
			{
				// Token: 0x17000243 RID: 579
				// (get) Token: 0x06000A4E RID: 2638 RVA: 0x00035C62 File Offset: 0x00033E62
				public static GameObject Horizontal
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal");
					}
				}

				// Token: 0x17000244 RID: 580
				// (get) Token: 0x06000A4F RID: 2639 RVA: 0x00035C6E File Offset: 0x00033E6E
				public static GameObject Icon_VRCPlus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Icon_VRC+");
					}
				}

				// Token: 0x02000235 RID: 565
				public class Horizontal_4
				{
					// Token: 0x17000440 RID: 1088
					// (get) Token: 0x06000CE5 RID: 3301 RVA: 0x000379A8 File Offset: 0x00035BA8
					public static GameObject FavoriteActionText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal/FavoriteActionText");
						}
					}

					// Token: 0x17000441 RID: 1089
					// (get) Token: 0x06000CE6 RID: 3302 RVA: 0x000379B4 File Offset: 0x00035BB4
					public static GameObject FavoritesCountSpacingText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal/FavoritesCountSpacingText");
						}
					}

					// Token: 0x17000442 RID: 1090
					// (get) Token: 0x06000CE7 RID: 3303 RVA: 0x000379C0 File Offset: 0x00035BC0
					public static GameObject FavoritesCurrentCountText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal/FavoritesCurrentCountText");
						}
					}

					// Token: 0x17000443 RID: 1091
					// (get) Token: 0x06000CE8 RID: 3304 RVA: 0x000379CC File Offset: 0x00035BCC
					public static GameObject FavoritesCountDividerText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal/FavoritesCountDividerText");
						}
					}

					// Token: 0x17000444 RID: 1092
					// (get) Token: 0x06000CE9 RID: 3305 RVA: 0x000379D8 File Offset: 0x00035BD8
					public static GameObject FavoritesMaxAvailableText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Favorite Button/Horizontal/FavoritesMaxAvailableText");
						}
					}
				}
			}

			// Token: 0x0200019C RID: 412
			public class Delete_Button_3
			{
				// Token: 0x17000245 RID: 581
				// (get) Token: 0x06000A51 RID: 2641 RVA: 0x00035C83 File Offset: 0x00033E83
				public static GameObject DeleteText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Delete Button/DeleteText");
					}
				}
			}

			// Token: 0x0200019D RID: 413
			public class AvatarUiPrefab2_3
			{
				// Token: 0x17000246 RID: 582
				// (get) Token: 0x06000A53 RID: 2643 RVA: 0x00035C98 File Offset: 0x00033E98
				public static GameObject RoomGlow
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/RoomGlow");
					}
				}

				// Token: 0x17000247 RID: 583
				// (get) Token: 0x06000A54 RID: 2644 RVA: 0x00035CA4 File Offset: 0x00033EA4
				public static GameObject RoomOutline
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/RoomOutline");
					}
				}

				// Token: 0x17000248 RID: 584
				// (get) Token: 0x06000A55 RID: 2645 RVA: 0x00035CB0 File Offset: 0x00033EB0
				public static GameObject RoomImageShape
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/RoomImageShape");
					}
				}

				// Token: 0x17000249 RID: 585
				// (get) Token: 0x06000A56 RID: 2646 RVA: 0x00035CBC File Offset: 0x00033EBC
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/TitleText");
					}
				}

				// Token: 0x02000236 RID: 566
				public class RoomImageShape_4
				{
					// Token: 0x17000445 RID: 1093
					// (get) Token: 0x06000CEB RID: 3307 RVA: 0x000379ED File Offset: 0x00035BED
					public static GameObject RoomImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/RoomImageShape/RoomImage");
						}
					}

					// Token: 0x020002F5 RID: 757
					public class RoomImage_5
					{
						// Token: 0x170005E7 RID: 1511
						// (get) Token: 0x06000F4C RID: 3916 RVA: 0x0003943C File Offset: 0x0003763C
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/AvatarUiPrefab2/RoomImageShape/RoomImage/Panel");
							}
						}
					}
				}
			}

			// Token: 0x0200019E RID: 414
			public class Stats_Button_3
			{
				// Token: 0x1700024A RID: 586
				// (get) Token: 0x06000A58 RID: 2648 RVA: 0x00035CD1 File Offset: 0x00033ED1
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Stats Button/Text");
					}
				}

				// Token: 0x1700024B RID: 587
				// (get) Token: 0x06000A59 RID: 2649 RVA: 0x00035CDD File Offset: 0x00033EDD
				public static GameObject PerfIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Stats Button/PerfIcon");
					}
				}
			}
		}

		// Token: 0x0200015D RID: 349
		public class FirstLogin_2
		{
			// Token: 0x17000128 RID: 296
			// (get) Token: 0x060008E0 RID: 2272 RVA: 0x000344E4 File Offset: 0x000326E4
			public static GameObject TutorialLaunch
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch");
				}
			}

			// Token: 0x0200019F RID: 415
			public class TutorialLaunch_3
			{
				// Token: 0x1700024C RID: 588
				// (get) Token: 0x06000A5B RID: 2651 RVA: 0x00035CF2 File Offset: 0x00033EF2
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel");
					}
				}

				// Token: 0x1700024D RID: 589
				// (get) Token: 0x06000A5C RID: 2652 RVA: 0x00035CFE File Offset: 0x00033EFE
				public static GameObject ButtonDone
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/ButtonDone");
					}
				}

				// Token: 0x1700024E RID: 590
				// (get) Token: 0x06000A5D RID: 2653 RVA: 0x00035D0A File Offset: 0x00033F0A
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/TitleText");
					}
				}

				// Token: 0x1700024F RID: 591
				// (get) Token: 0x06000A5E RID: 2654 RVA: 0x00035D16 File Offset: 0x00033F16
				public static GameObject BodyTextMouse
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/BodyTextMouse");
					}
				}

				// Token: 0x02000237 RID: 567
				public class Panel_4
				{
					// Token: 0x17000446 RID: 1094
					// (get) Token: 0x06000CED RID: 3309 RVA: 0x00037A02 File Offset: 0x00035C02
					public static GameObject Rectangle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/Rectangle");
						}
					}

					// Token: 0x17000447 RID: 1095
					// (get) Token: 0x06000CEE RID: 3310 RVA: 0x00037A0E File Offset: 0x00035C0E
					public static GameObject MidRing
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/MidRing");
						}
					}

					// Token: 0x17000448 RID: 1096
					// (get) Token: 0x06000CEF RID: 3311 RVA: 0x00037A1A File Offset: 0x00035C1A
					public static GameObject InnerDashRing
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/InnerDashRing");
						}
					}

					// Token: 0x17000449 RID: 1097
					// (get) Token: 0x06000CF0 RID: 3312 RVA: 0x00037A26 File Offset: 0x00035C26
					public static GameObject RingGlow
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/RingGlow");
						}
					}

					// Token: 0x1700044A RID: 1098
					// (get) Token: 0x06000CF1 RID: 3313 RVA: 0x00037A32 File Offset: 0x00035C32
					public static GameObject ArrowLeft
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/ArrowLeft");
						}
					}

					// Token: 0x1700044B RID: 1099
					// (get) Token: 0x06000CF2 RID: 3314 RVA: 0x00037A3E File Offset: 0x00035C3E
					public static GameObject ArrowRight
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/ArrowRight");
						}
					}

					// Token: 0x1700044C RID: 1100
					// (get) Token: 0x06000CF3 RID: 3315 RVA: 0x00037A4A File Offset: 0x00035C4A
					public static GameObject CornerBL
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/CornerBL");
						}
					}

					// Token: 0x1700044D RID: 1101
					// (get) Token: 0x06000CF4 RID: 3316 RVA: 0x00037A56 File Offset: 0x00035C56
					public static GameObject CornerTL
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/CornerTL");
						}
					}

					// Token: 0x1700044E RID: 1102
					// (get) Token: 0x06000CF5 RID: 3317 RVA: 0x00037A62 File Offset: 0x00035C62
					public static GameObject CornerBR
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/CornerBR");
						}
					}

					// Token: 0x1700044F RID: 1103
					// (get) Token: 0x06000CF6 RID: 3318 RVA: 0x00037A6E File Offset: 0x00035C6E
					public static GameObject CornerTR
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/Panel/CornerTR");
						}
					}
				}

				// Token: 0x02000238 RID: 568
				public class ButtonDone_4
				{
					// Token: 0x17000450 RID: 1104
					// (get) Token: 0x06000CF8 RID: 3320 RVA: 0x00037A83 File Offset: 0x00035C83
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/FirstLogin/TutorialLaunch/ButtonDone/Text");
						}
					}
				}
			}
		}

		// Token: 0x0200015E RID: 350
		public class Playlists_2
		{
			// Token: 0x17000129 RID: 297
			// (get) Token: 0x060008E2 RID: 2274 RVA: 0x000344F9 File Offset: 0x000326F9
			public static GameObject Vertical_Scroll_View
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Vertical Scroll View");
				}
			}

			// Token: 0x1700012A RID: 298
			// (get) Token: 0x060008E3 RID: 2275 RVA: 0x00034505 File Offset: 0x00032705
			public static GameObject Header
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header");
				}
			}

			// Token: 0x1700012B RID: 299
			// (get) Token: 0x060008E4 RID: 2276 RVA: 0x00034511 File Offset: 0x00032711
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/DepthOverlay");
				}
			}

			// Token: 0x020001A0 RID: 416
			public class Header_3
			{
				// Token: 0x17000250 RID: 592
				// (get) Token: 0x06000A60 RID: 2656 RVA: 0x00035D2B File Offset: 0x00033F2B
				public static GameObject TitlePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/TitlePanel");
					}
				}

				// Token: 0x17000251 RID: 593
				// (get) Token: 0x06000A61 RID: 2657 RVA: 0x00035D37 File Offset: 0x00033F37
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/TitleText");
					}
				}

				// Token: 0x17000252 RID: 594
				// (get) Token: 0x06000A62 RID: 2658 RVA: 0x00035D43 File Offset: 0x00033F43
				public static GameObject BackButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/BackButton");
					}
				}

				// Token: 0x17000253 RID: 595
				// (get) Token: 0x06000A63 RID: 2659 RVA: 0x00035D4F File Offset: 0x00033F4F
				public static GameObject TopLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/TopLine");
					}
				}

				// Token: 0x17000254 RID: 596
				// (get) Token: 0x06000A64 RID: 2660 RVA: 0x00035D5B File Offset: 0x00033F5B
				public static GameObject BottomLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/BottomLine");
					}
				}

				// Token: 0x02000239 RID: 569
				public class BackButton_4
				{
					// Token: 0x17000451 RID: 1105
					// (get) Token: 0x06000CFA RID: 3322 RVA: 0x00037A98 File Offset: 0x00035C98
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Playlists/Header/BackButton/Text");
						}
					}
				}
			}
		}

		// Token: 0x0200015F RID: 351
		public class Settings_Safety_2
		{
			// Token: 0x1700012C RID: 300
			// (get) Token: 0x060008E6 RID: 2278 RVA: 0x00034526 File Offset: 0x00032726
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/TitlePanel");
				}
			}

			// Token: 0x1700012D RID: 301
			// (get) Token: 0x060008E7 RID: 2279 RVA: 0x00034532 File Offset: 0x00032732
			public static GameObject _Buttons_SafetyLevel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel");
				}
			}

			// Token: 0x1700012E RID: 302
			// (get) Token: 0x060008E8 RID: 2280 RVA: 0x0003453E File Offset: 0x0003273E
			public static GameObject _Description_SafetyLevel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Description_SafetyLevel");
				}
			}

			// Token: 0x1700012F RID: 303
			// (get) Token: 0x060008E9 RID: 2281 RVA: 0x0003454A File Offset: 0x0003274A
			public static GameObject _SafetyMatrix
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix");
				}
			}

			// Token: 0x17000130 RID: 304
			// (get) Token: 0x060008EA RID: 2282 RVA: 0x00034556 File Offset: 0x00032756
			public static GameObject Button_Reset
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/Button_Reset");
				}
			}

			// Token: 0x17000131 RID: 305
			// (get) Token: 0x060008EB RID: 2283 RVA: 0x00034562 File Offset: 0x00032762
			public static GameObject _Buttons_UserLevel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel");
				}
			}

			// Token: 0x17000132 RID: 306
			// (get) Token: 0x060008EC RID: 2284 RVA: 0x0003456E File Offset: 0x0003276E
			public static GameObject _UserLevel_Tooltip
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_UserLevel_Tooltip");
				}
			}

			// Token: 0x17000133 RID: 307
			// (get) Token: 0x060008ED RID: 2285 RVA: 0x0003457A File Offset: 0x0003277A
			public static GameObject _Notification_CloseMenu
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Notification_CloseMenu");
				}
			}

			// Token: 0x020001A1 RID: 417
			public class TitlePanel_3
			{
				// Token: 0x17000255 RID: 597
				// (get) Token: 0x06000A66 RID: 2662 RVA: 0x00035D70 File Offset: 0x00033F70
				public static GameObject Button_PerformanceOptions
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/TitlePanel/Button_PerformanceOptions");
					}
				}

				// Token: 0x17000256 RID: 598
				// (get) Token: 0x06000A67 RID: 2663 RVA: 0x00035D7C File Offset: 0x00033F7C
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/TitlePanel/TitleText");
					}
				}

				// Token: 0x0200023A RID: 570
				public class Button_PerformanceOptions_4
				{
					// Token: 0x17000452 RID: 1106
					// (get) Token: 0x06000CFC RID: 3324 RVA: 0x00037AAD File Offset: 0x00035CAD
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/TitlePanel/Button_PerformanceOptions/Text");
						}
					}
				}
			}

			// Token: 0x020001A2 RID: 418
			public class _Buttons_SafetyLevel_3
			{
				// Token: 0x17000257 RID: 599
				// (get) Token: 0x06000A69 RID: 2665 RVA: 0x00035D91 File Offset: 0x00033F91
				public static GameObject Button_Maxiumum
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Maxiumum");
					}
				}

				// Token: 0x17000258 RID: 600
				// (get) Token: 0x06000A6A RID: 2666 RVA: 0x00035D9D File Offset: 0x00033F9D
				public static GameObject Button_Cautious
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Cautious");
					}
				}

				// Token: 0x17000259 RID: 601
				// (get) Token: 0x06000A6B RID: 2667 RVA: 0x00035DA9 File Offset: 0x00033FA9
				public static GameObject Button_Normal
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Normal");
					}
				}

				// Token: 0x1700025A RID: 602
				// (get) Token: 0x06000A6C RID: 2668 RVA: 0x00035DB5 File Offset: 0x00033FB5
				public static GameObject Button_Limited
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Limited");
					}
				}

				// Token: 0x1700025B RID: 603
				// (get) Token: 0x06000A6D RID: 2669 RVA: 0x00035DC1 File Offset: 0x00033FC1
				public static GameObject Button_None
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_None");
					}
				}

				// Token: 0x1700025C RID: 604
				// (get) Token: 0x06000A6E RID: 2670 RVA: 0x00035DCD File Offset: 0x00033FCD
				public static GameObject Button_Custom
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Custom");
					}
				}

				// Token: 0x0200023B RID: 571
				public class Button_Maxiumum_4
				{
					// Token: 0x17000453 RID: 1107
					// (get) Token: 0x06000CFE RID: 3326 RVA: 0x00037AC2 File Offset: 0x00035CC2
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Maxiumum/OFF");
						}
					}

					// Token: 0x17000454 RID: 1108
					// (get) Token: 0x06000CFF RID: 3327 RVA: 0x00037ACE File Offset: 0x00035CCE
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Maxiumum/ON");
						}
					}
				}

				// Token: 0x0200023C RID: 572
				public class Button_Cautious_4
				{
					// Token: 0x17000455 RID: 1109
					// (get) Token: 0x06000D01 RID: 3329 RVA: 0x00037AE3 File Offset: 0x00035CE3
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Cautious/OFF");
						}
					}

					// Token: 0x17000456 RID: 1110
					// (get) Token: 0x06000D02 RID: 3330 RVA: 0x00037AEF File Offset: 0x00035CEF
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Cautious/ON");
						}
					}
				}

				// Token: 0x0200023D RID: 573
				public class Button_Normal_4
				{
					// Token: 0x17000457 RID: 1111
					// (get) Token: 0x06000D04 RID: 3332 RVA: 0x00037B04 File Offset: 0x00035D04
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Normal/OFF");
						}
					}

					// Token: 0x17000458 RID: 1112
					// (get) Token: 0x06000D05 RID: 3333 RVA: 0x00037B10 File Offset: 0x00035D10
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Normal/ON");
						}
					}
				}

				// Token: 0x0200023E RID: 574
				public class Button_Limited_4
				{
					// Token: 0x17000459 RID: 1113
					// (get) Token: 0x06000D07 RID: 3335 RVA: 0x00037B25 File Offset: 0x00035D25
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Limited/OFF");
						}
					}

					// Token: 0x1700045A RID: 1114
					// (get) Token: 0x06000D08 RID: 3336 RVA: 0x00037B31 File Offset: 0x00035D31
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Limited/ON");
						}
					}
				}

				// Token: 0x0200023F RID: 575
				public class Button_None_4
				{
					// Token: 0x1700045B RID: 1115
					// (get) Token: 0x06000D0A RID: 3338 RVA: 0x00037B46 File Offset: 0x00035D46
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_None/OFF");
						}
					}

					// Token: 0x1700045C RID: 1116
					// (get) Token: 0x06000D0B RID: 3339 RVA: 0x00037B52 File Offset: 0x00035D52
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_None/ON");
						}
					}
				}

				// Token: 0x02000240 RID: 576
				public class Button_Custom_4
				{
					// Token: 0x1700045D RID: 1117
					// (get) Token: 0x06000D0D RID: 3341 RVA: 0x00037B67 File Offset: 0x00035D67
					public static GameObject OFF
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Custom/OFF");
						}
					}

					// Token: 0x1700045E RID: 1118
					// (get) Token: 0x06000D0E RID: 3342 RVA: 0x00037B73 File Offset: 0x00035D73
					public static GameObject ON
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_SafetyLevel/Button_Custom/ON");
						}
					}
				}
			}

			// Token: 0x020001A3 RID: 419
			public class _Description_SafetyLevel_3
			{
				// Token: 0x1700025D RID: 605
				// (get) Token: 0x06000A70 RID: 2672 RVA: 0x00035DE2 File Offset: 0x00033FE2
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Description_SafetyLevel/Text");
					}
				}
			}

			// Token: 0x020001A4 RID: 420
			public class _SafetyMatrix_3
			{
				// Token: 0x1700025E RID: 606
				// (get) Token: 0x06000A72 RID: 2674 RVA: 0x00035DF7 File Offset: 0x00033FF7
				public static GameObject SocialRankBG
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/SocialRankBG");
					}
				}

				// Token: 0x1700025F RID: 607
				// (get) Token: 0x06000A73 RID: 2675 RVA: 0x00035E03 File Offset: 0x00034003
				public static GameObject _Bracket
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Bracket");
					}
				}

				// Token: 0x17000260 RID: 608
				// (get) Token: 0x06000A74 RID: 2676 RVA: 0x00035E0F File Offset: 0x0003400F
				public static GameObject _Toggles
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles");
					}
				}

				// Token: 0x02000241 RID: 577
				public class _Bracket_4
				{
					// Token: 0x1700045F RID: 1119
					// (get) Token: 0x06000D10 RID: 3344 RVA: 0x00037B88 File Offset: 0x00035D88
					public static GameObject SocialRankBorder
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Bracket/SocialRankBorder");
						}
					}
				}

				// Token: 0x02000242 RID: 578
				public class _Toggles_4
				{
					// Token: 0x17000460 RID: 1120
					// (get) Token: 0x06000D12 RID: 3346 RVA: 0x00037B9D File Offset: 0x00035D9D
					public static GameObject Toggle_voice
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice");
						}
					}

					// Token: 0x17000461 RID: 1121
					// (get) Token: 0x06000D13 RID: 3347 RVA: 0x00037BA9 File Offset: 0x00035DA9
					public static GameObject Toggle_Avatar
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar");
						}
					}

					// Token: 0x17000462 RID: 1122
					// (get) Token: 0x06000D14 RID: 3348 RVA: 0x00037BB5 File Offset: 0x00035DB5
					public static GameObject Toggle_UserIcons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons");
						}
					}

					// Token: 0x17000463 RID: 1123
					// (get) Token: 0x06000D15 RID: 3349 RVA: 0x00037BC1 File Offset: 0x00035DC1
					public static GameObject Toggle_Audio
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio");
						}
					}

					// Token: 0x17000464 RID: 1124
					// (get) Token: 0x06000D16 RID: 3350 RVA: 0x00037BCD File Offset: 0x00035DCD
					public static GameObject Toggle_Particles
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles");
						}
					}

					// Token: 0x17000465 RID: 1125
					// (get) Token: 0x06000D17 RID: 3351 RVA: 0x00037BD9 File Offset: 0x00035DD9
					public static GameObject Toggle_Shaders
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders");
						}
					}

					// Token: 0x17000466 RID: 1126
					// (get) Token: 0x06000D18 RID: 3352 RVA: 0x00037BE5 File Offset: 0x00035DE5
					public static GameObject Toggle_CustomAnimations
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations");
						}
					}

					// Token: 0x020002F6 RID: 758
					public class Toggle_voice_5
					{
						// Token: 0x170005E8 RID: 1512
						// (get) Token: 0x06000F4E RID: 3918 RVA: 0x00039451 File Offset: 0x00037651
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice/Panel");
							}
						}

						// Token: 0x170005E9 RID: 1513
						// (get) Token: 0x06000F4F RID: 3919 RVA: 0x0003945D File Offset: 0x0003765D
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice/Text_Header");
							}
						}

						// Token: 0x170005EA RID: 1514
						// (get) Token: 0x06000F50 RID: 3920 RVA: 0x00039469 File Offset: 0x00037669
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice/Text_onOff");
							}
						}

						// Token: 0x170005EB RID: 1515
						// (get) Token: 0x06000F51 RID: 3921 RVA: 0x00039475 File Offset: 0x00037675
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice/RawImage");
							}
						}

						// Token: 0x170005EC RID: 1516
						// (get) Token: 0x06000F52 RID: 3922 RVA: 0x00039481 File Offset: 0x00037681
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_voice/Toggle_Image");
							}
						}
					}

					// Token: 0x020002F7 RID: 759
					public class Toggle_Avatar_5
					{
						// Token: 0x170005ED RID: 1517
						// (get) Token: 0x06000F54 RID: 3924 RVA: 0x00039496 File Offset: 0x00037696
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar/Panel");
							}
						}

						// Token: 0x170005EE RID: 1518
						// (get) Token: 0x06000F55 RID: 3925 RVA: 0x000394A2 File Offset: 0x000376A2
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar/Text_Header");
							}
						}

						// Token: 0x170005EF RID: 1519
						// (get) Token: 0x06000F56 RID: 3926 RVA: 0x000394AE File Offset: 0x000376AE
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar/Text_onOff");
							}
						}

						// Token: 0x170005F0 RID: 1520
						// (get) Token: 0x06000F57 RID: 3927 RVA: 0x000394BA File Offset: 0x000376BA
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar/RawImage");
							}
						}

						// Token: 0x170005F1 RID: 1521
						// (get) Token: 0x06000F58 RID: 3928 RVA: 0x000394C6 File Offset: 0x000376C6
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Avatar/Toggle_Image");
							}
						}
					}

					// Token: 0x020002F8 RID: 760
					public class Toggle_UserIcons_5
					{
						// Token: 0x170005F2 RID: 1522
						// (get) Token: 0x06000F5A RID: 3930 RVA: 0x000394DB File Offset: 0x000376DB
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons/Panel");
							}
						}

						// Token: 0x170005F3 RID: 1523
						// (get) Token: 0x06000F5B RID: 3931 RVA: 0x000394E7 File Offset: 0x000376E7
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons/Text_Header");
							}
						}

						// Token: 0x170005F4 RID: 1524
						// (get) Token: 0x06000F5C RID: 3932 RVA: 0x000394F3 File Offset: 0x000376F3
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons/Text_onOff");
							}
						}

						// Token: 0x170005F5 RID: 1525
						// (get) Token: 0x06000F5D RID: 3933 RVA: 0x000394FF File Offset: 0x000376FF
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons/RawImage");
							}
						}

						// Token: 0x170005F6 RID: 1526
						// (get) Token: 0x06000F5E RID: 3934 RVA: 0x0003950B File Offset: 0x0003770B
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_UserIcons/Toggle_Image");
							}
						}
					}

					// Token: 0x020002F9 RID: 761
					public class Toggle_Audio_5
					{
						// Token: 0x170005F7 RID: 1527
						// (get) Token: 0x06000F60 RID: 3936 RVA: 0x00039520 File Offset: 0x00037720
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio/Panel");
							}
						}

						// Token: 0x170005F8 RID: 1528
						// (get) Token: 0x06000F61 RID: 3937 RVA: 0x0003952C File Offset: 0x0003772C
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio/Text_Header");
							}
						}

						// Token: 0x170005F9 RID: 1529
						// (get) Token: 0x06000F62 RID: 3938 RVA: 0x00039538 File Offset: 0x00037738
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio/Text_onOff");
							}
						}

						// Token: 0x170005FA RID: 1530
						// (get) Token: 0x06000F63 RID: 3939 RVA: 0x00039544 File Offset: 0x00037744
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio/RawImage");
							}
						}

						// Token: 0x170005FB RID: 1531
						// (get) Token: 0x06000F64 RID: 3940 RVA: 0x00039550 File Offset: 0x00037750
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Audio/Toggle_Image");
							}
						}
					}

					// Token: 0x020002FA RID: 762
					public class Toggle_Particles_5
					{
						// Token: 0x170005FC RID: 1532
						// (get) Token: 0x06000F66 RID: 3942 RVA: 0x00039565 File Offset: 0x00037765
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles/Panel");
							}
						}

						// Token: 0x170005FD RID: 1533
						// (get) Token: 0x06000F67 RID: 3943 RVA: 0x00039571 File Offset: 0x00037771
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles/Text_Header");
							}
						}

						// Token: 0x170005FE RID: 1534
						// (get) Token: 0x06000F68 RID: 3944 RVA: 0x0003957D File Offset: 0x0003777D
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles/Text_onOff");
							}
						}

						// Token: 0x170005FF RID: 1535
						// (get) Token: 0x06000F69 RID: 3945 RVA: 0x00039589 File Offset: 0x00037789
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles/RawImage");
							}
						}

						// Token: 0x17000600 RID: 1536
						// (get) Token: 0x06000F6A RID: 3946 RVA: 0x00039595 File Offset: 0x00037795
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Particles/Toggle_Image");
							}
						}
					}

					// Token: 0x020002FB RID: 763
					public class Toggle_Shaders_5
					{
						// Token: 0x17000601 RID: 1537
						// (get) Token: 0x06000F6C RID: 3948 RVA: 0x000395AA File Offset: 0x000377AA
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders/Panel");
							}
						}

						// Token: 0x17000602 RID: 1538
						// (get) Token: 0x06000F6D RID: 3949 RVA: 0x000395B6 File Offset: 0x000377B6
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders/Text_Header");
							}
						}

						// Token: 0x17000603 RID: 1539
						// (get) Token: 0x06000F6E RID: 3950 RVA: 0x000395C2 File Offset: 0x000377C2
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders/Text_onOff");
							}
						}

						// Token: 0x17000604 RID: 1540
						// (get) Token: 0x06000F6F RID: 3951 RVA: 0x000395CE File Offset: 0x000377CE
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders/RawImage");
							}
						}

						// Token: 0x17000605 RID: 1541
						// (get) Token: 0x06000F70 RID: 3952 RVA: 0x000395DA File Offset: 0x000377DA
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_Shaders/Toggle_Image");
							}
						}
					}

					// Token: 0x020002FC RID: 764
					public class Toggle_CustomAnimations_5
					{
						// Token: 0x17000606 RID: 1542
						// (get) Token: 0x06000F72 RID: 3954 RVA: 0x000395EF File Offset: 0x000377EF
						public static GameObject Panel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations/Panel");
							}
						}

						// Token: 0x17000607 RID: 1543
						// (get) Token: 0x06000F73 RID: 3955 RVA: 0x000395FB File Offset: 0x000377FB
						public static GameObject Text_Header
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations/Text_Header");
							}
						}

						// Token: 0x17000608 RID: 1544
						// (get) Token: 0x06000F74 RID: 3956 RVA: 0x00039607 File Offset: 0x00037807
						public static GameObject Text_onOff
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations/Text_onOff");
							}
						}

						// Token: 0x17000609 RID: 1545
						// (get) Token: 0x06000F75 RID: 3957 RVA: 0x00039613 File Offset: 0x00037813
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations/RawImage");
							}
						}

						// Token: 0x1700060A RID: 1546
						// (get) Token: 0x06000F76 RID: 3958 RVA: 0x0003961F File Offset: 0x0003781F
						public static GameObject Toggle_Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_SafetyMatrix/_Toggles/Toggle_CustomAnimations/Toggle_Image");
							}
						}
					}
				}
			}

			// Token: 0x020001A5 RID: 421
			public class Button_Reset_3
			{
				// Token: 0x17000261 RID: 609
				// (get) Token: 0x06000A76 RID: 2678 RVA: 0x00035E24 File Offset: 0x00034024
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/Button_Reset/Text");
					}
				}
			}

			// Token: 0x020001A6 RID: 422
			public class _Buttons_UserLevel_3
			{
				// Token: 0x17000262 RID: 610
				// (get) Token: 0x06000A78 RID: 2680 RVA: 0x00035E39 File Offset: 0x00034039
				public static GameObject Button_Visitor
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Visitor");
					}
				}

				// Token: 0x17000263 RID: 611
				// (get) Token: 0x06000A79 RID: 2681 RVA: 0x00035E45 File Offset: 0x00034045
				public static GameObject Button_New
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_New");
					}
				}

				// Token: 0x17000264 RID: 612
				// (get) Token: 0x06000A7A RID: 2682 RVA: 0x00035E51 File Offset: 0x00034051
				public static GameObject Button_User
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_User");
					}
				}

				// Token: 0x17000265 RID: 613
				// (get) Token: 0x06000A7B RID: 2683 RVA: 0x00035E5D File Offset: 0x0003405D
				public static GameObject Button_Trusted
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Trusted");
					}
				}

				// Token: 0x17000266 RID: 614
				// (get) Token: 0x06000A7C RID: 2684 RVA: 0x00035E69 File Offset: 0x00034069
				public static GameObject Button_Advanced
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Advanced");
					}
				}

				// Token: 0x17000267 RID: 615
				// (get) Token: 0x06000A7D RID: 2685 RVA: 0x00035E75 File Offset: 0x00034075
				public static GameObject Button_Friends
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Friends");
					}
				}

				// Token: 0x02000243 RID: 579
				public class Button_Visitor_4
				{
					// Token: 0x17000467 RID: 1127
					// (get) Token: 0x06000D1A RID: 3354 RVA: 0x00037BFA File Offset: 0x00035DFA
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Visitor/Connector");
						}
					}

					// Token: 0x17000468 RID: 1128
					// (get) Token: 0x06000D1B RID: 3355 RVA: 0x00037C06 File Offset: 0x00035E06
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Visitor/Text");
						}
					}
				}

				// Token: 0x02000244 RID: 580
				public class Button_New_4
				{
					// Token: 0x17000469 RID: 1129
					// (get) Token: 0x06000D1D RID: 3357 RVA: 0x00037C1B File Offset: 0x00035E1B
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_New/Connector");
						}
					}

					// Token: 0x1700046A RID: 1130
					// (get) Token: 0x06000D1E RID: 3358 RVA: 0x00037C27 File Offset: 0x00035E27
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_New/Text");
						}
					}
				}

				// Token: 0x02000245 RID: 581
				public class Button_User_4
				{
					// Token: 0x1700046B RID: 1131
					// (get) Token: 0x06000D20 RID: 3360 RVA: 0x00037C3C File Offset: 0x00035E3C
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_User/Connector");
						}
					}

					// Token: 0x1700046C RID: 1132
					// (get) Token: 0x06000D21 RID: 3361 RVA: 0x00037C48 File Offset: 0x00035E48
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_User/Text");
						}
					}
				}

				// Token: 0x02000246 RID: 582
				public class Button_Trusted_4
				{
					// Token: 0x1700046D RID: 1133
					// (get) Token: 0x06000D23 RID: 3363 RVA: 0x00037C5D File Offset: 0x00035E5D
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Trusted/Connector");
						}
					}

					// Token: 0x1700046E RID: 1134
					// (get) Token: 0x06000D24 RID: 3364 RVA: 0x00037C69 File Offset: 0x00035E69
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Trusted/Text");
						}
					}
				}

				// Token: 0x02000247 RID: 583
				public class Button_Advanced_4
				{
					// Token: 0x1700046F RID: 1135
					// (get) Token: 0x06000D26 RID: 3366 RVA: 0x00037C7E File Offset: 0x00035E7E
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Advanced/Connector");
						}
					}

					// Token: 0x17000470 RID: 1136
					// (get) Token: 0x06000D27 RID: 3367 RVA: 0x00037C8A File Offset: 0x00035E8A
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Advanced/Text");
						}
					}
				}

				// Token: 0x02000248 RID: 584
				public class Button_Friends_4
				{
					// Token: 0x17000471 RID: 1137
					// (get) Token: 0x06000D29 RID: 3369 RVA: 0x00037C9F File Offset: 0x00035E9F
					public static GameObject Connector
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Friends/Connector");
						}
					}

					// Token: 0x17000472 RID: 1138
					// (get) Token: 0x06000D2A RID: 3370 RVA: 0x00037CAB File Offset: 0x00035EAB
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Buttons_UserLevel/Button_Friends/Text");
						}
					}
				}
			}

			// Token: 0x020001A7 RID: 423
			public class _UserLevel_Tooltip_3
			{
				// Token: 0x17000268 RID: 616
				// (get) Token: 0x06000A7F RID: 2687 RVA: 0x00035E8A File Offset: 0x0003408A
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_UserLevel_Tooltip/Panel");
					}
				}

				// Token: 0x17000269 RID: 617
				// (get) Token: 0x06000A80 RID: 2688 RVA: 0x00035E96 File Offset: 0x00034096
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_UserLevel_Tooltip/Text");
					}
				}
			}

			// Token: 0x020001A8 RID: 424
			public class _Notification_CloseMenu_3
			{
				// Token: 0x1700026A RID: 618
				// (get) Token: 0x06000A82 RID: 2690 RVA: 0x00035EAB File Offset: 0x000340AB
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings_Safety/_Notification_CloseMenu/Text");
					}
				}
			}
		}

		// Token: 0x02000160 RID: 352
		public class Settings_2
		{
			// Token: 0x17000134 RID: 308
			// (get) Token: 0x060008EF RID: 2287 RVA: 0x0003458F File Offset: 0x0003278F
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/TitlePanel");
				}
			}

			// Token: 0x17000135 RID: 309
			// (get) Token: 0x060008F0 RID: 2288 RVA: 0x0003459B File Offset: 0x0003279B
			public static GameObject ComfortSafetyPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel");
				}
			}

			// Token: 0x17000136 RID: 310
			// (get) Token: 0x060008F1 RID: 2289 RVA: 0x000345A7 File Offset: 0x000327A7
			public static GameObject AudioDevicePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel");
				}
			}

			// Token: 0x17000137 RID: 311
			// (get) Token: 0x060008F2 RID: 2290 RVA: 0x000345B3 File Offset: 0x000327B3
			public static GameObject MousePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel");
				}
			}

			// Token: 0x17000138 RID: 312
			// (get) Token: 0x060008F3 RID: 2291 RVA: 0x000345BF File Offset: 0x000327BF
			public static GameObject HeightPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel");
				}
			}

			// Token: 0x17000139 RID: 313
			// (get) Token: 0x060008F4 RID: 2292 RVA: 0x000345CB File Offset: 0x000327CB
			public static GameObject VoiceOptionsPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel");
				}
			}

			// Token: 0x1700013A RID: 314
			// (get) Token: 0x060008F5 RID: 2293 RVA: 0x000345D7 File Offset: 0x000327D7
			public static GameObject OtherOptionsPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel");
				}
			}

			// Token: 0x1700013B RID: 315
			// (get) Token: 0x060008F6 RID: 2294 RVA: 0x000345E3 File Offset: 0x000327E3
			public static GameObject VolumePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel");
				}
			}

			// Token: 0x1700013C RID: 316
			// (get) Token: 0x060008F7 RID: 2295 RVA: 0x000345EF File Offset: 0x000327EF
			public static GameObject Footer
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer");
				}
			}

			// Token: 0x1700013D RID: 317
			// (get) Token: 0x060008F8 RID: 2296 RVA: 0x000345FB File Offset: 0x000327FB
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/DepthOverlay");
				}
			}

			// Token: 0x1700013E RID: 318
			// (get) Token: 0x060008F9 RID: 2297 RVA: 0x00034607 File Offset: 0x00032807
			public static GameObject Button_AdvancedOptions
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Button_AdvancedOptions");
				}
			}

			// Token: 0x1700013F RID: 319
			// (get) Token: 0x060008FA RID: 2298 RVA: 0x00034613 File Offset: 0x00032813
			public static GameObject Button_EditBindings
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Button_EditBindings");
				}
			}

			// Token: 0x17000140 RID: 320
			// (get) Token: 0x060008FB RID: 2299 RVA: 0x0003461F File Offset: 0x0003281F
			public static GameObject UserVolumeOptions
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/UserVolumeOptions");
				}
			}

			// Token: 0x020001A9 RID: 425
			public class TitlePanel_3
			{
				// Token: 0x1700026B RID: 619
				// (get) Token: 0x06000A84 RID: 2692 RVA: 0x00035EC0 File Offset: 0x000340C0
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/TitlePanel/TitleText");
					}
				}

				// Token: 0x1700026C RID: 620
				// (get) Token: 0x06000A85 RID: 2693 RVA: 0x00035ECC File Offset: 0x000340CC
				public static GameObject VersionText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/TitlePanel/VersionText");
					}
				}
			}

			// Token: 0x020001AA RID: 426
			public class ComfortSafetyPanel_3
			{
				// Token: 0x1700026D RID: 621
				// (get) Token: 0x06000A87 RID: 2695 RVA: 0x00035EE1 File Offset: 0x000340E1
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/Panel_Header");
					}
				}

				// Token: 0x1700026E RID: 622
				// (get) Token: 0x06000A88 RID: 2696 RVA: 0x00035EED File Offset: 0x000340ED
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/TitleText (1)");
					}
				}

				// Token: 0x1700026F RID: 623
				// (get) Token: 0x06000A89 RID: 2697 RVA: 0x00035EF9 File Offset: 0x000340F9
				public static GameObject HoloportToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HoloportToggle");
					}
				}

				// Token: 0x17000270 RID: 624
				// (get) Token: 0x06000A8A RID: 2698 RVA: 0x00035F05 File Offset: 0x00034105
				public static GameObject ComfortTurnToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/ComfortTurnToggle");
					}
				}

				// Token: 0x17000271 RID: 625
				// (get) Token: 0x06000A8B RID: 2699 RVA: 0x00035F11 File Offset: 0x00034111
				public static GameObject PersonalSpaceToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/PersonalSpaceToggle");
					}
				}

				// Token: 0x17000272 RID: 626
				// (get) Token: 0x06000A8C RID: 2700 RVA: 0x00035F1D File Offset: 0x0003411D
				public static GameObject AllowUntrustedURL
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/AllowUntrustedURL");
					}
				}

				// Token: 0x17000273 RID: 627
				// (get) Token: 0x06000A8D RID: 2701 RVA: 0x00035F29 File Offset: 0x00034129
				public static GameObject StreamerModeToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/StreamerModeToggle");
					}
				}

				// Token: 0x17000274 RID: 628
				// (get) Token: 0x06000A8E RID: 2702 RVA: 0x00035F35 File Offset: 0x00034135
				public static GameObject MuteUsersToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/MuteUsersToggle");
					}
				}

				// Token: 0x17000275 RID: 629
				// (get) Token: 0x06000A8F RID: 2703 RVA: 0x00035F41 File Offset: 0x00034141
				public static GameObject BlockAvatarsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/BlockAvatarsToggle");
					}
				}

				// Token: 0x17000276 RID: 630
				// (get) Token: 0x06000A90 RID: 2704 RVA: 0x00035F4D File Offset: 0x0003414D
				public static GameObject HeadSetGazeToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HeadSetGazeToggle");
					}
				}

				// Token: 0x17000277 RID: 631
				// (get) Token: 0x06000A91 RID: 2705 RVA: 0x00035F59 File Offset: 0x00034159
				public static GameObject KeyboardToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/KeyboardToggle");
					}
				}

				// Token: 0x17000278 RID: 632
				// (get) Token: 0x06000A92 RID: 2706 RVA: 0x00035F65 File Offset: 0x00034165
				public static GameObject GamepadToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/GamepadToggle");
					}
				}

				// Token: 0x17000279 RID: 633
				// (get) Token: 0x06000A93 RID: 2707 RVA: 0x00035F71 File Offset: 0x00034171
				public static GameObject PrimaryInputPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/PrimaryInputPanel");
					}
				}

				// Token: 0x1700027A RID: 634
				// (get) Token: 0x06000A94 RID: 2708 RVA: 0x00035F7D File Offset: 0x0003417D
				public static GameObject LocomotionInputPanel_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/LocomotionInputPanel (1)");
					}
				}

				// Token: 0x02000249 RID: 585
				public class HoloportToggle_4
				{
					// Token: 0x17000473 RID: 1139
					// (get) Token: 0x06000D2C RID: 3372 RVA: 0x00037CC0 File Offset: 0x00035EC0
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HoloportToggle/Background");
						}
					}

					// Token: 0x17000474 RID: 1140
					// (get) Token: 0x06000D2D RID: 3373 RVA: 0x00037CCC File Offset: 0x00035ECC
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HoloportToggle/Label");
						}
					}

					// Token: 0x020002FD RID: 765
					public class Background_5
					{
						// Token: 0x1700060B RID: 1547
						// (get) Token: 0x06000F78 RID: 3960 RVA: 0x00039634 File Offset: 0x00037834
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HoloportToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024A RID: 586
				public class ComfortTurnToggle_4
				{
					// Token: 0x17000475 RID: 1141
					// (get) Token: 0x06000D2F RID: 3375 RVA: 0x00037CE1 File Offset: 0x00035EE1
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/ComfortTurnToggle/Background");
						}
					}

					// Token: 0x17000476 RID: 1142
					// (get) Token: 0x06000D30 RID: 3376 RVA: 0x00037CED File Offset: 0x00035EED
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/ComfortTurnToggle/Label");
						}
					}

					// Token: 0x020002FE RID: 766
					public class Background_5
					{
						// Token: 0x1700060C RID: 1548
						// (get) Token: 0x06000F7A RID: 3962 RVA: 0x00039649 File Offset: 0x00037849
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/ComfortTurnToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024B RID: 587
				public class PersonalSpaceToggle_4
				{
					// Token: 0x17000477 RID: 1143
					// (get) Token: 0x06000D32 RID: 3378 RVA: 0x00037D02 File Offset: 0x00035F02
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/PersonalSpaceToggle/Background");
						}
					}

					// Token: 0x17000478 RID: 1144
					// (get) Token: 0x06000D33 RID: 3379 RVA: 0x00037D0E File Offset: 0x00035F0E
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/PersonalSpaceToggle/Label");
						}
					}

					// Token: 0x020002FF RID: 767
					public class Background_5
					{
						// Token: 0x1700060D RID: 1549
						// (get) Token: 0x06000F7C RID: 3964 RVA: 0x0003965E File Offset: 0x0003785E
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/PersonalSpaceToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024C RID: 588
				public class AllowUntrustedURL_4
				{
					// Token: 0x17000479 RID: 1145
					// (get) Token: 0x06000D35 RID: 3381 RVA: 0x00037D23 File Offset: 0x00035F23
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/AllowUntrustedURL/Background");
						}
					}

					// Token: 0x1700047A RID: 1146
					// (get) Token: 0x06000D36 RID: 3382 RVA: 0x00037D2F File Offset: 0x00035F2F
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/AllowUntrustedURL/Label");
						}
					}

					// Token: 0x02000300 RID: 768
					public class Background_5
					{
						// Token: 0x1700060E RID: 1550
						// (get) Token: 0x06000F7E RID: 3966 RVA: 0x00039673 File Offset: 0x00037873
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/AllowUntrustedURL/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024D RID: 589
				public class StreamerModeToggle_4
				{
					// Token: 0x1700047B RID: 1147
					// (get) Token: 0x06000D38 RID: 3384 RVA: 0x00037D44 File Offset: 0x00035F44
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/StreamerModeToggle/Background");
						}
					}

					// Token: 0x1700047C RID: 1148
					// (get) Token: 0x06000D39 RID: 3385 RVA: 0x00037D50 File Offset: 0x00035F50
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/StreamerModeToggle/Label");
						}
					}

					// Token: 0x1700047D RID: 1149
					// (get) Token: 0x06000D3A RID: 3386 RVA: 0x00037D5C File Offset: 0x00035F5C
					public static GameObject InfoButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/StreamerModeToggle/InfoButton");
						}
					}

					// Token: 0x02000301 RID: 769
					public class Background_5
					{
						// Token: 0x1700060F RID: 1551
						// (get) Token: 0x06000F80 RID: 3968 RVA: 0x00039688 File Offset: 0x00037888
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/StreamerModeToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024E RID: 590
				public class MuteUsersToggle_4
				{
					// Token: 0x1700047E RID: 1150
					// (get) Token: 0x06000D3C RID: 3388 RVA: 0x00037D71 File Offset: 0x00035F71
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/MuteUsersToggle/Background");
						}
					}

					// Token: 0x1700047F RID: 1151
					// (get) Token: 0x06000D3D RID: 3389 RVA: 0x00037D7D File Offset: 0x00035F7D
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/MuteUsersToggle/Label");
						}
					}

					// Token: 0x02000302 RID: 770
					public class Background_5
					{
						// Token: 0x17000610 RID: 1552
						// (get) Token: 0x06000F82 RID: 3970 RVA: 0x0003969D File Offset: 0x0003789D
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/MuteUsersToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200024F RID: 591
				public class BlockAvatarsToggle_4
				{
					// Token: 0x17000480 RID: 1152
					// (get) Token: 0x06000D3F RID: 3391 RVA: 0x00037D92 File Offset: 0x00035F92
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/BlockAvatarsToggle/Background");
						}
					}

					// Token: 0x17000481 RID: 1153
					// (get) Token: 0x06000D40 RID: 3392 RVA: 0x00037D9E File Offset: 0x00035F9E
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/BlockAvatarsToggle/Label");
						}
					}

					// Token: 0x02000303 RID: 771
					public class Background_5
					{
						// Token: 0x17000611 RID: 1553
						// (get) Token: 0x06000F84 RID: 3972 RVA: 0x000396B2 File Offset: 0x000378B2
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/BlockAvatarsToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000250 RID: 592
				public class HeadSetGazeToggle_4
				{
					// Token: 0x17000482 RID: 1154
					// (get) Token: 0x06000D42 RID: 3394 RVA: 0x00037DB3 File Offset: 0x00035FB3
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HeadSetGazeToggle/Background");
						}
					}

					// Token: 0x17000483 RID: 1155
					// (get) Token: 0x06000D43 RID: 3395 RVA: 0x00037DBF File Offset: 0x00035FBF
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HeadSetGazeToggle/Label");
						}
					}

					// Token: 0x02000304 RID: 772
					public class Background_5
					{
						// Token: 0x17000612 RID: 1554
						// (get) Token: 0x06000F86 RID: 3974 RVA: 0x000396C7 File Offset: 0x000378C7
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/HeadSetGazeToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000251 RID: 593
				public class KeyboardToggle_4
				{
					// Token: 0x17000484 RID: 1156
					// (get) Token: 0x06000D45 RID: 3397 RVA: 0x00037DD4 File Offset: 0x00035FD4
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/KeyboardToggle/Background");
						}
					}

					// Token: 0x17000485 RID: 1157
					// (get) Token: 0x06000D46 RID: 3398 RVA: 0x00037DE0 File Offset: 0x00035FE0
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/KeyboardToggle/Label");
						}
					}

					// Token: 0x02000305 RID: 773
					public class Background_5
					{
						// Token: 0x17000613 RID: 1555
						// (get) Token: 0x06000F88 RID: 3976 RVA: 0x000396DC File Offset: 0x000378DC
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/KeyboardToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000252 RID: 594
				public class GamepadToggle_4
				{
					// Token: 0x17000486 RID: 1158
					// (get) Token: 0x06000D48 RID: 3400 RVA: 0x00037DF5 File Offset: 0x00035FF5
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/GamepadToggle/Background");
						}
					}

					// Token: 0x17000487 RID: 1159
					// (get) Token: 0x06000D49 RID: 3401 RVA: 0x00037E01 File Offset: 0x00036001
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/GamepadToggle/Label");
						}
					}

					// Token: 0x02000306 RID: 774
					public class Background_5
					{
						// Token: 0x17000614 RID: 1556
						// (get) Token: 0x06000F8A RID: 3978 RVA: 0x000396F1 File Offset: 0x000378F1
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/ComfortSafetyPanel/GamepadToggle/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001AB RID: 427
			public class AudioDevicePanel_3
			{
				// Token: 0x1700027B RID: 635
				// (get) Token: 0x06000A96 RID: 2710 RVA: 0x00035F92 File Offset: 0x00034192
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/Panel_Header");
					}
				}

				// Token: 0x1700027C RID: 636
				// (get) Token: 0x06000A97 RID: 2711 RVA: 0x00035F9E File Offset: 0x0003419E
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/TitleText");
					}
				}

				// Token: 0x1700027D RID: 637
				// (get) Token: 0x06000A98 RID: 2712 RVA: 0x00035FAA File Offset: 0x000341AA
				public static GameObject LevelText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/LevelText");
					}
				}

				// Token: 0x1700027E RID: 638
				// (get) Token: 0x06000A99 RID: 2713 RVA: 0x00035FB6 File Offset: 0x000341B6
				public static GameObject VolumeSlider
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider");
					}
				}

				// Token: 0x1700027F RID: 639
				// (get) Token: 0x06000A9A RID: 2714 RVA: 0x00035FC2 File Offset: 0x000341C2
				public static GameObject VolumeDisplay
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeDisplay");
					}
				}

				// Token: 0x17000280 RID: 640
				// (get) Token: 0x06000A9B RID: 2715 RVA: 0x00035FCE File Offset: 0x000341CE
				public static GameObject SelectPrevMic
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/SelectPrevMic");
					}
				}

				// Token: 0x17000281 RID: 641
				// (get) Token: 0x06000A9C RID: 2716 RVA: 0x00035FDA File Offset: 0x000341DA
				public static GameObject SelectNextMic
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/SelectNextMic");
					}
				}

				// Token: 0x17000282 RID: 642
				// (get) Token: 0x06000A9D RID: 2717 RVA: 0x00035FE6 File Offset: 0x000341E6
				public static GameObject MicDeviceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/MicDeviceText");
					}
				}

				// Token: 0x02000253 RID: 595
				public class VolumeSlider_4
				{
					// Token: 0x17000488 RID: 1160
					// (get) Token: 0x06000D4B RID: 3403 RVA: 0x00037E16 File Offset: 0x00036016
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider/Fill Area");
						}
					}

					// Token: 0x02000307 RID: 775
					public class Fill_Area_5
					{
						// Token: 0x17000615 RID: 1557
						// (get) Token: 0x06000F8C RID: 3980 RVA: 0x00039706 File Offset: 0x00037906
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider/Fill Area/Fill");
							}
						}

						// Token: 0x17000616 RID: 1558
						// (get) Token: 0x06000F8D RID: 3981 RVA: 0x00039712 File Offset: 0x00037912
						public static GameObject Label
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider/Fill Area/Label");
							}
						}
					}
				}

				// Token: 0x02000254 RID: 596
				public class VolumeDisplay_4
				{
					// Token: 0x17000489 RID: 1161
					// (get) Token: 0x06000D4D RID: 3405 RVA: 0x00037E2B File Offset: 0x0003602B
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeDisplay/Background");
						}
					}

					// Token: 0x1700048A RID: 1162
					// (get) Token: 0x06000D4E RID: 3406 RVA: 0x00037E37 File Offset: 0x00036037
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeDisplay/Fill Area");
						}
					}

					// Token: 0x02000308 RID: 776
					public class Fill_Area_5
					{
						// Token: 0x17000617 RID: 1559
						// (get) Token: 0x06000F8F RID: 3983 RVA: 0x00039727 File Offset: 0x00037927
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/VolumeDisplay/Fill Area/Fill");
							}
						}
					}
				}
			}

			// Token: 0x020001AC RID: 428
			public class MousePanel_3
			{
				// Token: 0x17000283 RID: 643
				// (get) Token: 0x06000A9F RID: 2719 RVA: 0x00035FFB File Offset: 0x000341FB
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/Panel_Header");
					}
				}

				// Token: 0x17000284 RID: 644
				// (get) Token: 0x06000AA0 RID: 2720 RVA: 0x00036007 File Offset: 0x00034207
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/TitleText");
					}
				}

				// Token: 0x17000285 RID: 645
				// (get) Token: 0x06000AA1 RID: 2721 RVA: 0x00036013 File Offset: 0x00034213
				public static GameObject MouseSensitivityText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/MouseSensitivityText");
					}
				}

				// Token: 0x17000286 RID: 646
				// (get) Token: 0x06000AA2 RID: 2722 RVA: 0x0003601F File Offset: 0x0003421F
				public static GameObject SensitivitySlider
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider");
					}
				}

				// Token: 0x17000287 RID: 647
				// (get) Token: 0x06000AA3 RID: 2723 RVA: 0x0003602B File Offset: 0x0003422B
				public static GameObject InvertedMouse
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/InvertedMouse");
					}
				}

				// Token: 0x02000255 RID: 597
				public class SensitivitySlider_4
				{
					// Token: 0x1700048B RID: 1163
					// (get) Token: 0x06000D50 RID: 3408 RVA: 0x00037E4C File Offset: 0x0003604C
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider/Background");
						}
					}

					// Token: 0x1700048C RID: 1164
					// (get) Token: 0x06000D51 RID: 3409 RVA: 0x00037E58 File Offset: 0x00036058
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider/Fill Area");
						}
					}

					// Token: 0x1700048D RID: 1165
					// (get) Token: 0x06000D52 RID: 3410 RVA: 0x00037E64 File Offset: 0x00036064
					public static GameObject Handle_Slide_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider/Handle Slide Area");
						}
					}

					// Token: 0x02000309 RID: 777
					public class Fill_Area_5
					{
						// Token: 0x17000618 RID: 1560
						// (get) Token: 0x06000F91 RID: 3985 RVA: 0x0003973C File Offset: 0x0003793C
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider/Fill Area/Fill");
							}
						}
					}

					// Token: 0x0200030A RID: 778
					public class Handle_Slide_Area_5
					{
						// Token: 0x17000619 RID: 1561
						// (get) Token: 0x06000F93 RID: 3987 RVA: 0x00039751 File Offset: 0x00037951
						public static GameObject Handle
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/SensitivitySlider/Handle Slide Area/Handle");
							}
						}
					}
				}

				// Token: 0x02000256 RID: 598
				public class InvertedMouse_4
				{
					// Token: 0x1700048E RID: 1166
					// (get) Token: 0x06000D54 RID: 3412 RVA: 0x00037E79 File Offset: 0x00036079
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/InvertedMouse/Background");
						}
					}

					// Token: 0x1700048F RID: 1167
					// (get) Token: 0x06000D55 RID: 3413 RVA: 0x00037E85 File Offset: 0x00036085
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/InvertedMouse/Label");
						}
					}

					// Token: 0x0200030B RID: 779
					public class Background_5
					{
						// Token: 0x1700061A RID: 1562
						// (get) Token: 0x06000F95 RID: 3989 RVA: 0x00039766 File Offset: 0x00037966
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/MousePanel/InvertedMouse/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001AD RID: 429
			public class HeightPanel_3
			{
				// Token: 0x17000288 RID: 648
				// (get) Token: 0x06000AA5 RID: 2725 RVA: 0x00036040 File Offset: 0x00034240
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel/Panel_Header");
					}
				}

				// Token: 0x17000289 RID: 649
				// (get) Token: 0x06000AA6 RID: 2726 RVA: 0x0003604C File Offset: 0x0003424C
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel/TitleText (1)");
					}
				}

				// Token: 0x1700028A RID: 650
				// (get) Token: 0x06000AA7 RID: 2727 RVA: 0x00036058 File Offset: 0x00034258
				public static GameObject HeightUP
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel/HeightUP");
					}
				}

				// Token: 0x1700028B RID: 651
				// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x00036064 File Offset: 0x00034264
				public static GameObject HeightDOWN
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel/HeightDOWN");
					}
				}

				// Token: 0x1700028C RID: 652
				// (get) Token: 0x06000AA9 RID: 2729 RVA: 0x00036070 File Offset: 0x00034270
				public static GameObject Label
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/HeightPanel/Label");
					}
				}
			}

			// Token: 0x020001AE RID: 430
			public class VoiceOptionsPanel_3
			{
				// Token: 0x1700028D RID: 653
				// (get) Token: 0x06000AAB RID: 2731 RVA: 0x00036085 File Offset: 0x00034285
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/Panel_Header");
					}
				}

				// Token: 0x1700028E RID: 654
				// (get) Token: 0x06000AAC RID: 2732 RVA: 0x00036091 File Offset: 0x00034291
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/TitleText (1)");
					}
				}

				// Token: 0x1700028F RID: 655
				// (get) Token: 0x06000AAD RID: 2733 RVA: 0x0003609D File Offset: 0x0003429D
				public static GameObject HardwareConfigToggle_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (1)");
					}
				}

				// Token: 0x17000290 RID: 656
				// (get) Token: 0x06000AAE RID: 2734 RVA: 0x000360A9 File Offset: 0x000342A9
				public static GameObject HardwareConfigToggle_4
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (4)");
					}
				}

				// Token: 0x17000291 RID: 657
				// (get) Token: 0x06000AAF RID: 2735 RVA: 0x000360B5 File Offset: 0x000342B5
				public static GameObject HardwareConfigToggle_6
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (6)");
					}
				}

				// Token: 0x17000292 RID: 658
				// (get) Token: 0x06000AB0 RID: 2736 RVA: 0x000360C1 File Offset: 0x000342C1
				public static GameObject HardwareConfigToggle_2
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (2)");
					}
				}

				// Token: 0x02000257 RID: 599
				public class HardwareConfigToggle_1_4
				{
					// Token: 0x17000490 RID: 1168
					// (get) Token: 0x06000D57 RID: 3415 RVA: 0x00037E9A File Offset: 0x0003609A
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (1)/Background");
						}
					}

					// Token: 0x17000491 RID: 1169
					// (get) Token: 0x06000D58 RID: 3416 RVA: 0x00037EA6 File Offset: 0x000360A6
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (1)/Label");
						}
					}

					// Token: 0x0200030C RID: 780
					public class Background_5
					{
						// Token: 0x1700061B RID: 1563
						// (get) Token: 0x06000F97 RID: 3991 RVA: 0x0003977B File Offset: 0x0003797B
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (1)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000258 RID: 600
				public class HardwareConfigToggle_4_4
				{
					// Token: 0x17000492 RID: 1170
					// (get) Token: 0x06000D5A RID: 3418 RVA: 0x00037EBB File Offset: 0x000360BB
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (4)/Background");
						}
					}

					// Token: 0x17000493 RID: 1171
					// (get) Token: 0x06000D5B RID: 3419 RVA: 0x00037EC7 File Offset: 0x000360C7
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (4)/Label");
						}
					}

					// Token: 0x0200030D RID: 781
					public class Background_5
					{
						// Token: 0x1700061C RID: 1564
						// (get) Token: 0x06000F99 RID: 3993 RVA: 0x00039790 File Offset: 0x00037990
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (4)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000259 RID: 601
				public class HardwareConfigToggle_6_4
				{
					// Token: 0x17000494 RID: 1172
					// (get) Token: 0x06000D5D RID: 3421 RVA: 0x00037EDC File Offset: 0x000360DC
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (6)/Background");
						}
					}

					// Token: 0x17000495 RID: 1173
					// (get) Token: 0x06000D5E RID: 3422 RVA: 0x00037EE8 File Offset: 0x000360E8
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (6)/Label");
						}
					}

					// Token: 0x0200030E RID: 782
					public class Background_5
					{
						// Token: 0x1700061D RID: 1565
						// (get) Token: 0x06000F9B RID: 3995 RVA: 0x000397A5 File Offset: 0x000379A5
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (6)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200025A RID: 602
				public class HardwareConfigToggle_2_4
				{
					// Token: 0x17000496 RID: 1174
					// (get) Token: 0x06000D60 RID: 3424 RVA: 0x00037EFD File Offset: 0x000360FD
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (2)/Background");
						}
					}

					// Token: 0x17000497 RID: 1175
					// (get) Token: 0x06000D61 RID: 3425 RVA: 0x00037F09 File Offset: 0x00036109
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (2)/Label");
						}
					}

					// Token: 0x0200030F RID: 783
					public class Background_5
					{
						// Token: 0x1700061E RID: 1566
						// (get) Token: 0x06000F9D RID: 3997 RVA: 0x000397BA File Offset: 0x000379BA
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VoiceOptionsPanel/HardwareConfigToggle (2)/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001AF RID: 431
			public class OtherOptionsPanel_3
			{
				// Token: 0x17000293 RID: 659
				// (get) Token: 0x06000AB2 RID: 2738 RVA: 0x000360D6 File Offset: 0x000342D6
				public static GameObject Panel_Header_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/Panel_Header (1)");
					}
				}

				// Token: 0x17000294 RID: 660
				// (get) Token: 0x06000AB3 RID: 2739 RVA: 0x000360E2 File Offset: 0x000342E2
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/TitleText (1)");
					}
				}

				// Token: 0x17000295 RID: 661
				// (get) Token: 0x06000AB4 RID: 2740 RVA: 0x000360EE File Offset: 0x000342EE
				public static GameObject HeadLookToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/HeadLookToggle");
					}
				}

				// Token: 0x17000296 RID: 662
				// (get) Token: 0x06000AB5 RID: 2741 RVA: 0x000360FA File Offset: 0x000342FA
				public static GameObject TooltipsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/TooltipsToggle");
					}
				}

				// Token: 0x17000297 RID: 663
				// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x00036106 File Offset: 0x00034306
				public static GameObject PRotationToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/3PRotationToggle");
					}
				}

				// Token: 0x17000298 RID: 664
				// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x00036112 File Offset: 0x00034312
				public static GameObject ViveAdvancedToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ViveAdvancedToggle");
					}
				}

				// Token: 0x17000299 RID: 665
				// (get) Token: 0x06000AB8 RID: 2744 RVA: 0x0003611E File Offset: 0x0003431E
				public static GameObject SkipGoButtonInLoad
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/SkipGoButtonInLoad");
					}
				}

				// Token: 0x1700029A RID: 666
				// (get) Token: 0x06000AB9 RID: 2745 RVA: 0x0003612A File Offset: 0x0003432A
				public static GameObject DesktopReticle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/DesktopReticle");
					}
				}

				// Token: 0x1700029B RID: 667
				// (get) Token: 0x06000ABA RID: 2746 RVA: 0x00036136 File Offset: 0x00034336
				public static GameObject AllowAvatarCopyingToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/AllowAvatarCopyingToggle");
					}
				}

				// Token: 0x1700029C RID: 668
				// (get) Token: 0x06000ABB RID: 2747 RVA: 0x00036142 File Offset: 0x00034342
				public static GameObject ShowCommunityLabsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ShowCommunityLabsToggle");
					}
				}

				// Token: 0x0200025B RID: 603
				public class HeadLookToggle_4
				{
					// Token: 0x17000498 RID: 1176
					// (get) Token: 0x06000D63 RID: 3427 RVA: 0x00037F1E File Offset: 0x0003611E
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/HeadLookToggle/Background");
						}
					}

					// Token: 0x17000499 RID: 1177
					// (get) Token: 0x06000D64 RID: 3428 RVA: 0x00037F2A File Offset: 0x0003612A
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/HeadLookToggle/Label");
						}
					}

					// Token: 0x02000310 RID: 784
					public class Background_5
					{
						// Token: 0x1700061F RID: 1567
						// (get) Token: 0x06000F9F RID: 3999 RVA: 0x000397CF File Offset: 0x000379CF
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/HeadLookToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200025C RID: 604
				public class TooltipsToggle_4
				{
					// Token: 0x1700049A RID: 1178
					// (get) Token: 0x06000D66 RID: 3430 RVA: 0x00037F3F File Offset: 0x0003613F
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/TooltipsToggle/Background");
						}
					}

					// Token: 0x1700049B RID: 1179
					// (get) Token: 0x06000D67 RID: 3431 RVA: 0x00037F4B File Offset: 0x0003614B
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/TooltipsToggle/Label");
						}
					}

					// Token: 0x02000311 RID: 785
					public class Background_5
					{
						// Token: 0x17000620 RID: 1568
						// (get) Token: 0x06000FA1 RID: 4001 RVA: 0x000397E4 File Offset: 0x000379E4
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/TooltipsToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200025D RID: 605
				public class PRotationToggle_4
				{
					// Token: 0x1700049C RID: 1180
					// (get) Token: 0x06000D69 RID: 3433 RVA: 0x00037F60 File Offset: 0x00036160
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/3PRotationToggle/Background");
						}
					}

					// Token: 0x1700049D RID: 1181
					// (get) Token: 0x06000D6A RID: 3434 RVA: 0x00037F6C File Offset: 0x0003616C
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/3PRotationToggle/Label");
						}
					}

					// Token: 0x02000312 RID: 786
					public class Background_5
					{
						// Token: 0x17000621 RID: 1569
						// (get) Token: 0x06000FA3 RID: 4003 RVA: 0x000397F9 File Offset: 0x000379F9
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/3PRotationToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200025E RID: 606
				public class ViveAdvancedToggle_4
				{
					// Token: 0x1700049E RID: 1182
					// (get) Token: 0x06000D6C RID: 3436 RVA: 0x00037F81 File Offset: 0x00036181
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ViveAdvancedToggle/Background");
						}
					}

					// Token: 0x1700049F RID: 1183
					// (get) Token: 0x06000D6D RID: 3437 RVA: 0x00037F8D File Offset: 0x0003618D
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ViveAdvancedToggle/Label");
						}
					}

					// Token: 0x02000313 RID: 787
					public class Background_5
					{
						// Token: 0x17000622 RID: 1570
						// (get) Token: 0x06000FA5 RID: 4005 RVA: 0x0003980E File Offset: 0x00037A0E
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ViveAdvancedToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200025F RID: 607
				public class SkipGoButtonInLoad_4
				{
					// Token: 0x170004A0 RID: 1184
					// (get) Token: 0x06000D6F RID: 3439 RVA: 0x00037FA2 File Offset: 0x000361A2
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/SkipGoButtonInLoad/Background");
						}
					}

					// Token: 0x170004A1 RID: 1185
					// (get) Token: 0x06000D70 RID: 3440 RVA: 0x00037FAE File Offset: 0x000361AE
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/SkipGoButtonInLoad/Label");
						}
					}

					// Token: 0x02000314 RID: 788
					public class Background_5
					{
						// Token: 0x17000623 RID: 1571
						// (get) Token: 0x06000FA7 RID: 4007 RVA: 0x00039823 File Offset: 0x00037A23
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/SkipGoButtonInLoad/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000260 RID: 608
				public class DesktopReticle_4
				{
					// Token: 0x170004A2 RID: 1186
					// (get) Token: 0x06000D72 RID: 3442 RVA: 0x00037FC3 File Offset: 0x000361C3
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/DesktopReticle/Background");
						}
					}

					// Token: 0x170004A3 RID: 1187
					// (get) Token: 0x06000D73 RID: 3443 RVA: 0x00037FCF File Offset: 0x000361CF
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/DesktopReticle/Label");
						}
					}

					// Token: 0x02000315 RID: 789
					public class Background_5
					{
						// Token: 0x17000624 RID: 1572
						// (get) Token: 0x06000FA9 RID: 4009 RVA: 0x00039838 File Offset: 0x00037A38
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/DesktopReticle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000261 RID: 609
				public class AllowAvatarCopyingToggle_4
				{
					// Token: 0x170004A4 RID: 1188
					// (get) Token: 0x06000D75 RID: 3445 RVA: 0x00037FE4 File Offset: 0x000361E4
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/AllowAvatarCopyingToggle/Background");
						}
					}

					// Token: 0x170004A5 RID: 1189
					// (get) Token: 0x06000D76 RID: 3446 RVA: 0x00037FF0 File Offset: 0x000361F0
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/AllowAvatarCopyingToggle/Label");
						}
					}

					// Token: 0x02000316 RID: 790
					public class Background_5
					{
						// Token: 0x17000625 RID: 1573
						// (get) Token: 0x06000FAB RID: 4011 RVA: 0x0003984D File Offset: 0x00037A4D
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/AllowAvatarCopyingToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x02000262 RID: 610
				public class ShowCommunityLabsToggle_4
				{
					// Token: 0x170004A6 RID: 1190
					// (get) Token: 0x06000D78 RID: 3448 RVA: 0x00038005 File Offset: 0x00036205
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ShowCommunityLabsToggle/Background");
						}
					}

					// Token: 0x170004A7 RID: 1191
					// (get) Token: 0x06000D79 RID: 3449 RVA: 0x00038011 File Offset: 0x00036211
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ShowCommunityLabsToggle/Label");
						}
					}

					// Token: 0x02000317 RID: 791
					public class Background_5
					{
						// Token: 0x17000626 RID: 1574
						// (get) Token: 0x06000FAD RID: 4013 RVA: 0x00039862 File Offset: 0x00037A62
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/OtherOptionsPanel/ShowCommunityLabsToggle/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001B0 RID: 432
			public class VolumePanel_3
			{
				// Token: 0x1700029D RID: 669
				// (get) Token: 0x06000ABD RID: 2749 RVA: 0x00036157 File Offset: 0x00034357
				public static GameObject Panel_Header_Top
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/Panel_Header Top");
					}
				}

				// Token: 0x1700029E RID: 670
				// (get) Token: 0x06000ABE RID: 2750 RVA: 0x00036163 File Offset: 0x00034363
				public static GameObject Panel_Header_Side
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/Panel_Header Side");
					}
				}

				// Token: 0x1700029F RID: 671
				// (get) Token: 0x06000ABF RID: 2751 RVA: 0x0003616F File Offset: 0x0003436F
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/TitleText (1)");
					}
				}

				// Token: 0x170002A0 RID: 672
				// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x0003617B File Offset: 0x0003437B
				public static GameObject VolumeMaster
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeMaster");
					}
				}

				// Token: 0x170002A1 RID: 673
				// (get) Token: 0x06000AC1 RID: 2753 RVA: 0x00036187 File Offset: 0x00034387
				public static GameObject VolumeUi
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeUi");
					}
				}

				// Token: 0x170002A2 RID: 674
				// (get) Token: 0x06000AC2 RID: 2754 RVA: 0x00036193 File Offset: 0x00034393
				public static GameObject VolumeGameWorld
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameWorld");
					}
				}

				// Token: 0x170002A3 RID: 675
				// (get) Token: 0x06000AC3 RID: 2755 RVA: 0x0003619F File Offset: 0x0003439F
				public static GameObject VolumeGameVoice
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameVoice");
					}
				}

				// Token: 0x170002A4 RID: 676
				// (get) Token: 0x06000AC4 RID: 2756 RVA: 0x000361AB File Offset: 0x000343AB
				public static GameObject VolumeGameAvatars
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameAvatars");
					}
				}

				// Token: 0x02000263 RID: 611
				public class VolumeMaster_4
				{
					// Token: 0x170004A8 RID: 1192
					// (get) Token: 0x06000D7B RID: 3451 RVA: 0x00038026 File Offset: 0x00036226
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeMaster/FillArea");
						}
					}

					// Token: 0x170004A9 RID: 1193
					// (get) Token: 0x06000D7C RID: 3452 RVA: 0x00038032 File Offset: 0x00036232
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeMaster/SliderLabel");
						}
					}

					// Token: 0x170004AA RID: 1194
					// (get) Token: 0x06000D7D RID: 3453 RVA: 0x0003803E File Offset: 0x0003623E
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeMaster/Label");
						}
					}

					// Token: 0x02000318 RID: 792
					public class FillArea_5
					{
						// Token: 0x17000627 RID: 1575
						// (get) Token: 0x06000FAF RID: 4015 RVA: 0x00039877 File Offset: 0x00037A77
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeMaster/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x02000264 RID: 612
				public class VolumeUi_4
				{
					// Token: 0x170004AB RID: 1195
					// (get) Token: 0x06000D7F RID: 3455 RVA: 0x00038053 File Offset: 0x00036253
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeUi/FillArea");
						}
					}

					// Token: 0x170004AC RID: 1196
					// (get) Token: 0x06000D80 RID: 3456 RVA: 0x0003805F File Offset: 0x0003625F
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeUi/SliderLabel");
						}
					}

					// Token: 0x170004AD RID: 1197
					// (get) Token: 0x06000D81 RID: 3457 RVA: 0x0003806B File Offset: 0x0003626B
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeUi/Label");
						}
					}

					// Token: 0x02000319 RID: 793
					public class FillArea_5
					{
						// Token: 0x17000628 RID: 1576
						// (get) Token: 0x06000FB1 RID: 4017 RVA: 0x0003988C File Offset: 0x00037A8C
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeUi/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x02000265 RID: 613
				public class VolumeGameWorld_4
				{
					// Token: 0x170004AE RID: 1198
					// (get) Token: 0x06000D83 RID: 3459 RVA: 0x00038080 File Offset: 0x00036280
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameWorld/FillArea");
						}
					}

					// Token: 0x170004AF RID: 1199
					// (get) Token: 0x06000D84 RID: 3460 RVA: 0x0003808C File Offset: 0x0003628C
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameWorld/SliderLabel");
						}
					}

					// Token: 0x170004B0 RID: 1200
					// (get) Token: 0x06000D85 RID: 3461 RVA: 0x00038098 File Offset: 0x00036298
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameWorld/Label");
						}
					}

					// Token: 0x0200031A RID: 794
					public class FillArea_5
					{
						// Token: 0x17000629 RID: 1577
						// (get) Token: 0x06000FB3 RID: 4019 RVA: 0x000398A1 File Offset: 0x00037AA1
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameWorld/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x02000266 RID: 614
				public class VolumeGameVoice_4
				{
					// Token: 0x170004B1 RID: 1201
					// (get) Token: 0x06000D87 RID: 3463 RVA: 0x000380AD File Offset: 0x000362AD
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameVoice/FillArea");
						}
					}

					// Token: 0x170004B2 RID: 1202
					// (get) Token: 0x06000D88 RID: 3464 RVA: 0x000380B9 File Offset: 0x000362B9
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameVoice/SliderLabel");
						}
					}

					// Token: 0x170004B3 RID: 1203
					// (get) Token: 0x06000D89 RID: 3465 RVA: 0x000380C5 File Offset: 0x000362C5
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameVoice/Label");
						}
					}

					// Token: 0x0200031B RID: 795
					public class FillArea_5
					{
						// Token: 0x1700062A RID: 1578
						// (get) Token: 0x06000FB5 RID: 4021 RVA: 0x000398B6 File Offset: 0x00037AB6
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameVoice/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x02000267 RID: 615
				public class VolumeGameAvatars_4
				{
					// Token: 0x170004B4 RID: 1204
					// (get) Token: 0x06000D8B RID: 3467 RVA: 0x000380DA File Offset: 0x000362DA
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameAvatars/FillArea");
						}
					}

					// Token: 0x170004B5 RID: 1205
					// (get) Token: 0x06000D8C RID: 3468 RVA: 0x000380E6 File Offset: 0x000362E6
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameAvatars/SliderLabel");
						}
					}

					// Token: 0x170004B6 RID: 1206
					// (get) Token: 0x06000D8D RID: 3469 RVA: 0x000380F2 File Offset: 0x000362F2
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameAvatars/Label");
						}
					}

					// Token: 0x0200031C RID: 796
					public class FillArea_5
					{
						// Token: 0x1700062B RID: 1579
						// (get) Token: 0x06000FB7 RID: 4023 RVA: 0x000398CB File Offset: 0x00037ACB
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/VolumePanel/VolumeGameAvatars/FillArea/Fill");
							}
						}
					}
				}
			}

			// Token: 0x020001B1 RID: 433
			public class Footer_3
			{
				// Token: 0x170002A5 RID: 677
				// (get) Token: 0x06000AC6 RID: 2758 RVA: 0x000361C0 File Offset: 0x000343C0
				public static GameObject Logout
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/Logout");
					}
				}

				// Token: 0x170002A6 RID: 678
				// (get) Token: 0x06000AC7 RID: 2759 RVA: 0x000361CC File Offset: 0x000343CC
				public static GameObject Exit
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/Exit");
					}
				}

				// Token: 0x170002A7 RID: 679
				// (get) Token: 0x06000AC8 RID: 2760 RVA: 0x000361D8 File Offset: 0x000343D8
				public static GameObject NameText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/NameText");
					}
				}

				// Token: 0x170002A8 RID: 680
				// (get) Token: 0x06000AC9 RID: 2761 RVA: 0x000361E4 File Offset: 0x000343E4
				public static GameObject UpgradeAccount
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/UpgradeAccount");
					}
				}

				// Token: 0x02000268 RID: 616
				public class Logout_4
				{
					// Token: 0x170004B7 RID: 1207
					// (get) Token: 0x06000D8F RID: 3471 RVA: 0x00038107 File Offset: 0x00036307
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/Logout/Text");
						}
					}
				}

				// Token: 0x02000269 RID: 617
				public class Exit_4
				{
					// Token: 0x170004B8 RID: 1208
					// (get) Token: 0x06000D91 RID: 3473 RVA: 0x0003811C File Offset: 0x0003631C
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/Exit/Text");
						}
					}
				}

				// Token: 0x0200026A RID: 618
				public class UpgradeAccount_4
				{
					// Token: 0x170004B9 RID: 1209
					// (get) Token: 0x06000D93 RID: 3475 RVA: 0x00038131 File Offset: 0x00036331
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Footer/UpgradeAccount/Text");
						}
					}
				}
			}

			// Token: 0x020001B2 RID: 434
			public class Button_AdvancedOptions_3
			{
				// Token: 0x170002A9 RID: 681
				// (get) Token: 0x06000ACB RID: 2763 RVA: 0x000361F9 File Offset: 0x000343F9
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Button_AdvancedOptions/Text");
					}
				}
			}

			// Token: 0x020001B3 RID: 435
			public class Button_EditBindings_3
			{
				// Token: 0x170002AA RID: 682
				// (get) Token: 0x06000ACD RID: 2765 RVA: 0x0003620E File Offset: 0x0003440E
				public static GameObject Image_NEW
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Button_EditBindings/Image_NEW");
					}
				}

				// Token: 0x170002AB RID: 683
				// (get) Token: 0x06000ACE RID: 2766 RVA: 0x0003621A File Offset: 0x0003441A
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/Button_EditBindings/Text");
					}
				}
			}

			// Token: 0x020001B4 RID: 436
			public class UserVolumeOptions_3
			{
				// Token: 0x170002AC RID: 684
				// (get) Token: 0x06000AD0 RID: 2768 RVA: 0x0003622F File Offset: 0x0003442F
				public static GameObject Panel_Header_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/UserVolumeOptions/Panel_Header (1)");
					}
				}

				// Token: 0x170002AD RID: 685
				// (get) Token: 0x06000AD1 RID: 2769 RVA: 0x0003623B File Offset: 0x0003443B
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/UserVolumeOptions/TitleText (1)");
					}
				}

				// Token: 0x170002AE RID: 686
				// (get) Token: 0x06000AD2 RID: 2770 RVA: 0x00036247 File Offset: 0x00034447
				public static GameObject Button_ClearChanges
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/UserVolumeOptions/Button_ClearChanges");
					}
				}

				// Token: 0x0200026B RID: 619
				public class Button_ClearChanges_4
				{
					// Token: 0x170004BA RID: 1210
					// (get) Token: 0x06000D95 RID: 3477 RVA: 0x00038146 File Offset: 0x00036346
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Settings/UserVolumeOptions/Button_ClearChanges/Text");
						}
					}
				}
			}
		}

		// Token: 0x02000161 RID: 353
		public class Social_2
		{
			// Token: 0x17000141 RID: 321
			// (get) Token: 0x060008FD RID: 2301 RVA: 0x00034634 File Offset: 0x00032834
			public static GameObject Ticker
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Ticker");
				}
			}

			// Token: 0x17000142 RID: 322
			// (get) Token: 0x060008FE RID: 2302 RVA: 0x00034640 File Offset: 0x00032840
			public static GameObject Vertical_Scroll_View
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Vertical Scroll View");
				}
			}

			// Token: 0x17000143 RID: 323
			// (get) Token: 0x060008FF RID: 2303 RVA: 0x0003464C File Offset: 0x0003284C
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Social/DepthOverlay");
				}
			}

			// Token: 0x17000144 RID: 324
			// (get) Token: 0x06000900 RID: 2304 RVA: 0x00034658 File Offset: 0x00032858
			public static GameObject Current_Status
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status");
				}
			}

			// Token: 0x020001B5 RID: 437
			public class Ticker_3
			{
				// Token: 0x170002AF RID: 687
				// (get) Token: 0x06000AD4 RID: 2772 RVA: 0x0003625C File Offset: 0x0003445C
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Ticker/Text");
					}
				}

				// Token: 0x170002B0 RID: 688
				// (get) Token: 0x06000AD5 RID: 2773 RVA: 0x00036268 File Offset: 0x00034468
				public static GameObject TopLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Ticker/TopLine");
					}
				}

				// Token: 0x170002B1 RID: 689
				// (get) Token: 0x06000AD6 RID: 2774 RVA: 0x00036274 File Offset: 0x00034474
				public static GameObject TopLine_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Ticker/TopLine (1)");
					}
				}
			}

			// Token: 0x020001B6 RID: 438
			public class Current_Status_3
			{
				// Token: 0x170002B2 RID: 690
				// (get) Token: 0x06000AD8 RID: 2776 RVA: 0x00036289 File Offset: 0x00034489
				public static GameObject TitlePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/TitlePanel");
					}
				}

				// Token: 0x170002B3 RID: 691
				// (get) Token: 0x06000AD9 RID: 2777 RVA: 0x00036295 File Offset: 0x00034495
				public static GameObject TopLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/TopLine");
					}
				}

				// Token: 0x170002B4 RID: 692
				// (get) Token: 0x06000ADA RID: 2778 RVA: 0x000362A1 File Offset: 0x000344A1
				public static GameObject StatusButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/StatusButton");
					}
				}

				// Token: 0x170002B5 RID: 693
				// (get) Token: 0x06000ADB RID: 2779 RVA: 0x000362AD File Offset: 0x000344AD
				public static GameObject StatusIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/StatusIcon");
					}
				}

				// Token: 0x170002B6 RID: 694
				// (get) Token: 0x06000ADC RID: 2780 RVA: 0x000362B9 File Offset: 0x000344B9
				public static GameObject StatusText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/StatusText");
					}
				}

				// Token: 0x170002B7 RID: 695
				// (get) Token: 0x06000ADD RID: 2781 RVA: 0x000362C5 File Offset: 0x000344C5
				public static GameObject BottomLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/BottomLine");
					}
				}

				// Token: 0x0200026C RID: 620
				public class StatusButton_4
				{
					// Token: 0x170004BB RID: 1211
					// (get) Token: 0x06000D97 RID: 3479 RVA: 0x0003815B File Offset: 0x0003635B
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/StatusButton/Text");
						}
					}

					// Token: 0x170004BC RID: 1212
					// (get) Token: 0x06000D98 RID: 3480 RVA: 0x00038167 File Offset: 0x00036367
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Social/Current Status/StatusButton/Image");
						}
					}
				}
			}
		}

		// Token: 0x02000162 RID: 354
		public class Title_2
		{
			// Token: 0x17000145 RID: 325
			// (get) Token: 0x06000902 RID: 2306 RVA: 0x0003466D File Offset: 0x0003286D
			public static GameObject Panel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Title/Panel");
				}
			}

			// Token: 0x17000146 RID: 326
			// (get) Token: 0x06000903 RID: 2307 RVA: 0x00034679 File Offset: 0x00032879
			public static GameObject LogoContainer
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Title/LogoContainer");
				}
			}

			// Token: 0x020001B7 RID: 439
			public class Panel_3
			{
				// Token: 0x170002B8 RID: 696
				// (get) Token: 0x06000ADF RID: 2783 RVA: 0x000362DA File Offset: 0x000344DA
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Title/Panel/Text");
					}
				}

				// Token: 0x170002B9 RID: 697
				// (get) Token: 0x06000AE0 RID: 2784 RVA: 0x000362E6 File Offset: 0x000344E6
				public static GameObject TitleImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Title/Panel/TitleImage");
					}
				}
			}

			// Token: 0x020001B8 RID: 440
			public class LogoContainer_3
			{
				// Token: 0x170002BA RID: 698
				// (get) Token: 0x06000AE2 RID: 2786 RVA: 0x000362FB File Offset: 0x000344FB
				public static GameObject vrchatlogo2sided
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Title/LogoContainer/vrchatlogo2sided");
					}
				}
			}
		}

		// Token: 0x02000163 RID: 355
		public class UpdateRequired_2
		{
			// Token: 0x17000147 RID: 327
			// (get) Token: 0x06000905 RID: 2309 RVA: 0x0003468E File Offset: 0x0003288E
			public static GameObject Panel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired/Panel");
				}
			}

			// Token: 0x020001B9 RID: 441
			public class Panel_3
			{
				// Token: 0x170002BB RID: 699
				// (get) Token: 0x06000AE4 RID: 2788 RVA: 0x00036310 File Offset: 0x00034510
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired/Panel/Text");
					}
				}

				// Token: 0x170002BC RID: 700
				// (get) Token: 0x06000AE5 RID: 2789 RVA: 0x0003631C File Offset: 0x0003451C
				public static GameObject TitleImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired/Panel/TitleImage");
					}
				}

				// Token: 0x170002BD RID: 701
				// (get) Token: 0x06000AE6 RID: 2790 RVA: 0x00036328 File Offset: 0x00034528
				public static GameObject ButtonUpdate
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired/Panel/ButtonUpdate");
					}
				}

				// Token: 0x0200026D RID: 621
				public class ButtonUpdate_4
				{
					// Token: 0x170004BD RID: 1213
					// (get) Token: 0x06000D9A RID: 3482 RVA: 0x0003817C File Offset: 0x0003637C
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UpdateRequired/Panel/ButtonUpdate/Text");
						}
					}
				}
			}
		}

		// Token: 0x02000164 RID: 356
		public class TitleXR_2
		{
			// Token: 0x17000148 RID: 328
			// (get) Token: 0x06000907 RID: 2311 RVA: 0x000346A3 File Offset: 0x000328A3
			public static GameObject Panel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/TitleXR/Panel");
				}
			}

			// Token: 0x020001BA RID: 442
			public class Panel_3
			{
				// Token: 0x170002BE RID: 702
				// (get) Token: 0x06000AE8 RID: 2792 RVA: 0x0003633D File Offset: 0x0003453D
				public static GameObject TitleImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/TitleXR/Panel/TitleImage");
					}
				}
			}
		}

		// Token: 0x02000165 RID: 357
		public class Gallery_2
		{
			// Token: 0x17000149 RID: 329
			// (get) Token: 0x06000909 RID: 2313 RVA: 0x000346B8 File Offset: 0x000328B8
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/TitlePanel");
				}
			}

			// Token: 0x1700014A RID: 330
			// (get) Token: 0x0600090A RID: 2314 RVA: 0x000346C4 File Offset: 0x000328C4
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/DepthOverlay");
				}
			}

			// Token: 0x1700014B RID: 331
			// (get) Token: 0x0600090B RID: 2315 RVA: 0x000346D0 File Offset: 0x000328D0
			public static GameObject Vertical_Scroll_View
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/Vertical Scroll View");
				}
			}

			// Token: 0x020001BB RID: 443
			public class TitlePanel_3
			{
				// Token: 0x170002BF RID: 703
				// (get) Token: 0x06000AEA RID: 2794 RVA: 0x00036352 File Offset: 0x00034552
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/TitlePanel/TitleText");
					}
				}

				// Token: 0x170002C0 RID: 704
				// (get) Token: 0x06000AEB RID: 2795 RVA: 0x0003635E File Offset: 0x0003455E
				public static GameObject UploadUserIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/TitlePanel/UploadUserIcon");
					}
				}

				// Token: 0x0200026E RID: 622
				public class UploadUserIcon_4
				{
					// Token: 0x170004BE RID: 1214
					// (get) Token: 0x06000D9C RID: 3484 RVA: 0x00038191 File Offset: 0x00036391
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Gallery/TitlePanel/UploadUserIcon/Text");
						}
					}
				}
			}
		}

		// Token: 0x02000166 RID: 358
		public class ImageDetails_2
		{
			// Token: 0x1700014C RID: 332
			// (get) Token: 0x0600090D RID: 2317 RVA: 0x000346E5 File Offset: 0x000328E5
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/TitlePanel");
				}
			}

			// Token: 0x1700014D RID: 333
			// (get) Token: 0x0600090E RID: 2318 RVA: 0x000346F1 File Offset: 0x000328F1
			public static GameObject LargeImage
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/LargeImage");
				}
			}

			// Token: 0x1700014E RID: 334
			// (get) Token: 0x0600090F RID: 2319 RVA: 0x000346FD File Offset: 0x000328FD
			public static GameObject ImageOptions
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions");
				}
			}

			// Token: 0x1700014F RID: 335
			// (get) Token: 0x06000910 RID: 2320 RVA: 0x00034709 File Offset: 0x00032909
			public static GameObject ImagesScrollView
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImagesScrollView");
				}
			}

			// Token: 0x17000150 RID: 336
			// (get) Token: 0x06000911 RID: 2321 RVA: 0x00034715 File Offset: 0x00032915
			public static GameObject BackButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/BackButton");
				}
			}

			// Token: 0x17000151 RID: 337
			// (get) Token: 0x06000912 RID: 2322 RVA: 0x00034721 File Offset: 0x00032921
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/DepthOverlay");
				}
			}

			// Token: 0x020001BC RID: 444
			public class TitlePanel_3
			{
				// Token: 0x170002C1 RID: 705
				// (get) Token: 0x06000AED RID: 2797 RVA: 0x00036373 File Offset: 0x00034573
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/TitlePanel/TitleText");
					}
				}
			}

			// Token: 0x020001BD RID: 445
			public class LargeImage_3
			{
				// Token: 0x170002C2 RID: 706
				// (get) Token: 0x06000AEF RID: 2799 RVA: 0x00036388 File Offset: 0x00034588
				public static GameObject Image
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/LargeImage/Image");
					}
				}

				// Token: 0x170002C3 RID: 707
				// (get) Token: 0x06000AF0 RID: 2800 RVA: 0x00036394 File Offset: 0x00034594
				public static GameObject ImageBorder
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/LargeImage/ImageBorder");
					}
				}
			}

			// Token: 0x020001BE RID: 446
			public class ImageOptions_3
			{
				// Token: 0x170002C4 RID: 708
				// (get) Token: 0x06000AF2 RID: 2802 RVA: 0x000363A9 File Offset: 0x000345A9
				public static GameObject SetAsProfilePic
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/SetAsProfilePic");
					}
				}

				// Token: 0x170002C5 RID: 709
				// (get) Token: 0x06000AF3 RID: 2803 RVA: 0x000363B5 File Offset: 0x000345B5
				public static GameObject CreateUserIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/CreateUserIcon");
					}
				}

				// Token: 0x170002C6 RID: 710
				// (get) Token: 0x06000AF4 RID: 2804 RVA: 0x000363C1 File Offset: 0x000345C1
				public static GameObject Delete
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Delete");
					}
				}

				// Token: 0x170002C7 RID: 711
				// (get) Token: 0x06000AF5 RID: 2805 RVA: 0x000363CD File Offset: 0x000345CD
				public static GameObject Save
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Save");
					}
				}

				// Token: 0x0200026F RID: 623
				public class SetAsProfilePic_4
				{
					// Token: 0x170004BF RID: 1215
					// (get) Token: 0x06000D9E RID: 3486 RVA: 0x000381A6 File Offset: 0x000363A6
					public static GameObject SetAsProfilePicButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/SetAsProfilePic/SetAsProfilePicButton");
						}
					}

					// Token: 0x0200031D RID: 797
					public class SetAsProfilePicButton_5
					{
						// Token: 0x1700062C RID: 1580
						// (get) Token: 0x06000FB9 RID: 4025 RVA: 0x000398E0 File Offset: 0x00037AE0
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/SetAsProfilePic/SetAsProfilePicButton/Image");
							}
						}
					}
				}

				// Token: 0x02000270 RID: 624
				public class CreateUserIcon_4
				{
					// Token: 0x170004C0 RID: 1216
					// (get) Token: 0x06000DA0 RID: 3488 RVA: 0x000381BB File Offset: 0x000363BB
					public static GameObject CreateUserIconButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/CreateUserIcon/CreateUserIconButton");
						}
					}

					// Token: 0x0200031E RID: 798
					public class CreateUserIconButton_5
					{
						// Token: 0x1700062D RID: 1581
						// (get) Token: 0x06000FBB RID: 4027 RVA: 0x000398F5 File Offset: 0x00037AF5
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/CreateUserIcon/CreateUserIconButton/Image");
							}
						}
					}
				}

				// Token: 0x02000271 RID: 625
				public class Delete_4
				{
					// Token: 0x170004C1 RID: 1217
					// (get) Token: 0x06000DA2 RID: 3490 RVA: 0x000381D0 File Offset: 0x000363D0
					public static GameObject DeleteButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Delete/DeleteButton");
						}
					}

					// Token: 0x0200031F RID: 799
					public class DeleteButton_5
					{
						// Token: 0x1700062E RID: 1582
						// (get) Token: 0x06000FBD RID: 4029 RVA: 0x0003990A File Offset: 0x00037B0A
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Delete/DeleteButton/Image");
							}
						}
					}
				}

				// Token: 0x02000272 RID: 626
				public class Save_4
				{
					// Token: 0x170004C2 RID: 1218
					// (get) Token: 0x06000DA4 RID: 3492 RVA: 0x000381E5 File Offset: 0x000363E5
					public static GameObject SaveButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Save/SaveButton");
						}
					}

					// Token: 0x02000320 RID: 800
					public class SaveButton_5
					{
						// Token: 0x1700062F RID: 1583
						// (get) Token: 0x06000FBF RID: 4031 RVA: 0x0003991F File Offset: 0x00037B1F
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/ImageOptions/Save/SaveButton/Image");
							}
						}
					}
				}
			}

			// Token: 0x020001BF RID: 447
			public class BackButton_3
			{
				// Token: 0x170002C8 RID: 712
				// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x000363E2 File Offset: 0x000345E2
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/ImageDetails/BackButton/Text");
					}
				}
			}
		}

		// Token: 0x02000167 RID: 359
		public class UserInfo_2
		{
			// Token: 0x17000152 RID: 338
			// (get) Token: 0x06000914 RID: 2324 RVA: 0x00034736 File Offset: 0x00032936
			public static GameObject Worlds
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds");
				}
			}

			// Token: 0x17000153 RID: 339
			// (get) Token: 0x06000915 RID: 2325 RVA: 0x00034742 File Offset: 0x00032942
			public static GameObject BackButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/BackButton");
				}
			}

			// Token: 0x17000154 RID: 340
			// (get) Token: 0x06000916 RID: 2326 RVA: 0x0003474E File Offset: 0x0003294E
			public static GameObject AvatarImage
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage");
				}
			}

			// Token: 0x17000155 RID: 341
			// (get) Token: 0x06000917 RID: 2327 RVA: 0x0003475A File Offset: 0x0003295A
			public static GameObject SelfButtons
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons");
				}
			}

			// Token: 0x17000156 RID: 342
			// (get) Token: 0x06000918 RID: 2328 RVA: 0x00034766 File Offset: 0x00032966
			public static GameObject OnlineFriendButtons
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons");
				}
			}

			// Token: 0x17000157 RID: 343
			// (get) Token: 0x06000919 RID: 2329 RVA: 0x00034772 File Offset: 0x00032972
			public static GameObject ViewUserOnVRChatWebsiteButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ViewUserOnVRChatWebsiteButton");
				}
			}

			// Token: 0x17000158 RID: 344
			// (get) Token: 0x0600091A RID: 2330 RVA: 0x0003477E File Offset: 0x0003297E
			public static GameObject User_Panel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel");
				}
			}

			// Token: 0x17000159 RID: 345
			// (get) Token: 0x0600091B RID: 2331 RVA: 0x0003478A File Offset: 0x0003298A
			public static GameObject Buttons
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons");
				}
			}

			// Token: 0x1700015A RID: 346
			// (get) Token: 0x0600091C RID: 2332 RVA: 0x00034796 File Offset: 0x00032996
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/DepthOverlay");
				}
			}

			// Token: 0x1700015B RID: 347
			// (get) Token: 0x0600091D RID: 2333 RVA: 0x000347A2 File Offset: 0x000329A2
			public static GameObject ReceivedFriendRequest
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest");
				}
			}

			// Token: 0x1700015C RID: 348
			// (get) Token: 0x0600091E RID: 2334 RVA: 0x000347AE File Offset: 0x000329AE
			public static GameObject SentFriendRequest
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest");
				}
			}

			// Token: 0x1700015D RID: 349
			// (get) Token: 0x0600091F RID: 2335 RVA: 0x000347BA File Offset: 0x000329BA
			public static GameObject ModerateDialog
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog");
				}
			}

			// Token: 0x020001C0 RID: 448
			public class Worlds_3
			{
				// Token: 0x170002C9 RID: 713
				// (get) Token: 0x06000AF9 RID: 2809 RVA: 0x000363F7 File Offset: 0x000345F7
				public static GameObject WorldScrollView
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/WorldScrollView");
					}
				}

				// Token: 0x170002CA RID: 714
				// (get) Token: 0x06000AFA RID: 2810 RVA: 0x00036403 File Offset: 0x00034603
				public static GameObject CurrentWorld
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld");
					}
				}

				// Token: 0x02000273 RID: 627
				public class CurrentWorld_4
				{
					// Token: 0x170004C3 RID: 1219
					// (get) Token: 0x06000DA6 RID: 3494 RVA: 0x000381FA File Offset: 0x000363FA
					public static GameObject CurrentWorldPanel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld/CurrentWorldPanel");
						}
					}

					// Token: 0x170004C4 RID: 1220
					// (get) Token: 0x06000DA7 RID: 3495 RVA: 0x00038206 File Offset: 0x00036406
					public static GameObject TitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld/TitleText");
						}
					}

					// Token: 0x170004C5 RID: 1221
					// (get) Token: 0x06000DA8 RID: 3496 RVA: 0x00038212 File Offset: 0x00036412
					public static GameObject WorldUiPrefab
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld/WorldUiPrefab");
						}
					}

					// Token: 0x02000321 RID: 801
					public class WorldUiPrefab_5
					{
						// Token: 0x17000630 RID: 1584
						// (get) Token: 0x06000FC1 RID: 4033 RVA: 0x00039934 File Offset: 0x00037B34
						public static GameObject RoomOutline
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld/WorldUiPrefab/RoomOutline");
							}
						}

						// Token: 0x17000631 RID: 1585
						// (get) Token: 0x06000FC2 RID: 4034 RVA: 0x00039940 File Offset: 0x00037B40
						public static GameObject RoomImageShape
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Worlds/CurrentWorld/WorldUiPrefab/RoomImageShape");
							}
						}
					}
				}
			}

			// Token: 0x020001C1 RID: 449
			public class BackButton_3
			{
				// Token: 0x170002CB RID: 715
				// (get) Token: 0x06000AFC RID: 2812 RVA: 0x00036418 File Offset: 0x00034618
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/BackButton/Text");
					}
				}
			}

			// Token: 0x020001C2 RID: 450
			public class AvatarImage_3
			{
				// Token: 0x170002CC RID: 716
				// (get) Token: 0x06000AFE RID: 2814 RVA: 0x0003642D File Offset: 0x0003462D
				public static GameObject AvatarImageMask
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/AvatarImageMask");
					}
				}

				// Token: 0x170002CD RID: 717
				// (get) Token: 0x06000AFF RID: 2815 RVA: 0x00036439 File Offset: 0x00034639
				public static GameObject HideUserAvatar
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/HideUserAvatar");
					}
				}

				// Token: 0x170002CE RID: 718
				// (get) Token: 0x06000B00 RID: 2816 RVA: 0x00036445 File Offset: 0x00034645
				public static GameObject AvatarBorder
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/AvatarBorder");
					}
				}

				// Token: 0x170002CF RID: 719
				// (get) Token: 0x06000B01 RID: 2817 RVA: 0x00036451 File Offset: 0x00034651
				public static GameObject Icon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/Icon");
					}
				}

				// Token: 0x170002D0 RID: 720
				// (get) Token: 0x06000B02 RID: 2818 RVA: 0x0003645D File Offset: 0x0003465D
				public static GameObject SupporterIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/SupporterIcon");
					}
				}

				// Token: 0x170002D1 RID: 721
				// (get) Token: 0x06000B03 RID: 2819 RVA: 0x00036469 File Offset: 0x00034669
				public static GameObject OverlayIcons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons");
					}
				}

				// Token: 0x02000274 RID: 628
				public class AvatarImageMask_4
				{
					// Token: 0x170004C6 RID: 1222
					// (get) Token: 0x06000DAA RID: 3498 RVA: 0x00038227 File Offset: 0x00036427
					public static GameObject AvatarImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/AvatarImageMask/AvatarImage");
						}
					}
				}

				// Token: 0x02000275 RID: 629
				public class HideUserAvatar_4
				{
					// Token: 0x170004C7 RID: 1223
					// (get) Token: 0x06000DAC RID: 3500 RVA: 0x0003823C File Offset: 0x0003643C
					public static GameObject PhotoHiddenText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/HideUserAvatar/PhotoHiddenText");
						}
					}
				}

				// Token: 0x02000276 RID: 630
				public class OverlayIcons_4
				{
					// Token: 0x170004C8 RID: 1224
					// (get) Token: 0x06000DAE RID: 3502 RVA: 0x00038251 File Offset: 0x00036451
					public static GameObject FavoriteIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/FavoriteIcon");
						}
					}

					// Token: 0x170004C9 RID: 1225
					// (get) Token: 0x06000DAF RID: 3503 RVA: 0x0003825D File Offset: 0x0003645D
					public static GameObject PlatformPCIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/PlatformPCIcon");
						}
					}

					// Token: 0x170004CA RID: 1226
					// (get) Token: 0x06000DB0 RID: 3504 RVA: 0x00038269 File Offset: 0x00036469
					public static GameObject PlatformMobileIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/PlatformMobileIcon");
						}
					}

					// Token: 0x170004CB RID: 1227
					// (get) Token: 0x06000DB1 RID: 3505 RVA: 0x00038275 File Offset: 0x00036475
					public static GameObject MobileIcons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/MobileIcons");
						}
					}

					// Token: 0x02000322 RID: 802
					public class MobileIcons_5
					{
						// Token: 0x17000632 RID: 1586
						// (get) Token: 0x06000FC4 RID: 4036 RVA: 0x00039955 File Offset: 0x00037B55
						public static GameObject MobilePlatformPCIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/MobileIcons/MobilePlatformPCIcon");
							}
						}

						// Token: 0x17000633 RID: 1587
						// (get) Token: 0x06000FC5 RID: 4037 RVA: 0x00039961 File Offset: 0x00037B61
						public static GameObject MobilePlatformMobileIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/AvatarImage/OverlayIcons/MobileIcons/MobilePlatformMobileIcon");
							}
						}
					}
				}
			}

			// Token: 0x020001C3 RID: 451
			public class SelfButtons_3
			{
				// Token: 0x170002D2 RID: 722
				// (get) Token: 0x06000B05 RID: 2821 RVA: 0x0003647E File Offset: 0x0003467E
				public static GameObject ChangeProfilePicButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/ChangeProfilePicButton");
					}
				}

				// Token: 0x170002D3 RID: 723
				// (get) Token: 0x06000B06 RID: 2822 RVA: 0x0003648A File Offset: 0x0003468A
				public static GameObject UseAvatarAsProfilePicButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/UseAvatarAsProfilePicButton");
					}
				}

				// Token: 0x02000277 RID: 631
				public class ChangeProfilePicButton_4
				{
					// Token: 0x170004CC RID: 1228
					// (get) Token: 0x06000DB3 RID: 3507 RVA: 0x0003828A File Offset: 0x0003648A
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/ChangeProfilePicButton/Image");
						}
					}

					// Token: 0x170004CD RID: 1229
					// (get) Token: 0x06000DB4 RID: 3508 RVA: 0x00038296 File Offset: 0x00036496
					public static GameObject VRCPlus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/ChangeProfilePicButton/VRC+");
						}
					}

					// Token: 0x02000323 RID: 803
					public class Image_5
					{
						// Token: 0x17000634 RID: 1588
						// (get) Token: 0x06000FC7 RID: 4039 RVA: 0x00039976 File Offset: 0x00037B76
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/ChangeProfilePicButton/Image/Text");
							}
						}
					}
				}

				// Token: 0x02000278 RID: 632
				public class UseAvatarAsProfilePicButton_4
				{
					// Token: 0x170004CE RID: 1230
					// (get) Token: 0x06000DB6 RID: 3510 RVA: 0x000382AB File Offset: 0x000364AB
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/UseAvatarAsProfilePicButton/Image");
						}
					}

					// Token: 0x02000324 RID: 804
					public class Image_5
					{
						// Token: 0x17000635 RID: 1589
						// (get) Token: 0x06000FC9 RID: 4041 RVA: 0x0003998B File Offset: 0x00037B8B
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SelfButtons/UseAvatarAsProfilePicButton/Image/Text");
							}
						}
					}
				}
			}

			// Token: 0x020001C4 RID: 452
			public class OnlineFriendButtons_3
			{
				// Token: 0x170002D4 RID: 724
				// (get) Token: 0x06000B08 RID: 2824 RVA: 0x0003649F File Offset: 0x0003469F
				public static GameObject JoinButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/JoinButton");
					}
				}

				// Token: 0x170002D5 RID: 725
				// (get) Token: 0x06000B09 RID: 2825 RVA: 0x000364AB File Offset: 0x000346AB
				public static GameObject Invite
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/Invite");
					}
				}

				// Token: 0x170002D6 RID: 726
				// (get) Token: 0x06000B0A RID: 2826 RVA: 0x000364B7 File Offset: 0x000346B7
				public static GameObject Actions
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/Actions");
					}
				}

				// Token: 0x02000279 RID: 633
				public class JoinButton_4
				{
					// Token: 0x170004CF RID: 1231
					// (get) Token: 0x06000DB8 RID: 3512 RVA: 0x000382C0 File Offset: 0x000364C0
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/JoinButton/Image");
						}
					}

					// Token: 0x02000325 RID: 805
					public class Image_5
					{
						// Token: 0x17000636 RID: 1590
						// (get) Token: 0x06000FCB RID: 4043 RVA: 0x000399A0 File Offset: 0x00037BA0
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/JoinButton/Image/Text");
							}
						}
					}
				}

				// Token: 0x0200027A RID: 634
				public class Invite_4
				{
					// Token: 0x170004D0 RID: 1232
					// (get) Token: 0x06000DBA RID: 3514 RVA: 0x000382D5 File Offset: 0x000364D5
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/Invite/Image");
						}
					}

					// Token: 0x02000326 RID: 806
					public class Image_5
					{
						// Token: 0x17000637 RID: 1591
						// (get) Token: 0x06000FCD RID: 4045 RVA: 0x000399B5 File Offset: 0x00037BB5
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/OnlineFriendButtons/Invite/Image/Text");
							}
						}
					}
				}
			}

			// Token: 0x020001C5 RID: 453
			public class User_Panel_3
			{
				// Token: 0x170002D7 RID: 727
				// (get) Token: 0x06000B0C RID: 2828 RVA: 0x000364CC File Offset: 0x000346CC
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/Panel");
					}
				}

				// Token: 0x170002D8 RID: 728
				// (get) Token: 0x06000B0D RID: 2829 RVA: 0x000364D8 File Offset: 0x000346D8
				public static GameObject PanelHeaderBackground
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/PanelHeaderBackground");
					}
				}

				// Token: 0x170002D9 RID: 729
				// (get) Token: 0x06000B0E RID: 2830 RVA: 0x000364E4 File Offset: 0x000346E4
				public static GameObject NameText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/NameText");
					}
				}

				// Token: 0x170002DA RID: 730
				// (get) Token: 0x06000B0F RID: 2831 RVA: 0x000364F0 File Offset: 0x000346F0
				public static GameObject UserIcon
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserIcon");
					}
				}

				// Token: 0x170002DB RID: 731
				// (get) Token: 0x06000B10 RID: 2832 RVA: 0x000364FC File Offset: 0x000346FC
				public static GameObject UserStatus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserStatus");
					}
				}

				// Token: 0x170002DC RID: 732
				// (get) Token: 0x06000B11 RID: 2833 RVA: 0x00036508 File Offset: 0x00034708
				public static GameObject TrustLevel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/TrustLevel");
					}
				}

				// Token: 0x170002DD RID: 733
				// (get) Token: 0x06000B12 RID: 2834 RVA: 0x00036514 File Offset: 0x00034714
				public static GameObject VRCIcons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/VRCIcons");
					}
				}

				// Token: 0x170002DE RID: 734
				// (get) Token: 0x06000B13 RID: 2835 RVA: 0x00036520 File Offset: 0x00034720
				public static GameObject UserBio
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserBio");
					}
				}

				// Token: 0x170002DF RID: 735
				// (get) Token: 0x06000B14 RID: 2836 RVA: 0x0003652C File Offset: 0x0003472C
				public static GameObject InviteNotification
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification");
					}
				}

				// Token: 0x0200027B RID: 635
				public class UserIcon_4
				{
					// Token: 0x170004D1 RID: 1233
					// (get) Token: 0x06000DBC RID: 3516 RVA: 0x000382EA File Offset: 0x000364EA
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserIcon/Background");
						}
					}

					// Token: 0x170004D2 RID: 1234
					// (get) Token: 0x06000DBD RID: 3517 RVA: 0x000382F6 File Offset: 0x000364F6
					public static GameObject User_Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserIcon/User Image");
						}
					}

					// Token: 0x170004D3 RID: 1235
					// (get) Token: 0x06000DBE RID: 3518 RVA: 0x00038302 File Offset: 0x00036502
					public static GameObject Initials
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserIcon/Initials");
						}
					}
				}

				// Token: 0x0200027C RID: 636
				public class UserStatus_4
				{
					// Token: 0x170004D4 RID: 1236
					// (get) Token: 0x06000DC0 RID: 3520 RVA: 0x00038317 File Offset: 0x00036517
					public static GameObject StatusIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserStatus/StatusIcon");
						}
					}

					// Token: 0x170004D5 RID: 1237
					// (get) Token: 0x06000DC1 RID: 3521 RVA: 0x00038323 File Offset: 0x00036523
					public static GameObject StatusText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserStatus/StatusText");
						}
					}
				}

				// Token: 0x0200027D RID: 637
				public class TrustLevel_4
				{
					// Token: 0x170004D6 RID: 1238
					// (get) Token: 0x06000DC3 RID: 3523 RVA: 0x00038338 File Offset: 0x00036538
					public static GameObject TrustIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/TrustLevel/TrustIcon");
						}
					}

					// Token: 0x170004D7 RID: 1239
					// (get) Token: 0x06000DC4 RID: 3524 RVA: 0x00038344 File Offset: 0x00036544
					public static GameObject TrustText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/TrustLevel/TrustText");
						}
					}
				}

				// Token: 0x0200027E RID: 638
				public class VRCIcons_4
				{
					// Token: 0x170004D8 RID: 1240
					// (get) Token: 0x06000DC6 RID: 3526 RVA: 0x00038359 File Offset: 0x00036559
					public static GameObject VRCPlusEarlyAdopterIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/VRCIcons/VRCPlusEarlyAdopterIcon");
						}
					}

					// Token: 0x170004D9 RID: 1241
					// (get) Token: 0x06000DC7 RID: 3527 RVA: 0x00038365 File Offset: 0x00036565
					public static GameObject VRCPlusSubscriberIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/VRCIcons/VRCPlusSubscriberIcon");
						}
					}
				}

				// Token: 0x0200027F RID: 639
				public class UserBio_4
				{
					// Token: 0x170004DA RID: 1242
					// (get) Token: 0x06000DC9 RID: 3529 RVA: 0x0003837A File Offset: 0x0003657A
					public static GameObject Bio_Scroll_View
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/UserBio/Bio Scroll View");
						}
					}
				}

				// Token: 0x02000280 RID: 640
				public class InviteNotification_4
				{
					// Token: 0x170004DB RID: 1243
					// (get) Token: 0x06000DCB RID: 3531 RVA: 0x0003838F File Offset: 0x0003658F
					public static GameObject Panel_Backdrop
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Panel_Backdrop");
						}
					}

					// Token: 0x170004DC RID: 1244
					// (get) Token: 0x06000DCC RID: 3532 RVA: 0x0003839B File Offset: 0x0003659B
					public static GameObject Actions
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Actions");
						}
					}

					// Token: 0x170004DD RID: 1245
					// (get) Token: 0x06000DCD RID: 3533 RVA: 0x000383A7 File Offset: 0x000365A7
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Image");
						}
					}

					// Token: 0x170004DE RID: 1246
					// (get) Token: 0x06000DCE RID: 3534 RVA: 0x000383B3 File Offset: 0x000365B3
					public static GameObject MessageText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/MessageText");
						}
					}

					// Token: 0x02000327 RID: 807
					public class Actions_5
					{
						// Token: 0x17000638 RID: 1592
						// (get) Token: 0x06000FCF RID: 4047 RVA: 0x000399CA File Offset: 0x00037BCA
						public static GameObject Accept
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Actions/Accept");
							}
						}

						// Token: 0x17000639 RID: 1593
						// (get) Token: 0x06000FD0 RID: 4048 RVA: 0x000399D6 File Offset: 0x00037BD6
						public static GameObject Decline
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Actions/Decline");
							}
						}

						// Token: 0x1700063A RID: 1594
						// (get) Token: 0x06000FD1 RID: 4049 RVA: 0x000399E2 File Offset: 0x00037BE2
						public static GameObject Block
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Actions/Block");
							}
						}
					}

					// Token: 0x02000328 RID: 808
					public class Image_5
					{
						// Token: 0x1700063B RID: 1595
						// (get) Token: 0x06000FD3 RID: 4051 RVA: 0x000399F7 File Offset: 0x00037BF7
						public static GameObject WorldImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Image/WorldImage");
							}
						}

						// Token: 0x1700063C RID: 1596
						// (get) Token: 0x06000FD4 RID: 4052 RVA: 0x00039A03 File Offset: 0x00037C03
						public static GameObject WorldBorder
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/User Panel/InviteNotification/Image/WorldBorder");
							}
						}
					}
				}
			}

			// Token: 0x020001C6 RID: 454
			public class Buttons_3
			{
				// Token: 0x170002E0 RID: 736
				// (get) Token: 0x06000B16 RID: 2838 RVA: 0x00036541 File Offset: 0x00034741
				public static GameObject RightSideButtons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons");
					}
				}

				// Token: 0x02000281 RID: 641
				public class RightSideButtons_4
				{
					// Token: 0x170004DF RID: 1247
					// (get) Token: 0x06000DD0 RID: 3536 RVA: 0x000383C8 File Offset: 0x000365C8
					public static GameObject RightUpperButtonColumn
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn");
						}
					}

					// Token: 0x170004E0 RID: 1248
					// (get) Token: 0x06000DD1 RID: 3537 RVA: 0x000383D4 File Offset: 0x000365D4
					public static GameObject RightLowerButtonColumn
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightLowerButtonColumn");
						}
					}

					// Token: 0x02000329 RID: 809
					public class RightUpperButtonColumn_5
					{
						// Token: 0x1700063D RID: 1597
						// (get) Token: 0x06000FD6 RID: 4054 RVA: 0x00039A18 File Offset: 0x00037C18
						public static GameObject Supporter
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn/Supporter");
							}
						}

						// Token: 0x1700063E RID: 1598
						// (get) Token: 0x06000FD7 RID: 4055 RVA: 0x00039A24 File Offset: 0x00037C24
						public static GameObject PlaylistsButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn/PlaylistsButton");
							}
						}

						// Token: 0x1700063F RID: 1599
						// (get) Token: 0x06000FD8 RID: 4056 RVA: 0x00039A30 File Offset: 0x00037C30
						public static GameObject FavoriteButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn/FavoriteButton");
							}
						}

						// Token: 0x17000640 RID: 1600
						// (get) Token: 0x06000FD9 RID: 4057 RVA: 0x00039A3C File Offset: 0x00037C3C
						public static GameObject EditBioButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn/EditBioButton");
							}
						}

						// Token: 0x17000641 RID: 1601
						// (get) Token: 0x06000FDA RID: 4058 RVA: 0x00039A48 File Offset: 0x00037C48
						public static GameObject EditStatusButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightUpperButtonColumn/EditStatusButton");
							}
						}
					}

					// Token: 0x0200032A RID: 810
					public class RightLowerButtonColumn_5
					{
						// Token: 0x17000642 RID: 1602
						// (get) Token: 0x06000FDC RID: 4060 RVA: 0x00039A5D File Offset: 0x00037C5D
						public static GameObject UnfriendButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightLowerButtonColumn/UnfriendButton");
							}
						}

						// Token: 0x17000643 RID: 1603
						// (get) Token: 0x06000FDD RID: 4061 RVA: 0x00039A69 File Offset: 0x00037C69
						public static GameObject FriendButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightLowerButtonColumn/FriendButton");
							}
						}

						// Token: 0x17000644 RID: 1604
						// (get) Token: 0x06000FDE RID: 4062 RVA: 0x00039A75 File Offset: 0x00037C75
						public static GameObject ReportButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightLowerButtonColumn/ReportButton");
							}
						}

						// Token: 0x17000645 RID: 1605
						// (get) Token: 0x06000FDF RID: 4063 RVA: 0x00039A81 File Offset: 0x00037C81
						public static GameObject ModerateButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/Buttons/RightSideButtons/RightLowerButtonColumn/ModerateButton");
							}
						}
					}
				}
			}

			// Token: 0x020001C7 RID: 455
			public class ReceivedFriendRequest_3
			{
				// Token: 0x170002E1 RID: 737
				// (get) Token: 0x06000B18 RID: 2840 RVA: 0x00036556 File Offset: 0x00034756
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Panel");
					}
				}

				// Token: 0x170002E2 RID: 738
				// (get) Token: 0x06000B19 RID: 2841 RVA: 0x00036562 File Offset: 0x00034762
				public static GameObject Actions
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions");
					}
				}

				// Token: 0x170002E3 RID: 739
				// (get) Token: 0x06000B1A RID: 2842 RVA: 0x0003656E File Offset: 0x0003476E
				public static GameObject Image
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Image");
					}
				}

				// Token: 0x170002E4 RID: 740
				// (get) Token: 0x06000B1B RID: 2843 RVA: 0x0003657A File Offset: 0x0003477A
				public static GameObject MessageText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/MessageText");
					}
				}

				// Token: 0x02000282 RID: 642
				public class Actions_4
				{
					// Token: 0x170004E1 RID: 1249
					// (get) Token: 0x06000DD3 RID: 3539 RVA: 0x000383E9 File Offset: 0x000365E9
					public static GameObject Accept
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Accept");
						}
					}

					// Token: 0x170004E2 RID: 1250
					// (get) Token: 0x06000DD4 RID: 3540 RVA: 0x000383F5 File Offset: 0x000365F5
					public static GameObject Decline
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Decline");
						}
					}

					// Token: 0x170004E3 RID: 1251
					// (get) Token: 0x06000DD5 RID: 3541 RVA: 0x00038401 File Offset: 0x00036601
					public static GameObject Block
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Block");
						}
					}

					// Token: 0x0200032B RID: 811
					public class Accept_5
					{
						// Token: 0x17000646 RID: 1606
						// (get) Token: 0x06000FE1 RID: 4065 RVA: 0x00039A96 File Offset: 0x00037C96
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Accept/Image");
							}
						}
					}

					// Token: 0x0200032C RID: 812
					public class Decline_5
					{
						// Token: 0x17000647 RID: 1607
						// (get) Token: 0x06000FE3 RID: 4067 RVA: 0x00039AAB File Offset: 0x00037CAB
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Decline/Image");
							}
						}
					}

					// Token: 0x0200032D RID: 813
					public class Block_5
					{
						// Token: 0x17000648 RID: 1608
						// (get) Token: 0x06000FE5 RID: 4069 RVA: 0x00039AC0 File Offset: 0x00037CC0
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Actions/Block/Image");
							}
						}
					}
				}

				// Token: 0x02000283 RID: 643
				public class Image_4
				{
					// Token: 0x170004E4 RID: 1252
					// (get) Token: 0x06000DD7 RID: 3543 RVA: 0x00038416 File Offset: 0x00036616
					public static GameObject WorldImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Image/WorldImage");
						}
					}

					// Token: 0x170004E5 RID: 1253
					// (get) Token: 0x06000DD8 RID: 3544 RVA: 0x00038422 File Offset: 0x00036622
					public static GameObject WorldBorder
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ReceivedFriendRequest/Image/WorldBorder");
						}
					}
				}
			}

			// Token: 0x020001C8 RID: 456
			public class SentFriendRequest_3
			{
				// Token: 0x170002E5 RID: 741
				// (get) Token: 0x06000B1D RID: 2845 RVA: 0x0003658F File Offset: 0x0003478F
				public static GameObject Actions
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/Actions");
					}
				}

				// Token: 0x170002E6 RID: 742
				// (get) Token: 0x06000B1E RID: 2846 RVA: 0x0003659B File Offset: 0x0003479B
				public static GameObject WorldImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/WorldImage");
					}
				}

				// Token: 0x02000284 RID: 644
				public class Actions_4
				{
					// Token: 0x170004E6 RID: 1254
					// (get) Token: 0x06000DDA RID: 3546 RVA: 0x00038437 File Offset: 0x00036637
					public static GameObject Friend
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/Actions/Friend");
						}
					}

					// Token: 0x170004E7 RID: 1255
					// (get) Token: 0x06000DDB RID: 3547 RVA: 0x00038443 File Offset: 0x00036643
					public static GameObject Block
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/Actions/Block");
						}
					}

					// Token: 0x0200032E RID: 814
					public class Friend_5
					{
						// Token: 0x17000649 RID: 1609
						// (get) Token: 0x06000FE7 RID: 4071 RVA: 0x00039AD5 File Offset: 0x00037CD5
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/Actions/Friend/Image");
							}
						}
					}

					// Token: 0x0200032F RID: 815
					public class Block_5
					{
						// Token: 0x1700064A RID: 1610
						// (get) Token: 0x06000FE9 RID: 4073 RVA: 0x00039AEA File Offset: 0x00037CEA
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/Actions/Block/Image");
							}
						}
					}
				}

				// Token: 0x02000285 RID: 645
				public class WorldImage_4
				{
					// Token: 0x170004E8 RID: 1256
					// (get) Token: 0x06000DDD RID: 3549 RVA: 0x00038458 File Offset: 0x00036658
					public static GameObject WorldImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/WorldImage/WorldImage");
						}
					}

					// Token: 0x170004E9 RID: 1257
					// (get) Token: 0x06000DDE RID: 3550 RVA: 0x00038464 File Offset: 0x00036664
					public static GameObject WorldBorder
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/SentFriendRequest/WorldImage/WorldBorder");
						}
					}
				}
			}

			// Token: 0x020001C9 RID: 457
			public class ModerateDialog_3
			{
				// Token: 0x170002E7 RID: 743
				// (get) Token: 0x06000B20 RID: 2848 RVA: 0x000365B0 File Offset: 0x000347B0
				public static GameObject Darkness
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Darkness");
					}
				}

				// Token: 0x170002E8 RID: 744
				// (get) Token: 0x06000B21 RID: 2849 RVA: 0x000365BC File Offset: 0x000347BC
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel");
					}
				}

				// Token: 0x02000286 RID: 646
				public class Panel_4
				{
					// Token: 0x170004EA RID: 1258
					// (get) Token: 0x06000DE0 RID: 3552 RVA: 0x00038479 File Offset: 0x00036679
					public static GameObject BorderImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/BorderImage");
						}
					}

					// Token: 0x170004EB RID: 1259
					// (get) Token: 0x06000DE1 RID: 3553 RVA: 0x00038485 File Offset: 0x00036685
					public static GameObject PanelHeaderBackground
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/PanelHeaderBackground");
						}
					}

					// Token: 0x170004EC RID: 1260
					// (get) Token: 0x06000DE2 RID: 3554 RVA: 0x00038491 File Offset: 0x00036691
					public static GameObject TitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/TitleText");
						}
					}

					// Token: 0x170004ED RID: 1261
					// (get) Token: 0x06000DE3 RID: 3555 RVA: 0x0003849D File Offset: 0x0003669D
					public static GameObject ExitButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/ExitButton");
						}
					}

					// Token: 0x170004EE RID: 1262
					// (get) Token: 0x06000DE4 RID: 3556 RVA: 0x000384A9 File Offset: 0x000366A9
					public static GameObject GeneralModerationTitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/GeneralModerationTitleText");
						}
					}

					// Token: 0x170004EF RID: 1263
					// (get) Token: 0x06000DE5 RID: 3557 RVA: 0x000384B5 File Offset: 0x000366B5
					public static GameObject GeneralModeration
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/GeneralModeration");
						}
					}

					// Token: 0x170004F0 RID: 1264
					// (get) Token: 0x06000DE6 RID: 3558 RVA: 0x000384C1 File Offset: 0x000366C1
					public static GameObject AdminModerationTitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/AdminModerationTitleText");
						}
					}

					// Token: 0x170004F1 RID: 1265
					// (get) Token: 0x06000DE7 RID: 3559 RVA: 0x000384CD File Offset: 0x000366CD
					public static GameObject InstanceOwnerModerationTitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/InstanceOwnerModerationTitleText");
						}
					}

					// Token: 0x170004F2 RID: 1266
					// (get) Token: 0x06000DE8 RID: 3560 RVA: 0x000384D9 File Offset: 0x000366D9
					public static GameObject ModerateButtons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/ModerateButtons");
						}
					}

					// Token: 0x02000330 RID: 816
					public class GeneralModeration_5
					{
						// Token: 0x1700064B RID: 1611
						// (get) Token: 0x06000FEB RID: 4075 RVA: 0x00039AFF File Offset: 0x00037CFF
						public static GameObject Mute
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/GeneralModeration/Mute");
							}
						}

						// Token: 0x1700064C RID: 1612
						// (get) Token: 0x06000FEC RID: 4076 RVA: 0x00039B0B File Offset: 0x00037D0B
						public static GameObject Block
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/GeneralModeration/Block");
							}
						}

						// Token: 0x1700064D RID: 1613
						// (get) Token: 0x06000FED RID: 4077 RVA: 0x00039B17 File Offset: 0x00037D17
						public static GameObject VoteKick
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/GeneralModeration/VoteKick");
							}
						}
					}

					// Token: 0x02000331 RID: 817
					public class ModerateButtons_5
					{
						// Token: 0x1700064E RID: 1614
						// (get) Token: 0x06000FEF RID: 4079 RVA: 0x00039B2C File Offset: 0x00037D2C
						public static GameObject Actions
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/UserInfo/ModerateDialog/Panel/ModerateButtons/Actions");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000168 RID: 360
		public class VRCPlus_2
		{
			// Token: 0x1700015E RID: 350
			// (get) Token: 0x06000921 RID: 2337 RVA: 0x000347CF File Offset: 0x000329CF
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/TitlePanel");
				}
			}

			// Token: 0x1700015F RID: 351
			// (get) Token: 0x06000922 RID: 2338 RVA: 0x000347DB File Offset: 0x000329DB
			public static GameObject Subscription
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription");
				}
			}

			// Token: 0x17000160 RID: 352
			// (get) Token: 0x06000923 RID: 2339 RVA: 0x000347E7 File Offset: 0x000329E7
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/DepthOverlay");
				}
			}

			// Token: 0x020001CA RID: 458
			public class TitlePanel_3
			{
				// Token: 0x170002E9 RID: 745
				// (get) Token: 0x06000B23 RID: 2851 RVA: 0x000365D1 File Offset: 0x000347D1
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/TitlePanel/TitleText");
					}
				}

				// Token: 0x170002EA RID: 746
				// (get) Token: 0x06000B24 RID: 2852 RVA: 0x000365DD File Offset: 0x000347DD
				public static GameObject TermsAndConditions
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/TitlePanel/TermsAndConditions");
					}
				}

				// Token: 0x02000287 RID: 647
				public class TermsAndConditions_4
				{
					// Token: 0x170004F3 RID: 1267
					// (get) Token: 0x06000DEA RID: 3562 RVA: 0x000384EE File Offset: 0x000366EE
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/TitlePanel/TermsAndConditions/Text");
						}
					}
				}
			}

			// Token: 0x020001CB RID: 459
			public class Subscription_3
			{
				// Token: 0x170002EB RID: 747
				// (get) Token: 0x06000B26 RID: 2854 RVA: 0x000365F2 File Offset: 0x000347F2
				public static GameObject NonSubscriberBanner
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/NonSubscriberBanner");
					}
				}

				// Token: 0x170002EC RID: 748
				// (get) Token: 0x06000B27 RID: 2855 RVA: 0x000365FE File Offset: 0x000347FE
				public static GameObject SubscriberBanner
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/SubscriberBanner");
					}
				}

				// Token: 0x170002ED RID: 749
				// (get) Token: 0x06000B28 RID: 2856 RVA: 0x0003660A File Offset: 0x0003480A
				public static GameObject GROUP_Features
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features");
					}
				}

				// Token: 0x170002EE RID: 750
				// (get) Token: 0x06000B29 RID: 2857 RVA: 0x00036616 File Offset: 0x00034816
				public static GameObject GROUP_Subscribe_Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons");
					}
				}

				// Token: 0x170002EF RID: 751
				// (get) Token: 0x06000B2A RID: 2858 RVA: 0x00036622 File Offset: 0x00034822
				public static GameObject GROUP_FeatureHovers
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers");
					}
				}

				// Token: 0x170002F0 RID: 752
				// (get) Token: 0x06000B2B RID: 2859 RVA: 0x0003662E File Offset: 0x0003482E
				public static GameObject ProcessingOverlay
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay");
					}
				}

				// Token: 0x02000288 RID: 648
				public class SubscriberBanner_4
				{
					// Token: 0x170004F4 RID: 1268
					// (get) Token: 0x06000DEC RID: 3564 RVA: 0x00038503 File Offset: 0x00036703
					public static GameObject Viewport
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/SubscriberBanner/Viewport");
						}
					}

					// Token: 0x170004F5 RID: 1269
					// (get) Token: 0x06000DED RID: 3565 RVA: 0x0003850F File Offset: 0x0003670F
					public static GameObject Frame
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/SubscriberBanner/Frame");
						}
					}
				}

				// Token: 0x02000289 RID: 649
				public class GROUP_Features_4
				{
					// Token: 0x170004F6 RID: 1270
					// (get) Token: 0x06000DEF RID: 3567 RVA: 0x00038524 File Offset: 0x00036724
					public static GameObject Feature_UserIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_UserIcon");
						}
					}

					// Token: 0x170004F7 RID: 1271
					// (get) Token: 0x06000DF0 RID: 3568 RVA: 0x00038530 File Offset: 0x00036730
					public static GameObject Feature_MoreFavorites
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_MoreFavorites");
						}
					}

					// Token: 0x170004F8 RID: 1272
					// (get) Token: 0x06000DF1 RID: 3569 RVA: 0x0003853C File Offset: 0x0003673C
					public static GameObject Feature_EarlySupporter
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_EarlySupporter");
						}
					}

					// Token: 0x170004F9 RID: 1273
					// (get) Token: 0x06000DF2 RID: 3570 RVA: 0x00038548 File Offset: 0x00036748
					public static GameObject Feature_ProfileImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_ProfileImage");
						}
					}

					// Token: 0x170004FA RID: 1274
					// (get) Token: 0x06000DF3 RID: 3571 RVA: 0x00038554 File Offset: 0x00036754
					public static GameObject Feature_PhotoInvites
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_PhotoInvites");
						}
					}

					// Token: 0x02000332 RID: 818
					public class Feature_UserIcon_5
					{
						// Token: 0x1700064F RID: 1615
						// (get) Token: 0x06000FF1 RID: 4081 RVA: 0x00039B41 File Offset: 0x00037D41
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_UserIcon/Text");
							}
						}
					}

					// Token: 0x02000333 RID: 819
					public class Feature_MoreFavorites_5
					{
						// Token: 0x17000650 RID: 1616
						// (get) Token: 0x06000FF3 RID: 4083 RVA: 0x00039B56 File Offset: 0x00037D56
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_MoreFavorites/Text");
							}
						}
					}

					// Token: 0x02000334 RID: 820
					public class Feature_EarlySupporter_5
					{
						// Token: 0x17000651 RID: 1617
						// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x00039B6B File Offset: 0x00037D6B
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_EarlySupporter/Text");
							}
						}
					}

					// Token: 0x02000335 RID: 821
					public class Feature_ProfileImage_5
					{
						// Token: 0x17000652 RID: 1618
						// (get) Token: 0x06000FF7 RID: 4087 RVA: 0x00039B80 File Offset: 0x00037D80
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_ProfileImage/Text");
							}
						}
					}

					// Token: 0x02000336 RID: 822
					public class Feature_PhotoInvites_5
					{
						// Token: 0x17000653 RID: 1619
						// (get) Token: 0x06000FF9 RID: 4089 RVA: 0x00039B95 File Offset: 0x00037D95
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Features/Feature_PhotoInvites/Text");
							}
						}
					}
				}

				// Token: 0x0200028A RID: 650
				public class GROUP_Subscribe_Buttons_4
				{
					// Token: 0x170004FB RID: 1275
					// (get) Token: 0x06000DF5 RID: 3573 RVA: 0x00038569 File Offset: 0x00036769
					public static GameObject SubscribeButton_Monthly
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/SubscribeButton_Monthly");
						}
					}

					// Token: 0x170004FC RID: 1276
					// (get) Token: 0x06000DF6 RID: 3574 RVA: 0x00038575 File Offset: 0x00036775
					public static GameObject SubscribeButton_Yearly
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/SubscribeButton_Yearly");
						}
					}

					// Token: 0x170004FD RID: 1277
					// (get) Token: 0x06000DF7 RID: 3575 RVA: 0x00038581 File Offset: 0x00036781
					public static GameObject GROUP_Manage_Subscription
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Manage_Subscription");
						}
					}

					// Token: 0x170004FE RID: 1278
					// (get) Token: 0x06000DF8 RID: 3576 RVA: 0x0003858D File Offset: 0x0003678D
					public static GameObject GROUP_Button_NotAvailable
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Button_NotAvailable");
						}
					}

					// Token: 0x170004FF RID: 1279
					// (get) Token: 0x06000DF9 RID: 3577 RVA: 0x00038599 File Offset: 0x00036799
					public static GameObject GROUP_IntroductoryOffer_Buttons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_IntroductoryOffer_Buttons");
						}
					}

					// Token: 0x02000337 RID: 823
					public class SubscribeButton_Monthly_5
					{
						// Token: 0x17000654 RID: 1620
						// (get) Token: 0x06000FFB RID: 4091 RVA: 0x00039BAA File Offset: 0x00037DAA
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/SubscribeButton_Monthly/Text");
							}
						}
					}

					// Token: 0x02000338 RID: 824
					public class SubscribeButton_Yearly_5
					{
						// Token: 0x17000655 RID: 1621
						// (get) Token: 0x06000FFD RID: 4093 RVA: 0x00039BBF File Offset: 0x00037DBF
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/SubscribeButton_Yearly/Text");
							}
						}

						// Token: 0x17000656 RID: 1622
						// (get) Token: 0x06000FFE RID: 4094 RVA: 0x00039BCB File Offset: 0x00037DCB
						public static GameObject RawImage
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/SubscribeButton_Yearly/RawImage");
							}
						}
					}

					// Token: 0x02000339 RID: 825
					public class GROUP_Manage_Subscription_5
					{
						// Token: 0x17000657 RID: 1623
						// (get) Token: 0x06001000 RID: 4096 RVA: 0x00039BE0 File Offset: 0x00037DE0
						public static GameObject SubscriptionName
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Manage_Subscription/SubscriptionName");
							}
						}

						// Token: 0x17000658 RID: 1624
						// (get) Token: 0x06001001 RID: 4097 RVA: 0x00039BEC File Offset: 0x00037DEC
						public static GameObject BillingDate
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Manage_Subscription/BillingDate");
							}
						}

						// Token: 0x17000659 RID: 1625
						// (get) Token: 0x06001002 RID: 4098 RVA: 0x00039BF8 File Offset: 0x00037DF8
						public static GameObject Amount
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Manage_Subscription/Amount");
							}
						}

						// Token: 0x1700065A RID: 1626
						// (get) Token: 0x06001003 RID: 4099 RVA: 0x00039C04 File Offset: 0x00037E04
						public static GameObject ManageSubscriptionButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Manage_Subscription/ManageSubscriptionButton");
							}
						}
					}

					// Token: 0x0200033A RID: 826
					public class GROUP_Button_NotAvailable_5
					{
						// Token: 0x1700065B RID: 1627
						// (get) Token: 0x06001005 RID: 4101 RVA: 0x00039C19 File Offset: 0x00037E19
						public static GameObject Button
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_Button_NotAvailable/Button");
							}
						}
					}

					// Token: 0x0200033B RID: 827
					public class GROUP_IntroductoryOffer_Buttons_5
					{
						// Token: 0x1700065C RID: 1628
						// (get) Token: 0x06001007 RID: 4103 RVA: 0x00039C2E File Offset: 0x00037E2E
						public static GameObject SubscribeButton_Monthly
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_IntroductoryOffer_Buttons/SubscribeButton_Monthly");
							}
						}

						// Token: 0x1700065D RID: 1629
						// (get) Token: 0x06001008 RID: 4104 RVA: 0x00039C3A File Offset: 0x00037E3A
						public static GameObject SubscribeButton_Yearly
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_IntroductoryOffer_Buttons/SubscribeButton_Yearly");
							}
						}

						// Token: 0x1700065E RID: 1630
						// (get) Token: 0x06001009 RID: 4105 RVA: 0x00039C46 File Offset: 0x00037E46
						public static GameObject Deal_HeaderPanel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_Subscribe_Buttons/GROUP_IntroductoryOffer_Buttons/Deal_HeaderPanel");
							}
						}
					}
				}

				// Token: 0x0200028B RID: 651
				public class GROUP_FeatureHovers_4
				{
					// Token: 0x17000500 RID: 1280
					// (get) Token: 0x06000DFB RID: 3579 RVA: 0x000385AE File Offset: 0x000367AE
					public static GameObject IMG_FeatureHover_NameIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers/IMG_FeatureHover_NameIcon");
						}
					}

					// Token: 0x17000501 RID: 1281
					// (get) Token: 0x06000DFC RID: 3580 RVA: 0x000385BA File Offset: 0x000367BA
					public static GameObject IMG_FeatureHover_MoreFavoriteAvatars
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers/IMG_FeatureHover_MoreFavoriteAvatars");
						}
					}

					// Token: 0x17000502 RID: 1282
					// (get) Token: 0x06000DFD RID: 3581 RVA: 0x000385C6 File Offset: 0x000367C6
					public static GameObject IMG_FeatureHover_EarlySupporterBadge
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers/IMG_FeatureHover_EarlySupporterBadge");
						}
					}

					// Token: 0x17000503 RID: 1283
					// (get) Token: 0x06000DFE RID: 3582 RVA: 0x000385D2 File Offset: 0x000367D2
					public static GameObject IMG_FeatureHover_ProfileImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers/IMG_FeatureHover_ProfileImage");
						}
					}

					// Token: 0x17000504 RID: 1284
					// (get) Token: 0x06000DFF RID: 3583 RVA: 0x000385DE File Offset: 0x000367DE
					public static GameObject IMG_FeatureHover_PhotoInvites
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/GROUP_FeatureHovers/IMG_FeatureHover_PhotoInvites");
						}
					}
				}

				// Token: 0x0200028C RID: 652
				public class ProcessingOverlay_4
				{
					// Token: 0x17000505 RID: 1285
					// (get) Token: 0x06000E01 RID: 3585 RVA: 0x000385F3 File Offset: 0x000367F3
					public static GameObject CloseButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/CloseButton");
						}
					}

					// Token: 0x17000506 RID: 1286
					// (get) Token: 0x06000E02 RID: 3586 RVA: 0x000385FF File Offset: 0x000367FF
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/Text");
						}
					}

					// Token: 0x17000507 RID: 1287
					// (get) Token: 0x06000E03 RID: 3587 RVA: 0x0003860B File Offset: 0x0003680B
					public static GameObject RawImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/RawImage");
						}
					}

					// Token: 0x17000508 RID: 1288
					// (get) Token: 0x06000E04 RID: 3588 RVA: 0x00038617 File Offset: 0x00036817
					public static GameObject CheckSteamText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/CheckSteamText");
						}
					}

					// Token: 0x17000509 RID: 1289
					// (get) Token: 0x06000E05 RID: 3589 RVA: 0x00038623 File Offset: 0x00036823
					public static GameObject CheckSteamOptionsText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/CheckSteamOptionsText");
						}
					}

					// Token: 0x0200033C RID: 828
					public class CloseButton_5
					{
						// Token: 0x1700065F RID: 1631
						// (get) Token: 0x0600100B RID: 4107 RVA: 0x00039C5B File Offset: 0x00037E5B
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/VRC+/Subscription/ProcessingOverlay/CloseButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000169 RID: 361
		public class WorldInfo_2
		{
			// Token: 0x17000161 RID: 353
			// (get) Token: 0x06000925 RID: 2341 RVA: 0x000347FC File Offset: 0x000329FC
			public static GameObject Panel_1
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panel (1)");
				}
			}

			// Token: 0x17000162 RID: 354
			// (get) Token: 0x06000926 RID: 2342 RVA: 0x00034808 File Offset: 0x00032A08
			public static GameObject Back_Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Back Button");
				}
			}

			// Token: 0x17000163 RID: 355
			// (get) Token: 0x06000927 RID: 2343 RVA: 0x00034814 File Offset: 0x00032A14
			public static GameObject WorldButtons
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons");
				}
			}

			// Token: 0x17000164 RID: 356
			// (get) Token: 0x06000928 RID: 2344 RVA: 0x00034820 File Offset: 0x00032A20
			public static GameObject WorldImage
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage");
				}
			}

			// Token: 0x17000165 RID: 357
			// (get) Token: 0x06000929 RID: 2345 RVA: 0x0003482C File Offset: 0x00032A2C
			public static GameObject OtherInstances
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OtherInstances");
				}
			}

			// Token: 0x17000166 RID: 358
			// (get) Token: 0x0600092A RID: 2346 RVA: 0x00034838 File Offset: 0x00032A38
			public static GameObject MakeHomeButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/MakeHomeButton");
				}
			}

			// Token: 0x17000167 RID: 359
			// (get) Token: 0x0600092B RID: 2347 RVA: 0x00034844 File Offset: 0x00032A44
			public static GameObject ResetHomeButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/ResetHomeButton");
				}
			}

			// Token: 0x17000168 RID: 360
			// (get) Token: 0x0600092C RID: 2348 RVA: 0x00034850 File Offset: 0x00032A50
			public static GameObject ReportButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/ReportButton");
				}
			}

			// Token: 0x17000169 RID: 361
			// (get) Token: 0x0600092D RID: 2349 RVA: 0x0003485C File Offset: 0x00032A5C
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/DepthOverlay");
				}
			}

			// Token: 0x1700016A RID: 362
			// (get) Token: 0x0600092E RID: 2350 RVA: 0x00034868 File Offset: 0x00032A68
			public static GameObject FavoriteButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/FavoriteButton");
				}
			}

			// Token: 0x1700016B RID: 363
			// (get) Token: 0x0600092F RID: 2351 RVA: 0x00034874 File Offset: 0x00032A74
			public static GameObject OwnerTextName
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OwnerText-Name");
				}
			}

			// Token: 0x1700016C RID: 364
			// (get) Token: 0x06000930 RID: 2352 RVA: 0x00034880 File Offset: 0x00032A80
			public static GameObject Panels
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels");
				}
			}

			// Token: 0x020001CC RID: 460
			public class Back_Button_3
			{
				// Token: 0x170002F1 RID: 753
				// (get) Token: 0x06000B2D RID: 2861 RVA: 0x00036643 File Offset: 0x00034843
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Back Button/Text");
					}
				}
			}

			// Token: 0x020001CD RID: 461
			public class WorldButtons_3
			{
				// Token: 0x170002F2 RID: 754
				// (get) Token: 0x06000B2F RID: 2863 RVA: 0x00036658 File Offset: 0x00034858
				public static GameObject GoButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/GoButton");
					}
				}

				// Token: 0x170002F3 RID: 755
				// (get) Token: 0x06000B30 RID: 2864 RVA: 0x00036664 File Offset: 0x00034864
				public static GameObject PortalButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/PortalButton");
					}
				}

				// Token: 0x170002F4 RID: 756
				// (get) Token: 0x06000B31 RID: 2865 RVA: 0x00036670 File Offset: 0x00034870
				public static GameObject NewButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/NewButton");
					}
				}

				// Token: 0x0200028D RID: 653
				public class GoButton_4
				{
					// Token: 0x1700050A RID: 1290
					// (get) Token: 0x06000E07 RID: 3591 RVA: 0x00038638 File Offset: 0x00036838
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/GoButton/Text");
						}
					}
				}

				// Token: 0x0200028E RID: 654
				public class PortalButton_4
				{
					// Token: 0x1700050B RID: 1291
					// (get) Token: 0x06000E09 RID: 3593 RVA: 0x0003864D File Offset: 0x0003684D
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/PortalButton/Text");
						}
					}
				}

				// Token: 0x0200028F RID: 655
				public class NewButton_4
				{
					// Token: 0x1700050C RID: 1292
					// (get) Token: 0x06000E0B RID: 3595 RVA: 0x00038662 File Offset: 0x00036862
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldButtons/NewButton/Text");
						}
					}
				}
			}

			// Token: 0x020001CE RID: 462
			public class WorldImage_3
			{
				// Token: 0x170002F5 RID: 757
				// (get) Token: 0x06000B33 RID: 2867 RVA: 0x00036685 File Offset: 0x00034885
				public static GameObject RoomImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/RoomImage");
					}
				}

				// Token: 0x170002F6 RID: 758
				// (get) Token: 0x06000B34 RID: 2868 RVA: 0x00036691 File Offset: 0x00034891
				public static GameObject RoomBorder
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/RoomBorder");
					}
				}

				// Token: 0x170002F7 RID: 759
				// (get) Token: 0x06000B35 RID: 2869 RVA: 0x0003669D File Offset: 0x0003489D
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/Panel");
					}
				}

				// Token: 0x170002F8 RID: 760
				// (get) Token: 0x06000B36 RID: 2870 RVA: 0x000366A9 File Offset: 0x000348A9
				public static GameObject CurrentInstance
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/CurrentInstance");
					}
				}

				// Token: 0x170002F9 RID: 761
				// (get) Token: 0x06000B37 RID: 2871 RVA: 0x000366B5 File Offset: 0x000348B5
				public static GameObject OverlayIcons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/OverlayIcons");
					}
				}

				// Token: 0x170002FA RID: 762
				// (get) Token: 0x06000B38 RID: 2872 RVA: 0x000366C1 File Offset: 0x000348C1
				public static GameObject InstanceInfo
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo");
					}
				}

				// Token: 0x02000290 RID: 656
				public class Panel_4
				{
					// Token: 0x1700050D RID: 1293
					// (get) Token: 0x06000E0D RID: 3597 RVA: 0x00038677 File Offset: 0x00036877
					public static GameObject NameText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/Panel/NameText");
						}
					}

					// Token: 0x1700050E RID: 1294
					// (get) Token: 0x06000E0E RID: 3598 RVA: 0x00038683 File Offset: 0x00036883
					public static GameObject IconPlayer
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/Panel/IconPlayer");
						}
					}

					// Token: 0x1700050F RID: 1295
					// (get) Token: 0x06000E0F RID: 3599 RVA: 0x0003868F File Offset: 0x0003688F
					public static GameObject PlayerCount
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/Panel/PlayerCount");
						}
					}
				}

				// Token: 0x02000291 RID: 657
				public class CurrentInstance_4
				{
					// Token: 0x17000510 RID: 1296
					// (get) Token: 0x06000E11 RID: 3601 RVA: 0x000386A4 File Offset: 0x000368A4
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/CurrentInstance/Text");
						}
					}
				}

				// Token: 0x02000292 RID: 658
				public class InstanceInfo_4
				{
					// Token: 0x17000511 RID: 1297
					// (get) Token: 0x06000E13 RID: 3603 RVA: 0x000386B9 File Offset: 0x000368B9
					public static GameObject InstanceIdBackground
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstanceIdBackground");
						}
					}

					// Token: 0x17000512 RID: 1298
					// (get) Token: 0x06000E14 RID: 3604 RVA: 0x000386C5 File Offset: 0x000368C5
					public static GameObject InstanceOwnerBackground
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstanceOwnerBackground");
						}
					}

					// Token: 0x17000513 RID: 1299
					// (get) Token: 0x06000E15 RID: 3605 RVA: 0x000386D1 File Offset: 0x000368D1
					public static GameObject InstancePrivacyBackground
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstancePrivacyBackground");
						}
					}

					// Token: 0x0200033D RID: 829
					public class InstanceIdBackground_5
					{
						// Token: 0x17000660 RID: 1632
						// (get) Token: 0x0600100D RID: 4109 RVA: 0x00039C70 File Offset: 0x00037E70
						public static GameObject InstanceId
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstanceIdBackground/InstanceId");
							}
						}
					}

					// Token: 0x0200033E RID: 830
					public class InstanceOwnerBackground_5
					{
						// Token: 0x17000661 RID: 1633
						// (get) Token: 0x0600100F RID: 4111 RVA: 0x00039C85 File Offset: 0x00037E85
						public static GameObject InstanceOwner
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstanceOwnerBackground/InstanceOwner");
							}
						}
					}

					// Token: 0x0200033F RID: 831
					public class InstancePrivacyBackground_5
					{
						// Token: 0x17000662 RID: 1634
						// (get) Token: 0x06001011 RID: 4113 RVA: 0x00039C9A File Offset: 0x00037E9A
						public static GameObject InstancePrivacy
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/WorldImage/InstanceInfo/InstancePrivacyBackground/InstancePrivacy");
							}
						}
					}
				}
			}

			// Token: 0x020001CF RID: 463
			public class OtherInstances_3
			{
				// Token: 0x170002FB RID: 763
				// (get) Token: 0x06000B3A RID: 2874 RVA: 0x000366D6 File Offset: 0x000348D6
				public static GameObject ViewPort
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OtherInstances/ViewPort");
					}
				}

				// Token: 0x170002FC RID: 764
				// (get) Token: 0x06000B3B RID: 2875 RVA: 0x000366E2 File Offset: 0x000348E2
				public static GameObject Button
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OtherInstances/Button");
					}
				}

				// Token: 0x02000293 RID: 659
				public class Button_4
				{
					// Token: 0x17000514 RID: 1300
					// (get) Token: 0x06000E17 RID: 3607 RVA: 0x000386E6 File Offset: 0x000368E6
					public static GameObject TitleText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OtherInstances/Button/TitleText");
						}
					}

					// Token: 0x17000515 RID: 1301
					// (get) Token: 0x06000E18 RID: 3608 RVA: 0x000386F2 File Offset: 0x000368F2
					public static GameObject ToggleIcon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/OtherInstances/Button/ToggleIcon");
						}
					}
				}
			}

			// Token: 0x020001D0 RID: 464
			public class MakeHomeButton_3
			{
				// Token: 0x170002FD RID: 765
				// (get) Token: 0x06000B3D RID: 2877 RVA: 0x000366F7 File Offset: 0x000348F7
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/MakeHomeButton/Text");
					}
				}
			}

			// Token: 0x020001D1 RID: 465
			public class ResetHomeButton_3
			{
				// Token: 0x170002FE RID: 766
				// (get) Token: 0x06000B3F RID: 2879 RVA: 0x0003670C File Offset: 0x0003490C
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/ResetHomeButton/Text");
					}
				}
			}

			// Token: 0x020001D2 RID: 466
			public class ReportButton_3
			{
				// Token: 0x170002FF RID: 767
				// (get) Token: 0x06000B41 RID: 2881 RVA: 0x00036721 File Offset: 0x00034921
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/ReportButton/Text");
					}
				}
			}

			// Token: 0x020001D3 RID: 467
			public class FavoriteButton_3
			{
				// Token: 0x17000300 RID: 768
				// (get) Token: 0x06000B43 RID: 2883 RVA: 0x00036736 File Offset: 0x00034936
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/FavoriteButton/Text");
					}
				}
			}

			// Token: 0x020001D4 RID: 468
			public class Panels_3
			{
				// Token: 0x17000301 RID: 769
				// (get) Token: 0x06000B45 RID: 2885 RVA: 0x0003674B File Offset: 0x0003494B
				public static GameObject PanelBackground
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/PanelBackground");
					}
				}

				// Token: 0x17000302 RID: 770
				// (get) Token: 0x06000B46 RID: 2886 RVA: 0x00036757 File Offset: 0x00034957
				public static GameObject DetailsPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel");
					}
				}

				// Token: 0x17000303 RID: 771
				// (get) Token: 0x06000B47 RID: 2887 RVA: 0x00036763 File Offset: 0x00034963
				public static GameObject TagsPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel");
					}
				}

				// Token: 0x02000294 RID: 660
				public class DetailsPanel_4
				{
					// Token: 0x17000516 RID: 1302
					// (get) Token: 0x06000E1A RID: 3610 RVA: 0x00038707 File Offset: 0x00036907
					public static GameObject AuthorTextTitle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/AuthorText-Title");
						}
					}

					// Token: 0x17000517 RID: 1303
					// (get) Token: 0x06000E1B RID: 3611 RVA: 0x00038713 File Offset: 0x00036913
					public static GameObject WorldSizeTextTitle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/WorldSizeTextTitle");
						}
					}

					// Token: 0x17000518 RID: 1304
					// (get) Token: 0x06000E1C RID: 3612 RVA: 0x0003871F File Offset: 0x0003691F
					public static GameObject PublishStatusData
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/PublishStatus-Data");
						}
					}

					// Token: 0x17000519 RID: 1305
					// (get) Token: 0x06000E1D RID: 3613 RVA: 0x0003872B File Offset: 0x0003692B
					public static GameObject DescTextTitle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/DescText-Title");
						}
					}

					// Token: 0x1700051A RID: 1306
					// (get) Token: 0x06000E1E RID: 3614 RVA: 0x00038737 File Offset: 0x00036937
					public static GameObject PublicTextTitle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/PublicTextTitle");
						}
					}

					// Token: 0x1700051B RID: 1307
					// (get) Token: 0x06000E1F RID: 3615 RVA: 0x00038743 File Offset: 0x00036943
					public static GameObject PrivateTextTitle
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/PrivateTextTitle");
						}
					}

					// Token: 0x1700051C RID: 1308
					// (get) Token: 0x06000E20 RID: 3616 RVA: 0x0003874F File Offset: 0x0003694F
					public static GameObject TagButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/TagButton");
						}
					}

					// Token: 0x02000340 RID: 832
					public class AuthorTextTitle_5
					{
						// Token: 0x17000663 RID: 1635
						// (get) Token: 0x06001013 RID: 4115 RVA: 0x00039CAF File Offset: 0x00037EAF
						public static GameObject AuthorButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/AuthorText-Title/AuthorButton");
							}
						}
					}

					// Token: 0x02000341 RID: 833
					public class WorldSizeTextTitle_5
					{
						// Token: 0x17000664 RID: 1636
						// (get) Token: 0x06001015 RID: 4117 RVA: 0x00039CC4 File Offset: 0x00037EC4
						public static GameObject WorldSizeText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/WorldSizeTextTitle/WorldSizeText");
							}
						}
					}

					// Token: 0x02000342 RID: 834
					public class DescTextTitle_5
					{
						// Token: 0x17000665 RID: 1637
						// (get) Token: 0x06001017 RID: 4119 RVA: 0x00039CD9 File Offset: 0x00037ED9
						public static GameObject DescTextDesc
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/DescText-Title/DescText-Desc");
							}
						}
					}

					// Token: 0x02000343 RID: 835
					public class PublicTextTitle_5
					{
						// Token: 0x17000666 RID: 1638
						// (get) Token: 0x06001019 RID: 4121 RVA: 0x00039CEE File Offset: 0x00037EEE
						public static GameObject PublicText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/PublicTextTitle/PublicText");
							}
						}
					}

					// Token: 0x02000344 RID: 836
					public class PrivateTextTitle_5
					{
						// Token: 0x17000667 RID: 1639
						// (get) Token: 0x0600101B RID: 4123 RVA: 0x00039D03 File Offset: 0x00037F03
						public static GameObject PrivateText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/PrivateTextTitle/PrivateText");
							}
						}
					}

					// Token: 0x02000345 RID: 837
					public class TagButton_5
					{
						// Token: 0x17000668 RID: 1640
						// (get) Token: 0x0600101D RID: 4125 RVA: 0x00039D18 File Offset: 0x00037F18
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/DetailsPanel/TagButton/Image");
							}
						}
					}
				}

				// Token: 0x02000295 RID: 661
				public class TagsPanel_4
				{
					// Token: 0x1700051D RID: 1309
					// (get) Token: 0x06000E22 RID: 3618 RVA: 0x00038764 File Offset: 0x00036964
					public static GameObject TagButtons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons");
						}
					}

					// Token: 0x1700051E RID: 1310
					// (get) Token: 0x06000E23 RID: 3619 RVA: 0x00038770 File Offset: 0x00036970
					public static GameObject DetailsButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/DetailsButton");
						}
					}

					// Token: 0x02000346 RID: 838
					public class TagButtons_5
					{
						// Token: 0x17000669 RID: 1641
						// (get) Token: 0x0600101F RID: 4127 RVA: 0x00039D2D File Offset: 0x00037F2D
						public static GameObject TagButton1
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagButton1");
							}
						}

						// Token: 0x1700066A RID: 1642
						// (get) Token: 0x06001020 RID: 4128 RVA: 0x00039D39 File Offset: 0x00037F39
						public static GameObject TagButton2
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagButton2");
							}
						}

						// Token: 0x1700066B RID: 1643
						// (get) Token: 0x06001021 RID: 4129 RVA: 0x00039D45 File Offset: 0x00037F45
						public static GameObject TagButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagButton3");
							}
						}

						// Token: 0x1700066C RID: 1644
						// (get) Token: 0x06001022 RID: 4130 RVA: 0x00039D51 File Offset: 0x00037F51
						public static GameObject TagButton4
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagButton4");
							}
						}

						// Token: 0x1700066D RID: 1645
						// (get) Token: 0x06001023 RID: 4131 RVA: 0x00039D5D File Offset: 0x00037F5D
						public static GameObject TagButton5
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagButton5");
							}
						}

						// Token: 0x1700066E RID: 1646
						// (get) Token: 0x06001024 RID: 4132 RVA: 0x00039D69 File Offset: 0x00037F69
						public static GameObject TagsLabel
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/TagButtons/TagsLabel");
							}
						}
					}

					// Token: 0x02000347 RID: 839
					public class DetailsButton_5
					{
						// Token: 0x1700066F RID: 1647
						// (get) Token: 0x06001026 RID: 4134 RVA: 0x00039D7E File Offset: 0x00037F7E
						public static GameObject Image
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/WorldInfo/Panels/TagsPanel/DetailsButton/Image");
							}
						}
					}
				}
			}
		}

		// Token: 0x0200016A RID: 362
		public class Worlds_2
		{
			// Token: 0x1700016D RID: 365
			// (get) Token: 0x06000932 RID: 2354 RVA: 0x00034895 File Offset: 0x00032A95
			public static GameObject Vertical_Scroll_View
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Vertical Scroll View");
				}
			}

			// Token: 0x1700016E RID: 366
			// (get) Token: 0x06000933 RID: 2355 RVA: 0x000348A1 File Offset: 0x00032AA1
			public static GameObject Current_Room
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room");
				}
			}

			// Token: 0x1700016F RID: 367
			// (get) Token: 0x06000934 RID: 2356 RVA: 0x000348AD File Offset: 0x00032AAD
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/DepthOverlay");
				}
			}

			// Token: 0x020001D5 RID: 469
			public class Current_Room_3
			{
				// Token: 0x17000304 RID: 772
				// (get) Token: 0x06000B49 RID: 2889 RVA: 0x00036778 File Offset: 0x00034978
				public static GameObject TitlePanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/TitlePanel");
					}
				}

				// Token: 0x17000305 RID: 773
				// (get) Token: 0x06000B4A RID: 2890 RVA: 0x00036784 File Offset: 0x00034984
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/Text");
					}
				}

				// Token: 0x17000306 RID: 774
				// (get) Token: 0x06000B4B RID: 2891 RVA: 0x00036790 File Offset: 0x00034990
				public static GameObject ThisWorldButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/ThisWorldButton");
					}
				}

				// Token: 0x17000307 RID: 775
				// (get) Token: 0x06000B4C RID: 2892 RVA: 0x0003679C File Offset: 0x0003499C
				public static GameObject RespawnButton_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/RespawnButton (1)");
					}
				}

				// Token: 0x17000308 RID: 776
				// (get) Token: 0x06000B4D RID: 2893 RVA: 0x000367A8 File Offset: 0x000349A8
				public static GameObject LikeButton_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/LikeButton (1)");
					}
				}

				// Token: 0x17000309 RID: 777
				// (get) Token: 0x06000B4E RID: 2894 RVA: 0x000367B4 File Offset: 0x000349B4
				public static GameObject TopLine
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/TopLine");
					}
				}

				// Token: 0x1700030A RID: 778
				// (get) Token: 0x06000B4F RID: 2895 RVA: 0x000367C0 File Offset: 0x000349C0
				public static GameObject TopLine_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/TopLine (1)");
					}
				}

				// Token: 0x02000296 RID: 662
				public class ThisWorldButton_4
				{
					// Token: 0x1700051F RID: 1311
					// (get) Token: 0x06000E25 RID: 3621 RVA: 0x00038785 File Offset: 0x00036985
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/ThisWorldButton/Text");
						}
					}
				}

				// Token: 0x02000297 RID: 663
				public class RespawnButton_1_4
				{
					// Token: 0x17000520 RID: 1312
					// (get) Token: 0x06000E27 RID: 3623 RVA: 0x0003879A File Offset: 0x0003699A
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/RespawnButton (1)/Text");
						}
					}

					// Token: 0x17000521 RID: 1313
					// (get) Token: 0x06000E28 RID: 3624 RVA: 0x000387A6 File Offset: 0x000369A6
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/RespawnButton (1)/Image");
						}
					}
				}

				// Token: 0x02000298 RID: 664
				public class LikeButton_1_4
				{
					// Token: 0x17000522 RID: 1314
					// (get) Token: 0x06000E2A RID: 3626 RVA: 0x000387BB File Offset: 0x000369BB
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/LikeButton (1)/Text");
						}
					}

					// Token: 0x17000523 RID: 1315
					// (get) Token: 0x06000E2B RID: 3627 RVA: 0x000387C7 File Offset: 0x000369C7
					public static GameObject Image
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Worlds/Current Room/LikeButton (1)/Image");
						}
					}
				}
			}
		}

		// Token: 0x0200016B RID: 363
		public class Menu_wqoRd0FotfW91RAccountswqoRd0FotfW91R_2
		{
			// Token: 0x17000170 RID: 368
			// (get) Token: 0x06000936 RID: 2358 RVA: 0x000348C2 File Offset: 0x00032AC2
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/TitlePanel");
				}
			}

			// Token: 0x17000171 RID: 369
			// (get) Token: 0x06000937 RID: 2359 RVA: 0x000348CE File Offset: 0x00032ACE
			public static GameObject ComfortSafetyPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel");
				}
			}

			// Token: 0x17000172 RID: 370
			// (get) Token: 0x06000938 RID: 2360 RVA: 0x000348DA File Offset: 0x00032ADA
			public static GameObject AudioDevicePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel");
				}
			}

			// Token: 0x17000173 RID: 371
			// (get) Token: 0x06000939 RID: 2361 RVA: 0x000348E6 File Offset: 0x00032AE6
			public static GameObject MousePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel");
				}
			}

			// Token: 0x17000174 RID: 372
			// (get) Token: 0x0600093A RID: 2362 RVA: 0x000348F2 File Offset: 0x00032AF2
			public static GameObject HeightPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel");
				}
			}

			// Token: 0x17000175 RID: 373
			// (get) Token: 0x0600093B RID: 2363 RVA: 0x000348FE File Offset: 0x00032AFE
			public static GameObject VoiceOptionsPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel");
				}
			}

			// Token: 0x17000176 RID: 374
			// (get) Token: 0x0600093C RID: 2364 RVA: 0x0003490A File Offset: 0x00032B0A
			public static GameObject OtherOptionsPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel");
				}
			}

			// Token: 0x17000177 RID: 375
			// (get) Token: 0x0600093D RID: 2365 RVA: 0x00034916 File Offset: 0x00032B16
			public static GameObject VolumePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel");
				}
			}

			// Token: 0x17000178 RID: 376
			// (get) Token: 0x0600093E RID: 2366 RVA: 0x00034922 File Offset: 0x00032B22
			public static GameObject Footer
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer");
				}
			}

			// Token: 0x17000179 RID: 377
			// (get) Token: 0x0600093F RID: 2367 RVA: 0x0003492E File Offset: 0x00032B2E
			public static GameObject DepthOverlay
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/DepthOverlay");
				}
			}

			// Token: 0x1700017A RID: 378
			// (get) Token: 0x06000940 RID: 2368 RVA: 0x0003493A File Offset: 0x00032B3A
			public static GameObject Button_AdvancedOptions
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Button_AdvancedOptions");
				}
			}

			// Token: 0x1700017B RID: 379
			// (get) Token: 0x06000941 RID: 2369 RVA: 0x00034946 File Offset: 0x00032B46
			public static GameObject Button_EditBindings
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Button_EditBindings");
				}
			}

			// Token: 0x1700017C RID: 380
			// (get) Token: 0x06000942 RID: 2370 RVA: 0x00034952 File Offset: 0x00032B52
			public static GameObject UserVolumeOptions
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/UserVolumeOptions");
				}
			}

			// Token: 0x020001D6 RID: 470
			public class TitlePanel_3
			{
				// Token: 0x1700030B RID: 779
				// (get) Token: 0x06000B51 RID: 2897 RVA: 0x000367D5 File Offset: 0x000349D5
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/TitlePanel/TitleText");
					}
				}

				// Token: 0x1700030C RID: 780
				// (get) Token: 0x06000B52 RID: 2898 RVA: 0x000367E1 File Offset: 0x000349E1
				public static GameObject VersionText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/TitlePanel/VersionText");
					}
				}
			}

			// Token: 0x020001D7 RID: 471
			public class ComfortSafetyPanel_3
			{
				// Token: 0x1700030D RID: 781
				// (get) Token: 0x06000B54 RID: 2900 RVA: 0x000367F6 File Offset: 0x000349F6
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/Panel_Header");
					}
				}

				// Token: 0x1700030E RID: 782
				// (get) Token: 0x06000B55 RID: 2901 RVA: 0x00036802 File Offset: 0x00034A02
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/TitleText (1)");
					}
				}

				// Token: 0x1700030F RID: 783
				// (get) Token: 0x06000B56 RID: 2902 RVA: 0x0003680E File Offset: 0x00034A0E
				public static GameObject HoloportToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HoloportToggle");
					}
				}

				// Token: 0x17000310 RID: 784
				// (get) Token: 0x06000B57 RID: 2903 RVA: 0x0003681A File Offset: 0x00034A1A
				public static GameObject ComfortTurnToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/ComfortTurnToggle");
					}
				}

				// Token: 0x17000311 RID: 785
				// (get) Token: 0x06000B58 RID: 2904 RVA: 0x00036826 File Offset: 0x00034A26
				public static GameObject PersonalSpaceToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/PersonalSpaceToggle");
					}
				}

				// Token: 0x17000312 RID: 786
				// (get) Token: 0x06000B59 RID: 2905 RVA: 0x00036832 File Offset: 0x00034A32
				public static GameObject AllowUntrustedURL
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/AllowUntrustedURL");
					}
				}

				// Token: 0x17000313 RID: 787
				// (get) Token: 0x06000B5A RID: 2906 RVA: 0x0003683E File Offset: 0x00034A3E
				public static GameObject StreamerModeToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/StreamerModeToggle");
					}
				}

				// Token: 0x17000314 RID: 788
				// (get) Token: 0x06000B5B RID: 2907 RVA: 0x0003684A File Offset: 0x00034A4A
				public static GameObject MuteUsersToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/MuteUsersToggle");
					}
				}

				// Token: 0x17000315 RID: 789
				// (get) Token: 0x06000B5C RID: 2908 RVA: 0x00036856 File Offset: 0x00034A56
				public static GameObject BlockAvatarsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/BlockAvatarsToggle");
					}
				}

				// Token: 0x17000316 RID: 790
				// (get) Token: 0x06000B5D RID: 2909 RVA: 0x00036862 File Offset: 0x00034A62
				public static GameObject HeadSetGazeToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HeadSetGazeToggle");
					}
				}

				// Token: 0x17000317 RID: 791
				// (get) Token: 0x06000B5E RID: 2910 RVA: 0x0003686E File Offset: 0x00034A6E
				public static GameObject KeyboardToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/KeyboardToggle");
					}
				}

				// Token: 0x17000318 RID: 792
				// (get) Token: 0x06000B5F RID: 2911 RVA: 0x0003687A File Offset: 0x00034A7A
				public static GameObject GamepadToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/GamepadToggle");
					}
				}

				// Token: 0x17000319 RID: 793
				// (get) Token: 0x06000B60 RID: 2912 RVA: 0x00036886 File Offset: 0x00034A86
				public static GameObject PrimaryInputPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/PrimaryInputPanel");
					}
				}

				// Token: 0x1700031A RID: 794
				// (get) Token: 0x06000B61 RID: 2913 RVA: 0x00036892 File Offset: 0x00034A92
				public static GameObject LocomotionInputPanel_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/LocomotionInputPanel (1)");
					}
				}

				// Token: 0x02000299 RID: 665
				public class HoloportToggle_4
				{
					// Token: 0x17000524 RID: 1316
					// (get) Token: 0x06000E2D RID: 3629 RVA: 0x000387DC File Offset: 0x000369DC
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HoloportToggle/Background");
						}
					}

					// Token: 0x17000525 RID: 1317
					// (get) Token: 0x06000E2E RID: 3630 RVA: 0x000387E8 File Offset: 0x000369E8
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HoloportToggle/Label");
						}
					}

					// Token: 0x02000348 RID: 840
					public class Background_5
					{
						// Token: 0x17000670 RID: 1648
						// (get) Token: 0x06001028 RID: 4136 RVA: 0x00039D93 File Offset: 0x00037F93
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HoloportToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029A RID: 666
				public class ComfortTurnToggle_4
				{
					// Token: 0x17000526 RID: 1318
					// (get) Token: 0x06000E30 RID: 3632 RVA: 0x000387FD File Offset: 0x000369FD
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/ComfortTurnToggle/Background");
						}
					}

					// Token: 0x17000527 RID: 1319
					// (get) Token: 0x06000E31 RID: 3633 RVA: 0x00038809 File Offset: 0x00036A09
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/ComfortTurnToggle/Label");
						}
					}

					// Token: 0x02000349 RID: 841
					public class Background_5
					{
						// Token: 0x17000671 RID: 1649
						// (get) Token: 0x0600102A RID: 4138 RVA: 0x00039DA8 File Offset: 0x00037FA8
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/ComfortTurnToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029B RID: 667
				public class PersonalSpaceToggle_4
				{
					// Token: 0x17000528 RID: 1320
					// (get) Token: 0x06000E33 RID: 3635 RVA: 0x0003881E File Offset: 0x00036A1E
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/PersonalSpaceToggle/Background");
						}
					}

					// Token: 0x17000529 RID: 1321
					// (get) Token: 0x06000E34 RID: 3636 RVA: 0x0003882A File Offset: 0x00036A2A
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/PersonalSpaceToggle/Label");
						}
					}

					// Token: 0x0200034A RID: 842
					public class Background_5
					{
						// Token: 0x17000672 RID: 1650
						// (get) Token: 0x0600102C RID: 4140 RVA: 0x00039DBD File Offset: 0x00037FBD
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/PersonalSpaceToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029C RID: 668
				public class AllowUntrustedURL_4
				{
					// Token: 0x1700052A RID: 1322
					// (get) Token: 0x06000E36 RID: 3638 RVA: 0x0003883F File Offset: 0x00036A3F
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/AllowUntrustedURL/Background");
						}
					}

					// Token: 0x1700052B RID: 1323
					// (get) Token: 0x06000E37 RID: 3639 RVA: 0x0003884B File Offset: 0x00036A4B
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/AllowUntrustedURL/Label");
						}
					}

					// Token: 0x0200034B RID: 843
					public class Background_5
					{
						// Token: 0x17000673 RID: 1651
						// (get) Token: 0x0600102E RID: 4142 RVA: 0x00039DD2 File Offset: 0x00037FD2
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/AllowUntrustedURL/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029D RID: 669
				public class StreamerModeToggle_4
				{
					// Token: 0x1700052C RID: 1324
					// (get) Token: 0x06000E39 RID: 3641 RVA: 0x00038860 File Offset: 0x00036A60
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/StreamerModeToggle/Background");
						}
					}

					// Token: 0x1700052D RID: 1325
					// (get) Token: 0x06000E3A RID: 3642 RVA: 0x0003886C File Offset: 0x00036A6C
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/StreamerModeToggle/Label");
						}
					}

					// Token: 0x1700052E RID: 1326
					// (get) Token: 0x06000E3B RID: 3643 RVA: 0x00038878 File Offset: 0x00036A78
					public static GameObject InfoButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/StreamerModeToggle/InfoButton");
						}
					}

					// Token: 0x0200034C RID: 844
					public class Background_5
					{
						// Token: 0x17000674 RID: 1652
						// (get) Token: 0x06001030 RID: 4144 RVA: 0x00039DE7 File Offset: 0x00037FE7
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/StreamerModeToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029E RID: 670
				public class MuteUsersToggle_4
				{
					// Token: 0x1700052F RID: 1327
					// (get) Token: 0x06000E3D RID: 3645 RVA: 0x0003888D File Offset: 0x00036A8D
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/MuteUsersToggle/Background");
						}
					}

					// Token: 0x17000530 RID: 1328
					// (get) Token: 0x06000E3E RID: 3646 RVA: 0x00038899 File Offset: 0x00036A99
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/MuteUsersToggle/Label");
						}
					}

					// Token: 0x0200034D RID: 845
					public class Background_5
					{
						// Token: 0x17000675 RID: 1653
						// (get) Token: 0x06001032 RID: 4146 RVA: 0x00039DFC File Offset: 0x00037FFC
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/MuteUsersToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x0200029F RID: 671
				public class BlockAvatarsToggle_4
				{
					// Token: 0x17000531 RID: 1329
					// (get) Token: 0x06000E40 RID: 3648 RVA: 0x000388AE File Offset: 0x00036AAE
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/BlockAvatarsToggle/Background");
						}
					}

					// Token: 0x17000532 RID: 1330
					// (get) Token: 0x06000E41 RID: 3649 RVA: 0x000388BA File Offset: 0x00036ABA
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/BlockAvatarsToggle/Label");
						}
					}

					// Token: 0x0200034E RID: 846
					public class Background_5
					{
						// Token: 0x17000676 RID: 1654
						// (get) Token: 0x06001034 RID: 4148 RVA: 0x00039E11 File Offset: 0x00038011
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/BlockAvatarsToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002A0 RID: 672
				public class HeadSetGazeToggle_4
				{
					// Token: 0x17000533 RID: 1331
					// (get) Token: 0x06000E43 RID: 3651 RVA: 0x000388CF File Offset: 0x00036ACF
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HeadSetGazeToggle/Background");
						}
					}

					// Token: 0x17000534 RID: 1332
					// (get) Token: 0x06000E44 RID: 3652 RVA: 0x000388DB File Offset: 0x00036ADB
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HeadSetGazeToggle/Label");
						}
					}

					// Token: 0x0200034F RID: 847
					public class Background_5
					{
						// Token: 0x17000677 RID: 1655
						// (get) Token: 0x06001036 RID: 4150 RVA: 0x00039E26 File Offset: 0x00038026
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/HeadSetGazeToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002A1 RID: 673
				public class KeyboardToggle_4
				{
					// Token: 0x17000535 RID: 1333
					// (get) Token: 0x06000E46 RID: 3654 RVA: 0x000388F0 File Offset: 0x00036AF0
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/KeyboardToggle/Background");
						}
					}

					// Token: 0x17000536 RID: 1334
					// (get) Token: 0x06000E47 RID: 3655 RVA: 0x000388FC File Offset: 0x00036AFC
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/KeyboardToggle/Label");
						}
					}

					// Token: 0x02000350 RID: 848
					public class Background_5
					{
						// Token: 0x17000678 RID: 1656
						// (get) Token: 0x06001038 RID: 4152 RVA: 0x00039E3B File Offset: 0x0003803B
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/KeyboardToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002A2 RID: 674
				public class GamepadToggle_4
				{
					// Token: 0x17000537 RID: 1335
					// (get) Token: 0x06000E49 RID: 3657 RVA: 0x00038911 File Offset: 0x00036B11
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/GamepadToggle/Background");
						}
					}

					// Token: 0x17000538 RID: 1336
					// (get) Token: 0x06000E4A RID: 3658 RVA: 0x0003891D File Offset: 0x00036B1D
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/GamepadToggle/Label");
						}
					}

					// Token: 0x02000351 RID: 849
					public class Background_5
					{
						// Token: 0x17000679 RID: 1657
						// (get) Token: 0x0600103A RID: 4154 RVA: 0x00039E50 File Offset: 0x00038050
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/ComfortSafetyPanel/GamepadToggle/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001D8 RID: 472
			public class AudioDevicePanel_3
			{
				// Token: 0x1700031B RID: 795
				// (get) Token: 0x06000B63 RID: 2915 RVA: 0x000368A7 File Offset: 0x00034AA7
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/Panel_Header");
					}
				}

				// Token: 0x1700031C RID: 796
				// (get) Token: 0x06000B64 RID: 2916 RVA: 0x000368B3 File Offset: 0x00034AB3
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/TitleText");
					}
				}

				// Token: 0x1700031D RID: 797
				// (get) Token: 0x06000B65 RID: 2917 RVA: 0x000368BF File Offset: 0x00034ABF
				public static GameObject LevelText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/LevelText");
					}
				}

				// Token: 0x1700031E RID: 798
				// (get) Token: 0x06000B66 RID: 2918 RVA: 0x000368CB File Offset: 0x00034ACB
				public static GameObject VolumeSlider
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeSlider");
					}
				}

				// Token: 0x1700031F RID: 799
				// (get) Token: 0x06000B67 RID: 2919 RVA: 0x000368D7 File Offset: 0x00034AD7
				public static GameObject VolumeDisplay
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeDisplay");
					}
				}

				// Token: 0x17000320 RID: 800
				// (get) Token: 0x06000B68 RID: 2920 RVA: 0x000368E3 File Offset: 0x00034AE3
				public static GameObject SelectPrevMic
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/SelectPrevMic");
					}
				}

				// Token: 0x17000321 RID: 801
				// (get) Token: 0x06000B69 RID: 2921 RVA: 0x000368EF File Offset: 0x00034AEF
				public static GameObject SelectNextMic
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/SelectNextMic");
					}
				}

				// Token: 0x17000322 RID: 802
				// (get) Token: 0x06000B6A RID: 2922 RVA: 0x000368FB File Offset: 0x00034AFB
				public static GameObject MicDeviceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/MicDeviceText");
					}
				}

				// Token: 0x020002A3 RID: 675
				public class VolumeSlider_4
				{
					// Token: 0x17000539 RID: 1337
					// (get) Token: 0x06000E4C RID: 3660 RVA: 0x00038932 File Offset: 0x00036B32
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeSlider/Fill Area");
						}
					}

					// Token: 0x02000352 RID: 850
					public class Fill_Area_5
					{
						// Token: 0x1700067A RID: 1658
						// (get) Token: 0x0600103C RID: 4156 RVA: 0x00039E65 File Offset: 0x00038065
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeSlider/Fill Area/Fill");
							}
						}

						// Token: 0x1700067B RID: 1659
						// (get) Token: 0x0600103D RID: 4157 RVA: 0x00039E71 File Offset: 0x00038071
						public static GameObject Label
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeSlider/Fill Area/Label");
							}
						}
					}
				}

				// Token: 0x020002A4 RID: 676
				public class VolumeDisplay_4
				{
					// Token: 0x1700053A RID: 1338
					// (get) Token: 0x06000E4E RID: 3662 RVA: 0x00038947 File Offset: 0x00036B47
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeDisplay/Background");
						}
					}

					// Token: 0x1700053B RID: 1339
					// (get) Token: 0x06000E4F RID: 3663 RVA: 0x00038953 File Offset: 0x00036B53
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeDisplay/Fill Area");
						}
					}

					// Token: 0x02000353 RID: 851
					public class Fill_Area_5
					{
						// Token: 0x1700067C RID: 1660
						// (get) Token: 0x0600103F RID: 4159 RVA: 0x00039E86 File Offset: 0x00038086
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/AudioDevicePanel/VolumeDisplay/Fill Area/Fill");
							}
						}
					}
				}
			}

			// Token: 0x020001D9 RID: 473
			public class MousePanel_3
			{
				// Token: 0x17000323 RID: 803
				// (get) Token: 0x06000B6C RID: 2924 RVA: 0x00036910 File Offset: 0x00034B10
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/Panel_Header");
					}
				}

				// Token: 0x17000324 RID: 804
				// (get) Token: 0x06000B6D RID: 2925 RVA: 0x0003691C File Offset: 0x00034B1C
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/TitleText");
					}
				}

				// Token: 0x17000325 RID: 805
				// (get) Token: 0x06000B6E RID: 2926 RVA: 0x00036928 File Offset: 0x00034B28
				public static GameObject MouseSensitivityText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/MouseSensitivityText");
					}
				}

				// Token: 0x17000326 RID: 806
				// (get) Token: 0x06000B6F RID: 2927 RVA: 0x00036934 File Offset: 0x00034B34
				public static GameObject SensitivitySlider
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider");
					}
				}

				// Token: 0x17000327 RID: 807
				// (get) Token: 0x06000B70 RID: 2928 RVA: 0x00036940 File Offset: 0x00034B40
				public static GameObject InvertedMouse
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/InvertedMouse");
					}
				}

				// Token: 0x020002A5 RID: 677
				public class SensitivitySlider_4
				{
					// Token: 0x1700053C RID: 1340
					// (get) Token: 0x06000E51 RID: 3665 RVA: 0x00038968 File Offset: 0x00036B68
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider/Background");
						}
					}

					// Token: 0x1700053D RID: 1341
					// (get) Token: 0x06000E52 RID: 3666 RVA: 0x00038974 File Offset: 0x00036B74
					public static GameObject Fill_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider/Fill Area");
						}
					}

					// Token: 0x1700053E RID: 1342
					// (get) Token: 0x06000E53 RID: 3667 RVA: 0x00038980 File Offset: 0x00036B80
					public static GameObject Handle_Slide_Area
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider/Handle Slide Area");
						}
					}

					// Token: 0x02000354 RID: 852
					public class Fill_Area_5
					{
						// Token: 0x1700067D RID: 1661
						// (get) Token: 0x06001041 RID: 4161 RVA: 0x00039E9B File Offset: 0x0003809B
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider/Fill Area/Fill");
							}
						}
					}

					// Token: 0x02000355 RID: 853
					public class Handle_Slide_Area_5
					{
						// Token: 0x1700067E RID: 1662
						// (get) Token: 0x06001043 RID: 4163 RVA: 0x00039EB0 File Offset: 0x000380B0
						public static GameObject Handle
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/SensitivitySlider/Handle Slide Area/Handle");
							}
						}
					}
				}

				// Token: 0x020002A6 RID: 678
				public class InvertedMouse_4
				{
					// Token: 0x1700053F RID: 1343
					// (get) Token: 0x06000E55 RID: 3669 RVA: 0x00038995 File Offset: 0x00036B95
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/InvertedMouse/Background");
						}
					}

					// Token: 0x17000540 RID: 1344
					// (get) Token: 0x06000E56 RID: 3670 RVA: 0x000389A1 File Offset: 0x00036BA1
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/InvertedMouse/Label");
						}
					}

					// Token: 0x02000356 RID: 854
					public class Background_5
					{
						// Token: 0x1700067F RID: 1663
						// (get) Token: 0x06001045 RID: 4165 RVA: 0x00039EC5 File Offset: 0x000380C5
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/MousePanel/InvertedMouse/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001DA RID: 474
			public class HeightPanel_3
			{
				// Token: 0x17000328 RID: 808
				// (get) Token: 0x06000B72 RID: 2930 RVA: 0x00036955 File Offset: 0x00034B55
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel/Panel_Header");
					}
				}

				// Token: 0x17000329 RID: 809
				// (get) Token: 0x06000B73 RID: 2931 RVA: 0x00036961 File Offset: 0x00034B61
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel/TitleText (1)");
					}
				}

				// Token: 0x1700032A RID: 810
				// (get) Token: 0x06000B74 RID: 2932 RVA: 0x0003696D File Offset: 0x00034B6D
				public static GameObject HeightUP
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel/HeightUP");
					}
				}

				// Token: 0x1700032B RID: 811
				// (get) Token: 0x06000B75 RID: 2933 RVA: 0x00036979 File Offset: 0x00034B79
				public static GameObject HeightDOWN
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel/HeightDOWN");
					}
				}

				// Token: 0x1700032C RID: 812
				// (get) Token: 0x06000B76 RID: 2934 RVA: 0x00036985 File Offset: 0x00034B85
				public static GameObject Label
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/HeightPanel/Label");
					}
				}
			}

			// Token: 0x020001DB RID: 475
			public class VoiceOptionsPanel_3
			{
				// Token: 0x1700032D RID: 813
				// (get) Token: 0x06000B78 RID: 2936 RVA: 0x0003699A File Offset: 0x00034B9A
				public static GameObject Panel_Header
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/Panel_Header");
					}
				}

				// Token: 0x1700032E RID: 814
				// (get) Token: 0x06000B79 RID: 2937 RVA: 0x000369A6 File Offset: 0x00034BA6
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/TitleText (1)");
					}
				}

				// Token: 0x1700032F RID: 815
				// (get) Token: 0x06000B7A RID: 2938 RVA: 0x000369B2 File Offset: 0x00034BB2
				public static GameObject HardwareConfigToggle_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (1)");
					}
				}

				// Token: 0x17000330 RID: 816
				// (get) Token: 0x06000B7B RID: 2939 RVA: 0x000369BE File Offset: 0x00034BBE
				public static GameObject HardwareConfigToggle_4
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (4)");
					}
				}

				// Token: 0x17000331 RID: 817
				// (get) Token: 0x06000B7C RID: 2940 RVA: 0x000369CA File Offset: 0x00034BCA
				public static GameObject HardwareConfigToggle_6
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (6)");
					}
				}

				// Token: 0x17000332 RID: 818
				// (get) Token: 0x06000B7D RID: 2941 RVA: 0x000369D6 File Offset: 0x00034BD6
				public static GameObject HardwareConfigToggle_2
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (2)");
					}
				}

				// Token: 0x020002A7 RID: 679
				public class HardwareConfigToggle_1_4
				{
					// Token: 0x17000541 RID: 1345
					// (get) Token: 0x06000E58 RID: 3672 RVA: 0x000389B6 File Offset: 0x00036BB6
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (1)/Background");
						}
					}

					// Token: 0x17000542 RID: 1346
					// (get) Token: 0x06000E59 RID: 3673 RVA: 0x000389C2 File Offset: 0x00036BC2
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (1)/Label");
						}
					}

					// Token: 0x02000357 RID: 855
					public class Background_5
					{
						// Token: 0x17000680 RID: 1664
						// (get) Token: 0x06001047 RID: 4167 RVA: 0x00039EDA File Offset: 0x000380DA
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (1)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002A8 RID: 680
				public class HardwareConfigToggle_4_4
				{
					// Token: 0x17000543 RID: 1347
					// (get) Token: 0x06000E5B RID: 3675 RVA: 0x000389D7 File Offset: 0x00036BD7
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (4)/Background");
						}
					}

					// Token: 0x17000544 RID: 1348
					// (get) Token: 0x06000E5C RID: 3676 RVA: 0x000389E3 File Offset: 0x00036BE3
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (4)/Label");
						}
					}

					// Token: 0x02000358 RID: 856
					public class Background_5
					{
						// Token: 0x17000681 RID: 1665
						// (get) Token: 0x06001049 RID: 4169 RVA: 0x00039EEF File Offset: 0x000380EF
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (4)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002A9 RID: 681
				public class HardwareConfigToggle_6_4
				{
					// Token: 0x17000545 RID: 1349
					// (get) Token: 0x06000E5E RID: 3678 RVA: 0x000389F8 File Offset: 0x00036BF8
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (6)/Background");
						}
					}

					// Token: 0x17000546 RID: 1350
					// (get) Token: 0x06000E5F RID: 3679 RVA: 0x00038A04 File Offset: 0x00036C04
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (6)/Label");
						}
					}

					// Token: 0x02000359 RID: 857
					public class Background_5
					{
						// Token: 0x17000682 RID: 1666
						// (get) Token: 0x0600104B RID: 4171 RVA: 0x00039F04 File Offset: 0x00038104
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (6)/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002AA RID: 682
				public class HardwareConfigToggle_2_4
				{
					// Token: 0x17000547 RID: 1351
					// (get) Token: 0x06000E61 RID: 3681 RVA: 0x00038A19 File Offset: 0x00036C19
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (2)/Background");
						}
					}

					// Token: 0x17000548 RID: 1352
					// (get) Token: 0x06000E62 RID: 3682 RVA: 0x00038A25 File Offset: 0x00036C25
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (2)/Label");
						}
					}

					// Token: 0x0200035A RID: 858
					public class Background_5
					{
						// Token: 0x17000683 RID: 1667
						// (get) Token: 0x0600104D RID: 4173 RVA: 0x00039F19 File Offset: 0x00038119
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VoiceOptionsPanel/HardwareConfigToggle (2)/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001DC RID: 476
			public class OtherOptionsPanel_3
			{
				// Token: 0x17000333 RID: 819
				// (get) Token: 0x06000B7F RID: 2943 RVA: 0x000369EB File Offset: 0x00034BEB
				public static GameObject Panel_Header_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/Panel_Header (1)");
					}
				}

				// Token: 0x17000334 RID: 820
				// (get) Token: 0x06000B80 RID: 2944 RVA: 0x000369F7 File Offset: 0x00034BF7
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/TitleText (1)");
					}
				}

				// Token: 0x17000335 RID: 821
				// (get) Token: 0x06000B81 RID: 2945 RVA: 0x00036A03 File Offset: 0x00034C03
				public static GameObject HeadLookToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/HeadLookToggle");
					}
				}

				// Token: 0x17000336 RID: 822
				// (get) Token: 0x06000B82 RID: 2946 RVA: 0x00036A0F File Offset: 0x00034C0F
				public static GameObject TooltipsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/TooltipsToggle");
					}
				}

				// Token: 0x17000337 RID: 823
				// (get) Token: 0x06000B83 RID: 2947 RVA: 0x00036A1B File Offset: 0x00034C1B
				public static GameObject PRotationToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/3PRotationToggle");
					}
				}

				// Token: 0x17000338 RID: 824
				// (get) Token: 0x06000B84 RID: 2948 RVA: 0x00036A27 File Offset: 0x00034C27
				public static GameObject ViveAdvancedToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ViveAdvancedToggle");
					}
				}

				// Token: 0x17000339 RID: 825
				// (get) Token: 0x06000B85 RID: 2949 RVA: 0x00036A33 File Offset: 0x00034C33
				public static GameObject SkipGoButtonInLoad
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/SkipGoButtonInLoad");
					}
				}

				// Token: 0x1700033A RID: 826
				// (get) Token: 0x06000B86 RID: 2950 RVA: 0x00036A3F File Offset: 0x00034C3F
				public static GameObject DesktopReticle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/DesktopReticle");
					}
				}

				// Token: 0x1700033B RID: 827
				// (get) Token: 0x06000B87 RID: 2951 RVA: 0x00036A4B File Offset: 0x00034C4B
				public static GameObject AllowAvatarCopyingToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/AllowAvatarCopyingToggle");
					}
				}

				// Token: 0x1700033C RID: 828
				// (get) Token: 0x06000B88 RID: 2952 RVA: 0x00036A57 File Offset: 0x00034C57
				public static GameObject ShowCommunityLabsToggle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ShowCommunityLabsToggle");
					}
				}

				// Token: 0x020002AB RID: 683
				public class HeadLookToggle_4
				{
					// Token: 0x17000549 RID: 1353
					// (get) Token: 0x06000E64 RID: 3684 RVA: 0x00038A3A File Offset: 0x00036C3A
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/HeadLookToggle/Background");
						}
					}

					// Token: 0x1700054A RID: 1354
					// (get) Token: 0x06000E65 RID: 3685 RVA: 0x00038A46 File Offset: 0x00036C46
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/HeadLookToggle/Label");
						}
					}

					// Token: 0x0200035B RID: 859
					public class Background_5
					{
						// Token: 0x17000684 RID: 1668
						// (get) Token: 0x0600104F RID: 4175 RVA: 0x00039F2E File Offset: 0x0003812E
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/HeadLookToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002AC RID: 684
				public class TooltipsToggle_4
				{
					// Token: 0x1700054B RID: 1355
					// (get) Token: 0x06000E67 RID: 3687 RVA: 0x00038A5B File Offset: 0x00036C5B
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/TooltipsToggle/Background");
						}
					}

					// Token: 0x1700054C RID: 1356
					// (get) Token: 0x06000E68 RID: 3688 RVA: 0x00038A67 File Offset: 0x00036C67
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/TooltipsToggle/Label");
						}
					}

					// Token: 0x0200035C RID: 860
					public class Background_5
					{
						// Token: 0x17000685 RID: 1669
						// (get) Token: 0x06001051 RID: 4177 RVA: 0x00039F43 File Offset: 0x00038143
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/TooltipsToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002AD RID: 685
				public class PRotationToggle_4
				{
					// Token: 0x1700054D RID: 1357
					// (get) Token: 0x06000E6A RID: 3690 RVA: 0x00038A7C File Offset: 0x00036C7C
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/3PRotationToggle/Background");
						}
					}

					// Token: 0x1700054E RID: 1358
					// (get) Token: 0x06000E6B RID: 3691 RVA: 0x00038A88 File Offset: 0x00036C88
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/3PRotationToggle/Label");
						}
					}

					// Token: 0x0200035D RID: 861
					public class Background_5
					{
						// Token: 0x17000686 RID: 1670
						// (get) Token: 0x06001053 RID: 4179 RVA: 0x00039F58 File Offset: 0x00038158
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/3PRotationToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002AE RID: 686
				public class ViveAdvancedToggle_4
				{
					// Token: 0x1700054F RID: 1359
					// (get) Token: 0x06000E6D RID: 3693 RVA: 0x00038A9D File Offset: 0x00036C9D
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ViveAdvancedToggle/Background");
						}
					}

					// Token: 0x17000550 RID: 1360
					// (get) Token: 0x06000E6E RID: 3694 RVA: 0x00038AA9 File Offset: 0x00036CA9
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ViveAdvancedToggle/Label");
						}
					}

					// Token: 0x0200035E RID: 862
					public class Background_5
					{
						// Token: 0x17000687 RID: 1671
						// (get) Token: 0x06001055 RID: 4181 RVA: 0x00039F6D File Offset: 0x0003816D
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ViveAdvancedToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002AF RID: 687
				public class SkipGoButtonInLoad_4
				{
					// Token: 0x17000551 RID: 1361
					// (get) Token: 0x06000E70 RID: 3696 RVA: 0x00038ABE File Offset: 0x00036CBE
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/SkipGoButtonInLoad/Background");
						}
					}

					// Token: 0x17000552 RID: 1362
					// (get) Token: 0x06000E71 RID: 3697 RVA: 0x00038ACA File Offset: 0x00036CCA
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/SkipGoButtonInLoad/Label");
						}
					}

					// Token: 0x0200035F RID: 863
					public class Background_5
					{
						// Token: 0x17000688 RID: 1672
						// (get) Token: 0x06001057 RID: 4183 RVA: 0x00039F82 File Offset: 0x00038182
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/SkipGoButtonInLoad/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002B0 RID: 688
				public class DesktopReticle_4
				{
					// Token: 0x17000553 RID: 1363
					// (get) Token: 0x06000E73 RID: 3699 RVA: 0x00038ADF File Offset: 0x00036CDF
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/DesktopReticle/Background");
						}
					}

					// Token: 0x17000554 RID: 1364
					// (get) Token: 0x06000E74 RID: 3700 RVA: 0x00038AEB File Offset: 0x00036CEB
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/DesktopReticle/Label");
						}
					}

					// Token: 0x02000360 RID: 864
					public class Background_5
					{
						// Token: 0x17000689 RID: 1673
						// (get) Token: 0x06001059 RID: 4185 RVA: 0x00039F97 File Offset: 0x00038197
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/DesktopReticle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002B1 RID: 689
				public class AllowAvatarCopyingToggle_4
				{
					// Token: 0x17000555 RID: 1365
					// (get) Token: 0x06000E76 RID: 3702 RVA: 0x00038B00 File Offset: 0x00036D00
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/AllowAvatarCopyingToggle/Background");
						}
					}

					// Token: 0x17000556 RID: 1366
					// (get) Token: 0x06000E77 RID: 3703 RVA: 0x00038B0C File Offset: 0x00036D0C
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/AllowAvatarCopyingToggle/Label");
						}
					}

					// Token: 0x02000361 RID: 865
					public class Background_5
					{
						// Token: 0x1700068A RID: 1674
						// (get) Token: 0x0600105B RID: 4187 RVA: 0x00039FAC File Offset: 0x000381AC
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/AllowAvatarCopyingToggle/Background/Checkmark");
							}
						}
					}
				}

				// Token: 0x020002B2 RID: 690
				public class ShowCommunityLabsToggle_4
				{
					// Token: 0x17000557 RID: 1367
					// (get) Token: 0x06000E79 RID: 3705 RVA: 0x00038B21 File Offset: 0x00036D21
					public static GameObject Background
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ShowCommunityLabsToggle/Background");
						}
					}

					// Token: 0x17000558 RID: 1368
					// (get) Token: 0x06000E7A RID: 3706 RVA: 0x00038B2D File Offset: 0x00036D2D
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ShowCommunityLabsToggle/Label");
						}
					}

					// Token: 0x02000362 RID: 866
					public class Background_5
					{
						// Token: 0x1700068B RID: 1675
						// (get) Token: 0x0600105D RID: 4189 RVA: 0x00039FC1 File Offset: 0x000381C1
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/OtherOptionsPanel/ShowCommunityLabsToggle/Background/Checkmark");
							}
						}
					}
				}
			}

			// Token: 0x020001DD RID: 477
			public class VolumePanel_3
			{
				// Token: 0x1700033D RID: 829
				// (get) Token: 0x06000B8A RID: 2954 RVA: 0x00036A6C File Offset: 0x00034C6C
				public static GameObject Panel_Header_Top
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/Panel_Header Top");
					}
				}

				// Token: 0x1700033E RID: 830
				// (get) Token: 0x06000B8B RID: 2955 RVA: 0x00036A78 File Offset: 0x00034C78
				public static GameObject Panel_Header_Side
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/Panel_Header Side");
					}
				}

				// Token: 0x1700033F RID: 831
				// (get) Token: 0x06000B8C RID: 2956 RVA: 0x00036A84 File Offset: 0x00034C84
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/TitleText (1)");
					}
				}

				// Token: 0x17000340 RID: 832
				// (get) Token: 0x06000B8D RID: 2957 RVA: 0x00036A90 File Offset: 0x00034C90
				public static GameObject VolumeMaster
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeMaster");
					}
				}

				// Token: 0x17000341 RID: 833
				// (get) Token: 0x06000B8E RID: 2958 RVA: 0x00036A9C File Offset: 0x00034C9C
				public static GameObject VolumeUi
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeUi");
					}
				}

				// Token: 0x17000342 RID: 834
				// (get) Token: 0x06000B8F RID: 2959 RVA: 0x00036AA8 File Offset: 0x00034CA8
				public static GameObject VolumeGameWorld
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameWorld");
					}
				}

				// Token: 0x17000343 RID: 835
				// (get) Token: 0x06000B90 RID: 2960 RVA: 0x00036AB4 File Offset: 0x00034CB4
				public static GameObject VolumeGameVoice
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameVoice");
					}
				}

				// Token: 0x17000344 RID: 836
				// (get) Token: 0x06000B91 RID: 2961 RVA: 0x00036AC0 File Offset: 0x00034CC0
				public static GameObject VolumeGameAvatars
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameAvatars");
					}
				}

				// Token: 0x020002B3 RID: 691
				public class VolumeMaster_4
				{
					// Token: 0x17000559 RID: 1369
					// (get) Token: 0x06000E7C RID: 3708 RVA: 0x00038B42 File Offset: 0x00036D42
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeMaster/FillArea");
						}
					}

					// Token: 0x1700055A RID: 1370
					// (get) Token: 0x06000E7D RID: 3709 RVA: 0x00038B4E File Offset: 0x00036D4E
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeMaster/SliderLabel");
						}
					}

					// Token: 0x1700055B RID: 1371
					// (get) Token: 0x06000E7E RID: 3710 RVA: 0x00038B5A File Offset: 0x00036D5A
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeMaster/Label");
						}
					}

					// Token: 0x02000363 RID: 867
					public class FillArea_5
					{
						// Token: 0x1700068C RID: 1676
						// (get) Token: 0x0600105F RID: 4191 RVA: 0x00039FD6 File Offset: 0x000381D6
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeMaster/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x020002B4 RID: 692
				public class VolumeUi_4
				{
					// Token: 0x1700055C RID: 1372
					// (get) Token: 0x06000E80 RID: 3712 RVA: 0x00038B6F File Offset: 0x00036D6F
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeUi/FillArea");
						}
					}

					// Token: 0x1700055D RID: 1373
					// (get) Token: 0x06000E81 RID: 3713 RVA: 0x00038B7B File Offset: 0x00036D7B
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeUi/SliderLabel");
						}
					}

					// Token: 0x1700055E RID: 1374
					// (get) Token: 0x06000E82 RID: 3714 RVA: 0x00038B87 File Offset: 0x00036D87
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeUi/Label");
						}
					}

					// Token: 0x02000364 RID: 868
					public class FillArea_5
					{
						// Token: 0x1700068D RID: 1677
						// (get) Token: 0x06001061 RID: 4193 RVA: 0x00039FEB File Offset: 0x000381EB
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeUi/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x020002B5 RID: 693
				public class VolumeGameWorld_4
				{
					// Token: 0x1700055F RID: 1375
					// (get) Token: 0x06000E84 RID: 3716 RVA: 0x00038B9C File Offset: 0x00036D9C
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameWorld/FillArea");
						}
					}

					// Token: 0x17000560 RID: 1376
					// (get) Token: 0x06000E85 RID: 3717 RVA: 0x00038BA8 File Offset: 0x00036DA8
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameWorld/SliderLabel");
						}
					}

					// Token: 0x17000561 RID: 1377
					// (get) Token: 0x06000E86 RID: 3718 RVA: 0x00038BB4 File Offset: 0x00036DB4
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameWorld/Label");
						}
					}

					// Token: 0x02000365 RID: 869
					public class FillArea_5
					{
						// Token: 0x1700068E RID: 1678
						// (get) Token: 0x06001063 RID: 4195 RVA: 0x0003A000 File Offset: 0x00038200
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameWorld/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x020002B6 RID: 694
				public class VolumeGameVoice_4
				{
					// Token: 0x17000562 RID: 1378
					// (get) Token: 0x06000E88 RID: 3720 RVA: 0x00038BC9 File Offset: 0x00036DC9
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameVoice/FillArea");
						}
					}

					// Token: 0x17000563 RID: 1379
					// (get) Token: 0x06000E89 RID: 3721 RVA: 0x00038BD5 File Offset: 0x00036DD5
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameVoice/SliderLabel");
						}
					}

					// Token: 0x17000564 RID: 1380
					// (get) Token: 0x06000E8A RID: 3722 RVA: 0x00038BE1 File Offset: 0x00036DE1
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameVoice/Label");
						}
					}

					// Token: 0x02000366 RID: 870
					public class FillArea_5
					{
						// Token: 0x1700068F RID: 1679
						// (get) Token: 0x06001065 RID: 4197 RVA: 0x0003A015 File Offset: 0x00038215
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameVoice/FillArea/Fill");
							}
						}
					}
				}

				// Token: 0x020002B7 RID: 695
				public class VolumeGameAvatars_4
				{
					// Token: 0x17000565 RID: 1381
					// (get) Token: 0x06000E8C RID: 3724 RVA: 0x00038BF6 File Offset: 0x00036DF6
					public static GameObject FillArea
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameAvatars/FillArea");
						}
					}

					// Token: 0x17000566 RID: 1382
					// (get) Token: 0x06000E8D RID: 3725 RVA: 0x00038C02 File Offset: 0x00036E02
					public static GameObject SliderLabel
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameAvatars/SliderLabel");
						}
					}

					// Token: 0x17000567 RID: 1383
					// (get) Token: 0x06000E8E RID: 3726 RVA: 0x00038C0E File Offset: 0x00036E0E
					public static GameObject Label
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameAvatars/Label");
						}
					}

					// Token: 0x02000367 RID: 871
					public class FillArea_5
					{
						// Token: 0x17000690 RID: 1680
						// (get) Token: 0x06001067 RID: 4199 RVA: 0x0003A02A File Offset: 0x0003822A
						public static GameObject Fill
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/VolumePanel/VolumeGameAvatars/FillArea/Fill");
							}
						}
					}
				}
			}

			// Token: 0x020001DE RID: 478
			public class Footer_3
			{
				// Token: 0x17000345 RID: 837
				// (get) Token: 0x06000B93 RID: 2963 RVA: 0x00036AD5 File Offset: 0x00034CD5
				public static GameObject Logout
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/Logout");
					}
				}

				// Token: 0x17000346 RID: 838
				// (get) Token: 0x06000B94 RID: 2964 RVA: 0x00036AE1 File Offset: 0x00034CE1
				public static GameObject Exit
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/Exit");
					}
				}

				// Token: 0x17000347 RID: 839
				// (get) Token: 0x06000B95 RID: 2965 RVA: 0x00036AED File Offset: 0x00034CED
				public static GameObject NameText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/NameText");
					}
				}

				// Token: 0x17000348 RID: 840
				// (get) Token: 0x06000B96 RID: 2966 RVA: 0x00036AF9 File Offset: 0x00034CF9
				public static GameObject UpgradeAccount
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/UpgradeAccount");
					}
				}

				// Token: 0x020002B8 RID: 696
				public class Logout_4
				{
					// Token: 0x17000568 RID: 1384
					// (get) Token: 0x06000E90 RID: 3728 RVA: 0x00038C23 File Offset: 0x00036E23
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/Logout/Text");
						}
					}
				}

				// Token: 0x020002B9 RID: 697
				public class Exit_4
				{
					// Token: 0x17000569 RID: 1385
					// (get) Token: 0x06000E92 RID: 3730 RVA: 0x00038C38 File Offset: 0x00036E38
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/Exit/Text");
						}
					}
				}

				// Token: 0x020002BA RID: 698
				public class UpgradeAccount_4
				{
					// Token: 0x1700056A RID: 1386
					// (get) Token: 0x06000E94 RID: 3732 RVA: 0x00038C4D File Offset: 0x00036E4D
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Footer/UpgradeAccount/Text");
						}
					}
				}
			}

			// Token: 0x020001DF RID: 479
			public class Button_AdvancedOptions_3
			{
				// Token: 0x17000349 RID: 841
				// (get) Token: 0x06000B98 RID: 2968 RVA: 0x00036B0E File Offset: 0x00034D0E
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Button_AdvancedOptions/Text");
					}
				}
			}

			// Token: 0x020001E0 RID: 480
			public class Button_EditBindings_3
			{
				// Token: 0x1700034A RID: 842
				// (get) Token: 0x06000B9A RID: 2970 RVA: 0x00036B23 File Offset: 0x00034D23
				public static GameObject Image_NEW
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Button_EditBindings/Image_NEW");
					}
				}

				// Token: 0x1700034B RID: 843
				// (get) Token: 0x06000B9B RID: 2971 RVA: 0x00036B2F File Offset: 0x00034D2F
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/Button_EditBindings/Text");
					}
				}
			}

			// Token: 0x020001E1 RID: 481
			public class UserVolumeOptions_3
			{
				// Token: 0x1700034C RID: 844
				// (get) Token: 0x06000B9D RID: 2973 RVA: 0x00036B44 File Offset: 0x00034D44
				public static GameObject Panel_Header_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/UserVolumeOptions/Panel_Header (1)");
					}
				}

				// Token: 0x1700034D RID: 845
				// (get) Token: 0x06000B9E RID: 2974 RVA: 0x00036B50 File Offset: 0x00034D50
				public static GameObject TitleText_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/UserVolumeOptions/TitleText (1)");
					}
				}

				// Token: 0x1700034E RID: 846
				// (get) Token: 0x06000B9F RID: 2975 RVA: 0x00036B5C File Offset: 0x00034D5C
				public static GameObject Button_ClearChanges
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/UserVolumeOptions/Button_ClearChanges");
					}
				}

				// Token: 0x020002BB RID: 699
				public class Button_ClearChanges_4
				{
					// Token: 0x1700056B RID: 1387
					// (get) Token: 0x06000E96 RID: 3734 RVA: 0x00038C62 File Offset: 0x00036E62
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Screens/Menu_wqoRd0Fot3fW91RAccountswqoRd0Fot3fW91R/UserVolumeOptions/Button_ClearChanges/Text");
						}
					}
				}
			}
		}
	}

	// Token: 0x020000C1 RID: 193
	public class Popups_1
	{
		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060004D9 RID: 1241 RVA: 0x00024C3B File Offset: 0x00022E3B
		public static GameObject AddToAvatarFavoritesPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup");
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x00024C47 File Offset: 0x00022E47
		public static GameObject AddToPlaylistPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup");
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x060004DB RID: 1243 RVA: 0x00024C53 File Offset: 0x00022E53
		public static GameObject AddInviteMessagePopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup");
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x00024C5F File Offset: 0x00022E5F
		public static GameObject AlertPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup");
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x00024C6B File Offset: 0x00022E6B
		public static GameObject CreateUserIconFromImagePopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup");
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x00024C77 File Offset: 0x00022E77
		public static GameObject BookmarkFriendPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup");
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060004DF RID: 1247 RVA: 0x00024C83 File Offset: 0x00022E83
		public static GameObject ClearPlaylistPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup");
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00024C8F File Offset: 0x00022E8F
		public static GameObject CommunityLabsPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup");
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060004E1 RID: 1249 RVA: 0x00024C9B File Offset: 0x00022E9B
		public static GameObject DatePopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup");
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00024CA7 File Offset: 0x00022EA7
		public static GameObject EditPlaylistPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup");
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060004E3 RID: 1251 RVA: 0x00024CB3 File Offset: 0x00022EB3
		public static GameObject LoadingPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup");
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x00024CBF File Offset: 0x00022EBF
		public static GameObject ReportWorldPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup");
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060004E5 RID: 1253 RVA: 0x00024CCB File Offset: 0x00022ECB
		public static GameObject RoomInfoPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup");
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060004E6 RID: 1254 RVA: 0x00024CD7 File Offset: 0x00022ED7
		public static GameObject RoomInstancePopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup");
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x00024CE3 File Offset: 0x00022EE3
		public static GameObject SearchOptionsPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup");
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060004E8 RID: 1256 RVA: 0x00024CEF File Offset: 0x00022EEF
		public static GameObject StandardPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup");
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x00024CFB File Offset: 0x00022EFB
		public static GameObject StandardPopupV2
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2");
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060004EA RID: 1258 RVA: 0x00024D07 File Offset: 0x00022F07
		public static GameObject ReportUserPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup");
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x00024D13 File Offset: 0x00022F13
		public static GameObject UpdateStatusPopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup");
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060004EC RID: 1260 RVA: 0x00024D1F File Offset: 0x00022F1F
		public static GameObject RequestInvitePopup
		{
			get
			{
				return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup");
			}
		}

		// Token: 0x0200016C RID: 364
		public class AddToAvatarFavoritesPopup_2
		{
			// Token: 0x1700017D RID: 381
			// (get) Token: 0x06000944 RID: 2372 RVA: 0x00034967 File Offset: 0x00032B67
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Darkness");
				}
			}

			// Token: 0x1700017E RID: 382
			// (get) Token: 0x06000945 RID: 2373 RVA: 0x00034973 File Offset: 0x00032B73
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup");
				}
			}

			// Token: 0x020001E2 RID: 482
			public class Popup_3
			{
				// Token: 0x1700034F RID: 847
				// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00036B71 File Offset: 0x00034D71
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/BorderImage");
					}
				}

				// Token: 0x17000350 RID: 848
				// (get) Token: 0x06000BA2 RID: 2978 RVA: 0x00036B7D File Offset: 0x00034D7D
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Panel");
					}
				}

				// Token: 0x17000351 RID: 849
				// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00036B89 File Offset: 0x00034D89
				public static GameObject InstanceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/InstanceText");
					}
				}

				// Token: 0x17000352 RID: 850
				// (get) Token: 0x06000BA4 RID: 2980 RVA: 0x00036B95 File Offset: 0x00034D95
				public static GameObject Checkboxes
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes");
					}
				}

				// Token: 0x17000353 RID: 851
				// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x00036BA1 File Offset: 0x00034DA1
				public static GameObject AddButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/AddButton");
					}
				}

				// Token: 0x17000354 RID: 852
				// (get) Token: 0x06000BA6 RID: 2982 RVA: 0x00036BAD File Offset: 0x00034DAD
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002BC RID: 700
				public class Checkboxes_4
				{
					// Token: 0x1700056C RID: 1388
					// (get) Token: 0x06000E98 RID: 3736 RVA: 0x00038C77 File Offset: 0x00036E77
					public static GameObject Favorites1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites1");
						}
					}

					// Token: 0x1700056D RID: 1389
					// (get) Token: 0x06000E99 RID: 3737 RVA: 0x00038C83 File Offset: 0x00036E83
					public static GameObject Favorites2
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites2");
						}
					}

					// Token: 0x1700056E RID: 1390
					// (get) Token: 0x06000E9A RID: 3738 RVA: 0x00038C8F File Offset: 0x00036E8F
					public static GameObject Favorites
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites3");
						}
					}

					// Token: 0x1700056F RID: 1391
					// (get) Token: 0x06000E9B RID: 3739 RVA: 0x00038C9B File Offset: 0x00036E9B
					public static GameObject Favorites4
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites4");
						}
					}

					// Token: 0x02000368 RID: 872
					public class Favorites1_5
					{
						// Token: 0x17000691 RID: 1681
						// (get) Token: 0x06001069 RID: 4201 RVA: 0x0003A03F File Offset: 0x0003823F
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites1/Checkmark");
							}
						}

						// Token: 0x17000692 RID: 1682
						// (get) Token: 0x0600106A RID: 4202 RVA: 0x0003A04B File Offset: 0x0003824B
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites1/Description");
							}
						}
					}

					// Token: 0x02000369 RID: 873
					public class Favorites2_5
					{
						// Token: 0x17000693 RID: 1683
						// (get) Token: 0x0600106C RID: 4204 RVA: 0x0003A060 File Offset: 0x00038260
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites2/Checkmark");
							}
						}

						// Token: 0x17000694 RID: 1684
						// (get) Token: 0x0600106D RID: 4205 RVA: 0x0003A06C File Offset: 0x0003826C
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites2/Description");
							}
						}
					}

					// Token: 0x0200036A RID: 874
					public class Favorites_5
					{
						// Token: 0x17000695 RID: 1685
						// (get) Token: 0x0600106F RID: 4207 RVA: 0x0003A081 File Offset: 0x00038281
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites3/Checkmark");
							}
						}

						// Token: 0x17000696 RID: 1686
						// (get) Token: 0x06001070 RID: 4208 RVA: 0x0003A08D File Offset: 0x0003828D
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites3/Description");
							}
						}
					}

					// Token: 0x0200036B RID: 875
					public class Favorites4_5
					{
						// Token: 0x17000697 RID: 1687
						// (get) Token: 0x06001072 RID: 4210 RVA: 0x0003A0A2 File Offset: 0x000382A2
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites4/Checkmark");
							}
						}

						// Token: 0x17000698 RID: 1688
						// (get) Token: 0x06001073 RID: 4211 RVA: 0x0003A0AE File Offset: 0x000382AE
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/Checkboxes/Favorites4/Description");
							}
						}
					}
				}

				// Token: 0x020002BD RID: 701
				public class AddButton_4
				{
					// Token: 0x17000570 RID: 1392
					// (get) Token: 0x06000E9D RID: 3741 RVA: 0x00038CB0 File Offset: 0x00036EB0
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToAvatarFavoritesPopup/Popup/AddButton/Text");
						}
					}
				}
			}
		}

		// Token: 0x0200016D RID: 365
		public class AddToPlaylistPopup_2
		{
			// Token: 0x1700017F RID: 383
			// (get) Token: 0x06000947 RID: 2375 RVA: 0x00034988 File Offset: 0x00032B88
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Darkness");
				}
			}

			// Token: 0x17000180 RID: 384
			// (get) Token: 0x06000948 RID: 2376 RVA: 0x00034994 File Offset: 0x00032B94
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup");
				}
			}

			// Token: 0x020001E3 RID: 483
			public class Popup_3
			{
				// Token: 0x17000355 RID: 853
				// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x00036BC2 File Offset: 0x00034DC2
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/BorderImage");
					}
				}

				// Token: 0x17000356 RID: 854
				// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x00036BCE File Offset: 0x00034DCE
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Panel");
					}
				}

				// Token: 0x17000357 RID: 855
				// (get) Token: 0x06000BAA RID: 2986 RVA: 0x00036BDA File Offset: 0x00034DDA
				public static GameObject InstanceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/InstanceText");
					}
				}

				// Token: 0x17000358 RID: 856
				// (get) Token: 0x06000BAB RID: 2987 RVA: 0x00036BE6 File Offset: 0x00034DE6
				public static GameObject Checkboxes
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes");
					}
				}

				// Token: 0x17000359 RID: 857
				// (get) Token: 0x06000BAC RID: 2988 RVA: 0x00036BF2 File Offset: 0x00034DF2
				public static GameObject AddButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/AddButton");
					}
				}

				// Token: 0x1700035A RID: 858
				// (get) Token: 0x06000BAD RID: 2989 RVA: 0x00036BFE File Offset: 0x00034DFE
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002BE RID: 702
				public class Checkboxes_4
				{
					// Token: 0x17000571 RID: 1393
					// (get) Token: 0x06000E9F RID: 3743 RVA: 0x00038CC5 File Offset: 0x00036EC5
					public static GameObject Playlist1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist1");
						}
					}

					// Token: 0x17000572 RID: 1394
					// (get) Token: 0x06000EA0 RID: 3744 RVA: 0x00038CD1 File Offset: 0x00036ED1
					public static GameObject Playlist2
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist2");
						}
					}

					// Token: 0x17000573 RID: 1395
					// (get) Token: 0x06000EA1 RID: 3745 RVA: 0x00038CDD File Offset: 0x00036EDD
					public static GameObject Playlist
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist3");
						}
					}

					// Token: 0x17000574 RID: 1396
					// (get) Token: 0x06000EA2 RID: 3746 RVA: 0x00038CE9 File Offset: 0x00036EE9
					public static GameObject Playlist4
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist4");
						}
					}

					// Token: 0x0200036C RID: 876
					public class Playlist1_5
					{
						// Token: 0x17000699 RID: 1689
						// (get) Token: 0x06001075 RID: 4213 RVA: 0x0003A0C3 File Offset: 0x000382C3
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist1/Checkmark");
							}
						}

						// Token: 0x1700069A RID: 1690
						// (get) Token: 0x06001076 RID: 4214 RVA: 0x0003A0CF File Offset: 0x000382CF
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist1/Description");
							}
						}
					}

					// Token: 0x0200036D RID: 877
					public class Playlist2_5
					{
						// Token: 0x1700069B RID: 1691
						// (get) Token: 0x06001078 RID: 4216 RVA: 0x0003A0E4 File Offset: 0x000382E4
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist2/Checkmark");
							}
						}

						// Token: 0x1700069C RID: 1692
						// (get) Token: 0x06001079 RID: 4217 RVA: 0x0003A0F0 File Offset: 0x000382F0
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist2/Description");
							}
						}
					}

					// Token: 0x0200036E RID: 878
					public class Playlist_5
					{
						// Token: 0x1700069D RID: 1693
						// (get) Token: 0x0600107B RID: 4219 RVA: 0x0003A105 File Offset: 0x00038305
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist3/Checkmark");
							}
						}

						// Token: 0x1700069E RID: 1694
						// (get) Token: 0x0600107C RID: 4220 RVA: 0x0003A111 File Offset: 0x00038311
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist3/Description");
							}
						}
					}

					// Token: 0x0200036F RID: 879
					public class Playlist4_5
					{
						// Token: 0x1700069F RID: 1695
						// (get) Token: 0x0600107E RID: 4222 RVA: 0x0003A126 File Offset: 0x00038326
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist4/Checkmark");
							}
						}

						// Token: 0x170006A0 RID: 1696
						// (get) Token: 0x0600107F RID: 4223 RVA: 0x0003A132 File Offset: 0x00038332
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/Checkboxes/Playlist4/Description");
							}
						}
					}
				}

				// Token: 0x020002BF RID: 703
				public class AddButton_4
				{
					// Token: 0x17000575 RID: 1397
					// (get) Token: 0x06000EA4 RID: 3748 RVA: 0x00038CFE File Offset: 0x00036EFE
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddToPlaylistPopup/Popup/AddButton/Text");
						}
					}
				}
			}
		}

		// Token: 0x0200016E RID: 366
		public class AddInviteMessagePopup_2
		{
			// Token: 0x17000181 RID: 385
			// (get) Token: 0x0600094A RID: 2378 RVA: 0x000349A9 File Offset: 0x00032BA9
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/Darkness");
				}
			}

			// Token: 0x17000182 RID: 386
			// (get) Token: 0x0600094B RID: 2379 RVA: 0x000349B5 File Offset: 0x00032BB5
			public static GameObject InviteResponseAddMessageMenu
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu");
				}
			}

			// Token: 0x020001E4 RID: 484
			public class InviteResponseAddMessageMenu_3
			{
				// Token: 0x1700035B RID: 859
				// (get) Token: 0x06000BAF RID: 2991 RVA: 0x00036C13 File Offset: 0x00034E13
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/BorderImage");
					}
				}

				// Token: 0x1700035C RID: 860
				// (get) Token: 0x06000BB0 RID: 2992 RVA: 0x00036C1F File Offset: 0x00034E1F
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/Panel");
					}
				}

				// Token: 0x1700035D RID: 861
				// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x00036C2B File Offset: 0x00034E2B
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/TitleText");
					}
				}

				// Token: 0x1700035E RID: 862
				// (get) Token: 0x06000BB2 RID: 2994 RVA: 0x00036C37 File Offset: 0x00034E37
				public static GameObject BackButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/BackButton");
					}
				}

				// Token: 0x1700035F RID: 863
				// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x00036C43 File Offset: 0x00034E43
				public static GameObject ScrollRect
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/ScrollRect");
					}
				}

				// Token: 0x020002C0 RID: 704
				public class BackButton_4
				{
					// Token: 0x17000576 RID: 1398
					// (get) Token: 0x06000EA6 RID: 3750 RVA: 0x00038D13 File Offset: 0x00036F13
					public static GameObject ArrowImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/AddInviteMessagePopup/InviteResponseAddMessageMenu/BackButton/ArrowImage");
						}
					}
				}
			}
		}

		// Token: 0x0200016F RID: 367
		public class AlertPopup_2
		{
			// Token: 0x17000183 RID: 387
			// (get) Token: 0x0600094D RID: 2381 RVA: 0x000349CA File Offset: 0x00032BCA
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/Darkness");
				}
			}

			// Token: 0x17000184 RID: 388
			// (get) Token: 0x0600094E RID: 2382 RVA: 0x000349D6 File Offset: 0x00032BD6
			public static GameObject Lighter
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/Lighter");
				}
			}

			// Token: 0x17000185 RID: 389
			// (get) Token: 0x0600094F RID: 2383 RVA: 0x000349E2 File Offset: 0x00032BE2
			public static GameObject TitleText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/TitleText");
				}
			}

			// Token: 0x17000186 RID: 390
			// (get) Token: 0x06000950 RID: 2384 RVA: 0x000349EE File Offset: 0x00032BEE
			public static GameObject BodyText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/BodyText");
				}
			}

			// Token: 0x17000187 RID: 391
			// (get) Token: 0x06000951 RID: 2385 RVA: 0x000349FA File Offset: 0x00032BFA
			public static GameObject TimerText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/TimerText");
				}
			}

			// Token: 0x17000188 RID: 392
			// (get) Token: 0x06000952 RID: 2386 RVA: 0x00034A06 File Offset: 0x00032C06
			public static GameObject Button
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/Button");
				}
			}

			// Token: 0x020001E5 RID: 485
			public class Button_3
			{
				// Token: 0x17000360 RID: 864
				// (get) Token: 0x06000BB5 RID: 2997 RVA: 0x00036C58 File Offset: 0x00034E58
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/AlertPopup/Button/Text");
					}
				}
			}
		}

		// Token: 0x02000170 RID: 368
		public class CreateUserIconFromImagePopup_2
		{
			// Token: 0x17000189 RID: 393
			// (get) Token: 0x06000954 RID: 2388 RVA: 0x00034A1B File Offset: 0x00032C1B
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Darkness");
				}
			}

			// Token: 0x1700018A RID: 394
			// (get) Token: 0x06000955 RID: 2389 RVA: 0x00034A27 File Offset: 0x00032C27
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup");
				}
			}

			// Token: 0x020001E6 RID: 486
			public class Popup_3
			{
				// Token: 0x17000361 RID: 865
				// (get) Token: 0x06000BB7 RID: 2999 RVA: 0x00036C6D File Offset: 0x00034E6D
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/BorderImage");
					}
				}

				// Token: 0x17000362 RID: 866
				// (get) Token: 0x06000BB8 RID: 3000 RVA: 0x00036C79 File Offset: 0x00034E79
				public static GameObject UserIconRoundBorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/UserIconRoundBorderImage");
					}
				}

				// Token: 0x17000363 RID: 867
				// (get) Token: 0x06000BB9 RID: 3001 RVA: 0x00036C85 File Offset: 0x00034E85
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Panel");
					}
				}

				// Token: 0x17000364 RID: 868
				// (get) Token: 0x06000BBA RID: 3002 RVA: 0x00036C91 File Offset: 0x00034E91
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/TitleText");
					}
				}

				// Token: 0x17000365 RID: 869
				// (get) Token: 0x06000BBB RID: 3003 RVA: 0x00036C9D File Offset: 0x00034E9D
				public static GameObject CreateUserIconGroup
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup");
					}
				}

				// Token: 0x17000366 RID: 870
				// (get) Token: 0x06000BBC RID: 3004 RVA: 0x00036CA9 File Offset: 0x00034EA9
				public static GameObject SetAsCurrentIconGroup
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup");
					}
				}

				// Token: 0x17000367 RID: 871
				// (get) Token: 0x06000BBD RID: 3005 RVA: 0x00036CB5 File Offset: 0x00034EB5
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/ExitButton");
					}
				}

				// Token: 0x17000368 RID: 872
				// (get) Token: 0x06000BBE RID: 3006 RVA: 0x00036CC1 File Offset: 0x00034EC1
				public static GameObject Max_Icons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons");
					}
				}

				// Token: 0x17000369 RID: 873
				// (get) Token: 0x06000BBF RID: 3007 RVA: 0x00036CCD File Offset: 0x00034ECD
				public static GameObject Upload_Group
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Upload Group");
					}
				}

				// Token: 0x020002C1 RID: 705
				public class CreateUserIconGroup_4
				{
					// Token: 0x17000577 RID: 1399
					// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x00038D28 File Offset: 0x00036F28
					public static GameObject Preview_Window
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Preview Window");
						}
					}

					// Token: 0x17000578 RID: 1400
					// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x00038D34 File Offset: 0x00036F34
					public static GameObject Zoom_Pan_Group
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Zoom Pan Group");
						}
					}

					// Token: 0x17000579 RID: 1401
					// (get) Token: 0x06000EAA RID: 3754 RVA: 0x00038D40 File Offset: 0x00036F40
					public static GameObject SaveAndApplyButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/SaveAndApplyButton");
						}
					}

					// Token: 0x02000370 RID: 880
					public class Preview_Window_5
					{
						// Token: 0x170006A1 RID: 1697
						// (get) Token: 0x06001081 RID: 4225 RVA: 0x0003A147 File Offset: 0x00038347
						public static GameObject Preview
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Preview Window/Preview");
							}
						}

						// Token: 0x170006A2 RID: 1698
						// (get) Token: 0x06001082 RID: 4226 RVA: 0x0003A153 File Offset: 0x00038353
						public static GameObject Overlay
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Preview Window/Overlay");
							}
						}

						// Token: 0x170006A3 RID: 1699
						// (get) Token: 0x06001083 RID: 4227 RVA: 0x0003A15F File Offset: 0x0003835F
						public static GameObject Bounds
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Preview Window/Bounds");
							}
						}
					}

					// Token: 0x02000371 RID: 881
					public class Zoom_Pan_Group_5
					{
						// Token: 0x170006A4 RID: 1700
						// (get) Token: 0x06001085 RID: 4229 RVA: 0x0003A174 File Offset: 0x00038374
						public static GameObject Zoom
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Zoom Pan Group/Zoom");
							}
						}

						// Token: 0x170006A5 RID: 1701
						// (get) Token: 0x06001086 RID: 4230 RVA: 0x0003A180 File Offset: 0x00038380
						public static GameObject Move_Icon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/Zoom Pan Group/Move Icon");
							}
						}
					}

					// Token: 0x02000372 RID: 882
					public class SaveAndApplyButton_5
					{
						// Token: 0x170006A6 RID: 1702
						// (get) Token: 0x06001088 RID: 4232 RVA: 0x0003A195 File Offset: 0x00038395
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/CreateUserIconGroup/SaveAndApplyButton/Text");
							}
						}
					}
				}

				// Token: 0x020002C2 RID: 706
				public class SetAsCurrentIconGroup_4
				{
					// Token: 0x1700057A RID: 1402
					// (get) Token: 0x06000EAC RID: 3756 RVA: 0x00038D55 File Offset: 0x00036F55
					public static GameObject Preview_Window
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/Preview Window");
						}
					}

					// Token: 0x1700057B RID: 1403
					// (get) Token: 0x06000EAD RID: 3757 RVA: 0x00038D61 File Offset: 0x00036F61
					public static GameObject UserIconCreatedText
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/UserIconCreatedText");
						}
					}

					// Token: 0x1700057C RID: 1404
					// (get) Token: 0x06000EAE RID: 3758 RVA: 0x00038D6D File Offset: 0x00036F6D
					public static GameObject SetAsCurrentIconButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/SetAsCurrentIconButton");
						}
					}

					// Token: 0x1700057D RID: 1405
					// (get) Token: 0x06000EAF RID: 3759 RVA: 0x00038D79 File Offset: 0x00036F79
					public static GameObject CloseCreateUserIconPopupButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/CloseCreateUserIconPopupButton");
						}
					}

					// Token: 0x02000373 RID: 883
					public class Preview_Window_5
					{
						// Token: 0x170006A7 RID: 1703
						// (get) Token: 0x0600108A RID: 4234 RVA: 0x0003A1AA File Offset: 0x000383AA
						public static GameObject Preview
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/Preview Window/Preview");
							}
						}

						// Token: 0x170006A8 RID: 1704
						// (get) Token: 0x0600108B RID: 4235 RVA: 0x0003A1B6 File Offset: 0x000383B6
						public static GameObject Overlay
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/Preview Window/Overlay");
							}
						}
					}

					// Token: 0x02000374 RID: 884
					public class SetAsCurrentIconButton_5
					{
						// Token: 0x170006A9 RID: 1705
						// (get) Token: 0x0600108D RID: 4237 RVA: 0x0003A1CB File Offset: 0x000383CB
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/SetAsCurrentIconButton/Text");
							}
						}
					}

					// Token: 0x02000375 RID: 885
					public class CloseCreateUserIconPopupButton_5
					{
						// Token: 0x170006AA RID: 1706
						// (get) Token: 0x0600108F RID: 4239 RVA: 0x0003A1E0 File Offset: 0x000383E0
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/SetAsCurrentIconGroup/CloseCreateUserIconPopupButton/Text");
							}
						}
					}
				}

				// Token: 0x020002C3 RID: 707
				public class Max_Icons_4
				{
					// Token: 0x1700057E RID: 1406
					// (get) Token: 0x06000EB1 RID: 3761 RVA: 0x00038D8E File Offset: 0x00036F8E
					public static GameObject Manage_Icons
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/Manage Icons");
						}
					}

					// Token: 0x1700057F RID: 1407
					// (get) Token: 0x06000EB2 RID: 3762 RVA: 0x00038D9A File Offset: 0x00036F9A
					public static GameObject BackButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/BackButton");
						}
					}

					// Token: 0x17000580 RID: 1408
					// (get) Token: 0x06000EB3 RID: 3763 RVA: 0x00038DA6 File Offset: 0x00036FA6
					public static GameObject Info
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/Info");
						}
					}

					// Token: 0x02000376 RID: 886
					public class Manage_Icons_5
					{
						// Token: 0x170006AB RID: 1707
						// (get) Token: 0x06001091 RID: 4241 RVA: 0x0003A1F5 File Offset: 0x000383F5
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/Manage Icons/Text");
							}
						}
					}

					// Token: 0x02000377 RID: 887
					public class BackButton_5
					{
						// Token: 0x170006AC RID: 1708
						// (get) Token: 0x06001093 RID: 4243 RVA: 0x0003A20A File Offset: 0x0003840A
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/BackButton/Text");
							}
						}
					}

					// Token: 0x02000378 RID: 888
					public class Info_5
					{
						// Token: 0x170006AD RID: 1709
						// (get) Token: 0x06001095 RID: 4245 RVA: 0x0003A21F File Offset: 0x0003841F
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/Info/Text");
							}
						}

						// Token: 0x170006AE RID: 1710
						// (get) Token: 0x06001096 RID: 4246 RVA: 0x0003A22B File Offset: 0x0003842B
						public static GameObject InfoIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Max Icons/Info/InfoIcon");
							}
						}
					}
				}

				// Token: 0x020002C4 RID: 708
				public class Upload_Group_4
				{
					// Token: 0x17000581 RID: 1409
					// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x00038DBB File Offset: 0x00036FBB
					public static GameObject Info
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Upload Group/Info");
						}
					}

					// Token: 0x02000379 RID: 889
					public class Info_5
					{
						// Token: 0x170006AF RID: 1711
						// (get) Token: 0x06001098 RID: 4248 RVA: 0x0003A240 File Offset: 0x00038440
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/CreateUserIconFromImagePopup/Popup/Upload Group/Info/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000171 RID: 369
		public class BookmarkFriendPopup_2
		{
			// Token: 0x1700018B RID: 395
			// (get) Token: 0x06000957 RID: 2391 RVA: 0x00034A3C File Offset: 0x00032C3C
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Darkness");
				}
			}

			// Token: 0x1700018C RID: 396
			// (get) Token: 0x06000958 RID: 2392 RVA: 0x00034A48 File Offset: 0x00032C48
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup");
				}
			}

			// Token: 0x020001E7 RID: 487
			public class Popup_3
			{
				// Token: 0x1700036A RID: 874
				// (get) Token: 0x06000BC1 RID: 3009 RVA: 0x00036CE2 File Offset: 0x00034EE2
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/BorderImage");
					}
				}

				// Token: 0x1700036B RID: 875
				// (get) Token: 0x06000BC2 RID: 3010 RVA: 0x00036CEE File Offset: 0x00034EEE
				public static GameObject Panel_2
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Panel (2)");
					}
				}

				// Token: 0x1700036C RID: 876
				// (get) Token: 0x06000BC3 RID: 3011 RVA: 0x00036CFA File Offset: 0x00034EFA
				public static GameObject InstanceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/InstanceText");
					}
				}

				// Token: 0x1700036D RID: 877
				// (get) Token: 0x06000BC4 RID: 3012 RVA: 0x00036D06 File Offset: 0x00034F06
				public static GameObject Checkboxes
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes");
					}
				}

				// Token: 0x1700036E RID: 878
				// (get) Token: 0x06000BC5 RID: 3013 RVA: 0x00036D12 File Offset: 0x00034F12
				public static GameObject AddButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/AddButton");
					}
				}

				// Token: 0x1700036F RID: 879
				// (get) Token: 0x06000BC6 RID: 3014 RVA: 0x00036D1E File Offset: 0x00034F1E
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002C5 RID: 709
				public class Checkboxes_4
				{
					// Token: 0x17000582 RID: 1410
					// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x00038DD0 File Offset: 0x00036FD0
					public static GameObject Bookmark1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark1");
						}
					}

					// Token: 0x17000583 RID: 1411
					// (get) Token: 0x06000EB8 RID: 3768 RVA: 0x00038DDC File Offset: 0x00036FDC
					public static GameObject Bookmark2
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark2");
						}
					}

					// Token: 0x17000584 RID: 1412
					// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x00038DE8 File Offset: 0x00036FE8
					public static GameObject Bookmark
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark3");
						}
					}

					// Token: 0x0200037A RID: 890
					public class Bookmark1_5
					{
						// Token: 0x170006B0 RID: 1712
						// (get) Token: 0x0600109A RID: 4250 RVA: 0x0003A255 File Offset: 0x00038455
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark1/Checkmark");
							}
						}

						// Token: 0x170006B1 RID: 1713
						// (get) Token: 0x0600109B RID: 4251 RVA: 0x0003A261 File Offset: 0x00038461
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark1/Description");
							}
						}
					}

					// Token: 0x0200037B RID: 891
					public class Bookmark2_5
					{
						// Token: 0x170006B2 RID: 1714
						// (get) Token: 0x0600109D RID: 4253 RVA: 0x0003A276 File Offset: 0x00038476
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark2/Checkmark");
							}
						}

						// Token: 0x170006B3 RID: 1715
						// (get) Token: 0x0600109E RID: 4254 RVA: 0x0003A282 File Offset: 0x00038482
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark2/Description");
							}
						}
					}

					// Token: 0x0200037C RID: 892
					public class Bookmark_5
					{
						// Token: 0x170006B4 RID: 1716
						// (get) Token: 0x060010A0 RID: 4256 RVA: 0x0003A297 File Offset: 0x00038497
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark3/Checkmark");
							}
						}

						// Token: 0x170006B5 RID: 1717
						// (get) Token: 0x060010A1 RID: 4257 RVA: 0x0003A2A3 File Offset: 0x000384A3
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/Checkboxes/Bookmark3/Description");
							}
						}
					}
				}

				// Token: 0x020002C6 RID: 710
				public class AddButton_4
				{
					// Token: 0x17000585 RID: 1413
					// (get) Token: 0x06000EBB RID: 3771 RVA: 0x00038DFD File Offset: 0x00036FFD
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/BookmarkFriendPopup/Popup/AddButton/Text");
						}
					}
				}
			}
		}

		// Token: 0x02000172 RID: 370
		public class ClearPlaylistPopup_2
		{
			// Token: 0x1700018D RID: 397
			// (get) Token: 0x0600095A RID: 2394 RVA: 0x00034A5D File Offset: 0x00032C5D
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Darkness");
				}
			}

			// Token: 0x1700018E RID: 398
			// (get) Token: 0x0600095B RID: 2395 RVA: 0x00034A69 File Offset: 0x00032C69
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup");
				}
			}

			// Token: 0x020001E8 RID: 488
			public class Popup_3
			{
				// Token: 0x17000370 RID: 880
				// (get) Token: 0x06000BC8 RID: 3016 RVA: 0x00036D33 File Offset: 0x00034F33
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/BorderImage");
					}
				}

				// Token: 0x17000371 RID: 881
				// (get) Token: 0x06000BC9 RID: 3017 RVA: 0x00036D3F File Offset: 0x00034F3F
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Panel");
					}
				}

				// Token: 0x17000372 RID: 882
				// (get) Token: 0x06000BCA RID: 3018 RVA: 0x00036D4B File Offset: 0x00034F4B
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/ExitButton");
					}
				}

				// Token: 0x17000373 RID: 883
				// (get) Token: 0x06000BCB RID: 3019 RVA: 0x00036D57 File Offset: 0x00034F57
				public static GameObject ClearPlaylistTitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/ClearPlaylistTitleText");
					}
				}

				// Token: 0x17000374 RID: 884
				// (get) Token: 0x06000BCC RID: 3020 RVA: 0x00036D63 File Offset: 0x00034F63
				public static GameObject ClearPlaylistInfoText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/ClearPlaylistInfoText");
					}
				}

				// Token: 0x17000375 RID: 885
				// (get) Token: 0x06000BCD RID: 3021 RVA: 0x00036D6F File Offset: 0x00034F6F
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Buttons");
					}
				}

				// Token: 0x020002C7 RID: 711
				public class Buttons_4
				{
					// Token: 0x17000586 RID: 1414
					// (get) Token: 0x06000EBD RID: 3773 RVA: 0x00038E12 File Offset: 0x00037012
					public static GameObject CancelButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Buttons/CancelButton");
						}
					}

					// Token: 0x17000587 RID: 1415
					// (get) Token: 0x06000EBE RID: 3774 RVA: 0x00038E1E File Offset: 0x0003701E
					public static GameObject ClearButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Buttons/ClearButton");
						}
					}

					// Token: 0x0200037D RID: 893
					public class CancelButton_5
					{
						// Token: 0x170006B6 RID: 1718
						// (get) Token: 0x060010A3 RID: 4259 RVA: 0x0003A2B8 File Offset: 0x000384B8
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Buttons/CancelButton/Text");
							}
						}
					}

					// Token: 0x0200037E RID: 894
					public class ClearButton_5
					{
						// Token: 0x170006B7 RID: 1719
						// (get) Token: 0x060010A5 RID: 4261 RVA: 0x0003A2CD File Offset: 0x000384CD
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ClearPlaylistPopup/Popup/Buttons/ClearButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000173 RID: 371
		public class CommunityLabsPopup_2
		{
			// Token: 0x1700018F RID: 399
			// (get) Token: 0x0600095D RID: 2397 RVA: 0x00034A7E File Offset: 0x00032C7E
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/Darkness");
				}
			}

			// Token: 0x17000190 RID: 400
			// (get) Token: 0x0600095E RID: 2398 RVA: 0x00034A8A File Offset: 0x00032C8A
			public static GameObject Rectangle
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/Rectangle");
				}
			}

			// Token: 0x17000191 RID: 401
			// (get) Token: 0x0600095F RID: 2399 RVA: 0x00034A96 File Offset: 0x00032C96
			public static GameObject UpperPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/UpperPanel");
				}
			}

			// Token: 0x17000192 RID: 402
			// (get) Token: 0x06000960 RID: 2400 RVA: 0x00034AA2 File Offset: 0x00032CA2
			public static GameObject TitlePanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/TitlePanel");
				}
			}

			// Token: 0x17000193 RID: 403
			// (get) Token: 0x06000961 RID: 2401 RVA: 0x00034AAE File Offset: 0x00032CAE
			public static GameObject TitleText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/TitleText");
				}
			}

			// Token: 0x17000194 RID: 404
			// (get) Token: 0x06000962 RID: 2402 RVA: 0x00034ABA File Offset: 0x00032CBA
			public static GameObject Icon_CL
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/Icon_CL");
				}
			}

			// Token: 0x17000195 RID: 405
			// (get) Token: 0x06000963 RID: 2403 RVA: 0x00034AC6 File Offset: 0x00032CC6
			public static GameObject BodyText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/BodyText");
				}
			}

			// Token: 0x17000196 RID: 406
			// (get) Token: 0x06000964 RID: 2404 RVA: 0x00034AD2 File Offset: 0x00032CD2
			public static GameObject ReportText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/ReportText");
				}
			}

			// Token: 0x17000197 RID: 407
			// (get) Token: 0x06000965 RID: 2405 RVA: 0x00034ADE File Offset: 0x00032CDE
			public static GameObject Graphic_CL_Report
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/Graphic_CL_Report");
				}
			}

			// Token: 0x17000198 RID: 408
			// (get) Token: 0x06000966 RID: 2406 RVA: 0x00034AEA File Offset: 0x00032CEA
			public static GameObject Icon_Warning
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/Icon_Warning");
				}
			}

			// Token: 0x17000199 RID: 409
			// (get) Token: 0x06000967 RID: 2407 RVA: 0x00034AF6 File Offset: 0x00032CF6
			public static GameObject WarningText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/WarningText");
				}
			}

			// Token: 0x1700019A RID: 410
			// (get) Token: 0x06000968 RID: 2408 RVA: 0x00034B02 File Offset: 0x00032D02
			public static GameObject CancelButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/CancelButton");
				}
			}

			// Token: 0x1700019B RID: 411
			// (get) Token: 0x06000969 RID: 2409 RVA: 0x00034B0E File Offset: 0x00032D0E
			public static GameObject AcceptButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/AcceptButton");
				}
			}

			// Token: 0x1700019C RID: 412
			// (get) Token: 0x0600096A RID: 2410 RVA: 0x00034B1A File Offset: 0x00032D1A
			public static GameObject ExitButton
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/ExitButton");
				}
			}

			// Token: 0x020001E9 RID: 489
			public class CancelButton_3
			{
				// Token: 0x17000376 RID: 886
				// (get) Token: 0x06000BCF RID: 3023 RVA: 0x00036D84 File Offset: 0x00034F84
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/CancelButton/Text");
					}
				}
			}

			// Token: 0x020001EA RID: 490
			public class AcceptButton_3
			{
				// Token: 0x17000377 RID: 887
				// (get) Token: 0x06000BD1 RID: 3025 RVA: 0x00036D99 File Offset: 0x00034F99
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/CommunityLabsPopup/AcceptButton/Text");
					}
				}
			}
		}

		// Token: 0x02000174 RID: 372
		public class DatePopup_2
		{
			// Token: 0x1700019D RID: 413
			// (get) Token: 0x0600096C RID: 2412 RVA: 0x00034B2F File Offset: 0x00032D2F
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/Darkness");
				}
			}

			// Token: 0x1700019E RID: 414
			// (get) Token: 0x0600096D RID: 2413 RVA: 0x00034B3B File Offset: 0x00032D3B
			public static GameObject Rectangle
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/Rectangle");
				}
			}

			// Token: 0x1700019F RID: 415
			// (get) Token: 0x0600096E RID: 2414 RVA: 0x00034B47 File Offset: 0x00032D47
			public static GameObject TitleText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/TitleText");
				}
			}

			// Token: 0x170001A0 RID: 416
			// (get) Token: 0x0600096F RID: 2415 RVA: 0x00034B53 File Offset: 0x00032D53
			public static GameObject ButtonLeft
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonLeft");
				}
			}

			// Token: 0x170001A1 RID: 417
			// (get) Token: 0x06000970 RID: 2416 RVA: 0x00034B5F File Offset: 0x00032D5F
			public static GameObject ButtonRight
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonRight");
				}
			}

			// Token: 0x170001A2 RID: 418
			// (get) Token: 0x06000971 RID: 2417 RVA: 0x00034B6B File Offset: 0x00032D6B
			public static GameObject ButtonCenter
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonCenter");
				}
			}

			// Token: 0x170001A3 RID: 419
			// (get) Token: 0x06000972 RID: 2418 RVA: 0x00034B77 File Offset: 0x00032D77
			public static GameObject MonthSpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/MonthSpinner");
				}
			}

			// Token: 0x170001A4 RID: 420
			// (get) Token: 0x06000973 RID: 2419 RVA: 0x00034B83 File Offset: 0x00032D83
			public static GameObject DayTenSpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayTenSpinner");
				}
			}

			// Token: 0x170001A5 RID: 421
			// (get) Token: 0x06000974 RID: 2420 RVA: 0x00034B8F File Offset: 0x00032D8F
			public static GameObject DayOneSpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayOneSpinner");
				}
			}

			// Token: 0x170001A6 RID: 422
			// (get) Token: 0x06000975 RID: 2421 RVA: 0x00034B9B File Offset: 0x00032D9B
			public static GameObject YearCenturySpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearCenturySpinner");
				}
			}

			// Token: 0x170001A7 RID: 423
			// (get) Token: 0x06000976 RID: 2422 RVA: 0x00034BA7 File Offset: 0x00032DA7
			public static GameObject YearTenSpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearTenSpinner");
				}
			}

			// Token: 0x170001A8 RID: 424
			// (get) Token: 0x06000977 RID: 2423 RVA: 0x00034BB3 File Offset: 0x00032DB3
			public static GameObject YearOneSpinner
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearOneSpinner");
				}
			}

			// Token: 0x170001A9 RID: 425
			// (get) Token: 0x06000978 RID: 2424 RVA: 0x00034BBF File Offset: 0x00032DBF
			public static GameObject MonthLabel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/MonthLabel");
				}
			}

			// Token: 0x170001AA RID: 426
			// (get) Token: 0x06000979 RID: 2425 RVA: 0x00034BCB File Offset: 0x00032DCB
			public static GameObject DayLabel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayLabel");
				}
			}

			// Token: 0x170001AB RID: 427
			// (get) Token: 0x0600097A RID: 2426 RVA: 0x00034BD7 File Offset: 0x00032DD7
			public static GameObject YearLabel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearLabel");
				}
			}

			// Token: 0x020001EB RID: 491
			public class ButtonLeft_3
			{
				// Token: 0x17000378 RID: 888
				// (get) Token: 0x06000BD3 RID: 3027 RVA: 0x00036DAE File Offset: 0x00034FAE
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonLeft/Text");
					}
				}
			}

			// Token: 0x020001EC RID: 492
			public class ButtonRight_3
			{
				// Token: 0x17000379 RID: 889
				// (get) Token: 0x06000BD5 RID: 3029 RVA: 0x00036DC3 File Offset: 0x00034FC3
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonRight/Text");
					}
				}
			}

			// Token: 0x020001ED RID: 493
			public class ButtonCenter_3
			{
				// Token: 0x1700037A RID: 890
				// (get) Token: 0x06000BD7 RID: 3031 RVA: 0x00036DD8 File Offset: 0x00034FD8
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/ButtonCenter/Text");
					}
				}
			}

			// Token: 0x020001EE RID: 494
			public class MonthSpinner_3
			{
				// Token: 0x1700037B RID: 891
				// (get) Token: 0x06000BD9 RID: 3033 RVA: 0x00036DED File Offset: 0x00034FED
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/MonthSpinner/SpinnerInput");
					}
				}

				// Token: 0x1700037C RID: 892
				// (get) Token: 0x06000BDA RID: 3034 RVA: 0x00036DF9 File Offset: 0x00034FF9
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/MonthSpinner/Minus");
					}
				}

				// Token: 0x1700037D RID: 893
				// (get) Token: 0x06000BDB RID: 3035 RVA: 0x00036E05 File Offset: 0x00035005
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/MonthSpinner/Plus");
					}
				}
			}

			// Token: 0x020001EF RID: 495
			public class DayTenSpinner_3
			{
				// Token: 0x1700037E RID: 894
				// (get) Token: 0x06000BDD RID: 3037 RVA: 0x00036E1A File Offset: 0x0003501A
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayTenSpinner/SpinnerInput");
					}
				}

				// Token: 0x1700037F RID: 895
				// (get) Token: 0x06000BDE RID: 3038 RVA: 0x00036E26 File Offset: 0x00035026
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayTenSpinner/Minus");
					}
				}

				// Token: 0x17000380 RID: 896
				// (get) Token: 0x06000BDF RID: 3039 RVA: 0x00036E32 File Offset: 0x00035032
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayTenSpinner/Plus");
					}
				}
			}

			// Token: 0x020001F0 RID: 496
			public class DayOneSpinner_3
			{
				// Token: 0x17000381 RID: 897
				// (get) Token: 0x06000BE1 RID: 3041 RVA: 0x00036E47 File Offset: 0x00035047
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayOneSpinner/SpinnerInput");
					}
				}

				// Token: 0x17000382 RID: 898
				// (get) Token: 0x06000BE2 RID: 3042 RVA: 0x00036E53 File Offset: 0x00035053
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayOneSpinner/Minus");
					}
				}

				// Token: 0x17000383 RID: 899
				// (get) Token: 0x06000BE3 RID: 3043 RVA: 0x00036E5F File Offset: 0x0003505F
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/DayOneSpinner/Plus");
					}
				}
			}

			// Token: 0x020001F1 RID: 497
			public class YearCenturySpinner_3
			{
				// Token: 0x17000384 RID: 900
				// (get) Token: 0x06000BE5 RID: 3045 RVA: 0x00036E74 File Offset: 0x00035074
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearCenturySpinner/SpinnerInput");
					}
				}

				// Token: 0x17000385 RID: 901
				// (get) Token: 0x06000BE6 RID: 3046 RVA: 0x00036E80 File Offset: 0x00035080
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearCenturySpinner/Minus");
					}
				}

				// Token: 0x17000386 RID: 902
				// (get) Token: 0x06000BE7 RID: 3047 RVA: 0x00036E8C File Offset: 0x0003508C
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearCenturySpinner/Plus");
					}
				}
			}

			// Token: 0x020001F2 RID: 498
			public class YearTenSpinner_3
			{
				// Token: 0x17000387 RID: 903
				// (get) Token: 0x06000BE9 RID: 3049 RVA: 0x00036EA1 File Offset: 0x000350A1
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearTenSpinner/SpinnerInput");
					}
				}

				// Token: 0x17000388 RID: 904
				// (get) Token: 0x06000BEA RID: 3050 RVA: 0x00036EAD File Offset: 0x000350AD
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearTenSpinner/Minus");
					}
				}

				// Token: 0x17000389 RID: 905
				// (get) Token: 0x06000BEB RID: 3051 RVA: 0x00036EB9 File Offset: 0x000350B9
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearTenSpinner/Plus");
					}
				}
			}

			// Token: 0x020001F3 RID: 499
			public class YearOneSpinner_3
			{
				// Token: 0x1700038A RID: 906
				// (get) Token: 0x06000BED RID: 3053 RVA: 0x00036ECE File Offset: 0x000350CE
				public static GameObject SpinnerInput
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearOneSpinner/SpinnerInput");
					}
				}

				// Token: 0x1700038B RID: 907
				// (get) Token: 0x06000BEE RID: 3054 RVA: 0x00036EDA File Offset: 0x000350DA
				public static GameObject Minus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearOneSpinner/Minus");
					}
				}

				// Token: 0x1700038C RID: 908
				// (get) Token: 0x06000BEF RID: 3055 RVA: 0x00036EE6 File Offset: 0x000350E6
				public static GameObject Plus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/DatePopup/YearOneSpinner/Plus");
					}
				}
			}
		}

		// Token: 0x02000175 RID: 373
		public class EditPlaylistPopup_2
		{
			// Token: 0x170001AC RID: 428
			// (get) Token: 0x0600097C RID: 2428 RVA: 0x00034BEC File Offset: 0x00032DEC
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Darkness");
				}
			}

			// Token: 0x170001AD RID: 429
			// (get) Token: 0x0600097D RID: 2429 RVA: 0x00034BF8 File Offset: 0x00032DF8
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup");
				}
			}

			// Token: 0x020001F4 RID: 500
			public class Popup_3
			{
				// Token: 0x1700038D RID: 909
				// (get) Token: 0x06000BF1 RID: 3057 RVA: 0x00036EFB File Offset: 0x000350FB
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/BorderImage");
					}
				}

				// Token: 0x1700038E RID: 910
				// (get) Token: 0x06000BF2 RID: 3058 RVA: 0x00036F07 File Offset: 0x00035107
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Panel");
					}
				}

				// Token: 0x1700038F RID: 911
				// (get) Token: 0x06000BF3 RID: 3059 RVA: 0x00036F13 File Offset: 0x00035113
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/ExitButton");
					}
				}

				// Token: 0x17000390 RID: 912
				// (get) Token: 0x06000BF4 RID: 3060 RVA: 0x00036F1F File Offset: 0x0003511F
				public static GameObject EditPlaylistTitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/EditPlaylistTitleText");
					}
				}

				// Token: 0x17000391 RID: 913
				// (get) Token: 0x06000BF5 RID: 3061 RVA: 0x00036F2B File Offset: 0x0003512B
				public static GameObject InputFieldPlaylistTitle
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/InputFieldPlaylistTitle");
					}
				}

				// Token: 0x17000392 RID: 914
				// (get) Token: 0x06000BF6 RID: 3062 RVA: 0x00036F37 File Offset: 0x00035137
				public static GameObject PrivacyStatus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus");
					}
				}

				// Token: 0x17000393 RID: 915
				// (get) Token: 0x06000BF7 RID: 3063 RVA: 0x00036F43 File Offset: 0x00035143
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Buttons");
					}
				}

				// Token: 0x020002C8 RID: 712
				public class PrivacyStatus_4
				{
					// Token: 0x17000588 RID: 1416
					// (get) Token: 0x06000EC0 RID: 3776 RVA: 0x00038E33 File Offset: 0x00037033
					public static GameObject Public
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Public");
						}
					}

					// Token: 0x17000589 RID: 1417
					// (get) Token: 0x06000EC1 RID: 3777 RVA: 0x00038E3F File Offset: 0x0003703F
					public static GameObject Friends
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Friends");
						}
					}

					// Token: 0x1700058A RID: 1418
					// (get) Token: 0x06000EC2 RID: 3778 RVA: 0x00038E4B File Offset: 0x0003704B
					public static GameObject Private
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Private");
						}
					}

					// Token: 0x0200037F RID: 895
					public class Public_5
					{
						// Token: 0x170006B8 RID: 1720
						// (get) Token: 0x060010A7 RID: 4263 RVA: 0x0003A2E2 File Offset: 0x000384E2
						public static GameObject PrivacyIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Public/PrivacyIcon");
							}
						}

						// Token: 0x170006B9 RID: 1721
						// (get) Token: 0x060010A8 RID: 4264 RVA: 0x0003A2EE File Offset: 0x000384EE
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Public/Description");
							}
						}

						// Token: 0x170006BA RID: 1722
						// (get) Token: 0x060010A9 RID: 4265 RVA: 0x0003A2FA File Offset: 0x000384FA
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Public/Highlight");
							}
						}
					}

					// Token: 0x02000380 RID: 896
					public class Friends_5
					{
						// Token: 0x170006BB RID: 1723
						// (get) Token: 0x060010AB RID: 4267 RVA: 0x0003A30F File Offset: 0x0003850F
						public static GameObject PrivacyIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Friends/PrivacyIcon");
							}
						}

						// Token: 0x170006BC RID: 1724
						// (get) Token: 0x060010AC RID: 4268 RVA: 0x0003A31B File Offset: 0x0003851B
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Friends/Description");
							}
						}

						// Token: 0x170006BD RID: 1725
						// (get) Token: 0x060010AD RID: 4269 RVA: 0x0003A327 File Offset: 0x00038527
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Friends/Highlight");
							}
						}
					}

					// Token: 0x02000381 RID: 897
					public class Private_5
					{
						// Token: 0x170006BE RID: 1726
						// (get) Token: 0x060010AF RID: 4271 RVA: 0x0003A33C File Offset: 0x0003853C
						public static GameObject PrivacyIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Private/PrivacyIcon");
							}
						}

						// Token: 0x170006BF RID: 1727
						// (get) Token: 0x060010B0 RID: 4272 RVA: 0x0003A348 File Offset: 0x00038548
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Private/Description");
							}
						}

						// Token: 0x170006C0 RID: 1728
						// (get) Token: 0x060010B1 RID: 4273 RVA: 0x0003A354 File Offset: 0x00038554
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/PrivacyStatus/Private/Highlight");
							}
						}
					}
				}

				// Token: 0x020002C9 RID: 713
				public class Buttons_4
				{
					// Token: 0x1700058B RID: 1419
					// (get) Token: 0x06000EC4 RID: 3780 RVA: 0x00038E60 File Offset: 0x00037060
					public static GameObject ClearButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Buttons/ClearButton");
						}
					}

					// Token: 0x1700058C RID: 1420
					// (get) Token: 0x06000EC5 RID: 3781 RVA: 0x00038E6C File Offset: 0x0003706C
					public static GameObject UpdateButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Buttons/UpdateButton");
						}
					}

					// Token: 0x02000382 RID: 898
					public class ClearButton_5
					{
						// Token: 0x170006C1 RID: 1729
						// (get) Token: 0x060010B3 RID: 4275 RVA: 0x0003A369 File Offset: 0x00038569
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Buttons/ClearButton/Text");
							}
						}
					}

					// Token: 0x02000383 RID: 899
					public class UpdateButton_5
					{
						// Token: 0x170006C2 RID: 1730
						// (get) Token: 0x060010B5 RID: 4277 RVA: 0x0003A37E File Offset: 0x0003857E
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/EditPlaylistPopup/Popup/Buttons/UpdateButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000176 RID: 374
		public class LoadingPopup_2
		{
			// Token: 0x170001AE RID: 430
			// (get) Token: 0x0600097F RID: 2431 RVA: 0x00034C0D File Offset: 0x00032E0D
			public static GameObject ButtonMiddle
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ButtonMiddle");
				}
			}

			// Token: 0x170001AF RID: 431
			// (get) Token: 0x06000980 RID: 2432 RVA: 0x00034C19 File Offset: 0x00032E19
			public static GameObject LoadingSound
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/LoadingSound");
				}
			}

			// Token: 0x170001B0 RID: 432
			// (get) Token: 0x06000981 RID: 2433 RVA: 0x00034C25 File Offset: 0x00032E25
			public static GameObject ProgressPanel
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel");
				}
			}

			// Token: 0x170001B1 RID: 433
			// (get) Token: 0x06000982 RID: 2434 RVA: 0x00034C31 File Offset: 0x00032E31
			public static GameObject DElements
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements");
				}
			}

			// Token: 0x170001B2 RID: 434
			// (get) Token: 0x06000983 RID: 2435 RVA: 0x00034C3D File Offset: 0x00032E3D
			public static GameObject MirroredElements
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements");
				}
			}

			// Token: 0x020001F5 RID: 501
			public class ButtonMiddle_3
			{
				// Token: 0x17000394 RID: 916
				// (get) Token: 0x06000BF9 RID: 3065 RVA: 0x00036F58 File Offset: 0x00035158
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ButtonMiddle/Text");
					}
				}
			}

			// Token: 0x020001F6 RID: 502
			public class ProgressPanel_3
			{
				// Token: 0x17000395 RID: 917
				// (get) Token: 0x06000BFB RID: 3067 RVA: 0x00036F6D File Offset: 0x0003516D
				public static GameObject Parent_Loading_Progress
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress");
					}
				}

				// Token: 0x020002CA RID: 714
				public class Parent_Loading_Progress_4
				{
					// Token: 0x1700058D RID: 1421
					// (get) Token: 0x06000EC7 RID: 3783 RVA: 0x00038E81 File Offset: 0x00037081
					public static GameObject Panel_Backdrop
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop");
						}
					}

					// Token: 0x1700058E RID: 1422
					// (get) Token: 0x06000EC8 RID: 3784 RVA: 0x00038E8D File Offset: 0x0003708D
					public static GameObject Decoration_Left
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Left");
						}
					}

					// Token: 0x1700058F RID: 1423
					// (get) Token: 0x06000EC9 RID: 3785 RVA: 0x00038E99 File Offset: 0x00037099
					public static GameObject Decoration_Right
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Right");
						}
					}

					// Token: 0x17000590 RID: 1424
					// (get) Token: 0x06000ECA RID: 3786 RVA: 0x00038EA5 File Offset: 0x000370A5
					public static GameObject Loading_Elements
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements");
						}
					}

					// Token: 0x17000591 RID: 1425
					// (get) Token: 0x06000ECB RID: 3787 RVA: 0x00038EB1 File Offset: 0x000370B1
					public static GameObject GoButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/GoButton");
						}
					}

					// Token: 0x02000384 RID: 900
					public class Loading_Elements_5
					{
						// Token: 0x170006C3 RID: 1731
						// (get) Token: 0x060010B7 RID: 4279 RVA: 0x0003A393 File Offset: 0x00038593
						public static GameObject txt_LOADING
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/txt_LOADING");
							}
						}

						// Token: 0x170006C4 RID: 1732
						// (get) Token: 0x060010B8 RID: 4280 RVA: 0x0003A39F File Offset: 0x0003859F
						public static GameObject txt_Percent
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/txt_Percent");
							}
						}

						// Token: 0x170006C5 RID: 1733
						// (get) Token: 0x060010B9 RID: 4281 RVA: 0x0003A3AB File Offset: 0x000385AB
						public static GameObject txt_LOADING_Size
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/txt_LOADING_Size");
							}
						}

						// Token: 0x170006C6 RID: 1734
						// (get) Token: 0x060010BA RID: 4282 RVA: 0x0003A3B7 File Offset: 0x000385B7
						public static GameObject LOADING_BAR_BG
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/LOADING_BAR_BG");
							}
						}

						// Token: 0x170006C7 RID: 1735
						// (get) Token: 0x060010BB RID: 4283 RVA: 0x0003A3C3 File Offset: 0x000385C3
						public static GameObject LOADING_BAR
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/LOADING_BAR");
							}
						}
					}

					// Token: 0x02000385 RID: 901
					public class GoButton_5
					{
						// Token: 0x170006C8 RID: 1736
						// (get) Token: 0x060010BD RID: 4285 RVA: 0x0003A3D8 File Offset: 0x000385D8
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/GoButton/Text");
							}
						}
					}
				}
			}

			// Token: 0x020001F7 RID: 503
			public class DElements_3
			{
				// Token: 0x17000396 RID: 918
				// (get) Token: 0x06000BFD RID: 3069 RVA: 0x00036F82 File Offset: 0x00035182
				public static GameObject LoadingBackground_TealGradient
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient");
					}
				}

				// Token: 0x17000397 RID: 919
				// (get) Token: 0x06000BFE RID: 3070 RVA: 0x00036F8E File Offset: 0x0003518E
				public static GameObject LoadingInfoPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel");
					}
				}

				// Token: 0x020002CB RID: 715
				public class LoadingBackground_TealGradient_4
				{
					// Token: 0x17000592 RID: 1426
					// (get) Token: 0x06000ECD RID: 3789 RVA: 0x00038EC6 File Offset: 0x000370C6
					public static GameObject _FX_ParticleBubbles
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles");
						}
					}

					// Token: 0x17000593 RID: 1427
					// (get) Token: 0x06000ECE RID: 3790 RVA: 0x00038ED2 File Offset: 0x000370D2
					public static GameObject SkyCube_Baked
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/SkyCube_Baked");
						}
					}

					// Token: 0x17000594 RID: 1428
					// (get) Token: 0x06000ECF RID: 3791 RVA: 0x00038EDE File Offset: 0x000370DE
					public static GameObject _Lighting_1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)");
						}
					}

					// Token: 0x02000386 RID: 902
					public class _FX_ParticleBubbles_5
					{
						// Token: 0x170006C9 RID: 1737
						// (get) Token: 0x060010BF RID: 4287 RVA: 0x0003A3ED File Offset: 0x000385ED
						public static GameObject FX_snow
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow");
							}
						}

						// Token: 0x170006CA RID: 1738
						// (get) Token: 0x060010C0 RID: 4288 RVA: 0x0003A3F9 File Offset: 0x000385F9
						public static GameObject FX_floor
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_floor");
							}
						}

						// Token: 0x170006CB RID: 1739
						// (get) Token: 0x060010C1 RID: 4289 RVA: 0x0003A405 File Offset: 0x00038605
						public static GameObject FX_CloseParticles
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_CloseParticles");
							}
						}
					}

					// Token: 0x02000387 RID: 903
					public class _Lighting_1_5
					{
						// Token: 0x170006CC RID: 1740
						// (get) Token: 0x060010C3 RID: 4291 RVA: 0x0003A41A File Offset: 0x0003861A
						public static GameObject Reflection_Probe
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Reflection Probe");
							}
						}

						// Token: 0x170006CD RID: 1741
						// (get) Token: 0x060010C4 RID: 4292 RVA: 0x0003A426 File Offset: 0x00038626
						public static GameObject Point_light
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Point light");
							}
						}

						// Token: 0x170006CE RID: 1742
						// (get) Token: 0x060010C5 RID: 4293 RVA: 0x0003A432 File Offset: 0x00038632
						public static GameObject Light_Probe_Group
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Light Probe Group");
							}
						}
					}
				}

				// Token: 0x020002CC RID: 716
				public class LoadingInfoPanel_4
				{
					// Token: 0x17000595 RID: 1429
					// (get) Token: 0x06000ED1 RID: 3793 RVA: 0x00038EF3 File Offset: 0x000370F3
					public static GameObject InfoPanel_Template_ANIM
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM");
						}
					}

					// Token: 0x02000388 RID: 904
					public class InfoPanel_Template_ANIM_5
					{
						// Token: 0x170006CF RID: 1743
						// (get) Token: 0x060010C7 RID: 4295 RVA: 0x0003A447 File Offset: 0x00038647
						public static GameObject ICON
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/ICON");
							}
						}

						// Token: 0x170006D0 RID: 1744
						// (get) Token: 0x060010C8 RID: 4296 RVA: 0x0003A453 File Offset: 0x00038653
						public static GameObject SCREEN
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN");
							}
						}

						// Token: 0x170006D1 RID: 1745
						// (get) Token: 0x060010C9 RID: 4297 RVA: 0x0003A45F File Offset: 0x0003865F
						public static GameObject TITLE
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/TITLE");
							}
						}

						// Token: 0x170006D2 RID: 1746
						// (get) Token: 0x060010CA RID: 4298 RVA: 0x0003A46B File Offset: 0x0003866B
						public static GameObject LoadingSceen_2_Sstatic_colliders
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/LoadingSceen_2_Sstatic_colliders");
							}
						}
					}
				}
			}

			// Token: 0x020001F8 RID: 504
			public class MirroredElements_3
			{
				// Token: 0x17000398 RID: 920
				// (get) Token: 0x06000C00 RID: 3072 RVA: 0x00036FA3 File Offset: 0x000351A3
				public static GameObject ButtonMiddle_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ButtonMiddle (1)");
					}
				}

				// Token: 0x17000399 RID: 921
				// (get) Token: 0x06000C01 RID: 3073 RVA: 0x00036FAF File Offset: 0x000351AF
				public static GameObject ProgressPanel_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)");
					}
				}

				// Token: 0x1700039A RID: 922
				// (get) Token: 0x06000C02 RID: 3074 RVA: 0x00036FBB File Offset: 0x000351BB
				public static GameObject LoadingInfoPanel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel");
					}
				}

				// Token: 0x020002CD RID: 717
				public class ButtonMiddle_1_4
				{
					// Token: 0x17000596 RID: 1430
					// (get) Token: 0x06000ED3 RID: 3795 RVA: 0x00038F08 File Offset: 0x00037108
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ButtonMiddle (1)/Text");
						}
					}
				}

				// Token: 0x020002CE RID: 718
				public class ProgressPanel_1_4
				{
					// Token: 0x17000597 RID: 1431
					// (get) Token: 0x06000ED5 RID: 3797 RVA: 0x00038F1D File Offset: 0x0003711D
					public static GameObject Parent_Loading_Progress
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress");
						}
					}

					// Token: 0x02000389 RID: 905
					public class Parent_Loading_Progress_5
					{
						// Token: 0x170006D3 RID: 1747
						// (get) Token: 0x060010CC RID: 4300 RVA: 0x0003A480 File Offset: 0x00038680
						public static GameObject Panel_Backdrop
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress/Panel_Backdrop");
							}
						}

						// Token: 0x170006D4 RID: 1748
						// (get) Token: 0x060010CD RID: 4301 RVA: 0x0003A48C File Offset: 0x0003868C
						public static GameObject Decoration_Left
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress/Decoration_Left");
							}
						}

						// Token: 0x170006D5 RID: 1749
						// (get) Token: 0x060010CE RID: 4302 RVA: 0x0003A498 File Offset: 0x00038698
						public static GameObject Decoration_Right
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress/Decoration_Right");
							}
						}

						// Token: 0x170006D6 RID: 1750
						// (get) Token: 0x060010CF RID: 4303 RVA: 0x0003A4A4 File Offset: 0x000386A4
						public static GameObject Loading_Elements
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress/Loading Elements");
							}
						}

						// Token: 0x170006D7 RID: 1751
						// (get) Token: 0x060010D0 RID: 4304 RVA: 0x0003A4B0 File Offset: 0x000386B0
						public static GameObject GoButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/ProgressPanel (1)/Parent_Loading_Progress/GoButton");
							}
						}
					}
				}

				// Token: 0x020002CF RID: 719
				public class LoadingInfoPanel_4
				{
					// Token: 0x17000598 RID: 1432
					// (get) Token: 0x06000ED7 RID: 3799 RVA: 0x00038F32 File Offset: 0x00037132
					public static GameObject InfoPanel_Template_ANIM
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel/InfoPanel_Template_ANIM");
						}
					}

					// Token: 0x0200038A RID: 906
					public class InfoPanel_Template_ANIM_5
					{
						// Token: 0x170006D8 RID: 1752
						// (get) Token: 0x060010D2 RID: 4306 RVA: 0x0003A4C5 File Offset: 0x000386C5
						public static GameObject ICON
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel/InfoPanel_Template_ANIM/ICON");
							}
						}

						// Token: 0x170006D9 RID: 1753
						// (get) Token: 0x060010D3 RID: 4307 RVA: 0x0003A4D1 File Offset: 0x000386D1
						public static GameObject SCREEN
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN");
							}
						}

						// Token: 0x170006DA RID: 1754
						// (get) Token: 0x060010D4 RID: 4308 RVA: 0x0003A4DD File Offset: 0x000386DD
						public static GameObject TITLE
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel/InfoPanel_Template_ANIM/TITLE");
							}
						}

						// Token: 0x170006DB RID: 1755
						// (get) Token: 0x060010D5 RID: 4309 RVA: 0x0003A4E9 File Offset: 0x000386E9
						public static GameObject LoadingSceen_2_Sstatic_colliders
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/MirroredElements/LoadingInfoPanel/InfoPanel_Template_ANIM/LoadingSceen_2_Sstatic_colliders");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000177 RID: 375
		public class ReportWorldPopup_2
		{
			// Token: 0x170001B3 RID: 435
			// (get) Token: 0x06000985 RID: 2437 RVA: 0x00034C52 File Offset: 0x00032E52
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Darkness");
				}
			}

			// Token: 0x170001B4 RID: 436
			// (get) Token: 0x06000986 RID: 2438 RVA: 0x00034C5E File Offset: 0x00032E5E
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup");
				}
			}

			// Token: 0x020001F9 RID: 505
			public class Popup_3
			{
				// Token: 0x1700039B RID: 923
				// (get) Token: 0x06000C04 RID: 3076 RVA: 0x00036FD0 File Offset: 0x000351D0
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/BorderImage");
					}
				}

				// Token: 0x1700039C RID: 924
				// (get) Token: 0x06000C05 RID: 3077 RVA: 0x00036FDC File Offset: 0x000351DC
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Panel");
					}
				}

				// Token: 0x1700039D RID: 925
				// (get) Token: 0x06000C06 RID: 3078 RVA: 0x00036FE8 File Offset: 0x000351E8
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/TitleText");
					}
				}

				// Token: 0x1700039E RID: 926
				// (get) Token: 0x06000C07 RID: 3079 RVA: 0x00036FF4 File Offset: 0x000351F4
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/ExitButton");
					}
				}

				// Token: 0x1700039F RID: 927
				// (get) Token: 0x06000C08 RID: 3080 RVA: 0x00037000 File Offset: 0x00035200
				public static GameObject EmailText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/EmailText");
					}
				}

				// Token: 0x170003A0 RID: 928
				// (get) Token: 0x06000C09 RID: 3081 RVA: 0x0003700C File Offset: 0x0003520C
				public static GameObject Pages
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages");
					}
				}

				// Token: 0x020002D0 RID: 720
				public class Pages_4
				{
					// Token: 0x17000599 RID: 1433
					// (get) Token: 0x06000ED9 RID: 3801 RVA: 0x00038F47 File Offset: 0x00037147
					public static GameObject Page1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page1");
						}
					}

					// Token: 0x1700059A RID: 1434
					// (get) Token: 0x06000EDA RID: 3802 RVA: 0x00038F53 File Offset: 0x00037153
					public static GameObject Page2
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page2");
						}
					}

					// Token: 0x1700059B RID: 1435
					// (get) Token: 0x06000EDB RID: 3803 RVA: 0x00038F5F File Offset: 0x0003715F
					public static GameObject ThanksPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ThanksPage");
						}
					}

					// Token: 0x1700059C RID: 1436
					// (get) Token: 0x06000EDC RID: 3804 RVA: 0x00038F6B File Offset: 0x0003716B
					public static GameObject ErrorPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ErrorPage");
						}
					}

					// Token: 0x1700059D RID: 1437
					// (get) Token: 0x06000EDD RID: 3805 RVA: 0x00038F77 File Offset: 0x00037177
					public static GameObject ResetPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ResetPage");
						}
					}

					// Token: 0x0200038B RID: 907
					public class Page1_5
					{
						// Token: 0x170006DC RID: 1756
						// (get) Token: 0x060010D7 RID: 4311 RVA: 0x0003A4FE File Offset: 0x000386FE
						public static GameObject Checkboxes
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page1/Checkboxes");
							}
						}

						// Token: 0x170006DD RID: 1757
						// (get) Token: 0x060010D8 RID: 4312 RVA: 0x0003A50A File Offset: 0x0003870A
						public static GameObject NextButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page1/NextButton");
							}
						}

						// Token: 0x170006DE RID: 1758
						// (get) Token: 0x060010D9 RID: 4313 RVA: 0x0003A516 File Offset: 0x00038716
						public static GameObject WhereText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page1/WhereText");
							}
						}
					}

					// Token: 0x0200038C RID: 908
					public class Page2_5
					{
						// Token: 0x170006DF RID: 1759
						// (get) Token: 0x060010DB RID: 4315 RVA: 0x0003A52B File Offset: 0x0003872B
						public static GameObject Checkboxes
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page2/Checkboxes");
							}
						}

						// Token: 0x170006E0 RID: 1760
						// (get) Token: 0x060010DC RID: 4316 RVA: 0x0003A537 File Offset: 0x00038737
						public static GameObject SubmitButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page2/SubmitButton");
							}
						}

						// Token: 0x170006E1 RID: 1761
						// (get) Token: 0x060010DD RID: 4317 RVA: 0x0003A543 File Offset: 0x00038743
						public static GameObject WhereCategoryText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page2/WhereCategoryText");
							}
						}

						// Token: 0x170006E2 RID: 1762
						// (get) Token: 0x060010DE RID: 4318 RVA: 0x0003A54F File Offset: 0x0003874F
						public static GameObject WhyText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/Page2/WhyText");
							}
						}
					}

					// Token: 0x0200038D RID: 909
					public class ThanksPage_5
					{
						// Token: 0x170006E3 RID: 1763
						// (get) Token: 0x060010E0 RID: 4320 RVA: 0x0003A564 File Offset: 0x00038764
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ThanksPage/CloseButton");
							}
						}

						// Token: 0x170006E4 RID: 1764
						// (get) Token: 0x060010E1 RID: 4321 RVA: 0x0003A570 File Offset: 0x00038770
						public static GameObject ThanksText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ThanksPage/ThanksText");
							}
						}

						// Token: 0x170006E5 RID: 1765
						// (get) Token: 0x060010E2 RID: 4322 RVA: 0x0003A57C File Offset: 0x0003877C
						public static GameObject WarningText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ThanksPage/WarningText");
							}
						}
					}

					// Token: 0x0200038E RID: 910
					public class ErrorPage_5
					{
						// Token: 0x170006E6 RID: 1766
						// (get) Token: 0x060010E4 RID: 4324 RVA: 0x0003A591 File Offset: 0x00038791
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ErrorPage/CloseButton");
							}
						}

						// Token: 0x170006E7 RID: 1767
						// (get) Token: 0x060010E5 RID: 4325 RVA: 0x0003A59D File Offset: 0x0003879D
						public static GameObject ErrorText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ErrorPage/ErrorText");
							}
						}
					}

					// Token: 0x0200038F RID: 911
					public class ResetPage_5
					{
						// Token: 0x170006E8 RID: 1768
						// (get) Token: 0x060010E7 RID: 4327 RVA: 0x0003A5B2 File Offset: 0x000387B2
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ResetPage/CloseButton");
							}
						}

						// Token: 0x170006E9 RID: 1769
						// (get) Token: 0x060010E8 RID: 4328 RVA: 0x0003A5BE File Offset: 0x000387BE
						public static GameObject Reset_Report
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ResetPage/Reset Report");
							}
						}

						// Token: 0x170006EA RID: 1770
						// (get) Token: 0x060010E9 RID: 4329 RVA: 0x0003A5CA File Offset: 0x000387CA
						public static GameObject ResetText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportWorldPopup/Popup/Pages/ResetPage/ResetText");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000178 RID: 376
		public class RoomInfoPopup_2
		{
			// Token: 0x170001B5 RID: 437
			// (get) Token: 0x06000988 RID: 2440 RVA: 0x00034C73 File Offset: 0x00032E73
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Darkness");
				}
			}

			// Token: 0x170001B6 RID: 438
			// (get) Token: 0x06000989 RID: 2441 RVA: 0x00034C7F File Offset: 0x00032E7F
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup");
				}
			}

			// Token: 0x020001FA RID: 506
			public class Popup_3
			{
				// Token: 0x170003A1 RID: 929
				// (get) Token: 0x06000C0B RID: 3083 RVA: 0x00037021 File Offset: 0x00035221
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/BorderImage");
					}
				}

				// Token: 0x170003A2 RID: 930
				// (get) Token: 0x06000C0C RID: 3084 RVA: 0x0003702D File Offset: 0x0003522D
				public static GameObject RoomPicture
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/RoomPicture");
					}
				}

				// Token: 0x170003A3 RID: 931
				// (get) Token: 0x06000C0D RID: 3085 RVA: 0x00037039 File Offset: 0x00035239
				public static GameObject NameText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/NameText");
					}
				}

				// Token: 0x170003A4 RID: 932
				// (get) Token: 0x06000C0E RID: 3086 RVA: 0x00037045 File Offset: 0x00035245
				public static GameObject AuthorText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/AuthorText");
					}
				}

				// Token: 0x170003A5 RID: 933
				// (get) Token: 0x06000C0F RID: 3087 RVA: 0x00037051 File Offset: 0x00035251
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons");
					}
				}

				// Token: 0x170003A6 RID: 934
				// (get) Token: 0x06000C10 RID: 3088 RVA: 0x0003705D File Offset: 0x0003525D
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002D1 RID: 721
				public class RoomPicture_4
				{
					// Token: 0x1700059E RID: 1438
					// (get) Token: 0x06000EDF RID: 3807 RVA: 0x00038F8C File Offset: 0x0003718C
					public static GameObject RoomImage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/RoomPicture/RoomImage");
						}
					}

					// Token: 0x1700059F RID: 1439
					// (get) Token: 0x06000EE0 RID: 3808 RVA: 0x00038F98 File Offset: 0x00037198
					public static GameObject RoomBorder
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/RoomPicture/RoomBorder");
						}
					}
				}

				// Token: 0x020002D2 RID: 722
				public class Buttons_4
				{
					// Token: 0x170005A0 RID: 1440
					// (get) Token: 0x06000EE2 RID: 3810 RVA: 0x00038FAD File Offset: 0x000371AD
					public static GameObject PortalButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/PortalButton");
						}
					}

					// Token: 0x170005A1 RID: 1441
					// (get) Token: 0x06000EE3 RID: 3811 RVA: 0x00038FB9 File Offset: 0x000371B9
					public static GameObject JoinButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/JoinButton");
						}
					}

					// Token: 0x170005A2 RID: 1442
					// (get) Token: 0x06000EE4 RID: 3812 RVA: 0x00038FC5 File Offset: 0x000371C5
					public static GameObject CloseButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/CloseButton");
						}
					}

					// Token: 0x02000390 RID: 912
					public class PortalButton_5
					{
						// Token: 0x170006EB RID: 1771
						// (get) Token: 0x060010EB RID: 4331 RVA: 0x0003A5DF File Offset: 0x000387DF
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/PortalButton/Text");
							}
						}
					}

					// Token: 0x02000391 RID: 913
					public class JoinButton_5
					{
						// Token: 0x170006EC RID: 1772
						// (get) Token: 0x060010ED RID: 4333 RVA: 0x0003A5F4 File Offset: 0x000387F4
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/JoinButton/Text");
							}
						}
					}

					// Token: 0x02000392 RID: 914
					public class CloseButton_5
					{
						// Token: 0x170006ED RID: 1773
						// (get) Token: 0x060010EF RID: 4335 RVA: 0x0003A609 File Offset: 0x00038809
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInfoPopup/Popup/Buttons/CloseButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x02000179 RID: 377
		public class RoomInstancePopup_2
		{
			// Token: 0x170001B7 RID: 439
			// (get) Token: 0x0600098B RID: 2443 RVA: 0x00034C94 File Offset: 0x00032E94
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Darkness");
				}
			}

			// Token: 0x170001B8 RID: 440
			// (get) Token: 0x0600098C RID: 2444 RVA: 0x00034CA0 File Offset: 0x00032EA0
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup");
				}
			}

			// Token: 0x020001FB RID: 507
			public class Popup_3
			{
				// Token: 0x170003A7 RID: 935
				// (get) Token: 0x06000C12 RID: 3090 RVA: 0x00037072 File Offset: 0x00035272
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/BorderImage");
					}
				}

				// Token: 0x170003A8 RID: 936
				// (get) Token: 0x06000C13 RID: 3091 RVA: 0x0003707E File Offset: 0x0003527E
				public static GameObject BorderImage_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/BorderImage (1)");
					}
				}

				// Token: 0x170003A9 RID: 937
				// (get) Token: 0x06000C14 RID: 3092 RVA: 0x0003708A File Offset: 0x0003528A
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Panel");
					}
				}

				// Token: 0x170003AA RID: 938
				// (get) Token: 0x06000C15 RID: 3093 RVA: 0x00037096 File Offset: 0x00035296
				public static GameObject InstanceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/InstanceText");
					}
				}

				// Token: 0x170003AB RID: 939
				// (get) Token: 0x06000C16 RID: 3094 RVA: 0x000370A2 File Offset: 0x000352A2
				public static GameObject NameText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/NameText");
					}
				}

				// Token: 0x170003AC RID: 940
				// (get) Token: 0x06000C17 RID: 3095 RVA: 0x000370AE File Offset: 0x000352AE
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons");
					}
				}

				// Token: 0x170003AD RID: 941
				// (get) Token: 0x06000C18 RID: 3096 RVA: 0x000370BA File Offset: 0x000352BA
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002D3 RID: 723
				public class Buttons_4
				{
					// Token: 0x170005A3 RID: 1443
					// (get) Token: 0x06000EE6 RID: 3814 RVA: 0x00038FDA File Offset: 0x000371DA
					public static GameObject PublicButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/PublicButton");
						}
					}

					// Token: 0x170005A4 RID: 1444
					// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x00038FE6 File Offset: 0x000371E6
					public static GameObject FriendsOfGuestsButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOfGuestsButton");
						}
					}

					// Token: 0x170005A5 RID: 1445
					// (get) Token: 0x06000EE8 RID: 3816 RVA: 0x00038FF2 File Offset: 0x000371F2
					public static GameObject FriendsOnlyButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOnlyButton");
						}
					}

					// Token: 0x170005A6 RID: 1446
					// (get) Token: 0x06000EE9 RID: 3817 RVA: 0x00038FFE File Offset: 0x000371FE
					public static GameObject InvitePlusButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InvitePlusButton");
						}
					}

					// Token: 0x170005A7 RID: 1447
					// (get) Token: 0x06000EEA RID: 3818 RVA: 0x0003900A File Offset: 0x0003720A
					public static GameObject InviteOnlyButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InviteOnlyButton");
						}
					}

					// Token: 0x02000393 RID: 915
					public class PublicButton_5
					{
						// Token: 0x170006EE RID: 1774
						// (get) Token: 0x060010F1 RID: 4337 RVA: 0x0003A61E File Offset: 0x0003881E
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/PublicButton/Text");
							}
						}

						// Token: 0x170006EF RID: 1775
						// (get) Token: 0x060010F2 RID: 4338 RVA: 0x0003A62A File Offset: 0x0003882A
						public static GameObject PublicDescription
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/PublicButton/PublicDescription");
							}
						}
					}

					// Token: 0x02000394 RID: 916
					public class FriendsOfGuestsButton_5
					{
						// Token: 0x170006F0 RID: 1776
						// (get) Token: 0x060010F4 RID: 4340 RVA: 0x0003A63F File Offset: 0x0003883F
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOfGuestsButton/Text");
							}
						}

						// Token: 0x170006F1 RID: 1777
						// (get) Token: 0x060010F5 RID: 4341 RVA: 0x0003A64B File Offset: 0x0003884B
						public static GameObject FOGDescription
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOfGuestsButton/FOGDescription");
							}
						}
					}

					// Token: 0x02000395 RID: 917
					public class FriendsOnlyButton_5
					{
						// Token: 0x170006F2 RID: 1778
						// (get) Token: 0x060010F7 RID: 4343 RVA: 0x0003A660 File Offset: 0x00038860
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOnlyButton/Text");
							}
						}

						// Token: 0x170006F3 RID: 1779
						// (get) Token: 0x060010F8 RID: 4344 RVA: 0x0003A66C File Offset: 0x0003886C
						public static GameObject FriendsDescription
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/FriendsOnlyButton/FriendsDescription");
							}
						}
					}

					// Token: 0x02000396 RID: 918
					public class InvitePlusButton_5
					{
						// Token: 0x170006F4 RID: 1780
						// (get) Token: 0x060010FA RID: 4346 RVA: 0x0003A681 File Offset: 0x00038881
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InvitePlusButton/Text");
							}
						}

						// Token: 0x170006F5 RID: 1781
						// (get) Token: 0x060010FB RID: 4347 RVA: 0x0003A68D File Offset: 0x0003888D
						public static GameObject InviteDescription
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InvitePlusButton/InviteDescription");
							}
						}
					}

					// Token: 0x02000397 RID: 919
					public class InviteOnlyButton_5
					{
						// Token: 0x170006F6 RID: 1782
						// (get) Token: 0x060010FD RID: 4349 RVA: 0x0003A6A2 File Offset: 0x000388A2
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InviteOnlyButton/Text");
							}
						}

						// Token: 0x170006F7 RID: 1783
						// (get) Token: 0x060010FE RID: 4350 RVA: 0x0003A6AE File Offset: 0x000388AE
						public static GameObject InviteDescription
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RoomInstancePopup/Popup/Buttons/InviteOnlyButton/InviteDescription");
							}
						}
					}
				}
			}
		}

		// Token: 0x0200017A RID: 378
		public class SearchOptionsPopup_2
		{
			// Token: 0x170001B9 RID: 441
			// (get) Token: 0x0600098E RID: 2446 RVA: 0x00034CB5 File Offset: 0x00032EB5
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Darkness");
				}
			}

			// Token: 0x170001BA RID: 442
			// (get) Token: 0x0600098F RID: 2447 RVA: 0x00034CC1 File Offset: 0x00032EC1
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup");
				}
			}

			// Token: 0x020001FC RID: 508
			public class Popup_3
			{
				// Token: 0x170003AE RID: 942
				// (get) Token: 0x06000C1A RID: 3098 RVA: 0x000370CF File Offset: 0x000352CF
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/BorderImage");
					}
				}

				// Token: 0x170003AF RID: 943
				// (get) Token: 0x06000C1B RID: 3099 RVA: 0x000370DB File Offset: 0x000352DB
				public static GameObject Panel_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Panel (1)");
					}
				}

				// Token: 0x170003B0 RID: 944
				// (get) Token: 0x06000C1C RID: 3100 RVA: 0x000370E7 File Offset: 0x000352E7
				public static GameObject InstanceText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/InstanceText");
					}
				}

				// Token: 0x170003B1 RID: 945
				// (get) Token: 0x06000C1D RID: 3101 RVA: 0x000370F3 File Offset: 0x000352F3
				public static GameObject Checkboxes
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes");
					}
				}

				// Token: 0x170003B2 RID: 946
				// (get) Token: 0x06000C1E RID: 3102 RVA: 0x000370FF File Offset: 0x000352FF
				public static GameObject ConfirmButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/ConfirmButton");
					}
				}

				// Token: 0x170003B3 RID: 947
				// (get) Token: 0x06000C1F RID: 3103 RVA: 0x0003710B File Offset: 0x0003530B
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/ExitButton");
					}
				}

				// Token: 0x020002D4 RID: 724
				public class Checkboxes_4
				{
					// Token: 0x170005A8 RID: 1448
					// (get) Token: 0x06000EEC RID: 3820 RVA: 0x0003901F File Offset: 0x0003721F
					public static GameObject Tags
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Tags");
						}
					}

					// Token: 0x170005A9 RID: 1449
					// (get) Token: 0x06000EED RID: 3821 RVA: 0x0003902B File Offset: 0x0003722B
					public static GameObject Title
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Title");
						}
					}

					// Token: 0x02000398 RID: 920
					public class Tags_5
					{
						// Token: 0x170006F8 RID: 1784
						// (get) Token: 0x06001100 RID: 4352 RVA: 0x0003A6C3 File Offset: 0x000388C3
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Tags/Checkmark");
							}
						}

						// Token: 0x170006F9 RID: 1785
						// (get) Token: 0x06001101 RID: 4353 RVA: 0x0003A6CF File Offset: 0x000388CF
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Tags/Description");
							}
						}
					}

					// Token: 0x02000399 RID: 921
					public class Title_5
					{
						// Token: 0x170006FA RID: 1786
						// (get) Token: 0x06001103 RID: 4355 RVA: 0x0003A6E4 File Offset: 0x000388E4
						public static GameObject Checkmark
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Title/Checkmark");
							}
						}

						// Token: 0x170006FB RID: 1787
						// (get) Token: 0x06001104 RID: 4356 RVA: 0x0003A6F0 File Offset: 0x000388F0
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/Checkboxes/Title/Description");
							}
						}
					}
				}

				// Token: 0x020002D5 RID: 725
				public class ConfirmButton_4
				{
					// Token: 0x170005AA RID: 1450
					// (get) Token: 0x06000EEF RID: 3823 RVA: 0x00039040 File Offset: 0x00037240
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/SearchOptionsPopup/Popup/ConfirmButton/Text");
						}
					}
				}
			}
		}

		// Token: 0x0200017B RID: 379
		public class StandardPopup_2
		{
			// Token: 0x170001BB RID: 443
			// (get) Token: 0x06000991 RID: 2449 RVA: 0x00034CD6 File Offset: 0x00032ED6
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Darkness");
				}
			}

			// Token: 0x170001BC RID: 444
			// (get) Token: 0x06000992 RID: 2450 RVA: 0x00034CE2 File Offset: 0x00032EE2
			public static GameObject Rectangle
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/Rectangle");
				}
			}

			// Token: 0x170001BD RID: 445
			// (get) Token: 0x06000993 RID: 2451 RVA: 0x00034CEE File Offset: 0x00032EEE
			public static GameObject MidRing
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/MidRing");
				}
			}

			// Token: 0x170001BE RID: 446
			// (get) Token: 0x06000994 RID: 2452 RVA: 0x00034CFA File Offset: 0x00032EFA
			public static GameObject InnerDashRing
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/InnerDashRing");
				}
			}

			// Token: 0x170001BF RID: 447
			// (get) Token: 0x06000995 RID: 2453 RVA: 0x00034D06 File Offset: 0x00032F06
			public static GameObject RingGlow
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/RingGlow");
				}
			}

			// Token: 0x170001C0 RID: 448
			// (get) Token: 0x06000996 RID: 2454 RVA: 0x00034D12 File Offset: 0x00032F12
			public static GameObject TitleText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/TitleText");
				}
			}

			// Token: 0x170001C1 RID: 449
			// (get) Token: 0x06000997 RID: 2455 RVA: 0x00034D1E File Offset: 0x00032F1E
			public static GameObject BodyText
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/BodyText");
				}
			}

			// Token: 0x170001C2 RID: 450
			// (get) Token: 0x06000998 RID: 2456 RVA: 0x00034D2A File Offset: 0x00032F2A
			public static GameObject ArrowLeft
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ArrowLeft");
				}
			}

			// Token: 0x170001C3 RID: 451
			// (get) Token: 0x06000999 RID: 2457 RVA: 0x00034D36 File Offset: 0x00032F36
			public static GameObject ArrowRight
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ArrowRight");
				}
			}

			// Token: 0x170001C4 RID: 452
			// (get) Token: 0x0600099A RID: 2458 RVA: 0x00034D42 File Offset: 0x00032F42
			public static GameObject CornerBL
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/CornerBL");
				}
			}

			// Token: 0x170001C5 RID: 453
			// (get) Token: 0x0600099B RID: 2459 RVA: 0x00034D4E File Offset: 0x00032F4E
			public static GameObject CornerTL
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/CornerTL");
				}
			}

			// Token: 0x170001C6 RID: 454
			// (get) Token: 0x0600099C RID: 2460 RVA: 0x00034D5A File Offset: 0x00032F5A
			public static GameObject CornerBR
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/CornerBR");
				}
			}

			// Token: 0x170001C7 RID: 455
			// (get) Token: 0x0600099D RID: 2461 RVA: 0x00034D66 File Offset: 0x00032F66
			public static GameObject CornerTR
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/CornerTR");
				}
			}

			// Token: 0x170001C8 RID: 456
			// (get) Token: 0x0600099E RID: 2462 RVA: 0x00034D72 File Offset: 0x00032F72
			public static GameObject ProgressLine
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ProgressLine");
				}
			}

			// Token: 0x170001C9 RID: 457
			// (get) Token: 0x0600099F RID: 2463 RVA: 0x00034D7E File Offset: 0x00032F7E
			public static GameObject LowPercent
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/LowPercent");
				}
			}

			// Token: 0x170001CA RID: 458
			// (get) Token: 0x060009A0 RID: 2464 RVA: 0x00034D8A File Offset: 0x00032F8A
			public static GameObject HighPercent
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/HighPercent");
				}
			}

			// Token: 0x170001CB RID: 459
			// (get) Token: 0x060009A1 RID: 2465 RVA: 0x00034D96 File Offset: 0x00032F96
			public static GameObject ButtonLeft
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonLeft");
				}
			}

			// Token: 0x170001CC RID: 460
			// (get) Token: 0x060009A2 RID: 2466 RVA: 0x00034DA2 File Offset: 0x00032FA2
			public static GameObject ButtonMiddle
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonMiddle");
				}
			}

			// Token: 0x170001CD RID: 461
			// (get) Token: 0x060009A3 RID: 2467 RVA: 0x00034DAE File Offset: 0x00032FAE
			public static GameObject ButtonRight
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonRight");
				}
			}

			// Token: 0x020001FD RID: 509
			public class ButtonLeft_3
			{
				// Token: 0x170003B4 RID: 948
				// (get) Token: 0x06000C21 RID: 3105 RVA: 0x00037120 File Offset: 0x00035320
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonLeft/Text");
					}
				}
			}

			// Token: 0x020001FE RID: 510
			public class ButtonMiddle_3
			{
				// Token: 0x170003B5 RID: 949
				// (get) Token: 0x06000C23 RID: 3107 RVA: 0x00037135 File Offset: 0x00035335
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonMiddle/Text");
					}
				}
			}

			// Token: 0x020001FF RID: 511
			public class ButtonRight_3
			{
				// Token: 0x170003B6 RID: 950
				// (get) Token: 0x06000C25 RID: 3109 RVA: 0x0003714A File Offset: 0x0003534A
				public static GameObject Text
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopup/ButtonRight/Text");
					}
				}
			}
		}

		// Token: 0x0200017C RID: 380
		public class StandardPopupV2_2
		{
			// Token: 0x170001CE RID: 462
			// (get) Token: 0x060009A5 RID: 2469 RVA: 0x00034DC3 File Offset: 0x00032FC3
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Darkness");
				}
			}

			// Token: 0x170001CF RID: 463
			// (get) Token: 0x060009A6 RID: 2470 RVA: 0x00034DCF File Offset: 0x00032FCF
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup");
				}
			}

			// Token: 0x02000200 RID: 512
			public class Popup_3
			{
				// Token: 0x170003B7 RID: 951
				// (get) Token: 0x06000C27 RID: 3111 RVA: 0x0003715F File Offset: 0x0003535F
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/BorderImage");
					}
				}

				// Token: 0x170003B8 RID: 952
				// (get) Token: 0x06000C28 RID: 3112 RVA: 0x0003716B File Offset: 0x0003536B
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Panel");
					}
				}

				// Token: 0x170003B9 RID: 953
				// (get) Token: 0x06000C29 RID: 3113 RVA: 0x00037177 File Offset: 0x00035377
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/ExitButton");
					}
				}

				// Token: 0x170003BA RID: 954
				// (get) Token: 0x06000C2A RID: 3114 RVA: 0x00037183 File Offset: 0x00035383
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/TitleText");
					}
				}

				// Token: 0x170003BB RID: 955
				// (get) Token: 0x06000C2B RID: 3115 RVA: 0x0003718F File Offset: 0x0003538F
				public static GameObject InfoText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/InfoText");
					}
				}

				// Token: 0x170003BC RID: 956
				// (get) Token: 0x06000C2C RID: 3116 RVA: 0x0003719B File Offset: 0x0003539B
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons");
					}
				}

				// Token: 0x020002D6 RID: 726
				public class Buttons_4
				{
					// Token: 0x170005AB RID: 1451
					// (get) Token: 0x06000EF1 RID: 3825 RVA: 0x00039055 File Offset: 0x00037255
					public static GameObject LeftButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/LeftButton");
						}
					}

					// Token: 0x170005AC RID: 1452
					// (get) Token: 0x06000EF2 RID: 3826 RVA: 0x00039061 File Offset: 0x00037261
					public static GameObject MiddleButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/MiddleButton");
						}
					}

					// Token: 0x170005AD RID: 1453
					// (get) Token: 0x06000EF3 RID: 3827 RVA: 0x0003906D File Offset: 0x0003726D
					public static GameObject RightButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/RightButton");
						}
					}

					// Token: 0x0200039A RID: 922
					public class LeftButton_5
					{
						// Token: 0x170006FC RID: 1788
						// (get) Token: 0x06001106 RID: 4358 RVA: 0x0003A705 File Offset: 0x00038905
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/LeftButton/Text");
							}
						}
					}

					// Token: 0x0200039B RID: 923
					public class MiddleButton_5
					{
						// Token: 0x170006FD RID: 1789
						// (get) Token: 0x06001108 RID: 4360 RVA: 0x0003A71A File Offset: 0x0003891A
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/MiddleButton/Text");
							}
						}
					}

					// Token: 0x0200039C RID: 924
					public class RightButton_5
					{
						// Token: 0x170006FE RID: 1790
						// (get) Token: 0x0600110A RID: 4362 RVA: 0x0003A72F File Offset: 0x0003892F
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Buttons/RightButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x0200017D RID: 381
		public class ReportUserPopup_2
		{
			// Token: 0x170001D0 RID: 464
			// (get) Token: 0x060009A8 RID: 2472 RVA: 0x00034DE4 File Offset: 0x00032FE4
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Darkness");
				}
			}

			// Token: 0x170001D1 RID: 465
			// (get) Token: 0x060009A9 RID: 2473 RVA: 0x00034DF0 File Offset: 0x00032FF0
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup");
				}
			}

			// Token: 0x02000201 RID: 513
			public class Popup_3
			{
				// Token: 0x170003BD RID: 957
				// (get) Token: 0x06000C2E RID: 3118 RVA: 0x000371B0 File Offset: 0x000353B0
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/BorderImage");
					}
				}

				// Token: 0x170003BE RID: 958
				// (get) Token: 0x06000C2F RID: 3119 RVA: 0x000371BC File Offset: 0x000353BC
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Panel");
					}
				}

				// Token: 0x170003BF RID: 959
				// (get) Token: 0x06000C30 RID: 3120 RVA: 0x000371C8 File Offset: 0x000353C8
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/TitleText");
					}
				}

				// Token: 0x170003C0 RID: 960
				// (get) Token: 0x06000C31 RID: 3121 RVA: 0x000371D4 File Offset: 0x000353D4
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/ExitButton");
					}
				}

				// Token: 0x170003C1 RID: 961
				// (get) Token: 0x06000C32 RID: 3122 RVA: 0x000371E0 File Offset: 0x000353E0
				public static GameObject EmailText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/EmailText");
					}
				}

				// Token: 0x170003C2 RID: 962
				// (get) Token: 0x06000C33 RID: 3123 RVA: 0x000371EC File Offset: 0x000353EC
				public static GameObject Pages
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages");
					}
				}

				// Token: 0x020002D7 RID: 727
				public class Pages_4
				{
					// Token: 0x170005AE RID: 1454
					// (get) Token: 0x06000EF5 RID: 3829 RVA: 0x00039082 File Offset: 0x00037282
					public static GameObject Page1
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page1");
						}
					}

					// Token: 0x170005AF RID: 1455
					// (get) Token: 0x06000EF6 RID: 3830 RVA: 0x0003908E File Offset: 0x0003728E
					public static GameObject Page2
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page2");
						}
					}

					// Token: 0x170005B0 RID: 1456
					// (get) Token: 0x06000EF7 RID: 3831 RVA: 0x0003909A File Offset: 0x0003729A
					public static GameObject ThanksPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ThanksPage");
						}
					}

					// Token: 0x170005B1 RID: 1457
					// (get) Token: 0x06000EF8 RID: 3832 RVA: 0x000390A6 File Offset: 0x000372A6
					public static GameObject ErrorPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ErrorPage");
						}
					}

					// Token: 0x170005B2 RID: 1458
					// (get) Token: 0x06000EF9 RID: 3833 RVA: 0x000390B2 File Offset: 0x000372B2
					public static GameObject ResetPage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ResetPage");
						}
					}

					// Token: 0x0200039D RID: 925
					public class Page1_5
					{
						// Token: 0x170006FF RID: 1791
						// (get) Token: 0x0600110C RID: 4364 RVA: 0x0003A744 File Offset: 0x00038944
						public static GameObject Checkboxes
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page1/Checkboxes");
							}
						}

						// Token: 0x17000700 RID: 1792
						// (get) Token: 0x0600110D RID: 4365 RVA: 0x0003A750 File Offset: 0x00038950
						public static GameObject NextButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page1/NextButton");
							}
						}

						// Token: 0x17000701 RID: 1793
						// (get) Token: 0x0600110E RID: 4366 RVA: 0x0003A75C File Offset: 0x0003895C
						public static GameObject WhereText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page1/WhereText");
							}
						}
					}

					// Token: 0x0200039E RID: 926
					public class Page2_5
					{
						// Token: 0x17000702 RID: 1794
						// (get) Token: 0x06001110 RID: 4368 RVA: 0x0003A771 File Offset: 0x00038971
						public static GameObject Checkboxes
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page2/Checkboxes");
							}
						}

						// Token: 0x17000703 RID: 1795
						// (get) Token: 0x06001111 RID: 4369 RVA: 0x0003A77D File Offset: 0x0003897D
						public static GameObject SubmitButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page2/SubmitButton");
							}
						}

						// Token: 0x17000704 RID: 1796
						// (get) Token: 0x06001112 RID: 4370 RVA: 0x0003A789 File Offset: 0x00038989
						public static GameObject WhereCategoryText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page2/WhereCategoryText");
							}
						}

						// Token: 0x17000705 RID: 1797
						// (get) Token: 0x06001113 RID: 4371 RVA: 0x0003A795 File Offset: 0x00038995
						public static GameObject WhyText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/Page2/WhyText");
							}
						}
					}

					// Token: 0x0200039F RID: 927
					public class ThanksPage_5
					{
						// Token: 0x17000706 RID: 1798
						// (get) Token: 0x06001115 RID: 4373 RVA: 0x0003A7AA File Offset: 0x000389AA
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ThanksPage/CloseButton");
							}
						}

						// Token: 0x17000707 RID: 1799
						// (get) Token: 0x06001116 RID: 4374 RVA: 0x0003A7B6 File Offset: 0x000389B6
						public static GameObject ThanksText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ThanksPage/ThanksText");
							}
						}

						// Token: 0x17000708 RID: 1800
						// (get) Token: 0x06001117 RID: 4375 RVA: 0x0003A7C2 File Offset: 0x000389C2
						public static GameObject WarningText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ThanksPage/WarningText");
							}
						}
					}

					// Token: 0x020003A0 RID: 928
					public class ErrorPage_5
					{
						// Token: 0x17000709 RID: 1801
						// (get) Token: 0x06001119 RID: 4377 RVA: 0x0003A7D7 File Offset: 0x000389D7
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ErrorPage/CloseButton");
							}
						}

						// Token: 0x1700070A RID: 1802
						// (get) Token: 0x0600111A RID: 4378 RVA: 0x0003A7E3 File Offset: 0x000389E3
						public static GameObject ErrorText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ErrorPage/ErrorText");
							}
						}
					}

					// Token: 0x020003A1 RID: 929
					public class ResetPage_5
					{
						// Token: 0x1700070B RID: 1803
						// (get) Token: 0x0600111C RID: 4380 RVA: 0x0003A7F8 File Offset: 0x000389F8
						public static GameObject CloseButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ResetPage/CloseButton");
							}
						}

						// Token: 0x1700070C RID: 1804
						// (get) Token: 0x0600111D RID: 4381 RVA: 0x0003A804 File Offset: 0x00038A04
						public static GameObject ResetButton
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ResetPage/ResetButton");
							}
						}

						// Token: 0x1700070D RID: 1805
						// (get) Token: 0x0600111E RID: 4382 RVA: 0x0003A810 File Offset: 0x00038A10
						public static GameObject ResetText
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/ReportUserPopup/Popup/Pages/ResetPage/ResetText");
							}
						}
					}
				}
			}
		}

		// Token: 0x0200017E RID: 382
		public class UpdateStatusPopup_2
		{
			// Token: 0x170001D2 RID: 466
			// (get) Token: 0x060009AB RID: 2475 RVA: 0x00034E05 File Offset: 0x00033005
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Darkness");
				}
			}

			// Token: 0x170001D3 RID: 467
			// (get) Token: 0x060009AC RID: 2476 RVA: 0x00034E11 File Offset: 0x00033011
			public static GameObject Popup
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup");
				}
			}

			// Token: 0x02000202 RID: 514
			public class Popup_3
			{
				// Token: 0x170003C3 RID: 963
				// (get) Token: 0x06000C35 RID: 3125 RVA: 0x00037201 File Offset: 0x00035401
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/BorderImage");
					}
				}

				// Token: 0x170003C4 RID: 964
				// (get) Token: 0x06000C36 RID: 3126 RVA: 0x0003720D File Offset: 0x0003540D
				public static GameObject BorderImage_1
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/BorderImage (1)");
					}
				}

				// Token: 0x170003C5 RID: 965
				// (get) Token: 0x06000C37 RID: 3127 RVA: 0x00037219 File Offset: 0x00035419
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/Panel");
					}
				}

				// Token: 0x170003C6 RID: 966
				// (get) Token: 0x06000C38 RID: 3128 RVA: 0x00037225 File Offset: 0x00035425
				public static GameObject ExitButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/ExitButton");
					}
				}

				// Token: 0x170003C7 RID: 967
				// (get) Token: 0x06000C39 RID: 3129 RVA: 0x00037231 File Offset: 0x00035431
				public static GameObject StatusHistoryButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusHistoryButton");
					}
				}

				// Token: 0x170003C8 RID: 968
				// (get) Token: 0x06000C3A RID: 3130 RVA: 0x0003723D File Offset: 0x0003543D
				public static GameObject UpdateStatusTitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/UpdateStatusTitleText");
					}
				}

				// Token: 0x170003C9 RID: 969
				// (get) Token: 0x06000C3B RID: 3131 RVA: 0x00037249 File Offset: 0x00035449
				public static GameObject InputFieldStatus
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/InputFieldStatus");
					}
				}

				// Token: 0x170003CA RID: 970
				// (get) Token: 0x06000C3C RID: 3132 RVA: 0x00037255 File Offset: 0x00035455
				public static GameObject StatusSettings
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings");
					}
				}

				// Token: 0x170003CB RID: 971
				// (get) Token: 0x06000C3D RID: 3133 RVA: 0x00037261 File Offset: 0x00035461
				public static GameObject Buttons
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/Buttons");
					}
				}

				// Token: 0x020002D8 RID: 728
				public class StatusHistoryButton_4
				{
					// Token: 0x170005B3 RID: 1459
					// (get) Token: 0x06000EFB RID: 3835 RVA: 0x000390C7 File Offset: 0x000372C7
					public static GameObject Icon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusHistoryButton/Icon");
						}
					}

					// Token: 0x170005B4 RID: 1460
					// (get) Token: 0x06000EFC RID: 3836 RVA: 0x000390D3 File Offset: 0x000372D3
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusHistoryButton/Text");
						}
					}
				}

				// Token: 0x020002D9 RID: 729
				public class StatusSettings_4
				{
					// Token: 0x170005B5 RID: 1461
					// (get) Token: 0x06000EFE RID: 3838 RVA: 0x000390E8 File Offset: 0x000372E8
					public static GameObject JoinMeStatus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/JoinMeStatus");
						}
					}

					// Token: 0x170005B6 RID: 1462
					// (get) Token: 0x06000EFF RID: 3839 RVA: 0x000390F4 File Offset: 0x000372F4
					public static GameObject OnlineStatus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OnlineStatus");
						}
					}

					// Token: 0x170005B7 RID: 1463
					// (get) Token: 0x06000F00 RID: 3840 RVA: 0x00039100 File Offset: 0x00037300
					public static GameObject AskMeStatus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/AskMeStatus");
						}
					}

					// Token: 0x170005B8 RID: 1464
					// (get) Token: 0x06000F01 RID: 3841 RVA: 0x0003910C File Offset: 0x0003730C
					public static GameObject DoNotDisturbStatus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/DoNotDisturbStatus");
						}
					}

					// Token: 0x170005B9 RID: 1465
					// (get) Token: 0x06000F02 RID: 3842 RVA: 0x00039118 File Offset: 0x00037318
					public static GameObject OfflineStatus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OfflineStatus");
						}
					}

					// Token: 0x020003A2 RID: 930
					public class JoinMeStatus_5
					{
						// Token: 0x1700070E RID: 1806
						// (get) Token: 0x06001120 RID: 4384 RVA: 0x0003A825 File Offset: 0x00038A25
						public static GameObject StatusIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/JoinMeStatus/StatusIcon");
							}
						}

						// Token: 0x1700070F RID: 1807
						// (get) Token: 0x06001121 RID: 4385 RVA: 0x0003A831 File Offset: 0x00038A31
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/JoinMeStatus/Description");
							}
						}

						// Token: 0x17000710 RID: 1808
						// (get) Token: 0x06001122 RID: 4386 RVA: 0x0003A83D File Offset: 0x00038A3D
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/JoinMeStatus/Highlight");
							}
						}
					}

					// Token: 0x020003A3 RID: 931
					public class OnlineStatus_5
					{
						// Token: 0x17000711 RID: 1809
						// (get) Token: 0x06001124 RID: 4388 RVA: 0x0003A852 File Offset: 0x00038A52
						public static GameObject StatusIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OnlineStatus/StatusIcon");
							}
						}

						// Token: 0x17000712 RID: 1810
						// (get) Token: 0x06001125 RID: 4389 RVA: 0x0003A85E File Offset: 0x00038A5E
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OnlineStatus/Description");
							}
						}

						// Token: 0x17000713 RID: 1811
						// (get) Token: 0x06001126 RID: 4390 RVA: 0x0003A86A File Offset: 0x00038A6A
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OnlineStatus/Highlight");
							}
						}
					}

					// Token: 0x020003A4 RID: 932
					public class AskMeStatus_5
					{
						// Token: 0x17000714 RID: 1812
						// (get) Token: 0x06001128 RID: 4392 RVA: 0x0003A87F File Offset: 0x00038A7F
						public static GameObject StatusIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/AskMeStatus/StatusIcon");
							}
						}

						// Token: 0x17000715 RID: 1813
						// (get) Token: 0x06001129 RID: 4393 RVA: 0x0003A88B File Offset: 0x00038A8B
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/AskMeStatus/Description");
							}
						}

						// Token: 0x17000716 RID: 1814
						// (get) Token: 0x0600112A RID: 4394 RVA: 0x0003A897 File Offset: 0x00038A97
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/AskMeStatus/Highlight");
							}
						}
					}

					// Token: 0x020003A5 RID: 933
					public class DoNotDisturbStatus_5
					{
						// Token: 0x17000717 RID: 1815
						// (get) Token: 0x0600112C RID: 4396 RVA: 0x0003A8AC File Offset: 0x00038AAC
						public static GameObject StatusIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/DoNotDisturbStatus/StatusIcon");
							}
						}

						// Token: 0x17000718 RID: 1816
						// (get) Token: 0x0600112D RID: 4397 RVA: 0x0003A8B8 File Offset: 0x00038AB8
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/DoNotDisturbStatus/Description");
							}
						}

						// Token: 0x17000719 RID: 1817
						// (get) Token: 0x0600112E RID: 4398 RVA: 0x0003A8C4 File Offset: 0x00038AC4
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/DoNotDisturbStatus/Highlight");
							}
						}
					}

					// Token: 0x020003A6 RID: 934
					public class OfflineStatus_5
					{
						// Token: 0x1700071A RID: 1818
						// (get) Token: 0x06001130 RID: 4400 RVA: 0x0003A8D9 File Offset: 0x00038AD9
						public static GameObject StatusIcon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OfflineStatus/StatusIcon");
							}
						}

						// Token: 0x1700071B RID: 1819
						// (get) Token: 0x06001131 RID: 4401 RVA: 0x0003A8E5 File Offset: 0x00038AE5
						public static GameObject Description
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OfflineStatus/Description");
							}
						}

						// Token: 0x1700071C RID: 1820
						// (get) Token: 0x06001132 RID: 4402 RVA: 0x0003A8F1 File Offset: 0x00038AF1
						public static GameObject Highlight
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/StatusSettings/OfflineStatus/Highlight");
							}
						}
					}
				}

				// Token: 0x020002DA RID: 730
				public class Buttons_4
				{
					// Token: 0x170005BA RID: 1466
					// (get) Token: 0x06000F04 RID: 3844 RVA: 0x0003912D File Offset: 0x0003732D
					public static GameObject UpdateButton
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/Buttons/UpdateButton");
						}
					}

					// Token: 0x020003A7 RID: 935
					public class UpdateButton_5
					{
						// Token: 0x1700071D RID: 1821
						// (get) Token: 0x06001134 RID: 4404 RVA: 0x0003A906 File Offset: 0x00038B06
						public static GameObject Text
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/UpdateStatusPopup/Popup/Buttons/UpdateButton/Text");
							}
						}
					}
				}
			}
		}

		// Token: 0x0200017F RID: 383
		public class RequestInvitePopup_2
		{
			// Token: 0x170001D4 RID: 468
			// (get) Token: 0x060009AE RID: 2478 RVA: 0x00034E26 File Offset: 0x00033026
			public static GameObject Darkness
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/Darkness");
				}
			}

			// Token: 0x170001D5 RID: 469
			// (get) Token: 0x060009AF RID: 2479 RVA: 0x00034E32 File Offset: 0x00033032
			public static GameObject RequestInviteMenu
			{
				get
				{
					return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu");
				}
			}

			// Token: 0x02000203 RID: 515
			public class RequestInviteMenu_3
			{
				// Token: 0x170003CC RID: 972
				// (get) Token: 0x06000C3F RID: 3135 RVA: 0x00037276 File Offset: 0x00035476
				public static GameObject BorderImage
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/BorderImage");
					}
				}

				// Token: 0x170003CD RID: 973
				// (get) Token: 0x06000C40 RID: 3136 RVA: 0x00037282 File Offset: 0x00035482
				public static GameObject Panel
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/Panel");
					}
				}

				// Token: 0x170003CE RID: 974
				// (get) Token: 0x06000C41 RID: 3137 RVA: 0x0003728E File Offset: 0x0003548E
				public static GameObject TitleText
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/TitleText");
					}
				}

				// Token: 0x170003CF RID: 975
				// (get) Token: 0x06000C42 RID: 3138 RVA: 0x0003729A File Offset: 0x0003549A
				public static GameObject SubscribeToAddPhotosButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/SubscribeToAddPhotosButton");
					}
				}

				// Token: 0x170003D0 RID: 976
				// (get) Token: 0x06000C43 RID: 3139 RVA: 0x000372A6 File Offset: 0x000354A6
				public static GameObject AddPhotoOrImageAttachment
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment");
					}
				}

				// Token: 0x170003D1 RID: 977
				// (get) Token: 0x06000C44 RID: 3140 RVA: 0x000372B2 File Offset: 0x000354B2
				public static GameObject AddMessageButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddMessageButton");
					}
				}

				// Token: 0x170003D2 RID: 978
				// (get) Token: 0x06000C45 RID: 3141 RVA: 0x000372BE File Offset: 0x000354BE
				public static GameObject EditMessageButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/EditMessageButton");
					}
				}

				// Token: 0x170003D3 RID: 979
				// (get) Token: 0x06000C46 RID: 3142 RVA: 0x000372CA File Offset: 0x000354CA
				public static GameObject SendButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/SendButton");
					}
				}

				// Token: 0x170003D4 RID: 980
				// (get) Token: 0x06000C47 RID: 3143 RVA: 0x000372D6 File Offset: 0x000354D6
				public static GameObject CancelButton
				{
					get
					{
						return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/CancelButton");
					}
				}

				// Token: 0x020002DB RID: 731
				public class AddPhotoOrImageAttachment_4
				{
					// Token: 0x170005BB RID: 1467
					// (get) Token: 0x06000F06 RID: 3846 RVA: 0x00039142 File Offset: 0x00037342
					public static GameObject PhotoToAttach
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment/PhotoToAttach");
						}
					}

					// Token: 0x170005BC RID: 1468
					// (get) Token: 0x06000F07 RID: 3847 RVA: 0x0003914E File Offset: 0x0003734E
					public static GameObject AddPhotoBackground
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment/AddPhotoBackground");
						}
					}

					// Token: 0x170005BD RID: 1469
					// (get) Token: 0x06000F08 RID: 3848 RVA: 0x0003915A File Offset: 0x0003735A
					public static GameObject AddGalleryImageGroup
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment/AddGalleryImageGroup");
						}
					}

					// Token: 0x170005BE RID: 1470
					// (get) Token: 0x06000F09 RID: 3849 RVA: 0x00039166 File Offset: 0x00037366
					public static GameObject VRCPlus
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment/VRC+");
						}
					}

					// Token: 0x020003A8 RID: 936
					public class PhotoToAttach_5
					{
						// Token: 0x1700071E RID: 1822
						// (get) Token: 0x06001136 RID: 4406 RVA: 0x0003A91B File Offset: 0x00038B1B
						public static GameObject AddPhotoOrImageGroup
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddPhotoOrImageAttachment/PhotoToAttach/AddPhotoOrImageGroup");
							}
						}
					}
				}

				// Token: 0x020002DC RID: 732
				public class AddMessageButton_4
				{
					// Token: 0x170005BF RID: 1471
					// (get) Token: 0x06000F0B RID: 3851 RVA: 0x0003917B File Offset: 0x0003737B
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddMessageButton/Text");
						}
					}

					// Token: 0x170005C0 RID: 1472
					// (get) Token: 0x06000F0C RID: 3852 RVA: 0x00039187 File Offset: 0x00037387
					public static GameObject Icon_AddMessage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/AddMessageButton/Icon_AddMessage");
						}
					}
				}

				// Token: 0x020002DD RID: 733
				public class EditMessageButton_4
				{
					// Token: 0x170005C1 RID: 1473
					// (get) Token: 0x06000F0E RID: 3854 RVA: 0x0003919C File Offset: 0x0003739C
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/EditMessageButton/Text");
						}
					}

					// Token: 0x170005C2 RID: 1474
					// (get) Token: 0x06000F0F RID: 3855 RVA: 0x000391A8 File Offset: 0x000373A8
					public static GameObject Icon_EditMessage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/EditMessageButton/Icon_EditMessage");
						}
					}

					// Token: 0x170005C3 RID: 1475
					// (get) Token: 0x06000F10 RID: 3856 RVA: 0x000391B4 File Offset: 0x000373B4
					public static GameObject ClearSelectedMessage
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/EditMessageButton/ClearSelectedMessage");
						}
					}

					// Token: 0x020003A9 RID: 937
					public class ClearSelectedMessage_5
					{
						// Token: 0x1700071F RID: 1823
						// (get) Token: 0x06001138 RID: 4408 RVA: 0x0003A930 File Offset: 0x00038B30
						public static GameObject Icon
						{
							get
							{
								return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/EditMessageButton/ClearSelectedMessage/Icon");
							}
						}
					}
				}

				// Token: 0x020002DE RID: 734
				public class SendButton_4
				{
					// Token: 0x170005C4 RID: 1476
					// (get) Token: 0x06000F12 RID: 3858 RVA: 0x000391C9 File Offset: 0x000373C9
					public static GameObject Text
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/SendButton/Text");
						}
					}
				}

				// Token: 0x020002DF RID: 735
				public class CancelButton_4
				{
					// Token: 0x170005C5 RID: 1477
					// (get) Token: 0x06000F14 RID: 3860 RVA: 0x000391DE File Offset: 0x000373DE
					public static GameObject Icon
					{
						get
						{
							return GameObject.Find("/UserInterface/MenuContent/Popups/RequestInvitePopup/RequestInviteMenu/CancelButton/Icon");
						}
					}
				}
			}
		}
	}
}
