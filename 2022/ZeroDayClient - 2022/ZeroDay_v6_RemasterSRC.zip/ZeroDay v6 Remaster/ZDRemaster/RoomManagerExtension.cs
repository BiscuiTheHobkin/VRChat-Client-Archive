﻿using System;
using System.Linq;
using System.Reflection;
using VRC.Core;

// Token: 0x0200001C RID: 28
internal static class RoomManagerExtension
{
	// Token: 0x0600007F RID: 127 RVA: 0x00006F24 File Offset: 0x00005124
	public static bool IsInWorld()
	{
		return RoomManagerExtension.GetWorld() != null || RoomManagerExtension.GetWorldInstance() != null;
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00006F48 File Offset: 0x00005148
	public static ApiWorld GetWorld()
	{
		return RoomManager.field_Internal_Static_ApiWorld_0;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00006F60 File Offset: 0x00005160
	public static string GetWorldName()
	{
		return RoomManagerExtension.GetWorld().name;
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00006F7C File Offset: 0x0000517C
	public static ApiWorldInstance GetWorldInstance()
	{
		return RoomManager.field_Internal_Static_ApiWorldInstance_0;
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00006F94 File Offset: 0x00005194
	public static string GetInstanceID()
	{
		bool flag = RoomManagerExtension.IsInWorld();
		string result;
		if (flag)
		{
			result = RoomManagerExtension.GetWorld().id + ":" + RoomManagerExtension.GetWorldInstance().instanceId;
		}
		else
		{
			result = "No World";
		}
		return result;
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00006FD8 File Offset: 0x000051D8
	public static int GetWorldOccupants()
	{
		return RoomManagerExtension.GetWorld().occupants;
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00006FF4 File Offset: 0x000051F4
	public static int GetWorldCapacity()
	{
		return RoomManagerExtension.GetWorld().capacity;
	}

	// Token: 0x020000C2 RID: 194
	private static class WorldStuff2
	{
		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060004EE RID: 1262 RVA: 0x00024D34 File Offset: 0x00022F34
		internal static RoomManagerExtension.WorldStuff2.APIWorldDelegate ApiWorld
		{
			get
			{
				bool flag = RoomManagerExtension.WorldStuff2.APIWorld != null;
				RoomManagerExtension.WorldStuff2.APIWorldDelegate apiworld;
				if (flag)
				{
					apiworld = RoomManagerExtension.WorldStuff2.APIWorld;
				}
				else
				{
					MethodInfo method = typeof(RoomManager).GetMethods().First((MethodInfo x) => x.ReturnType == typeof(ApiWorldInstance));
					RoomManagerExtension.WorldStuff2.APIWorld = (RoomManagerExtension.WorldStuff2.APIWorldDelegate)Delegate.CreateDelegate(typeof(RoomManagerExtension.WorldStuff2.APIWorldDelegate), method);
					apiworld = RoomManagerExtension.WorldStuff2.APIWorld;
				}
				return apiworld;
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x00024DB0 File Offset: 0x00022FB0
		internal static RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate ApiWorldInstance
		{
			get
			{
				bool flag = RoomManagerExtension.WorldStuff2.APIWorldInstance != null;
				RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate apiworldInstance;
				if (flag)
				{
					apiworldInstance = RoomManagerExtension.WorldStuff2.APIWorldInstance;
				}
				else
				{
					MethodInfo method = typeof(RoomManager).GetMethods().First((MethodInfo x) => x.ReturnType == typeof(ApiWorldInstance));
					RoomManagerExtension.WorldStuff2.APIWorldInstance = (RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate)Delegate.CreateDelegate(typeof(RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate), method);
					apiworldInstance = RoomManagerExtension.WorldStuff2.APIWorldInstance;
				}
				return apiworldInstance;
			}
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x00024E2C File Offset: 0x0002302C
		internal static RoomManagerExtension.WorldStuff2.APIWorldDelegate GetWorld()
		{
			return RoomManagerExtension.WorldStuff2.APIWorld;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x00024E44 File Offset: 0x00023044
		internal static RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate GetWorldInstance()
		{
			return RoomManagerExtension.WorldStuff2.APIWorldInstance;
		}

		// Token: 0x04000371 RID: 881
		private static RoomManagerExtension.WorldStuff2.APIWorldDelegate APIWorld;

		// Token: 0x04000372 RID: 882
		private static RoomManagerExtension.WorldStuff2.APIWorldInstanceDelegate APIWorldInstance;

		// Token: 0x02000180 RID: 384
		// (Invoke) Token: 0x060009B2 RID: 2482
		internal delegate RoomManager APIWorldDelegate();

		// Token: 0x02000181 RID: 385
		// (Invoke) Token: 0x060009B6 RID: 2486
		internal delegate RoomManager APIWorldInstanceDelegate();
	}
}
