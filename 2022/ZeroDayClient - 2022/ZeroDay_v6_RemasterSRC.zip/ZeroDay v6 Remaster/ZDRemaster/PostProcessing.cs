﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

// Token: 0x02000011 RID: 17
internal class PostProcessing
{
	// Token: 0x0600003F RID: 63 RVA: 0x00004B80 File Offset: 0x00002D80
	public static void GrabWorldVolumes()
	{
		try
		{
			PostProcessing.OriginalVolumes = new List<PostProcessing.OriginalVolume>();
			foreach (PostProcessVolume postProcessVolume in Resources.FindObjectsOfTypeAll<PostProcessVolume>())
			{
				PostProcessing.OriginalVolumes.Add(new PostProcessing.OriginalVolume
				{
					postProcessVolume = postProcessVolume,
					defaultState = postProcessVolume.enabled
				});
			}
		}
		catch
		{
		}
	}

	// Token: 0x06000040 RID: 64 RVA: 0x00004C14 File Offset: 0x00002E14
	public static void TogglePostProcessing(bool Toggle)
	{
		try
		{
			if (Toggle)
			{
				foreach (PostProcessing.OriginalVolume originalVolume in PostProcessing.OriginalVolumes)
				{
					bool flag = originalVolume.postProcessVolume;
					if (flag)
					{
						originalVolume.postProcessVolume.enabled = true;
					}
				}
			}
			else
			{
				bool flag2 = PostProcessing.OriginalVolumes == null;
				if (!flag2)
				{
					foreach (PostProcessing.OriginalVolume originalVolume2 in PostProcessing.OriginalVolumes)
					{
						bool flag3 = originalVolume2.postProcessVolume;
						if (flag3)
						{
							originalVolume2.postProcessVolume.enabled = false;
						}
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x0400002B RID: 43
	public static List<PostProcessing.OriginalVolume> OriginalVolumes;

	// Token: 0x020000B5 RID: 181
	public struct OriginalVolume
	{
		// Token: 0x0400034C RID: 844
		public PostProcessVolume postProcessVolume;

		// Token: 0x0400034D RID: 845
		public bool defaultState;
	}
}
