﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

// Token: 0x02000025 RID: 37
public class ResourceManager
{
	// Token: 0x1700001B RID: 27
	// (get) Token: 0x060000D4 RID: 212 RVA: 0x00008898 File Offset: 0x00006A98
	// (set) Token: 0x060000D5 RID: 213 RVA: 0x0000889F File Offset: 0x00006A9F
	public static ResourceManager Instance { get; private set; }

	// Token: 0x060000D6 RID: 214 RVA: 0x000088A8 File Offset: 0x00006AA8
	public ResourceManager(Assembly ourAssembly, string resourcePath)
	{
		bool flag = ResourceManager.Instance != null;
		if (flag)
		{
			throw new Exception("ResourceManager already exists.");
		}
		ResourceManager.Instance = this;
		this._ourAssembly = ourAssembly;
		this._resourcePath = resourcePath;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00008900 File Offset: 0x00006B00
	public Texture2D GetTexture(string resourceName)
	{
		bool flag = this._textures.ContainsKey(resourceName);
		Texture2D result;
		if (flag)
		{
			result = this._textures[resourceName];
		}
		else
		{
			string text = this._resourcePath + "." + resourceName + ".png";
			Stream manifestResourceStream = this._ourAssembly.GetManifestResourceStream(text);
			bool flag2 = manifestResourceStream == null;
			if (flag2)
			{
				throw new ArgumentException("Resource \"" + text + "\" doesn't exist", "resourceName");
			}
			using (MemoryStream memoryStream = new MemoryStream())
			{
				manifestResourceStream.CopyTo(memoryStream);
				Texture2D texture2D = new Texture2D(1, 1);
				ImageConversion.LoadImage(texture2D, memoryStream.ToArray());
				texture2D.hideFlags |= 32;
				texture2D.wrapMode = 1;
				this._textures.Add(resourceName, texture2D);
				result = texture2D;
			}
		}
		return result;
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x000089F0 File Offset: 0x00006BF0
	public Sprite GetSprite(string resourceName)
	{
		bool flag = this._sprites.ContainsKey(resourceName);
		Sprite result;
		if (flag)
		{
			result = this._sprites[resourceName];
		}
		else
		{
			Texture2D texture = this.GetTexture(resourceName);
			Rect rect;
			rect..ctor(0f, 0f, (float)texture.width, (float)texture.height);
			Vector2 vector;
			vector..ctor(0.5f, 0.5f);
			Vector4 zero = Vector4.zero;
			Sprite sprite = Sprite.CreateSprite_Injected(texture, ref rect, ref vector, 100f, 0U, 1, ref zero, false);
			sprite.hideFlags |= 32;
			this._sprites.Add(resourceName, sprite);
			result = sprite;
		}
		return result;
	}

	// Token: 0x04000093 RID: 147
	private readonly Dictionary<string, Texture2D> _textures = new Dictionary<string, Texture2D>();

	// Token: 0x04000094 RID: 148
	private readonly Dictionary<string, Sprite> _sprites = new Dictionary<string, Sprite>();

	// Token: 0x04000095 RID: 149
	private readonly Assembly _ourAssembly;

	// Token: 0x04000096 RID: 150
	private readonly string _resourcePath;
}
