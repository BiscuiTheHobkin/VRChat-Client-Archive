﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

// Token: 0x02000027 RID: 39
internal class Config_World_Histoy
{
	// Token: 0x060000E2 RID: 226 RVA: 0x00008B04 File Offset: 0x00006D04
	internal void SaveConfig()
	{
		string contents = JsonConvert.SerializeObject(this, 1);
		File.WriteAllText("ZDRemastered/WORLD_HISTORY.json", contents);
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00008B28 File Offset: 0x00006D28
	internal static Config_World_Histoy Load()
	{
		bool flag = !File.Exists("ZDRemastered/WORLD_HISTORY.json");
		Config_World_Histoy result;
		if (flag)
		{
			result = new Config_World_Histoy();
		}
		else
		{
			Config_World_Histoy.Instance = JsonConvert.DeserializeObject<Config_World_Histoy>(File.ReadAllText("ZDRemastered/WORLD_HISTORY.json"));
			result = Config_World_Histoy.Instance;
		}
		return result;
	}

	// Token: 0x0400009C RID: 156
	public List<WorldObjects> WorldHist = new List<WorldObjects>();

	// Token: 0x0400009D RID: 157
	public static Config_World_Histoy Instance;
}
