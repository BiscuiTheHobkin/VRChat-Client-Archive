﻿using System;
using System.Collections;
using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using ZDBase;
using ZDBase.Utils.Wrappers;
using ZeroDayRemastered;

// Token: 0x02000016 RID: 22
public class DesktopHUD
{
	// Token: 0x0600005F RID: 95 RVA: 0x00005AA0 File Offset: 0x00003CA0
	public static IEnumerator Initialize()
	{
		Logs.Log("Initializing Desktop HUD", false);
		DesktopHUD.CanvasObject = new GameObject("EbolaCanvas");
		Object.DontDestroyOnLoad(DesktopHUD.CanvasObject);
		DesktopHUD.CanvasObject.AddComponent<Canvas>().renderMode = 0;
		DesktopHUD.CanvasObject.transform.position = Vector3.zero;
		DesktopHUD.scaler = DesktopHUD.CanvasObject.AddComponent<CanvasScaler>();
		DesktopHUD.scaler.uiScaleMode = 0;
		DesktopHUD.BackgroundObject = new GameObject("Background");
		DesktopHUD.BackgroundObject.AddComponent<CanvasRenderer>();
		DesktopHUD.BackgroundImage = DesktopHUD.BackgroundObject.AddComponent<Image>();
		DesktopHUD.BackgroundObject.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		DesktopHUD.BackgroundObject.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		DesktopHUD.BackgroundObject.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
		DesktopHUD.BackgroundObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, -5f);
		DesktopHUD.BackgroundObject.GetComponent<RectTransform>().sizeDelta = new Vector2(325f, 768f);
		DesktopHUD.BackgroundObject.transform.SetParent(DesktopHUD.CanvasObject.transform, false);
		DesktopHUD.BackgroundImage.sprite = null;
		DesktopHUD.BackgroundImage.color = new Color(0f, 0f, 0f, 0.4f);
		DesktopHUD.TextObject = new GameObject("Text");
		DesktopHUD.TextObject.AddComponent<CanvasRenderer>();
		DesktopHUD.TextObject.transform.SetParent(DesktopHUD.BackgroundObject.transform, false);
		DesktopHUD.TextText = DesktopHUD.TextObject.AddComponent<Text>();
		DesktopHUD.TextText.alignment = 0;
		DesktopHUD.TextText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
		DesktopHUD.TextText.fontSize = 15;
		DesktopHUD.TextText.text = "";
		DesktopHUD.LogoIconContainer = new GameObject("EbolaEngineHUD");
		DesktopHUD.LogoIconContainer.AddComponent<CanvasRenderer>();
		DesktopHUD.LogoIconContainer.transform.SetParent(DesktopHUD.BackgroundObject.transform, false);
		DesktopHUD.emmLogo = DesktopHUD.LogoIconContainer.AddComponent<Image>();
		DesktopHUD.emmLogo.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		DesktopHUD.emmLogo.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		DesktopHUD.emmLogo.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
		DesktopHUD.emmLogo.GetComponent<RectTransform>().anchoredPosition = new Vector2(10f, -2.5f);
		DesktopHUD.emmLogo.GetComponent<RectTransform>().localScale = new Vector3(0.58f, 0.58f, 0.58f);
		DesktopHUD.emmLogo.sprite = ZeroDayMain.MakeSpriteFromImage(ZeroDayMain.GetImageFromResources("Logo2"));
		DesktopHUD.TextObject.GetComponent<RectTransform>().sizeDelta = new Vector2(310f, 768f);
		DesktopHUD.TextObject.GetComponent<RectTransform>().localPosition += new Vector3(0f, 3f, 0f);
		DesktopHUD.CanvasObject.SetActive(true);
		DesktopHUD.Initialized = true;
		Logs.LogSuccess("Desktop HUD initialized fully.", false);
		MelonCoroutines.Start(DesktopHUD.Loop());
		return null;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00005E20 File Offset: 0x00004020
	private static IEnumerator Loop()
	{
		for (;;)
		{
			DesktopHUD.CanvasObject.SetActive(true);
			yield return new WaitForEndOfFrame();
			bool flag = !Input.GetKey(101);
			if (flag)
			{
				DesktopHUD.keyFlag = false;
			}
			bool flag2 = !DesktopHUD.TextText;
			if (!flag2)
			{
				string text = CommonHUD.RenderPlayerList();
				DesktopHUD.TextText.text = string.Concat(new string[]
				{
					"\n                  Ebola Engine                        fps: ",
					Mathf.Floor(1f / Time.deltaTime).ToString(),
					"\n                  \n\n\nUsers in room",
					(RoomManager.field_Internal_Static_ApiWorldInstance_0 != null) ? (" (" + PlayerManager.field_Private_Static_PlayerManager_0.field_Private_List_1_Player_0.Count.ToString() + ")") : "",
					":\n",
					text,
					"\n\nPosition in world:\n",
					CommonHUD.RenderWorldInfo(),
					"\n\n"
				});
				bool flag3 = APIUser.CurrentUser != null;
				if (flag3)
				{
					DesktopHUD.TextText.text = DesktopHUD.TextText.text.Replace(APIUser.CurrentUser.DisplayName(), null);
				}
				else
				{
					bool flag4 = !DesktopHUD.UIExpanded;
					if (flag4)
					{
						DesktopHUD.TextText.text = "\n                  Ebola Engine                        fps: " + Mathf.Floor(1f / Time.deltaTime).ToString() + "\n                  ";
					}
				}
				text = null;
			}
		}
		yield break;
	}

	// Token: 0x04000044 RID: 68
	private static GameObject CanvasObject;

	// Token: 0x04000045 RID: 69
	private static GameObject BackgroundObject;

	// Token: 0x04000046 RID: 70
	private static GameObject TextObject;

	// Token: 0x04000047 RID: 71
	private static GameObject LogoIconContainer;

	// Token: 0x04000048 RID: 72
	private static Image BackgroundImage;

	// Token: 0x04000049 RID: 73
	private static Image emmLogo;

	// Token: 0x0400004A RID: 74
	private static Text TextText;

	// Token: 0x0400004B RID: 75
	private static bool keyFlag;

	// Token: 0x0400004C RID: 76
	public static bool UIExpanded = false;

	// Token: 0x0400004D RID: 77
	public static bool Initialized = false;

	// Token: 0x0400004E RID: 78
	public static bool enabled = true;

	// Token: 0x0400004F RID: 79
	private static CanvasScaler scaler;
}
