﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000008 RID: 8
internal class DiscordRpc
{
	// Token: 0x0600000E RID: 14
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_Initialize")]
	public static extern void Initialize(string applicationId, ref DiscordRpc.EventHandlers handlers, bool autoRegister, string optionalSteamId);

	// Token: 0x0600000F RID: 15
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_Shutdown")]
	public static extern void Shutdown();

	// Token: 0x06000010 RID: 16
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_RunCallbacks")]
	public static extern void RunCallbacks();

	// Token: 0x06000011 RID: 17
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_UpdatePresence")]
	public static extern void UpdatePresence(ref DiscordRpc.RichPresence presence);

	// Token: 0x06000012 RID: 18
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_ClearPresence")]
	public static extern void ClearPresence();

	// Token: 0x06000013 RID: 19
	[DllImport("Dependencies/discord-rpc.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "Discord_Respond")]
	public static extern void Respond(string userId, DiscordRpc.Reply reply);

	// Token: 0x06000014 RID: 20 RVA: 0x00002600 File Offset: 0x00000800
	internal static bool YHnbXoZrZWNjkZxALQX()
	{
		return DiscordRpc.F1O7kEZvJ5YvxOu7IQ7 == null;
	}

	// Token: 0x06000015 RID: 21 RVA: 0x0000261C File Offset: 0x0000081C
	internal static DiscordRpc Yn1bPHZVDCaPFLlDbBI()
	{
		return DiscordRpc.F1O7kEZvJ5YvxOu7IQ7;
	}

	// Token: 0x04000004 RID: 4
	private static DiscordRpc F1O7kEZvJ5YvxOu7IQ7;

	// Token: 0x0200009E RID: 158
	public struct EventHandlers
	{
		// Token: 0x040002F3 RID: 755
		public DiscordRpc.ReadyCallback readyCallback;

		// Token: 0x040002F4 RID: 756
		public DiscordRpc.DisconnectedCallback disconnectedCallback;

		// Token: 0x040002F5 RID: 757
		public DiscordRpc.ErrorCallback errorCallback;

		// Token: 0x040002F6 RID: 758
		public DiscordRpc.JoinCallback joinCallback;

		// Token: 0x040002F7 RID: 759
		public DiscordRpc.SpectateCallback spectateCallback;

		// Token: 0x040002F8 RID: 760
		public DiscordRpc.RequestCallback requestCallback;
	}

	// Token: 0x0200009F RID: 159
	[Serializable]
	public struct RichPresence
	{
		// Token: 0x040002F9 RID: 761
		public string state;

		// Token: 0x040002FA RID: 762
		public string details;

		// Token: 0x040002FB RID: 763
		public long startTimestamp;

		// Token: 0x040002FC RID: 764
		public long endTimestamp;

		// Token: 0x040002FD RID: 765
		public string largeImageKey;

		// Token: 0x040002FE RID: 766
		public string largeImageText;

		// Token: 0x040002FF RID: 767
		public string smallImageKey;

		// Token: 0x04000300 RID: 768
		public string smallImageText;

		// Token: 0x04000301 RID: 769
		public string partyId;

		// Token: 0x04000302 RID: 770
		public int partySize;

		// Token: 0x04000303 RID: 771
		public int partyMax;

		// Token: 0x04000304 RID: 772
		public string matchSecret;

		// Token: 0x04000305 RID: 773
		public string joinSecret;

		// Token: 0x04000306 RID: 774
		public string spectateSecret;

		// Token: 0x04000307 RID: 775
		public bool instance;
	}

	// Token: 0x020000A0 RID: 160
	[Serializable]
	public struct JoinRequest
	{
		// Token: 0x04000308 RID: 776
		public string userId;

		// Token: 0x04000309 RID: 777
		public string username;

		// Token: 0x0400030A RID: 778
		public string discriminator;

		// Token: 0x0400030B RID: 779
		public string avatar;
	}

	// Token: 0x020000A1 RID: 161
	public enum Reply
	{
		// Token: 0x0400030D RID: 781
		No,
		// Token: 0x0400030E RID: 782
		Yes,
		// Token: 0x0400030F RID: 783
		Ignore
	}

	// Token: 0x020000A2 RID: 162
	// (Invoke) Token: 0x0600046F RID: 1135
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void ReadyCallback();

	// Token: 0x020000A3 RID: 163
	// (Invoke) Token: 0x06000473 RID: 1139
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void DisconnectedCallback(int errorCode, string message);

	// Token: 0x020000A4 RID: 164
	// (Invoke) Token: 0x06000477 RID: 1143
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void ErrorCallback(int errorCode, string message);

	// Token: 0x020000A5 RID: 165
	// (Invoke) Token: 0x0600047B RID: 1147
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void JoinCallback(string secret);

	// Token: 0x020000A6 RID: 166
	// (Invoke) Token: 0x0600047F RID: 1151
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void SpectateCallback(string secret);

	// Token: 0x020000A7 RID: 167
	// (Invoke) Token: 0x06000483 RID: 1155
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate void RequestCallback(ref DiscordRpc.JoinRequest request);
}
