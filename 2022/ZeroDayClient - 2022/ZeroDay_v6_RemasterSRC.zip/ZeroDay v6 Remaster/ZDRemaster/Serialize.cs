﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Il2CppSystem;
using Il2CppSystem.IO;
using Il2CppSystem.Runtime.Serialization.Formatters.Binary;
using UnhollowerBaseLib;
using UnityEngine;

// Token: 0x0200002B RID: 43
internal class Serialize
{
	// Token: 0x06000119 RID: 281 RVA: 0x0000A028 File Offset: 0x00008228
	internal static byte[] GetByteArray(int sizeInKb)
	{
		Random random = new Random();
		byte[] array = new byte[sizeInKb * 1024];
		random.NextBytes(array);
		return array;
	}

	// Token: 0x0600011A RID: 282 RVA: 0x0000A058 File Offset: 0x00008258
	internal static Object ByteArrayToObjectUnity2(byte[] arrBytes)
	{
		Il2CppStructArray<byte> il2CppStructArray = new Il2CppStructArray<byte>((long)arrBytes.Length);
		arrBytes.CopyTo(il2CppStructArray, 0);
		return new Object(new Object(il2CppStructArray.Pointer).Pointer);
	}

	// Token: 0x0600011B RID: 283 RVA: 0x0000A098 File Offset: 0x00008298
	internal static byte[] ToByteArray(Object obj)
	{
		bool flag = obj == null;
		byte[] result;
		if (flag)
		{
			result = null;
		}
		else
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			MemoryStream memoryStream = new MemoryStream();
			binaryFormatter.Serialize(memoryStream, obj);
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x0600011C RID: 284 RVA: 0x0000A0D8 File Offset: 0x000082D8
	internal static byte[] ToByteArray(object obj)
	{
		bool flag = obj == null;
		byte[] result;
		if (flag)
		{
			result = null;
		}
		else
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			MemoryStream memoryStream = new MemoryStream();
			binaryFormatter.Serialize(memoryStream, obj);
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x0600011D RID: 285 RVA: 0x0000A114 File Offset: 0x00008314
	internal static T FromByteArray<T>(byte[] data)
	{
		bool flag = data == null;
		T result;
		if (flag)
		{
			result = default(T);
		}
		else
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			using (MemoryStream memoryStream = new MemoryStream(data))
			{
				result = (T)((object)binaryFormatter.Deserialize(memoryStream));
			}
		}
		return result;
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000A174 File Offset: 0x00008374
	internal static T IL2CPPFromByteArray<T>(byte[] data)
	{
		bool flag = data == null;
		T result;
		if (flag)
		{
			result = default(T);
		}
		else
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			MemoryStream memoryStream = new MemoryStream(data);
			result = (T)((object)binaryFormatter.Deserialize(memoryStream));
		}
		return result;
	}

	// Token: 0x0600011F RID: 287 RVA: 0x0000A1BC File Offset: 0x000083BC
	internal static T FromIL2CPPToManaged<T>(Object obj)
	{
		return Serialize.FromByteArray<T>(Serialize.ToByteArray(obj));
	}

	// Token: 0x06000120 RID: 288 RVA: 0x0000A1DC File Offset: 0x000083DC
	internal static T FromManagedToIL2CPP<T>(object obj)
	{
		return Serialize.IL2CPPFromByteArray<T>(Serialize.ToByteArray(obj));
	}
}
