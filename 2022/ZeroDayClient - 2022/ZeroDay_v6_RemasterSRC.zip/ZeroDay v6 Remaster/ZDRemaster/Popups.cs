﻿using System;
using System.Linq;
using System.Reflection;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerRuntimeLib;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200002A RID: 42
internal class Popups
{
	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000113 RID: 275 RVA: 0x00009E80 File Offset: 0x00008080
	public static Popups.YesNoPopupDelegate GetYesNoPopupDelegate
	{
		get
		{
			bool flag = Popups.yesNoPopupDelegate != null;
			Popups.YesNoPopupDelegate result;
			if (flag)
			{
				result = Popups.yesNoPopupDelegate;
			}
			else
			{
				MethodInfo method = typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public).Single((MethodInfo m) => m.GetParameters().Length == 7 && Popups.XRefScanFor(m, "Popups/StandardPopupV2"));
				Popups.yesNoPopupDelegate = (Popups.YesNoPopupDelegate)Delegate.CreateDelegate(typeof(Popups.YesNoPopupDelegate), VRCUiPopupManager.field_Private_Static_VRCUiPopupManager_0, method);
				result = Popups.yesNoPopupDelegate;
			}
			return result;
		}
	}

	// Token: 0x06000114 RID: 276 RVA: 0x00009F04 File Offset: 0x00008104
	public static void PopupCall(string title, string confirm, string placeholder, bool IsNumpad, Action<string> OnAccept, Action OnCancel = null)
	{
		VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Method_Public_Void_String_String_InputType_Boolean_String_Action_3_String_List_1_KeyCode_Text_Action_String_Boolean_Action_1_VRCUiPopup_Boolean_Int32_0("ZeroDay", "", 0, IsNumpad, confirm, DelegateSupport.ConvertDelegate<Action<string, List<KeyCode>, Text>>(new Action<string, List<KeyCode>, Text>(delegate(string a, List<KeyCode> b, Text c)
		{
			Action<string> onAccept = OnAccept;
			if (onAccept != null)
			{
				onAccept(a);
			}
		})), DelegateSupport.ConvertDelegate<Action>(OnCancel), placeholder, true, null, false, 0);
	}

	// Token: 0x06000115 RID: 277 RVA: 0x00009F58 File Offset: 0x00008158
	public static void GameObjects()
	{
		GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Darkness").SetActive(false);
		GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/BorderImage").GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.1f);
		GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Panel").GetComponent<Image>().color = new Color(102f, 0f, 102f, 0.1f);
	}

	// Token: 0x06000116 RID: 278 RVA: 0x00009FD4 File Offset: 0x000081D4
	public static bool XRefScanFor(MethodBase methodBase, string searchTerm)
	{
		return XrefScanner.XrefScan(methodBase).Any(delegate(XrefInstance xref)
		{
			bool flag = xref.Type == 0;
			bool result;
			if (flag)
			{
				Object @object = xref.ReadAsObject();
				bool flag2 = @object == null;
				result = (!flag2 && @object.ToString().IndexOf(searchTerm, StringComparison.OrdinalIgnoreCase) >= 0);
			}
			else
			{
				result = false;
			}
			return result;
		});
	}

	// Token: 0x06000117 RID: 279 RVA: 0x0000A00A File Offset: 0x0000820A
	public static void CloseCurrentPopup()
	{
		VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
	}

	// Token: 0x040000AB RID: 171
	public static Popups.YesNoPopupDelegate yesNoPopupDelegate;

	// Token: 0x020000DD RID: 221
	// (Invoke) Token: 0x06000570 RID: 1392
	public delegate void YesNoPopupDelegate(string title, string text, string leftButtonText, Action leftButtonAction, string rightButtonText, Action rightButtonAction, Action<VRCUiPopup> additionalShit = null);
}
