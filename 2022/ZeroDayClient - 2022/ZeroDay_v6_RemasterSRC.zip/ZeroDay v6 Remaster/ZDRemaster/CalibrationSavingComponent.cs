﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using UnityEngine;
using ZDBase;
using ZDBase.Utils;

// Token: 0x02000006 RID: 6
internal class CalibrationSavingComponent
{
	// Token: 0x06000007 RID: 7 RVA: 0x00002104 File Offset: 0x00000304
	public static void PatchSteamTracking()
	{
		try
		{
			MethodInfo[] methods = typeof(VRCTrackingSteam).GetMethods();
			foreach (MethodInfo methodInfo in methods)
			{
				int num = methodInfo.GetParameters().Length;
				int num2 = num;
				if (num2 != 1)
				{
					if (num2 == 3)
					{
						bool flag = methodInfo.GetParameters().First<ParameterInfo>().ParameterType == typeof(Animator) && methodInfo.ReturnType == typeof(void) && methodInfo.GetRuntimeBaseDefinition() == methodInfo;
						if (flag)
						{
							Patches.Instance.Patch(methodInfo, null, Patches.GetPatch("PerformCalibration"), null, null, null);
						}
					}
				}
				else
				{
					bool flag2 = methodInfo.GetParameters().First<ParameterInfo>().ParameterType == typeof(string) && methodInfo.ReturnType == typeof(bool) && methodInfo.GetRuntimeBaseDefinition() == methodInfo;
					if (flag2)
					{
						Patches.Instance.Patch(methodInfo, Patches.GetPatch("IsCalibratedForAvatar"), null, null, null, null);
					}
				}
			}
		}
		catch (Exception)
		{
			Logs.LogWarn("Could not patch VRCTrackingSteam methods. CalibrationSaver won't work.", false);
		}
	}

	// Token: 0x06000008 RID: 8 RVA: 0x00002268 File Offset: 0x00000468
	private static void PerformCalibration(ref VRCTrackingSteam __instance, Animator __0, bool __1, bool __2)
	{
		Logs.LogSuccess("Saving Calibration...", true);
		bool flag = !MainConfigSettings.Instance.CalibrationSaverEnabled || __0 == null || __instance == null;
		if (!flag)
		{
			string id = VRCPlayer.field_Internal_Static_VRCPlayer_0._player.Method_Public_get_ApiAvatar_0().id;
			Logs.LogSuccess("Calibrating Avatar [" + id + "]", true);
			CalibrationSavingComponent._savedCalibrations[id] = new CalibrationSavingComponent.FbtCalibration
			{
				LeftFoot = new KeyValuePair<Vector3, Quaternion>(__instance.field_Public_Transform_10.localPosition, __instance.field_Public_Transform_10.localRotation),
				RightFoot = new KeyValuePair<Vector3, Quaternion>(__instance.field_Public_Transform_11.localPosition, __instance.field_Public_Transform_11.localRotation),
				Hip = new KeyValuePair<Vector3, Quaternion>(__instance.field_Public_Transform_12.localPosition, __instance.field_Public_Transform_12.localRotation)
			};
			try
			{
				File.WriteAllText("Azura\\calibrations.json", JsonConvert.SerializeObject(CalibrationSavingComponent._savedCalibrations, 1, new JsonSerializerSettings
				{
					ReferenceLoopHandling = 1,
					ContractResolver = new DynamicContractResolver(new List<string>
					{
						"normalized"
					})
				}));
			}
			catch (Exception arg)
			{
				Logs.LogError(string.Format("Could not save current calibration to file!\n {0}", arg), true);
			}
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000023C0 File Offset: 0x000005C0
	private static bool IsCalibratedForAvatar(ref VRCTrackingSteam __instance, ref bool __result, string __0)
	{
		bool flag = !MainConfigSettings.Instance.CalibrationSaverEnabled;
		bool result;
		if (flag)
		{
			result = true;
		}
		else
		{
			bool flag2 = __instance.field_Private_String_0 == null;
			if (flag2)
			{
				__result = false;
				result = true;
			}
			else
			{
				bool flag3 = CalibrationSavingComponent._savedCalibrations.ContainsKey(__0);
				if (flag3)
				{
					CalibrationSavingComponent.FbtCalibration fbtCalibration = CalibrationSavingComponent._savedCalibrations[__0];
					__instance.field_Public_Transform_10.localPosition = fbtCalibration.LeftFoot.Key;
					__instance.field_Public_Transform_10.localRotation = fbtCalibration.LeftFoot.Value;
					__instance.field_Public_Transform_11.localPosition = fbtCalibration.RightFoot.Key;
					__instance.field_Public_Transform_11.localRotation = fbtCalibration.RightFoot.Value;
					__instance.field_Public_Transform_12.localPosition = fbtCalibration.Hip.Key;
					__instance.field_Public_Transform_12.localRotation = fbtCalibration.Hip.Value;
					__result = true;
					result = false;
				}
				else
				{
					__result = true;
					result = false;
				}
			}
		}
		return result;
	}

	// Token: 0x04000003 RID: 3
	public static Dictionary<string, CalibrationSavingComponent.FbtCalibration> _savedCalibrations;

	// Token: 0x0200009D RID: 157
	internal class FbtCalibration
	{
		// Token: 0x040002F0 RID: 752
		public KeyValuePair<Vector3, Quaternion> Hip;

		// Token: 0x040002F1 RID: 753
		public KeyValuePair<Vector3, Quaternion> LeftFoot;

		// Token: 0x040002F2 RID: 754
		public KeyValuePair<Vector3, Quaternion> RightFoot;
	}
}
