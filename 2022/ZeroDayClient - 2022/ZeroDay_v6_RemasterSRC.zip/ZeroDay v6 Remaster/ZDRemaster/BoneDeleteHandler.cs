﻿using System;
using UnhollowerBaseLib;
using UnityEngine;

// Token: 0x02000005 RID: 5
internal class BoneDeleteHandler : MonoBehaviour
{
	// Token: 0x06000005 RID: 5 RVA: 0x00002092 File Offset: 0x00000292
	public BoneDeleteHandler(IntPtr ptr) : base(ptr)
	{
	}

	// Token: 0x06000006 RID: 6 RVA: 0x000020A0 File Offset: 0x000002A0
	private void OnDestroy()
	{
		foreach (DynamicBone dynamicBone in base.GetComponents<DynamicBone>())
		{
			SolverApi.DynamicBoneOnDestroyPatch(((Il2CppObjectBase)dynamicBone).Pointer);
		}
	}
}
